var background = (function() {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/define-background.mjs
	function defineBackground(arg) {
		if (arg == null || typeof arg === "function") return { main: arg };
		return arg;
	}
	//#endregion
	//#region src/entrypoints/service/streamParser.ts
	var import_browser_polyfill = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		(function(global, factory) {
			if (typeof define === "function" && define.amd) define("webextension-polyfill", ["module"], factory);
			else if (typeof exports !== "undefined") factory(module);
			else {
				var mod = { exports: {} };
				factory(mod);
				global.browser = mod.exports;
			}
		})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module$1) {
			"use strict";
			if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw new Error("This script should only be loaded in a browser extension.");
			if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
				const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
				const wrapAPIs = (extensionAPIs) => {
					const apiMetadata = {
						"alarms": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"clearAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"bookmarks": {
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getChildren": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getRecent": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getSubTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTree": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"browserAction": {
							"disable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"enable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"getBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getBadgeText": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"openPopup": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setBadgeText": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"browsingData": {
							"remove": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"removeCache": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCookies": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeDownloads": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFormData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeHistory": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeLocalStorage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePasswords": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePluginData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"settings": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"commands": { "getAll": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"contextMenus": {
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"cookies": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAllCookieStores": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"devtools": {
							"inspectedWindow": { "eval": {
								"minArgs": 1,
								"maxArgs": 2,
								"singleCallbackArg": false
							} },
							"panels": {
								"create": {
									"minArgs": 3,
									"maxArgs": 3,
									"singleCallbackArg": true
								},
								"elements": { "createSidebarPane": {
									"minArgs": 1,
									"maxArgs": 1
								} }
							}
						},
						"downloads": {
							"cancel": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"download": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"erase": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFileIcon": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"open": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"pause": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFile": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"resume": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"extension": {
							"isAllowedFileSchemeAccess": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"isAllowedIncognitoAccess": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"history": {
							"addUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"deleteRange": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getVisits": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"i18n": {
							"detectLanguage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAcceptLanguages": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"identity": { "launchWebAuthFlow": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"idle": { "queryState": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"management": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getSelf": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setEnabled": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"uninstallSelf": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"notifications": {
							"clear": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPermissionLevel": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"pageAction": {
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"hide": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"permissions": {
							"contains": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"request": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"runtime": {
							"getBackgroundPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPlatformInfo": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"openOptionsPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"requestUpdateCheck": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"sendMessage": {
								"minArgs": 1,
								"maxArgs": 3
							},
							"sendNativeMessage": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"setUninstallURL": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"sessions": {
							"getDevices": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getRecentlyClosed": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"restore": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"storage": {
							"local": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							},
							"managed": {
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								}
							},
							"sync": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							}
						},
						"tabs": {
							"captureVisibleTab": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"detectLanguage": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"discard": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"duplicate": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"executeScript": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getZoom": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getZoomSettings": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goBack": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goForward": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"highlight": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"insertCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"query": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"reload": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"sendMessage": {
								"minArgs": 2,
								"maxArgs": 3
							},
							"setZoom": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"setZoomSettings": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"update": {
								"minArgs": 1,
								"maxArgs": 2
							}
						},
						"topSites": { "get": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"webNavigation": {
							"getAllFrames": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFrame": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"webRequest": { "handlerBehaviorChanged": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"windows": {
							"create": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getLastFocused": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						}
					};
					if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
					/**
					* A WeakMap subclass which creates and stores a value for any key which does
					* not exist when accessed, but behaves exactly as an ordinary WeakMap
					* otherwise.
					*
					* @param {function} createItem
					*        A function which will be called in order to create the value for any
					*        key which does not exist, the first time it is accessed. The
					*        function receives, as its only argument, the key being created.
					*/
					class DefaultWeakMap extends WeakMap {
						constructor(createItem, items = void 0) {
							super(items);
							this.createItem = createItem;
						}
						get(key) {
							if (!this.has(key)) this.set(key, this.createItem(key));
							return super.get(key);
						}
					}
					/**
					* Returns true if the given object is an object with a `then` method, and can
					* therefore be assumed to behave as a Promise.
					*
					* @param {*} value The value to test.
					* @returns {boolean} True if the value is thenable.
					*/
					const isThenable = (value) => {
						return value && typeof value === "object" && typeof value.then === "function";
					};
					/**
					* Creates and returns a function which, when called, will resolve or reject
					* the given promise based on how it is called:
					*
					* - If, when called, `chrome.runtime.lastError` contains a non-null object,
					*   the promise is rejected with that value.
					* - If the function is called with exactly one argument, the promise is
					*   resolved to that value.
					* - Otherwise, the promise is resolved to an array containing all of the
					*   function's arguments.
					*
					* @param {object} promise
					*        An object containing the resolution and rejection functions of a
					*        promise.
					* @param {function} promise.resolve
					*        The promise's resolution function.
					* @param {function} promise.reject
					*        The promise's rejection function.
					* @param {object} metadata
					*        Metadata about the wrapped method which has created the callback.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function}
					*        The generated callback function.
					*/
					const makeCallback = (promise, metadata) => {
						return (...callbackArgs) => {
							if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
							else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
							else promise.resolve(callbackArgs);
						};
					};
					const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
					/**
					* Creates a wrapper function for a method with the given name and metadata.
					*
					* @param {string} name
					*        The name of the method which is being wrapped.
					* @param {object} metadata
					*        Metadata about the method being wrapped.
					* @param {integer} metadata.minArgs
					*        The minimum number of arguments which must be passed to the
					*        function. If called with fewer than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {integer} metadata.maxArgs
					*        The maximum number of arguments which may be passed to the
					*        function. If called with more than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function(object, ...*)}
					*       The generated wrapper function.
					*/
					const wrapAsyncFunction = (name, metadata) => {
						return function asyncFunctionWrapper(target, ...args) {
							if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
							if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
							return new Promise((resolve, reject) => {
								if (metadata.fallbackToNoCallback) try {
									target[name](...args, makeCallback({
										resolve,
										reject
									}, metadata));
								} catch (cbError) {
									console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
									target[name](...args);
									metadata.fallbackToNoCallback = false;
									metadata.noCallback = true;
									resolve();
								}
								else if (metadata.noCallback) {
									target[name](...args);
									resolve();
								} else target[name](...args, makeCallback({
									resolve,
									reject
								}, metadata));
							});
						};
					};
					/**
					* Wraps an existing method of the target object, so that calls to it are
					* intercepted by the given wrapper function. The wrapper function receives,
					* as its first argument, the original `target` object, followed by each of
					* the arguments passed to the original method.
					*
					* @param {object} target
					*        The original target object that the wrapped method belongs to.
					* @param {function} method
					*        The method being wrapped. This is used as the target of the Proxy
					*        object which is created to wrap the method.
					* @param {function} wrapper
					*        The wrapper function which is called in place of a direct invocation
					*        of the wrapped method.
					*
					* @returns {Proxy<function>}
					*        A Proxy object for the given method, which invokes the given wrapper
					*        method in its place.
					*/
					const wrapMethod = (target, method, wrapper) => {
						return new Proxy(method, { apply(targetMethod, thisObj, args) {
							return wrapper.call(thisObj, target, ...args);
						} });
					};
					let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
					/**
					* Wraps an object in a Proxy which intercepts and wraps certain methods
					* based on the given `wrappers` and `metadata` objects.
					*
					* @param {object} target
					*        The target object to wrap.
					*
					* @param {object} [wrappers = {}]
					*        An object tree containing wrapper functions for special cases. Any
					*        function present in this object tree is called in place of the
					*        method in the same location in the `target` object tree. These
					*        wrapper methods are invoked as described in {@see wrapMethod}.
					*
					* @param {object} [metadata = {}]
					*        An object tree containing metadata used to automatically generate
					*        Promise-based wrapper functions for asynchronous. Any function in
					*        the `target` object tree which has a corresponding metadata object
					*        in the same location in the `metadata` tree is replaced with an
					*        automatically-generated wrapper function, as described in
					*        {@see wrapAsyncFunction}
					*
					* @returns {Proxy<object>}
					*/
					const wrapObject = (target, wrappers = {}, metadata = {}) => {
						let cache = Object.create(null);
						return new Proxy(Object.create(target), {
							has(proxyTarget, prop) {
								return prop in target || prop in cache;
							},
							get(proxyTarget, prop, receiver) {
								if (prop in cache) return cache[prop];
								if (!(prop in target)) return;
								let value = target[prop];
								if (typeof value === "function") if (typeof wrappers[prop] === "function") value = wrapMethod(target, target[prop], wrappers[prop]);
								else if (hasOwnProperty(metadata, prop)) {
									let wrapper = wrapAsyncFunction(prop, metadata[prop]);
									value = wrapMethod(target, target[prop], wrapper);
								} else value = value.bind(target);
								else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) value = wrapObject(value, wrappers[prop], metadata[prop]);
								else if (hasOwnProperty(metadata, "*")) value = wrapObject(value, wrappers[prop], metadata["*"]);
								else {
									Object.defineProperty(cache, prop, {
										configurable: true,
										enumerable: true,
										get() {
											return target[prop];
										},
										set(value) {
											target[prop] = value;
										}
									});
									return value;
								}
								cache[prop] = value;
								return value;
							},
							set(proxyTarget, prop, value, receiver) {
								if (prop in cache) cache[prop] = value;
								else target[prop] = value;
								return true;
							},
							defineProperty(proxyTarget, prop, desc) {
								return Reflect.defineProperty(cache, prop, desc);
							},
							deleteProperty(proxyTarget, prop) {
								return Reflect.deleteProperty(cache, prop);
							}
						});
					};
					/**
					* Creates a set of wrapper functions for an event object, which handles
					* wrapping of listener functions that those messages are passed.
					*
					* A single wrapper is created for each listener function, and stored in a
					* map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
					* retrieve the original wrapper, so that  attempts to remove a
					* previously-added listener work as expected.
					*
					* @param {DefaultWeakMap<function, function>} wrapperMap
					*        A DefaultWeakMap object which will create the appropriate wrapper
					*        for a given listener function when one does not exist, and retrieve
					*        an existing one when it does.
					*
					* @returns {object}
					*/
					const wrapEvent = (wrapperMap) => ({
						addListener(target, listener, ...args) {
							target.addListener(wrapperMap.get(listener), ...args);
						},
						hasListener(target, listener) {
							return target.hasListener(wrapperMap.get(listener));
						},
						removeListener(target, listener) {
							target.removeListener(wrapperMap.get(listener));
						}
					});
					const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps an onRequestFinished listener function so that it will return a
						* `getContent()` property which returns a `Promise` rather than using a
						* callback API.
						*
						* @param {object} req
						*        The HAR entry object representing the network request.
						*/
						return function onRequestFinished(req) {
							listener(wrapObject(req, {}, { getContent: {
								minArgs: 0,
								maxArgs: 0
							} }));
						};
					});
					const onMessageWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps a message listener function so that it may send responses based on
						* its return value, rather than by returning a sentinel value and calling a
						* callback. If the listener function returns a Promise, the response is
						* sent when the promise either resolves or rejects.
						*
						* @param {*} message
						*        The message sent by the other end of the channel.
						* @param {object} sender
						*        Details about the sender of the message.
						* @param {function(*)} sendResponse
						*        A callback which, when called with an arbitrary argument, sends
						*        that value as a response.
						* @returns {boolean}
						*        True if the wrapped listener returned a Promise, which will later
						*        yield a response. False otherwise.
						*/
						return function onMessage(message, sender, sendResponse) {
							let didCallSendResponse = false;
							let wrappedSendResponse;
							let sendResponsePromise = new Promise((resolve) => {
								wrappedSendResponse = function(response) {
									didCallSendResponse = true;
									resolve(response);
								};
							});
							let result;
							try {
								result = listener(message, sender, wrappedSendResponse);
							} catch (err) {
								result = Promise.reject(err);
							}
							const isResultThenable = result !== true && isThenable(result);
							if (result !== true && !isResultThenable && !didCallSendResponse) return false;
							const sendPromisedResult = (promise) => {
								promise.then((msg) => {
									sendResponse(msg);
								}, (error) => {
									let message;
									if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
									else message = "An unexpected error occurred";
									sendResponse({
										__mozWebExtensionPolyfillReject__: true,
										message
									});
								}).catch((err) => {
									console.error("Failed to send onMessage rejected reply", err);
								});
							};
							if (isResultThenable) sendPromisedResult(result);
							else sendPromisedResult(sendResponsePromise);
							return true;
						};
					});
					const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
						if (extensionAPIs.runtime.lastError) if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
						else reject(new Error(extensionAPIs.runtime.lastError.message));
						else if (reply && reply.__mozWebExtensionPolyfillReject__) reject(new Error(reply.message));
						else resolve(reply);
					};
					const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
						if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
						if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
						return new Promise((resolve, reject) => {
							const wrappedCb = wrappedSendMessageCallback.bind(null, {
								resolve,
								reject
							});
							args.push(wrappedCb);
							apiNamespaceObj.sendMessage(...args);
						});
					};
					const staticWrappers = {
						devtools: { network: { onRequestFinished: wrapEvent(onRequestFinishedWrappers) } },
						runtime: {
							onMessage: wrapEvent(onMessageWrappers),
							onMessageExternal: wrapEvent(onMessageWrappers),
							sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
								minArgs: 1,
								maxArgs: 3
							})
						},
						tabs: { sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
							minArgs: 2,
							maxArgs: 3
						}) }
					};
					const settingMetadata = {
						clear: {
							minArgs: 1,
							maxArgs: 1
						},
						get: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					};
					apiMetadata.privacy = {
						network: { "*": settingMetadata },
						services: { "*": settingMetadata },
						websites: { "*": settingMetadata }
					};
					return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
				};
				module$1.exports = wrapAPIs(chrome);
			} else module$1.exports = globalThis.browser;
		});
	})))(), 1);
	function parseSSELine(line) {
		const trimmed = line.trim();
		if (!trimmed || !trimmed.startsWith("data: ")) return null;
		const data = trimmed.slice(6);
		if (data === "[DONE]") return null;
		return { data };
	}
	function extractDeltaContent(data) {
		try {
			return JSON.parse(data).choices?.[0]?.delta?.content || null;
		} catch {
			return null;
		}
	}
	async function* parseSSEStream(reader) {
		const decoder = new TextDecoder();
		let buffer = "";
		try {
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buffer += decoder.decode(value, { stream: true });
				const lines = buffer.split("\n");
				buffer = lines.pop() || "";
				for (const line of lines) {
					const event = parseSSELine(line);
					if (!event) continue;
					const delta = extractDeltaContent(event.data);
					if (delta) yield delta;
				}
			}
		} finally {
			reader.releaseLock();
		}
	}
	//#endregion
	//#region node_modules/.pnpm/@wxt-dev+browser@0.1.42/node_modules/@wxt-dev/browser/src/index.mjs
	var browser$2 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
	//#endregion
	//#region node_modules/.pnpm/async-mutex@0.5.0/node_modules/async-mutex/index.mjs
	var E_CANCELED = /* @__PURE__ */ new Error("request for lock canceled");
	var __awaiter$2 = function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	var Semaphore = class {
		constructor(_value, _cancelError = E_CANCELED) {
			this._value = _value;
			this._cancelError = _cancelError;
			this._queue = [];
			this._weightedWaiters = [];
		}
		acquire(weight = 1, priority = 0) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			return new Promise((resolve, reject) => {
				const task = {
					resolve,
					reject,
					weight,
					priority
				};
				const i = findIndexFromEnd(this._queue, (other) => priority <= other.priority);
				if (i === -1 && weight <= this._value) this._dispatchItem(task);
				else this._queue.splice(i + 1, 0, task);
			});
		}
		runExclusive(callback_1) {
			return __awaiter$2(this, arguments, void 0, function* (callback, weight = 1, priority = 0) {
				const [value, release] = yield this.acquire(weight, priority);
				try {
					return yield callback(value);
				} finally {
					release();
				}
			});
		}
		waitForUnlock(weight = 1, priority = 0) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			if (this._couldLockImmediately(weight, priority)) return Promise.resolve();
			else return new Promise((resolve) => {
				if (!this._weightedWaiters[weight - 1]) this._weightedWaiters[weight - 1] = [];
				insertSorted(this._weightedWaiters[weight - 1], {
					resolve,
					priority
				});
			});
		}
		isLocked() {
			return this._value <= 0;
		}
		getValue() {
			return this._value;
		}
		setValue(value) {
			this._value = value;
			this._dispatchQueue();
		}
		release(weight = 1) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			this._value += weight;
			this._dispatchQueue();
		}
		cancel() {
			this._queue.forEach((entry) => entry.reject(this._cancelError));
			this._queue = [];
		}
		_dispatchQueue() {
			this._drainUnlockWaiters();
			while (this._queue.length > 0 && this._queue[0].weight <= this._value) {
				this._dispatchItem(this._queue.shift());
				this._drainUnlockWaiters();
			}
		}
		_dispatchItem(item) {
			const previousValue = this._value;
			this._value -= item.weight;
			item.resolve([previousValue, this._newReleaser(item.weight)]);
		}
		_newReleaser(weight) {
			let called = false;
			return () => {
				if (called) return;
				called = true;
				this.release(weight);
			};
		}
		_drainUnlockWaiters() {
			if (this._queue.length === 0) for (let weight = this._value; weight > 0; weight--) {
				const waiters = this._weightedWaiters[weight - 1];
				if (!waiters) continue;
				waiters.forEach((waiter) => waiter.resolve());
				this._weightedWaiters[weight - 1] = [];
			}
			else {
				const queuedPriority = this._queue[0].priority;
				for (let weight = this._value; weight > 0; weight--) {
					const waiters = this._weightedWaiters[weight - 1];
					if (!waiters) continue;
					const i = waiters.findIndex((waiter) => waiter.priority <= queuedPriority);
					(i === -1 ? waiters : waiters.splice(0, i)).forEach(((waiter) => waiter.resolve()));
				}
			}
		}
		_couldLockImmediately(weight, priority) {
			return (this._queue.length === 0 || this._queue[0].priority < priority) && weight <= this._value;
		}
	};
	function insertSorted(a, v) {
		const i = findIndexFromEnd(a, (other) => v.priority <= other.priority);
		a.splice(i + 1, 0, v);
	}
	function findIndexFromEnd(a, predicate) {
		for (let i = a.length - 1; i >= 0; i--) if (predicate(a[i])) return i;
		return -1;
	}
	var __awaiter$1 = function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	var Mutex = class {
		constructor(cancelError) {
			this._semaphore = new Semaphore(1, cancelError);
		}
		acquire() {
			return __awaiter$1(this, arguments, void 0, function* (priority = 0) {
				const [, releaser] = yield this._semaphore.acquire(1, priority);
				return releaser;
			});
		}
		runExclusive(callback, priority = 0) {
			return this._semaphore.runExclusive(() => callback(), 1, priority);
		}
		isLocked() {
			return this._semaphore.isLocked();
		}
		waitForUnlock(priority = 0) {
			return this._semaphore.waitForUnlock(1, priority);
		}
		release() {
			if (this._semaphore.isLocked()) this._semaphore.release();
		}
		cancel() {
			return this._semaphore.cancel();
		}
	};
	//#endregion
	//#region node_modules/.pnpm/dequal@2.0.3/node_modules/dequal/lite/index.mjs
	var has = Object.prototype.hasOwnProperty;
	function dequal(foo, bar) {
		var ctor, len;
		if (foo === bar) return true;
		if (foo && bar && (ctor = foo.constructor) === bar.constructor) {
			if (ctor === Date) return foo.getTime() === bar.getTime();
			if (ctor === RegExp) return foo.toString() === bar.toString();
			if (ctor === Array) {
				if ((len = foo.length) === bar.length) while (len-- && dequal(foo[len], bar[len]));
				return len === -1;
			}
			if (!ctor || typeof foo === "object") {
				len = 0;
				for (ctor in foo) {
					if (has.call(foo, ctor) && ++len && !has.call(bar, ctor)) return false;
					if (!(ctor in bar) || !dequal(foo[ctor], bar[ctor])) return false;
				}
				return Object.keys(bar).length === len;
			}
		}
		return foo !== foo && bar !== bar;
	}
	//#endregion
	//#region node_modules/.pnpm/@wxt-dev+storage@1.2.8/node_modules/@wxt-dev/storage/dist/index.mjs
	/**
	* Simplified storage APIs with support for versioned fields, snapshots, metadata, and item definitions.
	*
	* See [the guide](https://wxt.dev/storage.html) for more information.
	* @module @wxt-dev/storage
	*/
	var storage = createStorage();
	function createStorage() {
		const drivers = {
			local: createDriver("local"),
			session: createDriver("session"),
			sync: createDriver("sync"),
			managed: createDriver("managed")
		};
		const getDriver = (area) => {
			const driver = drivers[area];
			if (driver == null) {
				const areaNames = Object.keys(drivers).join(", ");
				throw Error(`Invalid area "${area}". Options: ${areaNames}`);
			}
			return driver;
		};
		const resolveKey = (key) => {
			const deliminatorIndex = key.indexOf(":");
			const driverArea = key.substring(0, deliminatorIndex);
			const driverKey = key.substring(deliminatorIndex + 1);
			if (driverKey == null) throw Error(`Storage key should be in the form of "area:key", but received "${key}"`);
			return {
				driverArea,
				driverKey,
				driver: getDriver(driverArea)
			};
		};
		const getMetaKey = (key) => key + "$";
		const mergeMeta = (oldMeta, newMeta) => {
			const newFields = { ...oldMeta };
			Object.entries(newMeta).forEach(([key, value]) => {
				if (value == null) delete newFields[key];
				else newFields[key] = value;
			});
			return newFields;
		};
		const getValueOrFallback = (value, fallback) => value ?? fallback ?? null;
		const getMetaValue = (properties) => typeof properties === "object" && !Array.isArray(properties) ? properties : {};
		const getItem = async (driver, driverKey, opts) => {
			return getValueOrFallback(await driver.getItem(driverKey), opts?.fallback ?? opts?.defaultValue);
		};
		const getMeta = async (driver, driverKey) => {
			const metaKey = getMetaKey(driverKey);
			return getMetaValue(await driver.getItem(metaKey));
		};
		const setItem = async (driver, driverKey, value) => {
			await driver.setItem(driverKey, value ?? null);
		};
		const setMeta = async (driver, driverKey, properties) => {
			const metaKey = getMetaKey(driverKey);
			const existingFields = getMetaValue(await driver.getItem(metaKey));
			await driver.setItem(metaKey, mergeMeta(existingFields, properties));
		};
		const removeItem = async (driver, driverKey, opts) => {
			await driver.removeItem(driverKey);
			if (opts?.removeMeta) {
				const metaKey = getMetaKey(driverKey);
				await driver.removeItem(metaKey);
			}
		};
		const removeMeta = async (driver, driverKey, properties) => {
			const metaKey = getMetaKey(driverKey);
			if (properties == null) await driver.removeItem(metaKey);
			else {
				const newFields = getMetaValue(await driver.getItem(metaKey));
				[properties].flat().forEach((field) => delete newFields[field]);
				await driver.setItem(metaKey, newFields);
			}
		};
		const watch = (driver, driverKey, cb) => driver.watch(driverKey, cb);
		return {
			getItem: async (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				return await getItem(driver, driverKey, opts);
			},
			getItems: async (keys) => {
				const areaToKeyMap = /* @__PURE__ */ new Map();
				const keyToOptsMap = /* @__PURE__ */ new Map();
				const orderedKeys = [];
				keys.forEach((key) => {
					let keyStr;
					let opts;
					if (typeof key === "string") keyStr = key;
					else if ("getValue" in key) {
						keyStr = key.key;
						opts = { fallback: key.fallback };
					} else {
						keyStr = key.key;
						opts = key.options;
					}
					orderedKeys.push(keyStr);
					const { driverArea, driverKey } = resolveKey(keyStr);
					const areaKeys = areaToKeyMap.get(driverArea) ?? [];
					areaToKeyMap.set(driverArea, areaKeys.concat(driverKey));
					keyToOptsMap.set(keyStr, opts);
				});
				const resultsMap = /* @__PURE__ */ new Map();
				await Promise.all(Array.from(areaToKeyMap.entries()).map(async ([driverArea, keys]) => {
					(await drivers[driverArea].getItems(keys)).forEach((driverResult) => {
						const key = `${driverArea}:${driverResult.key}`;
						const opts = keyToOptsMap.get(key);
						const value = getValueOrFallback(driverResult.value, opts?.fallback ?? opts?.defaultValue);
						resultsMap.set(key, value);
					});
				}));
				return orderedKeys.map((key) => ({
					key,
					value: resultsMap.get(key)
				}));
			},
			getMeta: async (key) => {
				const { driver, driverKey } = resolveKey(key);
				return await getMeta(driver, driverKey);
			},
			getMetas: async (args) => {
				const keys = args.map((arg) => {
					const key = typeof arg === "string" ? arg : arg.key;
					const { driverArea, driverKey } = resolveKey(key);
					return {
						key,
						driverArea,
						driverKey,
						driverMetaKey: getMetaKey(driverKey)
					};
				});
				const areaToDriverMetaKeysMap = keys.reduce((map, key) => {
					map[key.driverArea] ??= [];
					map[key.driverArea].push(key);
					return map;
				}, {});
				const resultsMap = {};
				await Promise.all(Object.entries(areaToDriverMetaKeysMap).map(async ([area, keys]) => {
					const areaRes = await browser$2.storage[area].get(keys.map((key) => key.driverMetaKey));
					keys.forEach((key) => {
						resultsMap[key.key] = areaRes[key.driverMetaKey] ?? {};
					});
				}));
				return keys.map((key) => ({
					key: key.key,
					meta: resultsMap[key.key]
				}));
			},
			setItem: async (key, value) => {
				const { driver, driverKey } = resolveKey(key);
				await setItem(driver, driverKey, value);
			},
			setItems: async (items) => {
				const areaToKeyValueMap = {};
				items.forEach((item) => {
					const { driverArea, driverKey } = resolveKey("key" in item ? item.key : item.item.key);
					areaToKeyValueMap[driverArea] ??= [];
					areaToKeyValueMap[driverArea].push({
						key: driverKey,
						value: item.value
					});
				});
				await Promise.all(Object.entries(areaToKeyValueMap).map(async ([driverArea, values]) => {
					await getDriver(driverArea).setItems(values);
				}));
			},
			setMeta: async (key, properties) => {
				const { driver, driverKey } = resolveKey(key);
				await setMeta(driver, driverKey, properties);
			},
			setMetas: async (items) => {
				const areaToMetaUpdatesMap = {};
				items.forEach((item) => {
					const { driverArea, driverKey } = resolveKey("key" in item ? item.key : item.item.key);
					areaToMetaUpdatesMap[driverArea] ??= [];
					areaToMetaUpdatesMap[driverArea].push({
						key: driverKey,
						properties: item.meta
					});
				});
				await Promise.all(Object.entries(areaToMetaUpdatesMap).map(async ([storageArea, updates]) => {
					const driver = getDriver(storageArea);
					const metaKeys = updates.map(({ key }) => getMetaKey(key));
					const existingMetas = await driver.getItems(metaKeys);
					const existingMetaMap = Object.fromEntries(existingMetas.map(({ key, value }) => [key, getMetaValue(value)]));
					const metaUpdates = updates.map(({ key, properties }) => {
						const metaKey = getMetaKey(key);
						return {
							key: metaKey,
							value: mergeMeta(existingMetaMap[metaKey] ?? {}, properties)
						};
					});
					await driver.setItems(metaUpdates);
				}));
			},
			removeItem: async (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				await removeItem(driver, driverKey, opts);
			},
			removeItems: async (keys) => {
				const areaToKeysMap = {};
				keys.forEach((key) => {
					let keyStr;
					let opts;
					if (typeof key === "string") keyStr = key;
					else if ("getValue" in key) keyStr = key.key;
					else if ("item" in key) {
						keyStr = key.item.key;
						opts = key.options;
					} else {
						keyStr = key.key;
						opts = key.options;
					}
					const { driverArea, driverKey } = resolveKey(keyStr);
					areaToKeysMap[driverArea] ??= [];
					areaToKeysMap[driverArea].push(driverKey);
					if (opts?.removeMeta) areaToKeysMap[driverArea].push(getMetaKey(driverKey));
				});
				await Promise.all(Object.entries(areaToKeysMap).map(async ([driverArea, keys]) => {
					await getDriver(driverArea).removeItems(keys);
				}));
			},
			clear: async (base) => {
				await getDriver(base).clear();
			},
			removeMeta: async (key, properties) => {
				const { driver, driverKey } = resolveKey(key);
				await removeMeta(driver, driverKey, properties);
			},
			snapshot: async (base, opts) => {
				const data = await getDriver(base).snapshot();
				opts?.excludeKeys?.forEach((key) => {
					delete data[key];
					delete data[getMetaKey(key)];
				});
				return data;
			},
			restoreSnapshot: async (base, data) => {
				await getDriver(base).restoreSnapshot(data);
			},
			watch: (key, cb) => {
				const { driver, driverKey } = resolveKey(key);
				return watch(driver, driverKey, cb);
			},
			unwatch() {
				Object.values(drivers).forEach((driver) => {
					driver.unwatch();
				});
			},
			defineItem: (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				const { version: targetVersion = 1, migrations = {}, onMigrationComplete, debug = false } = opts ?? {};
				if (targetVersion < 1) throw Error("Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.");
				let needsVersionSet = false;
				const migrate = async () => {
					const driverMetaKey = getMetaKey(driverKey);
					const [{ value }, { value: meta }] = await driver.getItems([driverKey, driverMetaKey]);
					needsVersionSet = value == null && meta?.v == null && !!targetVersion;
					if (value == null) return;
					const currentVersion = meta?.v ?? 1;
					if (currentVersion > targetVersion) throw Error(`Version downgrade detected (v${currentVersion} -> v${targetVersion}) for "${key}"`);
					if (currentVersion === targetVersion) return;
					if (debug) console.debug(`[@wxt-dev/storage] Running storage migration for ${key}: v${currentVersion} -> v${targetVersion}`);
					const migrationsToRun = Array.from({ length: targetVersion - currentVersion }, (_, i) => currentVersion + i + 1);
					let migratedValue = value;
					for (const migrateToVersion of migrationsToRun) try {
						migratedValue = await migrations?.[migrateToVersion]?.(migratedValue) ?? migratedValue;
						if (debug) console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${migrateToVersion}`);
					} catch (err) {
						throw new MigrationError(key, migrateToVersion, { cause: err });
					}
					await driver.setItems([{
						key: driverKey,
						value: migratedValue
					}, {
						key: driverMetaKey,
						value: {
							...meta,
							v: targetVersion
						}
					}]);
					if (debug) console.debug(`[@wxt-dev/storage] Storage migration completed for ${key} v${targetVersion}`, { migratedValue });
					onMigrationComplete?.(migratedValue, targetVersion);
				};
				const migrationsDone = opts?.migrations == null ? Promise.resolve() : migrate().catch((err) => {
					console.error(`[@wxt-dev/storage] Migration failed for ${key}`, err);
				});
				const initMutex = new Mutex();
				const getFallback = () => opts?.fallback ?? opts?.defaultValue ?? null;
				const getOrInitValue = () => initMutex.runExclusive(async () => {
					const value = await driver.getItem(driverKey);
					if (value != null || opts?.init == null) return value;
					const newValue = await opts.init();
					await driver.setItem(driverKey, newValue);
					if (value == null && targetVersion > 1) await setMeta(driver, driverKey, { v: targetVersion });
					return newValue;
				});
				migrationsDone.then(getOrInitValue);
				return {
					key,
					get defaultValue() {
						return getFallback();
					},
					get fallback() {
						return getFallback();
					},
					getValue: async () => {
						await migrationsDone;
						if (opts?.init) return await getOrInitValue();
						else return await getItem(driver, driverKey, opts);
					},
					getMeta: async () => {
						await migrationsDone;
						return await getMeta(driver, driverKey);
					},
					setValue: async (value) => {
						await migrationsDone;
						if (needsVersionSet) {
							needsVersionSet = false;
							await Promise.all([setItem(driver, driverKey, value), setMeta(driver, driverKey, { v: targetVersion })]);
						} else await setItem(driver, driverKey, value);
					},
					setMeta: async (properties) => {
						await migrationsDone;
						return await setMeta(driver, driverKey, properties);
					},
					removeValue: async (opts) => {
						await migrationsDone;
						return await removeItem(driver, driverKey, opts);
					},
					removeMeta: async (properties) => {
						await migrationsDone;
						return await removeMeta(driver, driverKey, properties);
					},
					watch: (cb) => watch(driver, driverKey, (newValue, oldValue) => cb(newValue ?? getFallback(), oldValue ?? getFallback())),
					migrate
				};
			}
		};
	}
	function createDriver(storageArea) {
		const getStorageArea = () => {
			if (browser$2.runtime == null) throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);
			if (browser$2.storage == null) throw Error("You must add the 'storage' permission to your manifest to use 'wxt/storage'");
			const area = browser$2.storage[storageArea];
			if (area == null) throw Error(`"browser.storage.${storageArea}" is undefined`);
			return area;
		};
		const watchListeners = /* @__PURE__ */ new Set();
		return {
			getItem: async (key) => {
				return (await getStorageArea().get(key))[key];
			},
			getItems: async (keys) => {
				const result = await getStorageArea().get(keys);
				return keys.map((key) => ({
					key,
					value: result[key] ?? null
				}));
			},
			setItem: async (key, value) => {
				if (value == null) await getStorageArea().remove(key);
				else await getStorageArea().set({ [key]: value });
			},
			setItems: async (values) => {
				const map = values.reduce((map, { key, value }) => {
					map[key] = value;
					return map;
				}, {});
				await getStorageArea().set(map);
			},
			removeItem: async (key) => {
				await getStorageArea().remove(key);
			},
			removeItems: async (keys) => {
				await getStorageArea().remove(keys);
			},
			clear: async () => {
				await getStorageArea().clear();
			},
			snapshot: async () => {
				return await getStorageArea().get();
			},
			restoreSnapshot: async (data) => {
				await getStorageArea().set(data);
			},
			watch(key, cb) {
				const listener = (changes) => {
					const change = changes[key];
					if (change == null || dequal(change.newValue, change.oldValue)) return;
					cb(change.newValue ?? null, change.oldValue ?? null);
				};
				getStorageArea().onChanged.addListener(listener);
				watchListeners.add(listener);
				return () => {
					getStorageArea().onChanged.removeListener(listener);
					watchListeners.delete(listener);
				};
			},
			unwatch() {
				watchListeners.forEach((listener) => {
					getStorageArea().onChanged.removeListener(listener);
				});
				watchListeners.clear();
			}
		};
	}
	var MigrationError = class extends Error {
		constructor(key, version, options) {
			super(`v${version} migration failed for "${key}"`, options);
			this.key = key;
			this.version = version;
		}
	};
	//#endregion
	//#region src/entrypoints/utils/cacheManager.ts
	var CacheManager = class {
		memoryCache = /* @__PURE__ */ new Map();
		storageKey;
		defaultTTL;
		constructor(storageKey, defaultTTL = 1440 * 60 * 1e3) {
			this.storageKey = storageKey;
			this.defaultTTL = defaultTTL;
		}
		async get(key) {
			const memoryEntry = this.memoryCache.get(key);
			if (memoryEntry && !this.isExpired(memoryEntry)) return memoryEntry.data;
			if (memoryEntry) this.memoryCache.delete(key);
			try {
				const entries = await storage.getItem(this.storageKey);
				if (entries && entries[key]) {
					const entry = entries[key];
					if (!this.isExpired(entry)) {
						this.memoryCache.set(key, entry);
						return entry.data;
					}
					delete entries[key];
					await storage.setItem(this.storageKey, entries);
				}
			} catch {}
			return null;
		}
		async set(key, data, ttl) {
			const entry = {
				data,
				timestamp: Date.now(),
				ttl: ttl || this.defaultTTL
			};
			this.memoryCache.set(key, entry);
			try {
				const entries = await storage.getItem(this.storageKey) || {};
				entries[key] = entry;
				await storage.setItem(this.storageKey, entries);
			} catch {}
		}
		async remove(key) {
			this.memoryCache.delete(key);
			try {
				const entries = await storage.getItem(this.storageKey);
				if (entries) {
					delete entries[key];
					await storage.setItem(this.storageKey, entries);
				}
			} catch {}
		}
		async clear() {
			this.memoryCache.clear();
			await storage.setItem(this.storageKey, {});
		}
		async getStats() {
			let storageSize = 0;
			try {
				const entries = await storage.getItem(this.storageKey);
				storageSize = entries ? Object.keys(entries).length : 0;
			} catch {}
			return {
				memorySize: this.memoryCache.size,
				storageSize
			};
		}
		isExpired(entry) {
			return Date.now() - entry.timestamp > entry.ttl;
		}
	};
	new CacheManager("local:analysisCache");
	var translationCache = new CacheManager("local:translationCache");
	//#endregion
	//#region src/entrypoints/utils/translateApi.ts
	async function getCachedTranslation(cacheKey) {
		const raw = await translationCache.get(cacheKey);
		if (!raw) return null;
		const map = /* @__PURE__ */ new Map();
		for (const [key, value] of Object.entries(raw)) map.set(key, value);
		return map;
	}
	async function cacheTranslation(cacheKey, data) {
		const obj = {};
		for (const [key, value] of data.entries()) obj[key] = value;
		await translationCache.set(cacheKey, obj, 10080 * 60 * 1e3);
	}
	function processTranslationResult(jsonResult) {
		const parsed = JSON.parse(jsonResult);
		const translations = parsed.translations || parsed;
		const result = /* @__PURE__ */ new Map();
		for (const item of translations) {
			if (typeof item?.id !== "string") continue;
			const translated = typeof item.translated_text === "string" ? item.translated_text : typeof item.text === "string" ? item.text : typeof item.translation === "string" ? item.translation : null;
			if (translated === null) continue;
			result.set(item.id, translated);
		}
		return result;
	}
	/**
	* Compare a raw LLM translation response against the original blocks to flag
	* cases where the model silently returned the source text unchanged — a sign
	* that the model refused, hit a content filter, or ignored instructions.
	*
	* LLM-agnostic: works for any translation service that returns the
	* {"translations":[{"id","translated_text"}]} shape. Returns the same JSON
	* string untouched so callers can pass it through to the parser.
	*/
	function logUnchangedBlocks(rawJson, originalBlocks) {
		try {
			const parsed = JSON.parse(rawJson);
			const translations = parsed.translations || parsed;
			if (!Array.isArray(translations)) return rawJson;
			const byId = new Map(originalBlocks.map((b) => [b.id, b.text]));
			const seenIds = /* @__PURE__ */ new Set();
			let unchanged = 0;
			let extraIds = 0;
			for (const item of translations) {
				const translatedText = typeof item.translated_text === "string" ? item.translated_text : typeof item.text === "string" ? item.text : typeof item.translation === "string" ? item.translation : null;
				seenIds.add(item.id);
				const original = byId.get(item.id);
				if (original === void 0) {
					extraIds++;
					continue;
				}
				if (translatedText !== null && translatedText === original) {
					unchanged++;
					console.warn("[TranslateApi] Block", item.id, "came back unchanged (LLM refused / no-op). Original:", original.substring(0, 80));
				}
			}
			const inputMissing = originalBlocks.length - seenIds.size;
			const totalMissing = extraIds + inputMissing;
			const total = originalBlocks.length;
			if (total > 0 && unchanged === translations.length) console.error("[TranslateApi] ALL", translations.length, "translated blocks came back unchanged — prompt may be too weak or content was filtered");
			else if (totalMissing > 0) console.warn("[TranslateApi]", totalMissing, "blocks missing from response (input had", total, "blocks)");
			else if (unchanged > 0) console.warn("[TranslateApi]", unchanged, "/", translations.length, "blocks returned unchanged");
		} catch {}
		return rawJson;
	}
	async function clearAllCache() {
		await translationCache.clear();
	}
	//#endregion
	//#region src/entrypoints/service/deepseek.ts
	var API_URL = "https://api.deepseek.com/v1/chat/completions";
	var MODEL = "deepseek-v4-flash";
	var USER_ID = "fanyi-extension";
	var TRANSLATION_TEMPERATURE = .1;
	/**
	* Estimate max output tokens for translation.
	*
	* 真实边界（已查 https://api-docs.deepseek.com/quick_start/pricing）：
	* - deepseek-v4-flash MAX OUTPUT = 384K（硬上限非常高）
	* - 计费 = actual tokens × price，不是 reserve × price
	*   → reserve 大小不会让账单变大，只影响 worst-case latency
	* - 必须设 cap，因为 response_format: json_object 下模型失控时
	*   可能"unending stream of whitespace"跑到 384K 仍不停
	*   （见 https://api-docs.deepseek.com/api/create-chat-completion）
	*
	* 翻译 ratio 经验值（chunkBuilder TARGET_TOKENS=800 → 典型 chunk）：
	* - input 800 tokens (12 blocks) → output ~2000 tokens
	* - input 1500 tokens (18 blocks) → output ~3700 tokens
	* - input 2000 tokens (30 blocks, worst case) → output ~5000 tokens
	* - + JSON 包装（id/translated_text 键名、引号、换行）≈ +10-20%
	*
	* 当前公式：* 4 * 2 = 8x input tokens，最低 1024。
	*  - 800 input  →  6400 reserve（典型 12 块，3.2x headroom）
	*  - 1500 input → 12000 reserve（18 块，3.2x headroom）
	*  - 2000 input → 16000 reserve（30 块，3.2x headroom）
	*  - 200 input  →  1024 reserve（retry 单块的下限）
	* 3.2x headroom 给模型留出"想多说点"或"加注释"的余量，同时远
	* 小于 384K 硬上限。再大的 chunk 触顶靠 content.ts 的 per-block
	* retry 兜底（retry 切到 1-3 块的小 chunk，reserve 永远不会触顶）。
	*/
	function estimateMaxTokens(inputJson) {
		const estimatedInputTokens = Math.ceil(inputJson.length * .5);
		return Math.max(1024, Math.ceil(estimatedInputTokens * 8 * 2));
	}
	function buildHeaders(apiKey) {
		return {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		};
	}
	function buildSystemContent(sourceLang, targetLang, sitePrompt, glossary) {
		let systemContent = `Translate ${!sourceLang ? "English" : sourceLang === "en" ? "English" : sourceLang} to ${!targetLang ? "Simplified Chinese" : targetLang === "zh" ? "Simplified Chinese" : targetLang}.

1. Return {"translations":[{"id":"x","translated_text":"y"}]}. One entry per input block, same ids.
2. For translatable text, provide a translation. Never return empty string or placeholder.
3. Keep URLs, code, and version numbers unchanged. Translate everything else.
4. Treat every block as independent — do not skip, summarize, merge, or reorder any block.`;
		const docTerms = glossary?.document_terms;
		if (docTerms && docTerms.length > 0) {
			const sorted = [...docTerms].sort();
			systemContent += `

Preserve only proper nouns and named entities. Examples:
- company names
- organization names
- product names
- service names
- trademarks

This page mentions:
${sorted.join("\n")}

Translate all ordinary English words and phrases normally.`;
		}
		if (sitePrompt) systemContent += `\n\nSite-specific rules:\n${sitePrompt}`;
		return systemContent;
	}
	function buildTranslationBody(blocks, sourceLang, targetLang, sitePrompt, glossary) {
		const blocksJson = JSON.stringify(blocks.map((b) => ({
			id: b.id,
			text: b.text
		})), null, 2);
		const systemContent = buildSystemContent(sourceLang, targetLang, sitePrompt, hasGlossaryEntries(glossary) ? glossary : void 0);
		console.log("[DeepSeek] System prompt built:\n" + systemContent);
		return {
			model: MODEL,
			messages: [{
				role: "system",
				content: systemContent
			}, {
				role: "user",
				content: `JSON:\n\n${blocksJson}`
			}],
			response_format: { type: "json_object" },
			temperature: TRANSLATION_TEMPERATURE,
			max_tokens: estimateMaxTokens(blocksJson),
			user_id: USER_ID,
			thinking: { type: "disabled" },
			stream: false
		};
	}
	async function callApi(apiKey, body) {
		try {
			const response = await fetch(API_URL, {
				method: "POST",
				headers: buildHeaders(apiKey),
				body
			});
			console.log("[DeepSeek] Response status:", response.status);
			const responseText = await response.text().catch(() => "");
			if (!response.ok) {
				let errorMessage = `HTTP ${response.status}`;
				try {
					const errorJson = JSON.parse(responseText);
					if (errorJson.error) {
						errorMessage += ` - ${errorJson.error.message || errorJson.error}`;
						if (errorJson.error.type) errorMessage += ` [${errorJson.error.type}]`;
						if (errorJson.error.code) errorMessage += ` (code: ${errorJson.error.code})`;
					} else if (errorJson.message) errorMessage += ` - ${errorJson.message}`;
					else errorMessage += ` - ${responseText.substring(0, 200)}`;
				} catch {
					errorMessage += ` - ${responseText.substring(0, 200)}`;
				}
				if (response.status === 401) errorMessage += "\n\n可能原因: API Key 无效或已过期";
				else if (response.status === 403) errorMessage += "\n\n可能原因: 账户余额不足或被封禁";
				else if (response.status === 429) errorMessage += "\n\n可能原因: 请求频率超限，请稍后重试";
				else if (response.status === 500 || response.status === 503) errorMessage += "\n\n可能原因: DeepSeek 服务暂时不可用";
				throw new Error(`DeepSeek API error: ${errorMessage}`);
			}
			const data = JSON.parse(responseText);
			const content = data.choices?.[0]?.message?.content;
			if (!content) {
				console.error("[DeepSeek] Invalid response structure:", JSON.stringify(data).substring(0, 500));
				throw new Error("DeepSeek 返回了无效响应: 缺少 choices[0].message.content");
			}
			return content;
		} catch (error) {
			if (error instanceof TypeError && error.message.includes("fetch")) {
				console.error("[DeepSeek] Fetch error - possible network/CORS issue:", error);
				throw new Error(`网络请求失败: ${error.message}\n\n可能原因:\n1. 网络连接问题\n2. Firefox 扩展权限不足\n3. 被防火墙/代理拦截`);
			}
			throw error;
		}
	}
	function hasGlossaryEntries(glossary) {
		return !!glossary && ((glossary.hard_terms?.length ?? 0) > 0 || (glossary.soft_terms?.length ?? 0) > 0 || (glossary.document_terms?.length ?? 0) > 0);
	}
	var DeepSeekTranslationService = class {
		apiKey;
		constructor(apiKey) {
			this.apiKey = apiKey;
		}
		async translate(jsonContent, sourceLang, targetLang, glossary, context) {
			const blocks = JSON.parse(jsonContent);
			const body = buildTranslationBody(blocks, sourceLang, targetLang, context, hasGlossaryEntries(glossary) ? glossary : void 0);
			return logUnchangedBlocks(await callApi(this.apiKey, JSON.stringify(body)), blocks);
		}
		async *translateStream(jsonContent, sourceLang, targetLang, glossary, context) {
			const blocks = JSON.parse(jsonContent);
			const bodyObj = buildTranslationBody(blocks, sourceLang, targetLang, context, hasGlossaryEntries(glossary) ? glossary : void 0);
			bodyObj.stream = true;
			const body = JSON.stringify(bodyObj);
			const response = await fetch(API_URL, {
				method: "POST",
				headers: buildHeaders(this.apiKey),
				body
			});
			if (!response.ok) {
				const text = await response.text().catch(() => "");
				throw new Error(`DeepSeek API error: HTTP ${response.status} - ${text.substring(0, 200)}`);
			}
			if (!response.body) throw new Error("DeepSeek API error: response body is null");
			const reader = response.body.getReader();
			let fullContent = "";
			for await (const delta of parseSSEStream(reader)) {
				fullContent += delta;
				yield fullContent;
			}
			return logUnchangedBlocks(fullContent, blocks);
		}
	};
	//#endregion
	//#region src/entrypoints/utils/config.ts
	var defaultConfig = {
		enabled: true,
		sourceLang: "auto",
		targetLang: "zh",
		mode: "bilingual",
		deepseekApiKey: "",
		shortcuts: {
			translatePage: "Alt+T",
			translateSelection: "Alt+S",
			restoreOriginal: "Alt+R",
			toggleTranslation: "Alt+V"
		},
		touchGesture: "TripleTap"
	};
	async function getConfig() {
		const config = await storage.getItem("local:config");
		return {
			...defaultConfig,
			...config
		};
	}
	//#endregion
	//#region src/entrypoints/utils/translationQueue.ts
	var TranslationQueue = class {
		queue = [];
		running = 0;
		concurrency;
		maxRetries;
		retryDelay;
		constructor(concurrency = 4, maxRetries = 2, retryDelay = 1e3) {
			this.concurrency = concurrency;
			this.maxRetries = maxRetries;
			this.retryDelay = retryDelay;
		}
		async add(task) {
			return new Promise((resolve, reject) => {
				this.queue.push({
					task,
					resolve,
					reject,
					retries: 0
				});
				this.process();
			});
		}
		async process() {
			while (this.running < this.concurrency && this.queue.length > 0) {
				const item = this.queue.shift();
				if (!item) break;
				this.running++;
				try {
					const result = await item.task();
					item.resolve(result);
				} catch (error) {
					if (item.retries < this.maxRetries) {
						item.retries++;
						await this.delay(this.retryDelay * item.retries);
						this.queue.unshift(item);
					} else item.reject(error instanceof Error ? error : new Error(String(error)));
				} finally {
					this.running--;
					this.process();
				}
			}
		}
		delay(ms) {
			return new Promise((resolve) => setTimeout(resolve, ms));
		}
		setConcurrency(n) {
			this.concurrency = n;
			if (n > 0) this.process();
		}
		async addAllWithWarmup(tasks, warmupCount, maxConcurrency) {
			if (tasks.length === 0) return [];
			const results = [];
			for (let i = 0; i < Math.min(warmupCount, tasks.length); i++) results.push(await this.add(tasks[i]));
			if (tasks.length > warmupCount) {
				this.setConcurrency(maxConcurrency);
				const remaining = tasks.slice(warmupCount).map((t) => this.add(t));
				results.push(...await Promise.all(remaining));
			}
			return results;
		}
		get pendingCount() {
			return this.queue.length;
		}
		get runningCount() {
			return this.running;
		}
	};
	var globalQueue = new TranslationQueue(1, 2, 1e3);
	//#endregion
	//#region src/entrypoints/utils/cacheKey.ts
	function simpleHash(str) {
		let hash = 0;
		for (let i = 0; i < str.length; i++) {
			const char = str.charCodeAt(i);
			hash = (hash << 5) - hash + char;
			hash = hash & 2147483647;
		}
		return hash;
	}
	function generateTranslationCacheKey(jsonContent, sourceLang, targetLang) {
		return `translation_${sourceLang}_${targetLang}_${simpleHash(jsonContent)}_${simpleHash(jsonContent.substring(0, 200))}`;
	}
	//#endregion
	//#region src/rules/index.ts
	var RULES = [
		{
			hostPattern: "github.com",
			documentTerms: [
				"Releases",
				"Packages",
				"license",
				"MIT",
				"README",
				"Issues",
				"Pull requests",
				"Actions",
				"Projects",
				"Wiki",
				"Security",
				"Insights",
				"Code",
				"Commits",
				"Branches",
				"Tags",
				"Contributors",
				"Fork",
				"Star",
				"Watch",
				"Code of conduct",
				"Contributing",
				"Support",
				"Funding"
			],
			skipSelectors: [
				".octicon",
				"[data-view-component=\"true\"].d-flex",
				"code",
				"pre",
				".react-blob-view-header-sticky",
				"[class*=\"stickyHeader\"]",
				"[class*=\"BlobViewHeader\"]",
				"[class*=\"FileNameStickyHeader\"]",
				"[class*=\"breadcrumbs\"]"
			],
			promptInstructions: "This is a GitHub page. Keep UI navigation terms, file extensions, and code-related vocabulary untranslated. Preserve brand names and technical terms."
		},
		{
			hostPattern: "reddit.com",
			skipTerms: [
				"Home",
				"Hot",
				"New",
				"Top",
				"Rising",
				"Reddit",
				"Subreddit",
				"Upvote",
				"Downvote",
				"Karma",
				"Award",
				"Share",
				"Save",
				"Report",
				"Crosspost",
				"Moderator",
				"Admin",
				"Post",
				"Comment",
				"Sort by",
				"Best",
				"Controversial"
			],
			skipSelectors: [
				"shreddit-comment",
				"faceplate-blot",
				"[data-click-id=\"score\"]"
			],
			skipTextPatterns: ["^SML\\.load\\s*\\(\\s*\\["],
			promptInstructions: "This is a Reddit page. Keep community-specific terms, subreddit names, UI labels like \"upvote/downvote/karma\", and usernames untranslated."
		},
		{
			hostPattern: "news.ycombinator.com",
			documentTerms: [
				"Hacker News",
				"new",
				"past",
				"comments",
				"hide",
				"favorite",
				"flag",
				"upvote",
				"points",
				"user",
				"about",
				"favorite",
				"submit",
				"show",
				"ask",
				"jobs",
				"threads",
				"guidelines",
				"FAQ",
				"API",
				"Security",
				"YC",
				"Startup",
				"Book",
				"Login"
			],
			skipSelectors: [
				".votelinks",
				".rank",
				".score",
				".subtext",
				"code",
				"pre"
			],
			promptInstructions: "This is Hacker News. Keep navigation terms, voting-related vocabulary, YC-specific terminology, and code snippets untranslated."
		},
		{
			hostPattern: "fortune.com",
			documentTerms: [
				"Fortune",
				"Uber",
				"AI",
				"API",
				"ChatGPT",
				"GPT"
			],
			skipSelectors: [
				"[class*=\"paywall\"]",
				"[class*=\"pay-wall\"]",
				"[class*=\"subscribe\"]",
				"[class*=\"subscription\"]"
			],
			promptInstructions: "This is a Fortune news article page. Keep proper names, brand names, and technical acronyms untranslated. Focus on translating the article content."
		}
	];
	function matchSiteRule(url) {
		let host;
		try {
			host = new URL(url).hostname;
		} catch {
			return null;
		}
		for (const rule of RULES) if (hostMatches(host, rule.hostPattern)) return {
			siteRule: rule,
			matchedPattern: rule.hostPattern
		};
		return null;
	}
	function hostMatches(host, pattern) {
		if (pattern.startsWith("*.")) {
			const suffix = pattern.slice(2);
			return host === suffix || host.endsWith("." + suffix);
		}
		return host === pattern;
	}
	function buildSitePrompt(rule) {
		const parts = [];
		if (rule.documentTerms && rule.documentTerms.length > 0) parts.push(`"document_terms":${JSON.stringify(rule.documentTerms, null, 2)}`);
		if (rule.promptInstructions) parts.push(rule.promptInstructions);
		return parts.join("\n");
	}
	//#endregion
	//#region src/entrypoints/background.ts
	var background_default = defineBackground({
		persistent: { safari: false },
		main() {
			console.log("Background script loaded");
			const isContextMenuSupported = !!import_browser_polyfill.default.contextMenus;
			const isCommandsSupported = !!import_browser_polyfill.default.commands;
			const serviceCache = /* @__PURE__ */ new Map();
			function getService(apiKey) {
				if (!serviceCache.has(apiKey)) serviceCache.set(apiKey, new DeepSeekTranslationService(apiKey));
				return serviceCache.get(apiKey);
			}
			import_browser_polyfill.default.runtime.onInstalled.addListener(() => {
				console.log("Extension installed");
				if (isContextMenuSupported) try {
					import_browser_polyfill.default.contextMenus.create({
						id: "translate-page",
						title: "翻译此页面",
						contexts: ["page"]
					});
					import_browser_polyfill.default.contextMenus.create({
						id: "restore-original",
						title: "恢复原文",
						contexts: ["page"]
					});
					import_browser_polyfill.default.contextMenus.create({
						id: "toggle-translation",
						title: "切换译文显示",
						contexts: ["page"]
					});
				} catch (error) {
					console.warn("Context menu creation failed:", error);
				}
				registerCommands();
			});
			if (isCommandsSupported) try {
				import_browser_polyfill.default.commands.onCommand.addListener(async (command) => {
					try {
						const [tab] = await import_browser_polyfill.default.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!tab?.id) return;
						switch (command) {
							case "translate-page":
								import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "translatePage" }).catch(() => {});
								break;
							case "restore-original":
								import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "restoreOriginal" }).catch(() => {});
								break;
							case "toggle-translation":
								import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "toggleTranslation" }).catch(() => {});
								break;
						}
					} catch (error) {
						console.warn("Command handling failed:", error);
					}
				});
			} catch (error) {
				console.warn("Commands API not available:", error);
			}
			if (isContextMenuSupported) try {
				import_browser_polyfill.default.contextMenus.onClicked.addListener(async (info, tab) => {
					if (!tab?.id) return;
					switch (info.menuItemId) {
						case "translate-page":
							import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "translatePage" }).catch(() => {});
							break;
						case "restore-original":
							import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "restoreOriginal" }).catch(() => {});
							break;
						case "toggle-translation":
							import_browser_polyfill.default.tabs.sendMessage(tab.id, { action: "toggleTranslation" }).catch(() => {});
							break;
					}
				});
			} catch (error) {
				console.warn("Context menu click listener failed:", error);
			}
			import_browser_polyfill.default.runtime.onMessage.addListener((message, sender, sendResponse) => {
				(async () => {
					try {
						if (message.action === "translateChunk") await handleTranslateChunk(message, sendResponse);
						else if (message.action === "translateChunkStream") await handleTranslateChunkStream(message, sender, sendResponse);
						else if (message.action === "validateApiKey") await handleValidateApiKey(message, sendResponse);
						else if (message.action === "clearCache") await handleClearCache(sendResponse);
						else if (message.action === "checkConfig") await handleCheckConfig(sendResponse);
						else sendResponse({
							success: false,
							error: "Unknown action"
						});
					} catch (error) {
						console.error("[Background] Message handler error:", error);
						sendResponse({
							success: false,
							error: error instanceof Error ? error.message : "Unknown error"
						});
					}
				})();
				return true;
			});
			async function handleTranslateChunk(message, sendResponse) {
				try {
					const config = await getConfig();
					if (!config.deepseekApiKey) {
						sendResponse({
							success: false,
							error: "DeepSeek API Key not configured"
						});
						return;
					}
					const { jsonContent, sourceLang, targetLang, cacheKey: providedCacheKey, pageUrl, glossary } = message;
					const matchedRule = pageUrl ? matchSiteRule(pageUrl) : null;
					const sitePrompt = matchedRule ? buildSitePrompt(matchedRule.siteRule) : "";
					const cacheKey = providedCacheKey || generateTranslationCacheKey(jsonContent, sourceLang, targetLang);
					const cached = await getCachedTranslation(cacheKey);
					if (cached && cached.size > 0) {
						sendResponse({
							success: true,
							result: Array.from(cached.entries())
						});
						return;
					}
					const service = getService(config.deepseekApiKey);
					let inputBlocks = [];
					try {
						inputBlocks = JSON.parse(jsonContent);
					} catch {}
					const inputIds = inputBlocks.map((b) => b.id);
					const inputBytes = jsonContent.length;
					const estInputTokens = Math.ceil(inputBytes / 4);
					const reservedMaxTokens = Math.max(256, Math.ceil(estInputTokens * 2 * 1.2));
					console.log("[Background][ChunkTrace] INPUT", `inputBlocks=${inputBlocks.length}`, `inputIds=[${inputIds.join(",")}]`, `inputBytes=${inputBytes}`, `estInputTokens=${estInputTokens}`, `reservedMaxTokens=${reservedMaxTokens}`, `sourceLang=${sourceLang}`, `targetLang=${targetLang}`);
					const jsonResult = await globalQueue.add(() => service.translate(jsonContent, sourceLang, targetLang, glossary, sitePrompt));
					let outputIds = [];
					let outputBytes = 0;
					let jsonParseFailed = false;
					let outputTail = "";
					let parseErrorMsg = "";
					try {
						const parsed = JSON.parse(jsonResult);
						const translations = parsed.translations || parsed;
						if (Array.isArray(translations)) outputIds = translations.map((t) => typeof t?.id === "string" ? t.id : null).filter((id) => !!id);
						outputBytes = jsonResult.length;
					} catch (parseErr) {
						jsonParseFailed = true;
						outputBytes = jsonResult.length;
						outputTail = jsonResult.slice(-200);
						parseErrorMsg = parseErr instanceof Error ? parseErr.message : String(parseErr);
						console.error("[Background][ChunkTrace] OUTPUT NOT VALID JSON — likely truncated at max_tokens ceiling", {
							inputBlocks: inputBlocks.length,
							outputBytes,
							reservedMaxTokens,
							outputTail,
							parseError: parseErrorMsg
						});
					}
					const missingInResponse = inputIds.filter((id) => !outputIds.includes(id));
					console.log("[Background][ChunkTrace] OUTPUT", `outputBlocks=${outputIds.length}`, `outputBytes=${outputBytes}`, `missingInResponse=${JSON.stringify(missingInResponse)}`);
					if (missingInResponse.length > 0) console.warn("[Background][ChunkTrace] MISSING — model did not return entries for:", missingInResponse, "reservedMaxTokens was", reservedMaxTokens, "(try increasing estimateMaxTokens or split chunk smaller)");
					const result = processTranslationResult(jsonResult);
					await cacheTranslation(cacheKey, result);
					const trace = {
						inputBytes,
						estInputTokens,
						reservedMaxTokens,
						outputBytes,
						outputBlocks: outputIds.length,
						outputIds: outputIds.slice(0, 30),
						outputPreview: jsonResult.substring(0, 200),
						missingInResponse,
						jsonParseFailed,
						outputTail: jsonParseFailed ? outputTail : "",
						parseError: parseErrorMsg
					};
					sendResponse({
						success: true,
						result: Array.from(result.entries()),
						trace
					});
				} catch (error) {
					console.error("[Background] translateChunk error:", error);
					console.error("[Background] Full error details:", {
						name: error instanceof Error ? error.name : "unknown",
						message: error instanceof Error ? error.message : String(error),
						stack: error instanceof Error ? error.stack?.substring(0, 500) : null
					});
					sendResponse({
						success: false,
						error: error instanceof Error ? error.message : "Unknown error",
						debugInfo: error instanceof Error ? {
							name: error.name,
							stack: error.stack?.substring(0, 300)
						} : null
					});
				}
			}
			async function handleTranslateChunkStream(message, sender, sendResponse) {
				try {
					const config = await getConfig();
					if (!config.deepseekApiKey) {
						sendResponse({
							success: false,
							error: "DeepSeek API Key not configured"
						});
						return;
					}
					const { jsonContent, sourceLang, targetLang, pageUrl, glossary } = message;
					const matchedRule = pageUrl ? matchSiteRule(pageUrl) : null;
					const sitePrompt = matchedRule ? buildSitePrompt(matchedRule.siteRule) : "";
					const stream = getService(config.deepseekApiKey).translateStream(jsonContent, sourceLang, targetLang, glossary, sitePrompt);
					let finalContent = "";
					for await (const partial of stream) {
						finalContent = partial;
						try {
							await import_browser_polyfill.default.tabs.sendMessage(message.tabId || sender.tab?.id, {
								action: "translationStreamUpdate",
								partial
							});
						} catch {}
					}
					const result = processTranslationResult(finalContent);
					try {
						const parsed = JSON.parse(finalContent);
						const translations = parsed.translations || parsed;
						if (Array.isArray(translations)) {
							const streamInputIds = (() => {
								try {
									return JSON.parse(message.jsonContent).map((b) => b);
								} catch {
									return [];
								}
							})();
							const sample = translations.slice(0, 3).map((t) => ({
								id: t.id,
								text: typeof t.translated_text === "string" ? t.translated_text.substring(0, 80) : "N/A"
							}));
							const noOpCount = translations.filter((t, i) => {
								const inputBlock = streamInputIds[i];
								return inputBlock && t.translated_text === inputBlock.text;
							}).length;
							console.log("[Background][StreamTrace] sample=", JSON.stringify(sample), `noOpCount=${noOpCount}/${translations.length}`);
						}
					} catch {}
					sendResponse({
						success: true,
						result: Array.from(result.entries())
					});
				} catch (error) {
					console.error("[Background] translateChunkStream error:", error);
					sendResponse({
						success: false,
						error: error instanceof Error ? error.message : "Unknown error"
					});
				}
			}
			async function handleValidateApiKey(message, sendResponse) {
				try {
					const { apiKey } = message;
					if (!apiKey) {
						sendResponse({
							success: false,
							error: "API Key 不能为空"
						});
						return;
					}
					console.log("[Background] Validating API Key, length:", apiKey.length);
					const service = new DeepSeekTranslationService(apiKey);
					const testContent = JSON.stringify([{
						id: "test",
						text: "Hello"
					}]);
					const timeout = new Promise((_, reject) => {
						setTimeout(() => reject(/* @__PURE__ */ new Error("请求超时（10秒）")), 1e4);
					});
					await Promise.race([service.translate(testContent, "en", "zh", []), timeout]);
					sendResponse({ success: true });
				} catch (error) {
					console.error("[Background] API Key validation failed:", error);
					const errorMsg = error instanceof Error ? error.message : "验证失败";
					console.error("[Background] Full error stack:", error);
					sendResponse({
						success: false,
						error: errorMsg,
						debugInfo: error instanceof Error ? {
							name: error.name,
							message: error.message,
							stack: error.stack?.substring(0, 300)
						} : null
					});
				}
			}
			async function handleClearCache(sendResponse) {
				try {
					await clearAllCache();
					sendResponse({ success: true });
				} catch (error) {
					sendResponse({
						success: false,
						error: error instanceof Error ? error.message : "Unknown error"
					});
				}
			}
			async function handleCheckConfig(sendResponse) {
				try {
					const config = await getConfig();
					sendResponse({
						success: !!config.deepseekApiKey,
						config
					});
				} catch (error) {
					console.error("[Background] checkConfig error:", error);
					sendResponse({
						success: false,
						error: error instanceof Error ? error.message : "Unknown error"
					});
				}
			}
			async function registerCommands() {
				if (!isCommandsSupported) return;
				try {
					const commands = await import_browser_polyfill.default.commands.getAll();
					console.log("Registered commands:", commands);
				} catch (error) {
					console.warn("Commands API not available:", error);
				}
			}
		}
	});
	//#endregion
	//#region node_modules/.pnpm/@webext-core+match-patterns@1.0.3/node_modules/@webext-core/match-patterns/lib/index.js
	var _MatchPattern = class {
		constructor(matchPattern) {
			if (matchPattern === "<all_urls>") {
				this.isAllUrls = true;
				this.protocolMatches = [..._MatchPattern.PROTOCOLS];
				this.hostnameMatch = "*";
				this.pathnameMatch = "*";
			} else {
				const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
				if (groups == null) throw new InvalidMatchPattern(matchPattern, "Incorrect format");
				const [_, protocol, hostname, pathname] = groups;
				validateProtocol(matchPattern, protocol);
				validateHostname(matchPattern, hostname);
				this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
				this.hostnameMatch = hostname;
				this.pathnameMatch = pathname;
			}
		}
		includes(url) {
			if (this.isAllUrls) return true;
			const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
			return !!this.protocolMatches.find((protocol) => {
				if (protocol === "http") return this.isHttpMatch(u);
				if (protocol === "https") return this.isHttpsMatch(u);
				if (protocol === "file") return this.isFileMatch(u);
				if (protocol === "ftp") return this.isFtpMatch(u);
				if (protocol === "urn") return this.isUrnMatch(u);
			});
		}
		isHttpMatch(url) {
			return url.protocol === "http:" && this.isHostPathMatch(url);
		}
		isHttpsMatch(url) {
			return url.protocol === "https:" && this.isHostPathMatch(url);
		}
		isHostPathMatch(url) {
			if (!this.hostnameMatch || !this.pathnameMatch) return false;
			const hostnameMatchRegexs = [this.convertPatternToRegex(this.hostnameMatch), this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))];
			const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
			return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
		}
		isFileMatch(url) {
			throw Error("Not implemented: file:// pattern matching. Open a PR to add support");
		}
		isFtpMatch(url) {
			throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
		}
		isUrnMatch(url) {
			throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
		}
		convertPatternToRegex(pattern) {
			const starsReplaced = this.escapeForRegex(pattern).replace(/\\\*/g, ".*");
			return RegExp(`^${starsReplaced}$`);
		}
		escapeForRegex(string) {
			return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
	};
	var MatchPattern = _MatchPattern;
	MatchPattern.PROTOCOLS = [
		"http",
		"https",
		"file",
		"ftp",
		"urn"
	];
	var InvalidMatchPattern = class extends Error {
		constructor(matchPattern, reason) {
			super(`Invalid match pattern "${matchPattern}": ${reason}`);
		}
	};
	function validateProtocol(matchPattern, protocol) {
		if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*") throw new InvalidMatchPattern(matchPattern, `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`);
	}
	function validateHostname(matchPattern, hostname) {
		if (hostname.includes(":")) throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
		if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*.")) throw new InvalidMatchPattern(matchPattern, `If using a wildcard (*), it must go at the start of the hostname`);
	}
	//#endregion
	//#region \0virtual:wxt-background-entrypoint?/Users/saga/code-repos/fanyi-extension/src/entrypoints/background.ts
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => ([...args], void 0),
		log: (...args) => ([...args], void 0),
		warn: (...args) => ([...args], void 0),
		error: (...args) => ([...args], void 0)
	};
	var result;
	try {
		result = background_default.main();
		if (result instanceof Promise) console.warn("The background's main() function return a promise, but it must be synchronous");
	} catch (err) {
		logger.error("The background crashed on startup!");
		throw err;
	}
	//#endregion
	return result;
})();
