var content = (function() {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/define-content-script.mjs
	function defineContentScript(definition) {
		return definition;
	}
	//#endregion
	//#region node_modules/.pnpm/@wxt-dev+browser@0.1.42/node_modules/@wxt-dev/browser/src/index.mjs
	var import_browser_polyfill = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		(function(global, factory) {
			if (typeof define === "function" && define.amd) define("webextension-polyfill", ["module"], factory);
			else if (typeof exports !== "undefined") factory(module);
			else {
				var mod = { exports: {} };
				factory(mod);
				global.browser = mod.exports;
			}
		})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module$1) {
			"use strict";
			if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw new Error("This script should only be loaded in a browser extension.");
			if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
				const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
				const wrapAPIs = (extensionAPIs) => {
					const apiMetadata = {
						"alarms": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"clearAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"bookmarks": {
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getChildren": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getRecent": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getSubTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTree": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"browserAction": {
							"disable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"enable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"getBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getBadgeText": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"openPopup": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setBadgeText": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"browsingData": {
							"remove": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"removeCache": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCookies": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeDownloads": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFormData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeHistory": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeLocalStorage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePasswords": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePluginData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"settings": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"commands": { "getAll": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"contextMenus": {
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"cookies": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAllCookieStores": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"devtools": {
							"inspectedWindow": { "eval": {
								"minArgs": 1,
								"maxArgs": 2,
								"singleCallbackArg": false
							} },
							"panels": {
								"create": {
									"minArgs": 3,
									"maxArgs": 3,
									"singleCallbackArg": true
								},
								"elements": { "createSidebarPane": {
									"minArgs": 1,
									"maxArgs": 1
								} }
							}
						},
						"downloads": {
							"cancel": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"download": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"erase": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFileIcon": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"open": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"pause": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFile": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"resume": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"extension": {
							"isAllowedFileSchemeAccess": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"isAllowedIncognitoAccess": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"history": {
							"addUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"deleteRange": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getVisits": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"i18n": {
							"detectLanguage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAcceptLanguages": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"identity": { "launchWebAuthFlow": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"idle": { "queryState": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"management": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getSelf": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setEnabled": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"uninstallSelf": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"notifications": {
							"clear": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPermissionLevel": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"pageAction": {
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"hide": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"permissions": {
							"contains": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"request": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"runtime": {
							"getBackgroundPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPlatformInfo": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"openOptionsPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"requestUpdateCheck": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"sendMessage": {
								"minArgs": 1,
								"maxArgs": 3
							},
							"sendNativeMessage": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"setUninstallURL": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"sessions": {
							"getDevices": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getRecentlyClosed": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"restore": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"storage": {
							"local": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							},
							"managed": {
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								}
							},
							"sync": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							}
						},
						"tabs": {
							"captureVisibleTab": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"detectLanguage": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"discard": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"duplicate": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"executeScript": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getZoom": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getZoomSettings": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goBack": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goForward": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"highlight": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"insertCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"query": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"reload": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"sendMessage": {
								"minArgs": 2,
								"maxArgs": 3
							},
							"setZoom": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"setZoomSettings": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"update": {
								"minArgs": 1,
								"maxArgs": 2
							}
						},
						"topSites": { "get": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"webNavigation": {
							"getAllFrames": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFrame": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"webRequest": { "handlerBehaviorChanged": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"windows": {
							"create": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getLastFocused": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						}
					};
					if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
					/**
					* A WeakMap subclass which creates and stores a value for any key which does
					* not exist when accessed, but behaves exactly as an ordinary WeakMap
					* otherwise.
					*
					* @param {function} createItem
					*        A function which will be called in order to create the value for any
					*        key which does not exist, the first time it is accessed. The
					*        function receives, as its only argument, the key being created.
					*/
					class DefaultWeakMap extends WeakMap {
						constructor(createItem, items = void 0) {
							super(items);
							this.createItem = createItem;
						}
						get(key) {
							if (!this.has(key)) this.set(key, this.createItem(key));
							return super.get(key);
						}
					}
					/**
					* Returns true if the given object is an object with a `then` method, and can
					* therefore be assumed to behave as a Promise.
					*
					* @param {*} value The value to test.
					* @returns {boolean} True if the value is thenable.
					*/
					const isThenable = (value) => {
						return value && typeof value === "object" && typeof value.then === "function";
					};
					/**
					* Creates and returns a function which, when called, will resolve or reject
					* the given promise based on how it is called:
					*
					* - If, when called, `chrome.runtime.lastError` contains a non-null object,
					*   the promise is rejected with that value.
					* - If the function is called with exactly one argument, the promise is
					*   resolved to that value.
					* - Otherwise, the promise is resolved to an array containing all of the
					*   function's arguments.
					*
					* @param {object} promise
					*        An object containing the resolution and rejection functions of a
					*        promise.
					* @param {function} promise.resolve
					*        The promise's resolution function.
					* @param {function} promise.reject
					*        The promise's rejection function.
					* @param {object} metadata
					*        Metadata about the wrapped method which has created the callback.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function}
					*        The generated callback function.
					*/
					const makeCallback = (promise, metadata) => {
						return (...callbackArgs) => {
							if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
							else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
							else promise.resolve(callbackArgs);
						};
					};
					const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
					/**
					* Creates a wrapper function for a method with the given name and metadata.
					*
					* @param {string} name
					*        The name of the method which is being wrapped.
					* @param {object} metadata
					*        Metadata about the method being wrapped.
					* @param {integer} metadata.minArgs
					*        The minimum number of arguments which must be passed to the
					*        function. If called with fewer than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {integer} metadata.maxArgs
					*        The maximum number of arguments which may be passed to the
					*        function. If called with more than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function(object, ...*)}
					*       The generated wrapper function.
					*/
					const wrapAsyncFunction = (name, metadata) => {
						return function asyncFunctionWrapper(target, ...args) {
							if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
							if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
							return new Promise((resolve, reject) => {
								if (metadata.fallbackToNoCallback) try {
									target[name](...args, makeCallback({
										resolve,
										reject
									}, metadata));
								} catch (cbError) {
									console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
									target[name](...args);
									metadata.fallbackToNoCallback = false;
									metadata.noCallback = true;
									resolve();
								}
								else if (metadata.noCallback) {
									target[name](...args);
									resolve();
								} else target[name](...args, makeCallback({
									resolve,
									reject
								}, metadata));
							});
						};
					};
					/**
					* Wraps an existing method of the target object, so that calls to it are
					* intercepted by the given wrapper function. The wrapper function receives,
					* as its first argument, the original `target` object, followed by each of
					* the arguments passed to the original method.
					*
					* @param {object} target
					*        The original target object that the wrapped method belongs to.
					* @param {function} method
					*        The method being wrapped. This is used as the target of the Proxy
					*        object which is created to wrap the method.
					* @param {function} wrapper
					*        The wrapper function which is called in place of a direct invocation
					*        of the wrapped method.
					*
					* @returns {Proxy<function>}
					*        A Proxy object for the given method, which invokes the given wrapper
					*        method in its place.
					*/
					const wrapMethod = (target, method, wrapper) => {
						return new Proxy(method, { apply(targetMethod, thisObj, args) {
							return wrapper.call(thisObj, target, ...args);
						} });
					};
					let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
					/**
					* Wraps an object in a Proxy which intercepts and wraps certain methods
					* based on the given `wrappers` and `metadata` objects.
					*
					* @param {object} target
					*        The target object to wrap.
					*
					* @param {object} [wrappers = {}]
					*        An object tree containing wrapper functions for special cases. Any
					*        function present in this object tree is called in place of the
					*        method in the same location in the `target` object tree. These
					*        wrapper methods are invoked as described in {@see wrapMethod}.
					*
					* @param {object} [metadata = {}]
					*        An object tree containing metadata used to automatically generate
					*        Promise-based wrapper functions for asynchronous. Any function in
					*        the `target` object tree which has a corresponding metadata object
					*        in the same location in the `metadata` tree is replaced with an
					*        automatically-generated wrapper function, as described in
					*        {@see wrapAsyncFunction}
					*
					* @returns {Proxy<object>}
					*/
					const wrapObject = (target, wrappers = {}, metadata = {}) => {
						let cache = Object.create(null);
						return new Proxy(Object.create(target), {
							has(proxyTarget, prop) {
								return prop in target || prop in cache;
							},
							get(proxyTarget, prop, receiver) {
								if (prop in cache) return cache[prop];
								if (!(prop in target)) return;
								let value = target[prop];
								if (typeof value === "function") if (typeof wrappers[prop] === "function") value = wrapMethod(target, target[prop], wrappers[prop]);
								else if (hasOwnProperty(metadata, prop)) {
									let wrapper = wrapAsyncFunction(prop, metadata[prop]);
									value = wrapMethod(target, target[prop], wrapper);
								} else value = value.bind(target);
								else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) value = wrapObject(value, wrappers[prop], metadata[prop]);
								else if (hasOwnProperty(metadata, "*")) value = wrapObject(value, wrappers[prop], metadata["*"]);
								else {
									Object.defineProperty(cache, prop, {
										configurable: true,
										enumerable: true,
										get() {
											return target[prop];
										},
										set(value) {
											target[prop] = value;
										}
									});
									return value;
								}
								cache[prop] = value;
								return value;
							},
							set(proxyTarget, prop, value, receiver) {
								if (prop in cache) cache[prop] = value;
								else target[prop] = value;
								return true;
							},
							defineProperty(proxyTarget, prop, desc) {
								return Reflect.defineProperty(cache, prop, desc);
							},
							deleteProperty(proxyTarget, prop) {
								return Reflect.deleteProperty(cache, prop);
							}
						});
					};
					/**
					* Creates a set of wrapper functions for an event object, which handles
					* wrapping of listener functions that those messages are passed.
					*
					* A single wrapper is created for each listener function, and stored in a
					* map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
					* retrieve the original wrapper, so that  attempts to remove a
					* previously-added listener work as expected.
					*
					* @param {DefaultWeakMap<function, function>} wrapperMap
					*        A DefaultWeakMap object which will create the appropriate wrapper
					*        for a given listener function when one does not exist, and retrieve
					*        an existing one when it does.
					*
					* @returns {object}
					*/
					const wrapEvent = (wrapperMap) => ({
						addListener(target, listener, ...args) {
							target.addListener(wrapperMap.get(listener), ...args);
						},
						hasListener(target, listener) {
							return target.hasListener(wrapperMap.get(listener));
						},
						removeListener(target, listener) {
							target.removeListener(wrapperMap.get(listener));
						}
					});
					const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps an onRequestFinished listener function so that it will return a
						* `getContent()` property which returns a `Promise` rather than using a
						* callback API.
						*
						* @param {object} req
						*        The HAR entry object representing the network request.
						*/
						return function onRequestFinished(req) {
							listener(wrapObject(req, {}, { getContent: {
								minArgs: 0,
								maxArgs: 0
							} }));
						};
					});
					const onMessageWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps a message listener function so that it may send responses based on
						* its return value, rather than by returning a sentinel value and calling a
						* callback. If the listener function returns a Promise, the response is
						* sent when the promise either resolves or rejects.
						*
						* @param {*} message
						*        The message sent by the other end of the channel.
						* @param {object} sender
						*        Details about the sender of the message.
						* @param {function(*)} sendResponse
						*        A callback which, when called with an arbitrary argument, sends
						*        that value as a response.
						* @returns {boolean}
						*        True if the wrapped listener returned a Promise, which will later
						*        yield a response. False otherwise.
						*/
						return function onMessage(message, sender, sendResponse) {
							let didCallSendResponse = false;
							let wrappedSendResponse;
							let sendResponsePromise = new Promise((resolve) => {
								wrappedSendResponse = function(response) {
									didCallSendResponse = true;
									resolve(response);
								};
							});
							let result;
							try {
								result = listener(message, sender, wrappedSendResponse);
							} catch (err) {
								result = Promise.reject(err);
							}
							const isResultThenable = result !== true && isThenable(result);
							if (result !== true && !isResultThenable && !didCallSendResponse) return false;
							const sendPromisedResult = (promise) => {
								promise.then((msg) => {
									sendResponse(msg);
								}, (error) => {
									let message;
									if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
									else message = "An unexpected error occurred";
									sendResponse({
										__mozWebExtensionPolyfillReject__: true,
										message
									});
								}).catch((err) => {
									console.error("Failed to send onMessage rejected reply", err);
								});
							};
							if (isResultThenable) sendPromisedResult(result);
							else sendPromisedResult(sendResponsePromise);
							return true;
						};
					});
					const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
						if (extensionAPIs.runtime.lastError) if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
						else reject(new Error(extensionAPIs.runtime.lastError.message));
						else if (reply && reply.__mozWebExtensionPolyfillReject__) reject(new Error(reply.message));
						else resolve(reply);
					};
					const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
						if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
						if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
						return new Promise((resolve, reject) => {
							const wrappedCb = wrappedSendMessageCallback.bind(null, {
								resolve,
								reject
							});
							args.push(wrappedCb);
							apiNamespaceObj.sendMessage(...args);
						});
					};
					const staticWrappers = {
						devtools: { network: { onRequestFinished: wrapEvent(onRequestFinishedWrappers) } },
						runtime: {
							onMessage: wrapEvent(onMessageWrappers),
							onMessageExternal: wrapEvent(onMessageWrappers),
							sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
								minArgs: 1,
								maxArgs: 3
							})
						},
						tabs: { sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
							minArgs: 2,
							maxArgs: 3
						}) }
					};
					const settingMetadata = {
						clear: {
							minArgs: 1,
							maxArgs: 1
						},
						get: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					};
					apiMetadata.privacy = {
						network: { "*": settingMetadata },
						services: { "*": settingMetadata },
						websites: { "*": settingMetadata }
					};
					return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
				};
				module$1.exports = wrapAPIs(chrome);
			} else module$1.exports = globalThis.browser;
		});
	})))(), 1);
	var browser$7 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
	//#endregion
	//#region node_modules/.pnpm/async-mutex@0.5.0/node_modules/async-mutex/index.mjs
	var E_CANCELED = /* @__PURE__ */ new Error("request for lock canceled");
	var __awaiter$2 = function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	var Semaphore = class {
		constructor(_value, _cancelError = E_CANCELED) {
			this._value = _value;
			this._cancelError = _cancelError;
			this._queue = [];
			this._weightedWaiters = [];
		}
		acquire(weight = 1, priority = 0) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			return new Promise((resolve, reject) => {
				const task = {
					resolve,
					reject,
					weight,
					priority
				};
				const i = findIndexFromEnd(this._queue, (other) => priority <= other.priority);
				if (i === -1 && weight <= this._value) this._dispatchItem(task);
				else this._queue.splice(i + 1, 0, task);
			});
		}
		runExclusive(callback_1) {
			return __awaiter$2(this, arguments, void 0, function* (callback, weight = 1, priority = 0) {
				const [value, release] = yield this.acquire(weight, priority);
				try {
					return yield callback(value);
				} finally {
					release();
				}
			});
		}
		waitForUnlock(weight = 1, priority = 0) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			if (this._couldLockImmediately(weight, priority)) return Promise.resolve();
			else return new Promise((resolve) => {
				if (!this._weightedWaiters[weight - 1]) this._weightedWaiters[weight - 1] = [];
				insertSorted(this._weightedWaiters[weight - 1], {
					resolve,
					priority
				});
			});
		}
		isLocked() {
			return this._value <= 0;
		}
		getValue() {
			return this._value;
		}
		setValue(value) {
			this._value = value;
			this._dispatchQueue();
		}
		release(weight = 1) {
			if (weight <= 0) throw new Error(`invalid weight ${weight}: must be positive`);
			this._value += weight;
			this._dispatchQueue();
		}
		cancel() {
			this._queue.forEach((entry) => entry.reject(this._cancelError));
			this._queue = [];
		}
		_dispatchQueue() {
			this._drainUnlockWaiters();
			while (this._queue.length > 0 && this._queue[0].weight <= this._value) {
				this._dispatchItem(this._queue.shift());
				this._drainUnlockWaiters();
			}
		}
		_dispatchItem(item) {
			const previousValue = this._value;
			this._value -= item.weight;
			item.resolve([previousValue, this._newReleaser(item.weight)]);
		}
		_newReleaser(weight) {
			let called = false;
			return () => {
				if (called) return;
				called = true;
				this.release(weight);
			};
		}
		_drainUnlockWaiters() {
			if (this._queue.length === 0) for (let weight = this._value; weight > 0; weight--) {
				const waiters = this._weightedWaiters[weight - 1];
				if (!waiters) continue;
				waiters.forEach((waiter) => waiter.resolve());
				this._weightedWaiters[weight - 1] = [];
			}
			else {
				const queuedPriority = this._queue[0].priority;
				for (let weight = this._value; weight > 0; weight--) {
					const waiters = this._weightedWaiters[weight - 1];
					if (!waiters) continue;
					const i = waiters.findIndex((waiter) => waiter.priority <= queuedPriority);
					(i === -1 ? waiters : waiters.splice(0, i)).forEach(((waiter) => waiter.resolve()));
				}
			}
		}
		_couldLockImmediately(weight, priority) {
			return (this._queue.length === 0 || this._queue[0].priority < priority) && weight <= this._value;
		}
	};
	function insertSorted(a, v) {
		const i = findIndexFromEnd(a, (other) => v.priority <= other.priority);
		a.splice(i + 1, 0, v);
	}
	function findIndexFromEnd(a, predicate) {
		for (let i = a.length - 1; i >= 0; i--) if (predicate(a[i])) return i;
		return -1;
	}
	var __awaiter$1 = function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	var Mutex = class {
		constructor(cancelError) {
			this._semaphore = new Semaphore(1, cancelError);
		}
		acquire() {
			return __awaiter$1(this, arguments, void 0, function* (priority = 0) {
				const [, releaser] = yield this._semaphore.acquire(1, priority);
				return releaser;
			});
		}
		runExclusive(callback, priority = 0) {
			return this._semaphore.runExclusive(() => callback(), 1, priority);
		}
		isLocked() {
			return this._semaphore.isLocked();
		}
		waitForUnlock(priority = 0) {
			return this._semaphore.waitForUnlock(1, priority);
		}
		release() {
			if (this._semaphore.isLocked()) this._semaphore.release();
		}
		cancel() {
			return this._semaphore.cancel();
		}
	};
	//#endregion
	//#region node_modules/.pnpm/dequal@2.0.3/node_modules/dequal/lite/index.mjs
	var has$1 = Object.prototype.hasOwnProperty;
	function dequal(foo, bar) {
		var ctor, len;
		if (foo === bar) return true;
		if (foo && bar && (ctor = foo.constructor) === bar.constructor) {
			if (ctor === Date) return foo.getTime() === bar.getTime();
			if (ctor === RegExp) return foo.toString() === bar.toString();
			if (ctor === Array) {
				if ((len = foo.length) === bar.length) while (len-- && dequal(foo[len], bar[len]));
				return len === -1;
			}
			if (!ctor || typeof foo === "object") {
				len = 0;
				for (ctor in foo) {
					if (has$1.call(foo, ctor) && ++len && !has$1.call(bar, ctor)) return false;
					if (!(ctor in bar) || !dequal(foo[ctor], bar[ctor])) return false;
				}
				return Object.keys(bar).length === len;
			}
		}
		return foo !== foo && bar !== bar;
	}
	//#endregion
	//#region node_modules/.pnpm/@wxt-dev+storage@1.2.8/node_modules/@wxt-dev/storage/dist/index.mjs
	/**
	* Simplified storage APIs with support for versioned fields, snapshots, metadata, and item definitions.
	*
	* See [the guide](https://wxt.dev/storage.html) for more information.
	* @module @wxt-dev/storage
	*/
	var storage = createStorage();
	function createStorage() {
		const drivers = {
			local: createDriver("local"),
			session: createDriver("session"),
			sync: createDriver("sync"),
			managed: createDriver("managed")
		};
		const getDriver = (area) => {
			const driver = drivers[area];
			if (driver == null) {
				const areaNames = Object.keys(drivers).join(", ");
				throw Error(`Invalid area "${area}". Options: ${areaNames}`);
			}
			return driver;
		};
		const resolveKey = (key) => {
			const deliminatorIndex = key.indexOf(":");
			const driverArea = key.substring(0, deliminatorIndex);
			const driverKey = key.substring(deliminatorIndex + 1);
			if (driverKey == null) throw Error(`Storage key should be in the form of "area:key", but received "${key}"`);
			return {
				driverArea,
				driverKey,
				driver: getDriver(driverArea)
			};
		};
		const getMetaKey = (key) => key + "$";
		const mergeMeta = (oldMeta, newMeta) => {
			const newFields = { ...oldMeta };
			Object.entries(newMeta).forEach(([key, value]) => {
				if (value == null) delete newFields[key];
				else newFields[key] = value;
			});
			return newFields;
		};
		const getValueOrFallback = (value, fallback) => value ?? fallback ?? null;
		const getMetaValue = (properties) => typeof properties === "object" && !Array.isArray(properties) ? properties : {};
		const getItem = async (driver, driverKey, opts) => {
			return getValueOrFallback(await driver.getItem(driverKey), opts?.fallback ?? opts?.defaultValue);
		};
		const getMeta = async (driver, driverKey) => {
			const metaKey = getMetaKey(driverKey);
			return getMetaValue(await driver.getItem(metaKey));
		};
		const setItem = async (driver, driverKey, value) => {
			await driver.setItem(driverKey, value ?? null);
		};
		const setMeta = async (driver, driverKey, properties) => {
			const metaKey = getMetaKey(driverKey);
			const existingFields = getMetaValue(await driver.getItem(metaKey));
			await driver.setItem(metaKey, mergeMeta(existingFields, properties));
		};
		const removeItem = async (driver, driverKey, opts) => {
			await driver.removeItem(driverKey);
			if (opts?.removeMeta) {
				const metaKey = getMetaKey(driverKey);
				await driver.removeItem(metaKey);
			}
		};
		const removeMeta = async (driver, driverKey, properties) => {
			const metaKey = getMetaKey(driverKey);
			if (properties == null) await driver.removeItem(metaKey);
			else {
				const newFields = getMetaValue(await driver.getItem(metaKey));
				[properties].flat().forEach((field) => delete newFields[field]);
				await driver.setItem(metaKey, newFields);
			}
		};
		const watch = (driver, driverKey, cb) => driver.watch(driverKey, cb);
		return {
			getItem: async (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				return await getItem(driver, driverKey, opts);
			},
			getItems: async (keys) => {
				const areaToKeyMap = /* @__PURE__ */ new Map();
				const keyToOptsMap = /* @__PURE__ */ new Map();
				const orderedKeys = [];
				keys.forEach((key) => {
					let keyStr;
					let opts;
					if (typeof key === "string") keyStr = key;
					else if ("getValue" in key) {
						keyStr = key.key;
						opts = { fallback: key.fallback };
					} else {
						keyStr = key.key;
						opts = key.options;
					}
					orderedKeys.push(keyStr);
					const { driverArea, driverKey } = resolveKey(keyStr);
					const areaKeys = areaToKeyMap.get(driverArea) ?? [];
					areaToKeyMap.set(driverArea, areaKeys.concat(driverKey));
					keyToOptsMap.set(keyStr, opts);
				});
				const resultsMap = /* @__PURE__ */ new Map();
				await Promise.all(Array.from(areaToKeyMap.entries()).map(async ([driverArea, keys]) => {
					(await drivers[driverArea].getItems(keys)).forEach((driverResult) => {
						const key = `${driverArea}:${driverResult.key}`;
						const opts = keyToOptsMap.get(key);
						const value = getValueOrFallback(driverResult.value, opts?.fallback ?? opts?.defaultValue);
						resultsMap.set(key, value);
					});
				}));
				return orderedKeys.map((key) => ({
					key,
					value: resultsMap.get(key)
				}));
			},
			getMeta: async (key) => {
				const { driver, driverKey } = resolveKey(key);
				return await getMeta(driver, driverKey);
			},
			getMetas: async (args) => {
				const keys = args.map((arg) => {
					const key = typeof arg === "string" ? arg : arg.key;
					const { driverArea, driverKey } = resolveKey(key);
					return {
						key,
						driverArea,
						driverKey,
						driverMetaKey: getMetaKey(driverKey)
					};
				});
				const areaToDriverMetaKeysMap = keys.reduce((map, key) => {
					map[key.driverArea] ??= [];
					map[key.driverArea].push(key);
					return map;
				}, {});
				const resultsMap = {};
				await Promise.all(Object.entries(areaToDriverMetaKeysMap).map(async ([area, keys]) => {
					const areaRes = await browser$7.storage[area].get(keys.map((key) => key.driverMetaKey));
					keys.forEach((key) => {
						resultsMap[key.key] = areaRes[key.driverMetaKey] ?? {};
					});
				}));
				return keys.map((key) => ({
					key: key.key,
					meta: resultsMap[key.key]
				}));
			},
			setItem: async (key, value) => {
				const { driver, driverKey } = resolveKey(key);
				await setItem(driver, driverKey, value);
			},
			setItems: async (items) => {
				const areaToKeyValueMap = {};
				items.forEach((item) => {
					const { driverArea, driverKey } = resolveKey("key" in item ? item.key : item.item.key);
					areaToKeyValueMap[driverArea] ??= [];
					areaToKeyValueMap[driverArea].push({
						key: driverKey,
						value: item.value
					});
				});
				await Promise.all(Object.entries(areaToKeyValueMap).map(async ([driverArea, values]) => {
					await getDriver(driverArea).setItems(values);
				}));
			},
			setMeta: async (key, properties) => {
				const { driver, driverKey } = resolveKey(key);
				await setMeta(driver, driverKey, properties);
			},
			setMetas: async (items) => {
				const areaToMetaUpdatesMap = {};
				items.forEach((item) => {
					const { driverArea, driverKey } = resolveKey("key" in item ? item.key : item.item.key);
					areaToMetaUpdatesMap[driverArea] ??= [];
					areaToMetaUpdatesMap[driverArea].push({
						key: driverKey,
						properties: item.meta
					});
				});
				await Promise.all(Object.entries(areaToMetaUpdatesMap).map(async ([storageArea, updates]) => {
					const driver = getDriver(storageArea);
					const metaKeys = updates.map(({ key }) => getMetaKey(key));
					const existingMetas = await driver.getItems(metaKeys);
					const existingMetaMap = Object.fromEntries(existingMetas.map(({ key, value }) => [key, getMetaValue(value)]));
					const metaUpdates = updates.map(({ key, properties }) => {
						const metaKey = getMetaKey(key);
						return {
							key: metaKey,
							value: mergeMeta(existingMetaMap[metaKey] ?? {}, properties)
						};
					});
					await driver.setItems(metaUpdates);
				}));
			},
			removeItem: async (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				await removeItem(driver, driverKey, opts);
			},
			removeItems: async (keys) => {
				const areaToKeysMap = {};
				keys.forEach((key) => {
					let keyStr;
					let opts;
					if (typeof key === "string") keyStr = key;
					else if ("getValue" in key) keyStr = key.key;
					else if ("item" in key) {
						keyStr = key.item.key;
						opts = key.options;
					} else {
						keyStr = key.key;
						opts = key.options;
					}
					const { driverArea, driverKey } = resolveKey(keyStr);
					areaToKeysMap[driverArea] ??= [];
					areaToKeysMap[driverArea].push(driverKey);
					if (opts?.removeMeta) areaToKeysMap[driverArea].push(getMetaKey(driverKey));
				});
				await Promise.all(Object.entries(areaToKeysMap).map(async ([driverArea, keys]) => {
					await getDriver(driverArea).removeItems(keys);
				}));
			},
			clear: async (base) => {
				await getDriver(base).clear();
			},
			removeMeta: async (key, properties) => {
				const { driver, driverKey } = resolveKey(key);
				await removeMeta(driver, driverKey, properties);
			},
			snapshot: async (base, opts) => {
				const data = await getDriver(base).snapshot();
				opts?.excludeKeys?.forEach((key) => {
					delete data[key];
					delete data[getMetaKey(key)];
				});
				return data;
			},
			restoreSnapshot: async (base, data) => {
				await getDriver(base).restoreSnapshot(data);
			},
			watch: (key, cb) => {
				const { driver, driverKey } = resolveKey(key);
				return watch(driver, driverKey, cb);
			},
			unwatch() {
				Object.values(drivers).forEach((driver) => {
					driver.unwatch();
				});
			},
			defineItem: (key, opts) => {
				const { driver, driverKey } = resolveKey(key);
				const { version: targetVersion = 1, migrations = {}, onMigrationComplete, debug = false } = opts ?? {};
				if (targetVersion < 1) throw Error("Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.");
				let needsVersionSet = false;
				const migrate = async () => {
					const driverMetaKey = getMetaKey(driverKey);
					const [{ value }, { value: meta }] = await driver.getItems([driverKey, driverMetaKey]);
					needsVersionSet = value == null && meta?.v == null && !!targetVersion;
					if (value == null) return;
					const currentVersion = meta?.v ?? 1;
					if (currentVersion > targetVersion) throw Error(`Version downgrade detected (v${currentVersion} -> v${targetVersion}) for "${key}"`);
					if (currentVersion === targetVersion) return;
					if (debug) console.debug(`[@wxt-dev/storage] Running storage migration for ${key}: v${currentVersion} -> v${targetVersion}`);
					const migrationsToRun = Array.from({ length: targetVersion - currentVersion }, (_, i) => currentVersion + i + 1);
					let migratedValue = value;
					for (const migrateToVersion of migrationsToRun) try {
						migratedValue = await migrations?.[migrateToVersion]?.(migratedValue) ?? migratedValue;
						if (debug) console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${migrateToVersion}`);
					} catch (err) {
						throw new MigrationError(key, migrateToVersion, { cause: err });
					}
					await driver.setItems([{
						key: driverKey,
						value: migratedValue
					}, {
						key: driverMetaKey,
						value: {
							...meta,
							v: targetVersion
						}
					}]);
					if (debug) console.debug(`[@wxt-dev/storage] Storage migration completed for ${key} v${targetVersion}`, { migratedValue });
					onMigrationComplete?.(migratedValue, targetVersion);
				};
				const migrationsDone = opts?.migrations == null ? Promise.resolve() : migrate().catch((err) => {
					console.error(`[@wxt-dev/storage] Migration failed for ${key}`, err);
				});
				const initMutex = new Mutex();
				const getFallback = () => opts?.fallback ?? opts?.defaultValue ?? null;
				const getOrInitValue = () => initMutex.runExclusive(async () => {
					const value = await driver.getItem(driverKey);
					if (value != null || opts?.init == null) return value;
					const newValue = await opts.init();
					await driver.setItem(driverKey, newValue);
					if (value == null && targetVersion > 1) await setMeta(driver, driverKey, { v: targetVersion });
					return newValue;
				});
				migrationsDone.then(getOrInitValue);
				return {
					key,
					get defaultValue() {
						return getFallback();
					},
					get fallback() {
						return getFallback();
					},
					getValue: async () => {
						await migrationsDone;
						if (opts?.init) return await getOrInitValue();
						else return await getItem(driver, driverKey, opts);
					},
					getMeta: async () => {
						await migrationsDone;
						return await getMeta(driver, driverKey);
					},
					setValue: async (value) => {
						await migrationsDone;
						if (needsVersionSet) {
							needsVersionSet = false;
							await Promise.all([setItem(driver, driverKey, value), setMeta(driver, driverKey, { v: targetVersion })]);
						} else await setItem(driver, driverKey, value);
					},
					setMeta: async (properties) => {
						await migrationsDone;
						return await setMeta(driver, driverKey, properties);
					},
					removeValue: async (opts) => {
						await migrationsDone;
						return await removeItem(driver, driverKey, opts);
					},
					removeMeta: async (properties) => {
						await migrationsDone;
						return await removeMeta(driver, driverKey, properties);
					},
					watch: (cb) => watch(driver, driverKey, (newValue, oldValue) => cb(newValue ?? getFallback(), oldValue ?? getFallback())),
					migrate
				};
			}
		};
	}
	function createDriver(storageArea) {
		const getStorageArea = () => {
			if (browser$7.runtime == null) throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);
			if (browser$7.storage == null) throw Error("You must add the 'storage' permission to your manifest to use 'wxt/storage'");
			const area = browser$7.storage[storageArea];
			if (area == null) throw Error(`"browser.storage.${storageArea}" is undefined`);
			return area;
		};
		const watchListeners = /* @__PURE__ */ new Set();
		return {
			getItem: async (key) => {
				return (await getStorageArea().get(key))[key];
			},
			getItems: async (keys) => {
				const result = await getStorageArea().get(keys);
				return keys.map((key) => ({
					key,
					value: result[key] ?? null
				}));
			},
			setItem: async (key, value) => {
				if (value == null) await getStorageArea().remove(key);
				else await getStorageArea().set({ [key]: value });
			},
			setItems: async (values) => {
				const map = values.reduce((map, { key, value }) => {
					map[key] = value;
					return map;
				}, {});
				await getStorageArea().set(map);
			},
			removeItem: async (key) => {
				await getStorageArea().remove(key);
			},
			removeItems: async (keys) => {
				await getStorageArea().remove(keys);
			},
			clear: async () => {
				await getStorageArea().clear();
			},
			snapshot: async () => {
				return await getStorageArea().get();
			},
			restoreSnapshot: async (data) => {
				await getStorageArea().set(data);
			},
			watch(key, cb) {
				const listener = (changes) => {
					const change = changes[key];
					if (change == null || dequal(change.newValue, change.oldValue)) return;
					cb(change.newValue ?? null, change.oldValue ?? null);
				};
				getStorageArea().onChanged.addListener(listener);
				watchListeners.add(listener);
				return () => {
					getStorageArea().onChanged.removeListener(listener);
					watchListeners.delete(listener);
				};
			},
			unwatch() {
				watchListeners.forEach((listener) => {
					getStorageArea().onChanged.removeListener(listener);
				});
				watchListeners.clear();
			}
		};
	}
	var MigrationError = class extends Error {
		constructor(key, version, options) {
			super(`v${version} migration failed for "${key}"`, options);
			this.key = key;
			this.version = version;
		}
	};
	//#endregion
	//#region src/entrypoints/utils/config.ts
	var defaultConfig = {
		sourceLang: "auto",
		targetLang: "zh",
		deepseekApiKey: "",
		provider: "deepseek",
		promptStyle: "default",
		shortcuts: {
			translatePage: "Alt+T",
			translateSelection: "Alt+S",
			restoreOriginal: "Alt+R",
			toggleTranslation: "Alt+V"
		},
		useServerTranslation: false,
		serverUrl: "https://s.sunxiunan.com/fanyi/page"
	};
	async function getConfig() {
		const config = await storage.getItem("local:config");
		return {
			...defaultConfig,
			...config
		};
	}
	//#endregion
	//#region src/entrypoints/content/styles.ts
	/**
	* content script 注入页面的全部 CSS。
	*
	* 之所以单独抽出：
	*  - 主文件减少 60+ 行模板字符串，专注业务逻辑
	*  - 改样式时不用在 1000 行文件里翻找
	*  - 移动/桌面分支（isMobile）只在一处集中处理
	*
	* 类名约定（避免与站点样式冲突，全部加 fanyi- 前缀）：
	*   fanyi-status-overlay  状态提示条
	*   fanyi-loading/success/error 状态条颜色
	*   fanyi-original/translation/missing  翻译渲染
	*   fanyi-config-panel   配置面板
	*   fanyi-btn-save/translate/restore 配置面板按钮
	*/
	function getStyles(isMobile) {
		return `
    .fanyi-status-overlay {
      position: fixed;
      bottom: ${isMobile ? "70px" : "24px"};
      left: 50%;
      transform: translateX(-50%);
      padding: ${isMobile ? "10px 20px" : "14px 28px"};
      background: rgba(0, 0, 0, 0.72);
      color: rgba(255, 255, 255, 0.96);
      border-radius: 24px;
      z-index: 999999;
      font-size: ${isMobile ? "14px" : "16px"};
      font-weight: 500;
      display: none;
      max-width: 80%;
      text-align: center;
      pointer-events: none;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    }
    .fanyi-loading { border: 1px solid rgba(64, 158, 255, 0.3); }
    .fanyi-success { border: 1px solid rgba(103, 194, 58, 0.3); }
    .fanyi-error { border: 1px solid rgba(245, 108, 108, 0.3); }

    .fanyi-original {
      display: block;
    }
    .fanyi-translation {
      display: block;
    }
    /* 未翻译成功的段落：黄色高亮 + help 光标，鼠标悬停时由 title 提示原因。 */
    .fanyi-missing {
      background: linear-gradient(transparent 60%, rgba(255, 215, 0, 0.35) 60%);
      cursor: help;
    }

    .fanyi-btn-save,
    .fanyi-btn-translate,
    .fanyi-btn-restore {
      flex: 1;
      padding: ${isMobile ? "8px 10px" : "10px 12px"};
      border: 1px solid #e0e0e0;
      border-radius: 10px;
      background: white;
      cursor: pointer;
      font-size: ${isMobile ? "12px" : "13px"};
      font-weight: 600;
      white-space: nowrap;
    }
    .fanyi-btn-save {
      background: linear-gradient(135deg, #409eff, #66b1ff);
      color: white;
      border: none;
    }
    .fanyi-btn-translate {
      background: linear-gradient(135deg, #67c23a, #85ce61);
      color: white;
      border: none;
    }
    .fanyi-btn-restore {
      background: linear-gradient(135deg, #e6a23c, #ebb563);
      color: white;
      border: none;
    }
    .fanyi-btn-save:active,
    .fanyi-btn-translate:active,
    .fanyi-btn-restore:active {
      opacity: 0.8;
      transform: scale(0.98);
    }

    /* 低优先级元素视觉弱化（保留 DOM，hover 恢复） */
    [data-fanyi-low-priority="true"] {
      opacity: 0.35 !important;
      filter: grayscale(60%) !important;
      transition: opacity 0.2s ease, filter 0.2s ease !important;
    }
    [data-fanyi-low-priority="true"]:hover {
      opacity: 1 !important;
      filter: none !important;
    }

    /* 弹窗 / overlay / cookie banner 直接隐藏 */
    [data-fanyi-remove="true"] {
      display: none !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }

    /* 动态注入的通知/订阅弹窗兜底隐藏（InfoWorld 等站点的 subscribers notification prompt） */
    [class*="notification"], [id*="notification"],
    [class*="subscribers"], [id*="subscribers"],
    [class*="push-notification"], [id*="push-notification"] {
      display: none !important;
    }
  `;
	}
	//#endregion
	//#region src/entrypoints/content/statusOverlay.ts
	/**
	* 屏幕底部居中显示的状态提示条（小气泡）。
	*
	* 用于在翻译流程中提示用户：
	*   - "正在提取文本..."
	*   - "翻译进度: 3/5"
	*   - "翻译完成"
	*   - "API Key 无效"
	*
	* 使用场景：
	*   - 任何需要"轻提示用户但不阻塞操作"的反馈
	*   - 默认 2-3 秒后自动隐藏（调用方控制 setTimeout）
	*
	* 注意：translationOverlay 缓存在模块级单例，因为页面同时只会显示一个气泡。
	*/
	var translationOverlay = null;
	/**
	* 显示一条状态提示。如已存在则替换文案 + 颜色类。
	* 不会自动隐藏，需调用方在合适的时机调用 hideStatus()。
	*/
	function showStatus(message, type) {
		if (!translationOverlay) {
			translationOverlay = document.createElement("div");
			translationOverlay.className = "fanyi-status-overlay";
			document.body.appendChild(translationOverlay);
		}
		translationOverlay.className = `fanyi-status-overlay fanyi-${type}`;
		translationOverlay.textContent = message;
		translationOverlay.removeAttribute("data-fanyi-remove");
		translationOverlay.style.setProperty("display", "flex", "important");
	}
	/** 隐藏状态条（不销毁 DOM，下一次 showStatus 可复用）。 */
	function hideStatus() {
		if (translationOverlay) translationOverlay.style.display = "none";
	}
	//#endregion
	//#region src/entrypoints/content/floatingButton.ts
	/**
	* 切换按钮的"已翻译"状态：
	*   - 译（灰色） ↔ 原（绿色 + fanyi-btn-translated）
	*   - title 文案也对应变化
	*/
	function updateButtonState(isTranslated) {
		const btn = document.querySelector(".fanyi-floating-btn");
		if (!btn) return;
		if (isTranslated) {
			btn.innerHTML = "原";
			btn.title = "已翻译，点击恢复原文，长按设置";
			btn.classList.add("fanyi-btn-translated");
		} else {
			btn.innerHTML = "译";
			btn.title = "点击翻译，长按设置";
			btn.classList.remove("fanyi-btn-translated");
		}
	}
	var PATTERNS = {
		TUPLE: /\[\s*['"][^'"]+['"]\s*,\s*-?\d+(?:\.\d+)?\s*\]/g,
		BASE64: /^[A-Za-z0-9+/=_-]{200,}$/,
		UI_TEXT: /^[A-Z0-9\s]+$/,
		DIGIT_SPACE: /^[0-9\s]+$/,
		HEADING: /^H[1-6]$/
	};
	var DIRECT_SET = new Set([
		"h1",
		"h2",
		"h3",
		"h4",
		"h5",
		"h6",
		"p",
		"li",
		"dd",
		"blockquote",
		"figcaption"
	]);
	var SKIP_SET = new Set([
		"html",
		"head",
		"body",
		"title",
		"meta",
		"link",
		"base",
		"script",
		"style",
		"noscript",
		"iframe",
		"template",
		"slot",
		"embed",
		"object",
		"param",
		"video",
		"audio",
		"track",
		"source",
		"picture",
		"map",
		"area",
		"input",
		"textarea",
		"code",
		"pre",
		"kbd",
		"samp",
		"var",
		"tt",
		"table",
		"thead",
		"tbody",
		"tfoot",
		"tr",
		"td",
		"th",
		"caption",
		"col",
		"colgroup",
		"dt"
	]);
	var SEMANTIC_SKIP_TAGS = new Set([
		"header",
		"footer",
		"aside",
		"nav",
		"search",
		"dialog",
		"address"
	]);
	var INLINE_SET = new Set([
		"a",
		"abbr",
		"b",
		"bdi",
		"bdo",
		"br",
		"cite",
		"code",
		"data",
		"dfn",
		"em",
		"i",
		"kbd",
		"mark",
		"q",
		"s",
		"samp",
		"small",
		"span",
		"strong",
		"sub",
		"sup",
		"time",
		"u",
		"var",
		"wbr",
		"ruby",
		"rb",
		"rt",
		"rp",
		"del",
		"ins",
		"font",
		"tt",
		"big",
		"strike",
		"mdspan",
		"img"
	]);
	/**
	* 跳过类名列表 (小写,精确匹配 + 前后缀分隔符匹配)。
	* 大小写不敏感。
	*/
	var SKIP_CLASS_PATTERNS = [
		"sidebar",
		"side-bar",
		"sideBar",
		"nav-menu",
		"main-menu",
		"navigation-menu",
		"mobile-nav",
		"channels-nav",
		"topics-nav",
		"nav-topics",
		"footer-wrap",
		"post-footer",
		"site-footer",
		"footer",
		"footnote",
		"copyright",
		"content-column-post-footer",
		"content-column-mobile-footer",
		"site-header",
		"site-top",
		"top-bar",
		"topbar",
		"masthead",
		"site-branding",
		"site-logo",
		"header-top",
		"header-main",
		"breadcrumb",
		"byline",
		"post-meta",
		"author-box",
		"subscribe-widget",
		"widget-area",
		"subscribe-",
		"login-form",
		"login-box",
		"login-bar",
		"loginbar",
		"signin-form",
		"signup-form",
		"register-form",
		"registration",
		"auth-form",
		"auth-box",
		"user-area",
		"user-menu",
		"user-profile",
		"member-area",
		"membership",
		"newsletter-signup",
		"newsletter-form",
		"newsletter-subscribe",
		"newsletter-popup",
		"newsletter-overlay",
		"newsletter-modal",
		"email-signup",
		"email-subscribe",
		"email-capture",
		"signup-form",
		"inline-signup",
		"inline_newsletter",
		"inline-newsletter",
		"inline-subscribe",
		"inline-subscription",
		"embed-signup",
		"embed-newsletter",
		"embed-subscribe",
		"ad-container",
		"ad-slot",
		"ads-box",
		"advertisement",
		"adsbygoogle",
		"google-ad",
		"google-ads",
		"dfp-ad",
		"dfp-unit",
		"gpt-ad",
		"div-gpt-ad",
		"ad-wrapper",
		"ad-panel",
		"ad-frame",
		"ad-box",
		"ad-inner",
		"ad-holder",
		"ad-banner",
		"ad-placeholder",
		"ad-label",
		"ad-unit",
		"ad-widget",
		"ad-area",
		"ad-div",
		"ad-code",
		"ad-block",
		"ad-content",
		"ad-outer",
		"adslot",
		"adunit",
		"adbox",
		"advert",
		"advertorial",
		"adv",
		"display-ad",
		"display-ads",
		"header-ad",
		"footer-ad",
		"sticky-ad",
		"in-article-ad",
		"inline-ad",
		"incontent-ad",
		"incontent-ads",
		"ezoic-ad",
		"ezoic-pub",
		"freestar-ad",
		"leaderboard",
		"skyscraper",
		"taboola",
		"taboola-widget",
		"trc",
		"outbrain",
		"outbrain-widget",
		"ob-widget",
		"mgid",
		"mgbox",
		"marketgid",
		"revcontent",
		"rev-content",
		"zergnet",
		"zergnet-widget",
		"rc-widget",
		"native-ad",
		"nativead",
		"native-ads",
		"hybrid-ad",
		"hybrid-ad-wrapper",
		"hybrid_ad_wrapper",
		"hybridad",
		"content-recommendation",
		"recommended-content",
		"sponsored",
		"sponsored-content",
		"sponsored-post",
		"sponsored-link",
		"sponsored-links",
		"promoted",
		"promoted-content",
		"promoted-post",
		"paid-content",
		"paid-post",
		"affiliate",
		"affiliate-link",
		"commercial",
		"commercial-content",
		"cookie-consent",
		"cookie-banner",
		"cookie-notice",
		"cookie-policy",
		"cookie-table",
		"cookie-settings",
		"cookie-bar",
		"cookie-box",
		"cookie-modal",
		"cookie-container",
		"cookie-popup",
		"cookie-overlay",
		"cookie-wrapper",
		"cookie-law",
		"cookie-disclaimer",
		"cookie-management",
		"cookie-accept",
		"cookie-compliance",
		"cookie-control",
		"cookies-modal",
		"cookies-wrapper",
		"cookie__wrap",
		"coockies",
		"modal-cookie",
		"modal-cookies",
		"cookie-div",
		"cc-window",
		"cc-banner",
		"cc-overlay",
		"cc-container",
		"cc-floating",
		"cmpbox",
		"cmpwrapper",
		"cmp",
		"klaro",
		"onetrust-banner",
		"onetrust-pc",
		"onetrust-overlay",
		"ot-sdk",
		"ot-pc",
		"onetrust",
		"ot-cookie",
		"ot-policy",
		"ot-category",
		"ot-floating",
		"borlabs-cookie",
		"brlbs",
		"cmplz",
		"cmplz-cookie",
		"cmplz-manage",
		"moove-gdpr",
		"cli-modal",
		"cli-popup",
		"cli-bar",
		"wt-cli",
		"cky-consent",
		"cky-notice",
		"cky-modal",
		"cky-banner",
		"wpfront-notification-bar",
		"gdpr",
		"gdpr-banner",
		"gdpr-consent",
		"gdpr-modal",
		"gdpr-overlay",
		"gdpr-mask",
		"privacy",
		"privacy-policy",
		"privacy-notice",
		"privacy-pref",
		"privacy-popup",
		"privacy-modal",
		"privacy-info",
		"data-protection",
		"data-privacy",
		"data-consent",
		"consent",
		"consent-banner",
		"consent-container",
		"consent-modal",
		"consent-overlay",
		"consent-popup",
		"consent-wrapper",
		"outer-consent",
		"opt-in",
		"optin",
		"eucookie",
		"euc",
		"cnil",
		"ccpa",
		"lgpd",
		"rodo",
		"hinweis",
		"confidentialite",
		"disclaimer",
		"disclamer",
		"disclaimer-container",
		"cookieman",
		"cookiemgmt",
		"cookie-management",
		"cbar",
		"cono",
		"coo",
		"cook",
		"lawdiv",
		"cookie-law-info",
		"banner-ad",
		"popup-overlay",
		"modal-dialog",
		"modal-backdrop",
		"social-share",
		"share-buttons",
		"share-menu",
		"share-list",
		"share-icons",
		"social-icons",
		"social-icon-list",
		"social-share-list",
		"share-toolbar",
		"trending-stories",
		"tns-trending-stories-block",
		"related-posts",
		"related-articles",
		"related-content",
		"more-stories",
		"more-articles",
		"also-read",
		"you-may-like",
		"read-next",
		"read-more",
		"read_more",
		"readmore",
		"reading-list",
		"reading_list",
		"readinglist",
		"recommended-reading",
		"recommended_reading",
		"recommendedreading",
		"recommended-articles",
		"recommended_articles",
		"more-from",
		"more_from",
		"morefrom",
		"storylines-carousel",
		"storylines-carousel-wrapper",
		"storylines-carousel-block",
		"article-carousel",
		"article-carousel-wrapper",
		"inline-carousel",
		"related-carousel",
		"related-stories",
		"more-stories-carousel",
		"comment-list",
		"comment-section",
		"comment-area",
		"comment-module",
		"comment-wrapper",
		"comment-body",
		"comment-content",
		"comment-form",
		"comment-reply",
		"comment-thread",
		"comment-holder",
		"comment-entry",
		"comments-area",
		"comments-section",
		"comments-wrapper",
		"commentlist",
		"discussion",
		"search-form",
		"search-box",
		"search-bar",
		"searchbar",
		"search-input",
		"search-wrapper",
		"search-widget",
		"search-container",
		"search-results",
		"pagination",
		"pager",
		"paging",
		"page-nav",
		"page-numbers",
		"nav-links",
		"post-navigation",
		"toc",
		"table-of-contents",
		"toc-container",
		"toc-widget",
		"lang-switcher",
		"language-switcher",
		"language-selector",
		"lang-select",
		"lang-selector",
		"locale-switcher",
		"locale-selector",
		"post-article-wrapper",
		"post_article_wrapper",
		"postarticlewrapper",
		"post-content-wrapper",
		"after-article",
		"after-article-wrapper",
		"below-content",
		"below-content-wrapper",
		"article-footer-widgets",
		"printed-branding",
		"print-branding",
		"printed-logo",
		"print-logo",
		"print-only",
		"print-version",
		"printable",
		"tagcloud",
		"tags-list",
		"tag-list",
		"categories-list",
		"category-list",
		"taxonomy-list",
		"meta-tags",
		"entry-tags",
		"captcha",
		"g-recaptcha",
		"recaptcha",
		"h-captcha",
		"hcaptcha",
		"turnstile",
		"post-date",
		"entry-date",
		"entry-time",
		"published-date",
		"published-time",
		"posted-on",
		"updated-on",
		"rating-widget",
		"rating-box",
		"rating-container",
		"star-rating",
		"user-rating",
		"review-widget",
		"review-box",
		"review-form",
		"reviews-widget",
		"reviews-list",
		"poll",
		"voting",
		"vote-widget",
		"survey",
		"exit-popup",
		"exit-intent",
		"welcome-popup",
		"welcome-mat",
		"notranslate"
	];
	var METADATA_TOKENS = new Set([
		"meta",
		"author",
		"byline",
		"category",
		"categories",
		"dateline"
	]);
	var CONTENT_TOKENS = new Set([
		"post",
		"content",
		"article",
		"story",
		"entry",
		"rich"
	]);
	var ARTICLE_CONTAINER_CLASS_PATTERNS = [
		"article-content",
		"article-body",
		"article-text",
		"story-content",
		"story-body",
		"story-text",
		"main-content",
		"content-body",
		"content-area",
		"post-content",
		"entry-content",
		"page-content"
	];
	var COOKIE_BANNER_TEXT_PATTERNS = new Set([
		"accept all",
		"reject all",
		"allow all",
		"cookie settings",
		"cookie preferences",
		"manage cookies",
		"manage your cookies",
		"we use cookies",
		"uses cookies",
		"cookie policy",
		"privacy settings",
		"your privacy choices",
		"consent preferences"
	]);
	var AD_IFRAME_PATTERNS = new Set([
		"googlesyndication",
		"doubleclick",
		"adsystem",
		"googleadservices",
		"taboola",
		"outbrain",
		"criteo",
		"amazon-adsystem",
		"facebook.com/tr",
		"analytics"
	]);
	/**
	* 常见标准广告位尺寸 (宽 x 高, 像素)。
	* 配合容差 (±5px) 识别固定尺寸广告位。
	*/
	var AD_SIZE_PATTERNS = [
		[300, 250],
		[728, 90],
		[970, 90],
		[970, 250],
		[160, 600],
		[300, 600],
		[320, 50],
		[320, 100],
		[468, 60],
		[120, 600],
		[250, 250],
		[200, 200]
	];
	/**
	* Popup / Modal / Floating Banner 的 style 特征阈值。
	*/
	var POPUP_STYLE_DETECTION = {
		/** z-index 超过此值才认为是弹窗。 */
		MIN_Z_INDEX: 1e3,
		/** 覆盖视口面积比例超过此值才认为是弹窗 (避免误判固定导航栏)。 */
		MIN_VIEWPORT_COVER_RATIO: .15,
		/** 最小 pixel 面积,避免很小的 fixed 图标被误判。 */
		MIN_AREA_PX: 1e4
	};
	/**
	* 需要参与动态噪声检测的容器标签。
	* 只对这类块级容器调用 getComputedStyle / getBoundingClientRect,避免 inline 元素浪费性能。
	*/
	var DYNAMIC_NOISE_CONTAINER_TAGS = new Set([
		"div",
		"section",
		"aside",
		"dialog",
		"article",
		"main",
		"nav",
		"footer",
		"header"
	]);
	//#endregion
	//#region src/rules/index.ts
	var RULES = [
		{
			hostPattern: "github.com",
			documentTerms: [
				"Releases",
				"Packages",
				"license",
				"MIT",
				"README",
				"Issues",
				"Pull requests",
				"Actions",
				"Projects",
				"Wiki",
				"Security",
				"Insights",
				"Code",
				"Commits",
				"Branches",
				"Tags",
				"Contributors",
				"Fork",
				"Star",
				"Watch",
				"Code of conduct",
				"Contributing",
				"Support",
				"Funding"
			],
			skipSelectors: [
				".octicon",
				"[data-view-component=\"true\"].d-flex",
				"code",
				"pre",
				".react-blob-view-header-sticky",
				"[class*=\"stickyHeader\"]",
				"[class*=\"BlobViewHeader\"]",
				"[class*=\"FileNameStickyHeader\"]",
				"[class*=\"breadcrumbs\"]"
			],
			promptInstructions: "This is a GitHub page. Keep UI navigation terms, file extensions, and code-related vocabulary untranslated. Preserve brand names and technical terms."
		},
		{
			hostPattern: "reddit.com",
			skipTerms: [
				"Home",
				"Hot",
				"New",
				"Top",
				"Rising",
				"Reddit",
				"Subreddit",
				"Upvote",
				"Downvote",
				"Karma",
				"Award",
				"Share",
				"Save",
				"Report",
				"Crosspost",
				"Moderator",
				"Admin",
				"Post",
				"Comment",
				"Sort by",
				"Best",
				"Controversial"
			],
			skipSelectors: [
				"shreddit-comment",
				"faceplate-blot",
				"[data-click-id=\"score\"]"
			],
			skipTextPatterns: ["^SML\\.load\\s*\\(\\s*\\["],
			promptInstructions: "This is a Reddit page. Keep community-specific terms, subreddit names, UI labels like \"upvote/downvote/karma\", and usernames untranslated."
		},
		{
			hostPattern: "news.ycombinator.com",
			documentTerms: [
				"Hacker News",
				"new",
				"past",
				"comments",
				"hide",
				"favorite",
				"flag",
				"upvote",
				"points",
				"user",
				"about",
				"favorite",
				"submit",
				"show",
				"ask",
				"jobs",
				"threads",
				"guidelines",
				"FAQ",
				"API",
				"Security",
				"YC",
				"Startup",
				"Book",
				"Login"
			],
			skipSelectors: [
				".votelinks",
				".rank",
				".score",
				".subtext",
				"code",
				"pre"
			],
			promptInstructions: "This is Hacker News. Keep navigation terms, voting-related vocabulary, YC-specific terminology, and code snippets untranslated."
		},
		{
			hostPattern: "fortune.com",
			documentTerms: [
				"Fortune",
				"Uber",
				"AI",
				"API",
				"ChatGPT",
				"GPT"
			],
			skipSelectors: [
				"[class*=\"paywall\"]",
				"[class*=\"pay-wall\"]",
				"[class*=\"subscribe\"]",
				"[class*=\"subscription\"]"
			],
			promptInstructions: "This is a Fortune news article page. Keep proper names, brand names, and technical acronyms untranslated. Focus on translating the article content."
		},
		{
			hostPattern: "www.youtube.com",
			forceDirectTranslation: true,
			skipGlossary: true,
			promptInstructions: "This is a YouTube page (title, description, comments). Translate concisely and naturally. Keep video IDs, channel names, and timestamps unchanged."
		}
	];
	function matchSiteRule(url) {
		let host;
		try {
			host = new URL(url).hostname;
		} catch {
			return null;
		}
		for (const rule of RULES) if (hostMatches(host, rule.hostPattern)) return {
			siteRule: rule,
			matchedPattern: rule.hostPattern
		};
		return null;
	}
	function hostMatches(host, pattern) {
		if (pattern.startsWith("*.")) {
			const suffix = pattern.slice(2);
			return host === suffix || host.endsWith("." + suffix);
		}
		return host === pattern;
	}
	//#endregion
	//#region src/entrypoints/utils/blockExtractor/rules.ts
	/**
	* blockExtractor 判定规则
	*
	* 所有 shouldSkip* / is* 谓词集中在这里,逻辑上分两类:
	*   1. 节点级判定: 根据元素自身属性决定 (class, hidden, namespace, ...)
	*   2. 上下文判定: 向上/向下遍历父链或子树 (isInsideArticle, hasBlockLevelParent, ...)
	*
	* 为什么独立: walker.ts 只负责"按这些规则决定 FILTER_*",不混入具体判定逻辑;
	* 每条规则都可独立加测试。
	*/
	var cachedRule = null;
	var cachedUrl = null;
	function getSiteRule() {
		const currentUrl = window.location.href;
		if (cachedUrl === currentUrl) return cachedRule;
		const matched = matchSiteRule(currentUrl);
		cachedUrl = currentUrl;
		cachedRule = matched?.siteRule || null;
		return cachedRule;
	}
	/**
	* 把 className 按空白切分,小写。
	* 防御: SVG 元素的 className 是 SVGAnimatedString,不是 string,直接当 string 用会报错。
	*
	* 过滤含 ':' 或 '[' 的 token: 这些是 Tailwind CSS 的变体前缀(如
	* 'toc-visible:@md:col-span-8')和任意值语法(如 'backdrop-blur-[4.375rem]'),
	* 不是语义化的 class 名。保留它们会导致 'toc-visible:' 被误匹配为 'toc'
	* 目录, 'backdrop-blur-[...]' 被误匹配为 'backdrop' 弹窗, 从而跳过正文内容。
	*/
	function tokenizeClass$1(el) {
		if (!el.className || typeof el.className !== "string") return [];
		return el.className.toLowerCase().split(/\s+/).filter((t) => t && !t.includes(":") && !t.includes("["));
	}
	/**
	* 精确 / 前后缀边界匹配 (与 SKIP_CLASS_PATTERNS 配合使用):
	*   - 精确:    "social-share" === "social-share"
	*   - 前缀:    "social-share-buttons" startsWith "social-share-"
	*   - 后缀:    "post-social-share" endsWith "-social-share"
	*   - 不匹配:  "social-shareholder-list" (前缀 'social-share' 后不是 '-' 或 '_')
	*/
	function matchesSkipClass(token, pattern) {
		return token === pattern || token.startsWith(pattern + "-") || token.startsWith(pattern + "_") || token.endsWith("-" + pattern) || token.endsWith("_" + pattern);
	}
	/**
	* 噪声类元素文本长度安全阀：超过此长度的元素不视为噪声，防误杀长 FAQ。
	*
	* webclaw 借鉴：cookie/consent/footer 等噪声类元素若 textContent > 5000 字符，
	* 很可能是长 FAQ / 长隐私政策正文 / 长评论，不应被整棵跳过。
	*
	* 回归 case: #cookiesModal (Bootstrap modal 含 cookie policy tabs) 有 ~50k
	* 字符文本，因 class 含 "cookie" 被跳过，但它实际是页面正文。
	*/
	var NOISE_TEXT_SAFE_VALVE = 5e3;
	var _noiseSafeValveMemo = /* @__PURE__ */ new WeakSet();
	/**
	* 检查元素是否因文本过长而豁免噪声判定。
	* 用 WeakSet 缓存，同一元素不会重复计算 textContent。
	*/
	function isNoiseSafeValve(el) {
		if (_noiseSafeValveMemo.has(el)) return true;
		if ((el.textContent || "").length > NOISE_TEXT_SAFE_VALVE) {
			_noiseSafeValveMemo.add(el);
			return true;
		}
		return false;
	}
	/**
	* 是否因 class 命中 SKIP_CLASS_PATTERNS 而应跳过 (整棵子树拒绝)。
	* 跨站通用: 广告 / cookie / 推荐 / 弹窗 / 导航 等。
	*
	* 安全阀：若元素 textContent > 5000 字符，即使 class 命中噪声模式也不跳过，
	* 防止误杀长 FAQ / 长隐私政策等正文内容。
	*/
	function shouldSkipByClass(el) {
		const tokens = tokenizeClass$1(el);
		if (tokens.length === 0) return false;
		for (const token of tokens) for (const pattern of SKIP_CLASS_PATTERNS) if (matchesSkipClass(token, pattern)) {
			if (isNoiseSafeValve(el)) return false;
			return true;
		}
		return false;
	}
	/**
	* 是否为元数据容器 (作者 / 日期 / 分类 / byline)。
	* 用**整词分割**匹配,不是子串——避免误伤 "metadata-block" / "authorship"。
	* 命中后整棵子树拒绝,避免误翻人名 / 日期格式 / 分类标签。
	*/
	function isMetadataClass(el) {
		const tokens = tokenizeClass$1(el);
		if (tokens.length === 0) return false;
		for (const token of tokens) for (const sub of token.split(/[_\-]+/)) if (METADATA_TOKENS.has(sub)) return true;
		return false;
	}
	/**
	* 元素是否同时拥有内容容器 token (post/content/article/story/entry/rich)。
	*
	* WordPress 等CMS 会在正文容器上叠加 category-* / tag-* 等 metadata class
	* (如 <section class="post__content category-ai-and-ml">)。
	* 当元素同时命中 metadata 和 content token 时, 它是正文容器, 不应被拒绝。
	*/
	function hasContentTokens(el) {
		const tokens = tokenizeClass$1(el);
		if (tokens.length === 0) return false;
		for (const token of tokens) for (const sub of token.split(/[_\-]+/)) if (CONTENT_TOKENS.has(sub)) return true;
		return false;
	}
	/**
	* 站点特殊规则 (src/rules/): 命中后整棵子树拒绝。
	* 通过 CSS selector 匹配,允许站点级更复杂的命中 (e.g. 复合选择器)。
	*/
	function shouldSkipBySiteRules(el) {
		const rule = getSiteRule();
		if (!rule?.skipSelectors) return false;
		for (const selector of rule.skipSelectors) if (el.closest(selector)) return true;
		return false;
	}
	/**
	* 是否隐藏 (display: none / visibility: hidden / hidden 属性 / aria-hidden=true)。
	*
	* ⚠️ 性能: 原实现走父链 + getComputedStyle, 大型页面 (~1000 节点 × 15 深)
	* 触发 ~15000 次 layout。优化后只检查 el 自身 (cheap attributes + inline style
	* + 单次 getComputedStyle)。理由:
	*   1. 父链上 hidden 的元素, 它的子元素会被 rejectedCache 拦截, walker
	*      根本不会访问到——所以"父隐藏子"的情况不会浪费检查。
	*   2. display:none 几乎总在 inline style 或顶层 modal/popover 容器上,
	*      极少需要沿父链回溯。
	*   3. 如果实测有漏网, 可以升级为带 memoization 的实现 (WeakSet 已查过 visible
	*      的元素跳过 computed style 查), 见 _elementVisibilityMemo。
	*/
	var _elementVisibilityMemo = /* @__PURE__ */ new WeakSet();
	function isElementHidden(el) {
		if (_elementVisibilityMemo.has(el)) return false;
		if (el.hasAttribute("hidden")) return true;
		if (el.getAttribute("aria-hidden") === "true") return true;
		if (el instanceof HTMLElement) {
			const s = el.style;
			if (s.display === "none" || s.visibility === "hidden") return true;
		}
		if (el instanceof HTMLElement) try {
			const computed = window.getComputedStyle(el);
			if (computed.display === "none" || computed.visibility === "hidden") return true;
		} catch {}
		_elementVisibilityMemo.add(el);
		return false;
	}
	/**
	* 是否在非 HTML 命名空间 (SVG, MathML)。
	* 翻译 SVG <text> 元素很危险 (可能破坏图表); 整棵拒绝。
	*/
	function isNonHTMLNamespace(el) {
		return el.namespaceURI !== null && el.namespaceURI !== "http://www.w3.org/1999/xhtml";
	}
	/**
	* 文本是否值得翻译:
	*   - 长度在 [MIN, MAX) 区间
	*   - 不是全大写短 UI 文本 ("EMAIL", "SUBSCRIBE")
	*   - 不是 base64 块
	*   - 不是 Sentry / Webpack 元组列表
	*   - 不匹配站点规则的 skipTextPatterns
	*/
	function isValidText(text) {
		if (!text) return false;
		const trimmed = text.trim();
		if (trimmed.length < 3 || trimmed.length >= 3072) return false;
		if (trimmed.length < 25 && PATTERNS.UI_TEXT.test(trimmed) && !PATTERNS.DIGIT_SPACE.test(trimmed)) return false;
		const tupleMatches = trimmed.match(PATTERNS.TUPLE);
		if (tupleMatches && tupleMatches.length >= 8) return false;
		if (PATTERNS.BASE64.test(trimmed)) return false;
		const rule = getSiteRule();
		if (rule?.skipTextPatterns) for (const pattern of rule.skipTextPatterns) try {
			if (new RegExp(pattern, "i").test(trimmed)) return false;
		} catch {}
		return true;
	}
	/**
	* 元素是否在文章容器内 (<article> 标签 / role=article / role=main /
	* 常见文章类名)。仅在 INLINE_SET 元素上调用 (判断 span/a/em 是否值得抓)。
	*/
	function isInsideArticle(el) {
		let current = el;
		while (current) {
			if (current.tagName.toLowerCase() === "article") return true;
			const role = current.getAttribute("role");
			if (role === "article" || role === "main") return true;
			const tokens = tokenizeClass$1(current);
			for (const token of tokens) for (const pattern of ARTICLE_CONTAINER_CLASS_PATTERNS) if (matchesSkipClass(token, pattern)) return true;
			current = current.parentElement;
		}
		return false;
	}
	/**
	* 元素是否有 DIRECT_SET 块级父 (p/li/dd/blockquote/...)。
	* 用在 INLINE_SET 元素上: 如果外层已是块级,内联不单独抓 (会碎片化句子);
	* 如果只在 inline 容器里 (e.g. <span class="highlight">单独成段</span>),可单独抓。
	*/
	function hasBlockLevelParent(el) {
		let current = el.parentElement;
		while (current) {
			const tag = current.tagName.toLowerCase();
			if (DIRECT_SET.has(tag)) return true;
			if (tag === "body" || tag === "html") return false;
			current = current.parentElement;
		}
		return false;
	}
	/**
	* 把一个非块级元素分类成"容器"或"内联文本":
	*   - hasDirectText=true + hasOnlyInlineChildren=true → 当作翻译块
	*   - hasNonInlineChild=true → 容器,跳过 (子树会被独立处理)
	*   - 都没有 → 空容器,跳过
	*/
	function classifyChildren(el) {
		let hasDirectText = false;
		let hasNonEmptyElement = false;
		let hasOnlyInlineChildren = true;
		for (const child of Array.from(el.childNodes)) {
			if (child.nodeType === Node.TEXT_NODE && child.textContent?.trim()) {
				hasDirectText = true;
				continue;
			}
			if (child.nodeType !== Node.ELEMENT_NODE) continue;
			const childEl = child;
			if (childEl.textContent?.trim()) hasNonEmptyElement = true;
			if (!DIRECT_SET.has(childEl.tagName.toLowerCase()) && !INLINE_SET.has(childEl.tagName.toLowerCase())) hasOnlyInlineChildren = false;
		}
		return {
			hasDirectText,
			hasNonInlineChild: !hasOnlyInlineChildren,
			hasNonEmptyElement,
			hasOnlyInlineChildren
		};
	}
	/** 元素是否处于可编辑状态 (contenteditable / isContentEditable)。 */
	function isContentEditable(el) {
		return !!el.isContentEditable || el.getAttribute("contenteditable") === "true";
	}
	/** 元素是否被自身标记 "不要翻译" (fanyi-bilingual-block) 或 "notranslate"。 */
	function hasTranslateBlockClass(el) {
		return el.classList.contains("fanyi-bilingual-block") || el.classList.contains("notranslate");
	}
	var _cookieBannerMemo = /* @__PURE__ */ new WeakSet();
	var _popupMemo = /* @__PURE__ */ new WeakSet();
	var _adSizeMemo = /* @__PURE__ */ new WeakSet();
	/**
	* 是否因文本内容命中 Cookie Banner / Consent 弹窗关键词。
	* 命中后整棵子树拒绝,避免翻译 "Accept All" / "Manage Cookies" 等 UI 文本。
	*/
	function isCookieBannerByText(el) {
		if (_cookieBannerMemo.has(el)) return true;
		const tag = el.tagName.toLowerCase();
		if (!DYNAMIC_NOISE_CONTAINER_TAGS.has(tag)) return false;
		const directText = Array.from(el.childNodes).filter((n) => n.nodeType === Node.TEXT_NODE).map((n) => n.textContent || "").join(" ").toLowerCase();
		if (Array.from(COOKIE_BANNER_TEXT_PATTERNS).some((p) => directText.includes(p))) {
			_cookieBannerMemo.add(el);
			return true;
		}
		return false;
	}
	/**
	* 是否因固定 / sticky 定位 + 高 z-index + 大面积覆盖视口而被判定为 Popup / Modal。
	* 命中后整棵子树拒绝,避免翻译 Newsletter 订阅框、登录弹窗、促销浮层等。
	*/
	function isPopupByStyle(el) {
		if (_popupMemo.has(el)) return true;
		if (!(el instanceof HTMLElement)) return false;
		const tag = el.tagName.toLowerCase();
		if (!DYNAMIC_NOISE_CONTAINER_TAGS.has(tag)) return false;
		try {
			const style = window.getComputedStyle(el);
			if (style.position !== "fixed" && style.position !== "sticky") return false;
			const zIndex = parseInt(style.zIndex || "0", 10);
			if (Number.isNaN(zIndex) || zIndex < POPUP_STYLE_DETECTION.MIN_Z_INDEX) return false;
			const rect = el.getBoundingClientRect();
			const area = rect.width * rect.height;
			if (area < POPUP_STYLE_DETECTION.MIN_AREA_PX) return false;
			const viewportArea = window.innerWidth * window.innerHeight;
			if (viewportArea <= 0) return false;
			if (area / viewportArea < POPUP_STYLE_DETECTION.MIN_VIEWPORT_COVER_RATIO) return false;
			_popupMemo.add(el);
			return true;
		} catch {
			return false;
		}
	}
	/**
	* 是否因尺寸匹配标准广告位而被判定为广告容器。
	* 命中后整棵子树拒绝。
	*/
	function isAdBySize(el) {
		if (_adSizeMemo.has(el)) return true;
		if (!(el instanceof HTMLElement)) return false;
		const tag = el.tagName.toLowerCase();
		if (!DYNAMIC_NOISE_CONTAINER_TAGS.has(tag) && tag !== "iframe") return false;
		try {
			const rect = el.getBoundingClientRect();
			for (const [w, h] of AD_SIZE_PATTERNS) if (Math.abs(rect.width - w) <= 5 && Math.abs(rect.height - h) <= 5) {
				_adSizeMemo.add(el);
				return true;
			}
		} catch {}
		return false;
	}
	/**
	* 广告 iframe: 通过 src 匹配常见广告/追踪域名。
	* 命中后整棵子树拒绝。
	*/
	function isAdIframe(el) {
		if (el.tagName.toLowerCase() !== "iframe") return false;
		const src = (el.src || "").toLowerCase();
		return Array.from(AD_IFRAME_PATTERNS).some((p) => src.includes(p));
	}
	var LOW_PRIORITY_SELECTORS = [
		{ tag: "nav" },
		{ tag: "footer" },
		{ tag: "aside" },
		{ classPattern: /\bad\b|banner|sponsor|\bpromo\b|affiliate|advert/i },
		{ idPattern: /\bad\b|banner|sponsor|\bpromo\b|advert/i },
		{ classPattern: /\bshare\b|\bsocial\b|comment|related|recommend|sidebar/i },
		{ idPattern: /\bshare\b|\bsocial\b|comment|related|recommend|sidebar/i },
		{ classPattern: /\bnavbar\b|site-nav|global-nav|\btopbar\b|subscribe|newsletter|\bcookie\b|\bconsent\b/i },
		{ idPattern: /\bnavbar\b|site-nav|global-nav|\btopbar\b|subscribe|newsletter|\bcookie\b|\bconsent\b/i },
		{
			tag: "form",
			classPattern: /subscribe|newsletter/i
		}
	];
	var OVERLAY_PATTERNS = [
		{ classPattern: /\bcookie\b|\bconsent\b|\bgdpr\b|privacy-banner|cookie-banner/i },
		{ idPattern: /\bcookie\b|\bconsent\b|\bgdpr\b|privacy/i },
		{ classPattern: /\bpopup\b|\bmodal\b|overlay|\bdialog\b|backdrop|lightbox/i },
		{ idPattern: /\bpopup\b|\bmodal\b|overlay|\bdialog\b/i },
		{ role: "dialog" },
		{ classPattern: /subscription-popup|paywall|subscribe-popup|newsletter-modal/i },
		{ classPattern: /notification|notifications|push-notification|browser-notification|notification-prompt|subscribers/i },
		{ idPattern: /notification|notifications|push-notification|browser-notification|notification-prompt|subscribers/i },
		{ role: "alertdialog" },
		{
			tag: "div",
			styleCheck: (el) => {
				if (!(el instanceof HTMLElement)) return false;
				const pos = el.style?.position;
				return pos === "fixed" || pos === "sticky";
			}
		}
	];
	function matchSelectorRule(el, rule) {
		if (rule.tag && el.tagName.toLowerCase() !== rule.tag) return false;
		if (rule.role && el.getAttribute("role") !== rule.role) return false;
		if (!(rule.classPattern || rule.idPattern || rule.styleCheck)) return true;
		if (rule.classPattern) {
			const cls = (typeof el.className === "string" ? el.className : "").toLowerCase();
			if (rule.classPattern.test(cls)) return true;
		}
		if (rule.idPattern) {
			const id = (el.id || "").toLowerCase();
			if (rule.idPattern.test(id)) return true;
		}
		if (rule.styleCheck) {
			if (rule.styleCheck(el)) return true;
		}
		return false;
	}
	/**
	* 是否为低优先级元素（需要视觉弱化但保留 DOM）。
	* 注意：这只是标记建议，最终是否打标记由 walker 在拒绝分支中决定。
	*/
	function isLowPriorityElement(el) {
		if (el.tagName.toLowerCase() === "header") {
			if (el.querySelector("h1,h2,h3,h4,h5,h6") !== null) return false;
		}
		for (const rule of LOW_PRIORITY_SELECTORS) if (matchSelectorRule(el, rule)) return true;
		return false;
	}
	/**
	* 是否为弹窗 / overlay / cookie banner 等遮挡性元素。
	* 这些元素会直接被隐藏（display: none）。
	*
	* 注意：article / main 内部的容器即使 class 含 "overlay" 也很可能是
	* 站点 CMS 包装（如 Substack 的 .overlay-zrMCxn），不在此列。
	*/
	function isOverlayElement(el) {
		if (el.closest("article, main, [role=\"main\"], [role=\"article\"]")) return false;
		for (const rule of OVERLAY_PATTERNS) if (matchSelectorRule(el, rule)) return true;
		return false;
	}
	//#endregion
	//#region src/entrypoints/utils/blockExtractor/walker.ts
	/**
	* blockExtractor TreeWalker
	*
	* 核心遍历逻辑:
	*   1. createTreeWalker + acceptNode 决定每个节点的 FILTER_* 状态
	*   2. FILTER_ACCEPT 节点进 grabNode() 评估是否可作为翻译块
	*   3. 已拒绝的祖先进 WeakSet 缓存,后代 O(1) 查表拒绝,避免回溯父链
	*
	* 同时处理 Shadow DOM (Reddit <shreddit-post> 等 web component 文本)。
	*/
	/** DIRECT_SET 拼接成 CSS 选择器, 用于 querySelector 检查子树是否还有 DIRECT_SET 元素。 */
	var DIRECT_SET_CSS_SELECTOR = Array.from(DIRECT_SET).join(",");
	function computeSoftHint(el) {
		let score = 0;
		const cls = (el.className || "").toLowerCase();
		if (cls.includes("article") || cls.includes("post")) score += 2;
		if (cls.includes("content") || cls.includes("body")) score += 2;
		if (cls.includes("main")) score += 1;
		if (cls.includes("sidebar") || cls.includes("nav")) score -= 3;
		if (cls.includes("footer") || cls.includes("comment")) score -= 2;
		return score;
	}
	function getSoftHint(el, scoreHint) {
		let hint = scoreHint.get(el);
		if (hint === void 0) {
			hint = computeSoftHint(el);
			scoreHint.set(el, hint);
		}
		return hint;
	}
	/**
	* 对低优先级元素打标记。同一元素只打一次（通过 scoreHint 缓存判断）。
	*/
	function markLowPriorityIfNeeded(el, scoreHint) {
		if (!scoreHint.has(el) && isLowPriorityElement(el)) el.setAttribute("data-fanyi-low-priority", "true");
	}
	/**
	* 是否值得作为翻译块返回。
	* 与 walker 的 acceptNode 不同: 这里做更细的内容检查 (text 有效性、子树结构)。
	* 节点已被 walker 接受,不代表它一定能作为翻译块 (e.g. 空 <p>)。
	*/
	function grabNode(node) {
		if (!node || node instanceof Text) return false;
		if (!(node instanceof Element)) return false;
		const el = node;
		const tag = el.tagName.toLowerCase();
		if (DIRECT_SET.has(tag)) {
			if (el.querySelector(DIRECT_SET_CSS_SELECTOR) !== null) return false;
			return isValidText(el.textContent) ? el : false;
		}
		if (INLINE_SET.has(tag)) {
			if (isInsideArticle(el) && !hasBlockLevelParent(el)) return isValidText(el.textContent) ? el : false;
			return false;
		}
		const { hasDirectText, hasNonInlineChild } = classifyChildren(el);
		if (hasNonInlineChild) return false;
		if (hasDirectText) return isValidText(el.textContent) ? el : false;
		return false;
	}
	/**
	* TreeWalker 的 acceptNode: 决定 FILTER_ACCEPT / FILTER_SKIP / FILTER_REJECT。
	*
	* 状态机核心:
	*   - FILTER_REJECT = 跳过自身 + 整棵子树
	*   - FILTER_SKIP   = 跳过自身, 走子树
	*   - FILTER_ACCEPT = 自身进 grabNode, 不走子树
	*
	* 性能优化:
	*   1. rejectedCache (WeakSet) 缓存所有被 REJECT 的元素,后代 O(1) 拒绝
	*   2. 早返回: 便宜的检查放前面 (parent rejected, SKIP_SET)
	*   3. 隐藏/命名空间检查一旦失败立即入 cache
	*/
	function acceptWalkerNode(node, counters, rejectedCache, scoreHint) {
		if (node instanceof Text) {
			if (node.parentElement && rejectedCache.has(node.parentElement)) return NodeFilter.FILTER_REJECT;
			return NodeFilter.FILTER_ACCEPT;
		}
		if (!(node instanceof Element)) return NodeFilter.FILTER_SKIP;
		const el = node;
		const tag = el.tagName.toLowerCase();
		if (el.parentElement && rejectedCache.has(el.parentElement)) {
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (isOverlayElement(el)) {
			el.setAttribute("data-fanyi-remove", "true");
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (isNonHTMLNamespace(el)) {
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		const skipSetMatch = SKIP_SET.has(tag);
		const isNestedBody = tag === "body" && el.parentElement?.tagName?.toLowerCase() !== "html";
		if (skipSetMatch && !isNestedBody || hasTranslateBlockClass(el) || isContentEditable(el)) {
			markLowPriorityIfNeeded(el, scoreHint);
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (isElementHidden(el)) {
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (shouldSkipByClass(el) || shouldSkipBySiteRules(el)) {
			markLowPriorityIfNeeded(el, scoreHint);
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (isCookieBannerByText(el) || isPopupByStyle(el) || isAdBySize(el) || isAdIframe(el)) {
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		const isContainerWithContent = (tag === "section" || tag === "div") && hasContentTokens(el);
		if (tag !== "article" && tag !== "main" && isMetadataClass(el) && !isContainerWithContent) {
			rejectedCache.add(el);
			counters.rejected++;
			return NodeFilter.FILTER_REJECT;
		}
		if (tag === "header") {
			if (el.querySelector("h1, h2, h3, h4, h5, h6") !== null) {
				counters.skipped++;
				return NodeFilter.FILTER_SKIP;
			}
			rejectedCache.add(el);
			counters.skipped++;
			return NodeFilter.FILTER_REJECT;
		}
		if (SEMANTIC_SKIP_TAGS.has(tag)) {
			rejectedCache.add(el);
			counters.skipped++;
			return NodeFilter.FILTER_REJECT;
		}
		const hint = getSoftHint(el, scoreHint);
		if (DIRECT_SET.has(tag)) {
			if (el.querySelector(DIRECT_SET_CSS_SELECTOR) !== null) {
				counters.skipped++;
				return NodeFilter.FILTER_SKIP;
			}
			if (hint < 0) {
				counters.skipped++;
				return NodeFilter.FILTER_SKIP;
			}
			if (isValidText(el.textContent)) {
				counters.accepted++;
				return NodeFilter.FILTER_ACCEPT;
			}
			counters.skipped++;
			return NodeFilter.FILTER_SKIP;
		}
		const { hasDirectText, hasNonEmptyElement, hasOnlyInlineChildren } = classifyChildren(el);
		if (!hasOnlyInlineChildren) {
			counters.skipped++;
			return NodeFilter.FILTER_SKIP;
		}
		if (hasDirectText || hasNonEmptyElement) {
			if (isValidText(el.textContent)) {
				counters.accepted++;
				return NodeFilter.FILTER_ACCEPT;
			}
		}
		counters.skipped++;
		return NodeFilter.FILTER_SKIP;
	}
	/**
	* 从 startNode 出发, 收集所有翻译块到 blocks。
	* 同时跨 Shadow DOM 边界 (Reddit <shreddit-post> 等)。
	*/
	function collectBlocks(startNode, blocks, blockIdRef, seenTexts) {
		const counters = {
			rejected: 0,
			skipped: 0,
			accepted: 0
		};
		const rejectedCache = /* @__PURE__ */ new WeakSet();
		const scoreHint = /* @__PURE__ */ new WeakMap();
		const walker = document.createTreeWalker(startNode, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: (node) => acceptWalkerNode(node, counters, rejectedCache, scoreHint) });
		let currentNode;
		while ((currentNode = walker.nextNode()) !== null) {
			const translateNode = grabNode(currentNode);
			if (!translateNode) continue;
			const text = translateNode.textContent?.trim();
			if (!text) continue;
			if (seenTexts.has(text)) {
				counters.skipped++;
				continue;
			}
			seenTexts.add(text);
			const id = `b${++blockIdRef.value}`;
			if (translateNode instanceof HTMLElement) translateNode.dataset.fanyiBlockId = id;
			blocks.push({
				id,
				xpath: getXPath(translateNode),
				tag: translateNode.tagName.toLowerCase(),
				text,
				context: {
					headingPath: getHeadingPath(translateNode),
					position: blockIdRef.value
				}
			});
		}
		collectFromShadowHosts(startNode, blocks, blockIdRef, seenTexts);
		return counters;
	}
	/**
	* 递归遍历 host 元素的 open shadow root。
	* 用宽松的 walker (FILTER_ACCEPT) 拿到 host 自身, 检查 shadowRoot。
	*/
	function collectFromShadowHosts(root, blocks, blockIdRef, seenTexts) {
		const treeWalker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, { acceptNode: () => NodeFilter.FILTER_ACCEPT });
		let currentNode;
		while ((currentNode = treeWalker.nextNode()) !== null) {
			if (!(currentNode instanceof Element)) continue;
			const shadow = currentNode.shadowRoot;
			if (shadow && shadow.mode === "open") collectBlocks(shadow, blocks, blockIdRef, seenTexts);
		}
	}
	/** 生成元素 XPath, 用于回退查找 (data attr 优先)。 */
	function getXPath(node) {
		if (node.nodeType === Node.DOCUMENT_NODE) return "";
		if (!(node instanceof Element)) return "";
		const parts = [];
		let current = node;
		while (current && current.nodeType === Node.ELEMENT_NODE) {
			let index = 1;
			let sibling = current.previousElementSibling;
			while (sibling) {
				if (sibling.tagName === current.tagName) index++;
				sibling = sibling.previousElementSibling;
			}
			parts.unshift(`${current.tagName.toLowerCase()}[${index}]`);
			current = current.parentElement;
		}
		return "/" + parts.join("/");
	}
	/** 收集元素之前所有 h1-h6 标题, 用于 context.headingPath。 */
	function getHeadingPath(block) {
		const headings = [];
		let current = block;
		while (current) {
			const prev = findPreviousHeading(current);
			if (!prev) break;
			headings.unshift(prev.textContent?.trim() || "");
			current = prev;
		}
		return headings;
	}
	function findPreviousHeading(element) {
		let current = element;
		while (current) {
			while (current.previousSibling) {
				current = current.previousSibling;
				if (current.nodeType === Node.ELEMENT_NODE) {
					const el = current;
					if (isHeading(el)) return el;
					const found = findLastHeadingInSubtree(el);
					if (found) return found;
				}
			}
			current = current.parentElement;
		}
		return null;
	}
	function findLastHeadingInSubtree(element) {
		for (const child of Array.from(element.children).reverse()) {
			if (isHeading(child)) return child;
			const found = findLastHeadingInSubtree(child);
			if (found) return found;
		}
		return null;
	}
	function isHeading(el) {
		return /^H[1-6]$/.test(el.tagName);
	}
	//#endregion
	//#region src/entrypoints/utils/blockExtractor/index.ts
	/**
	* blockExtractor 公共 API
	*
	* 负责对外暴露的函数和类型。内部实现拆分为:
	*   - ./constants  静态数据 (regex, set, 跳过类名, 计数接口)
	*   - ./rules      谓词 (shouldSkip*, is*, classifyChildren, ...)
	*   - ./walker     TreeWalker 收集 (collectBlocks, acceptNode, grabNode)
	*
	* 公开 API:
	*   - extractBlocks(rootNode)         主入口: 提取所有翻译块
	*   - findBlockNode(block, root)      按 id 查回 DOM 节点 (data attr + XPath 兜底)
	*   - buildNodeMap(blocks, root)      构建 blockId → Node 的 Map
	*
	* 为什么不直接用 Mozilla Readability:
	*   - Readability 是"挑出主文章"模式,返回单一 article 节点,适合 Reader View。
	*   - 我们需要"逐块翻译整页所有可读文本",必须保留 nav / sidebar 之外的
	*     所有正文,模型逐块收到独立 context 才能稳定返回 JSON。
	*   - 同类翻译扩展 (XTranslate, 侧边翻译, Read Frog) 都用 block-walking
	*     方案,这是行业标准。
	*/
	/**
	* 合并 CSS letter-spacing 渲染的"分散单词"。
	*
	* hero section、CTA 按钮、品牌名常用 `letter-spacing` 装饰，textContent
	* 抽取后变成 "S t a r t" 这种单字符 + 空格序列。直接送给翻译模型会被
	* 当成独立字符处理，返回 "开 始 使 用" 这种带空格的中文，apply 回 DOM
	* 后视觉错乱。
	*
	* 检测连续 ≥4 个 "ASCII 字母/数字 + 空格" 序列，合并为无空格单词。
	* 阈值 4：避免误伤 "I am a coder" 这类正常英文（"I a" 只有 2 个单字符
	* 序列，远低于阈值）。
	*
	* 不处理 CJK：中文字符本身是有意义的单字，letter-spacing 渲染的中文
	* （如 "开 始 使 用"）应保留原样，让翻译模型按独立字符处理。
	*
	* @example
	*   collapseSpacedText('S t a r t')        // → 'Start'
	*   collapseSpacedText('2 0 2 4 年度报告')  // → '2024 年度报告'
	*   collapseSpacedText('hello world')      // → 'hello world'（不变）
	*   collapseSpacedText('I am a coder')     // → 'I am a coder'（不变）
	*   collapseSpacedText('开 始 使 用')       // → '开 始 使 用'（中文不变）
	*/
	function collapseSpacedText(text) {
		return text.replace(/([a-zA-Z0-9](?:\s+[a-zA-Z0-9]){3,})/g, (match) => match.replace(/\s+/g, ""));
	}
	/**
	* 从 rootNode 出发抽取所有翻译块。
	* @param rootNode Document 或 DocumentFragment
	* @returns 顺序的 TextBlock 数组
	*/
	function extractBlocks(rootNode) {
		const blocks = [];
		const blockIdRef = { value: 0 };
		const seenTexts = /* @__PURE__ */ new Set();
		const startNode = (typeof Document !== "undefined" ? rootNode instanceof Document : !!rootNode.body || !!rootNode.documentElement) ? rootNode.body || rootNode.documentElement : rootNode;
		if (!startNode) {
			console.warn("[BlockExtractor] No valid start node found");
			return [];
		}
		collectBlocks(startNode, blocks, blockIdRef, seenTexts);
		for (const block of blocks) block.text = collapseSpacedText(block.text);
		return blocks;
	}
	/**
	* 按 block.id 找回 DOM 节点。
	* 优先用临时 data 属性 (更健壮, 抗 DOM 变化), 回退到 XPath。
	*/
	function findBlockNode(block, root) {
		const el = root.querySelector(`[data-fanyi-block-id="${block.id}"]`);
		if (el) return el;
		try {
			return root.evaluate(block.xpath, root, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
		} catch {
			return null;
		}
	}
	/** 批量构建 blockId → Node 映射, 用于翻译应用阶段。 */
	function buildNodeMap(blocks, root) {
		const map = /* @__PURE__ */ new Map();
		for (const block of blocks) {
			const node = findBlockNode(block, root);
			if (node) map.set(block.id, node);
		}
		return map;
	}
	//#endregion
	//#region src/entrypoints/utils/chunkBuilder.ts
	var MAX_INPUT_TOKENS = 5e5;
	var TARGET_TOKENS = 800;
	var WARMUP_TARGET_TOKENS = 400;
	function estimateTokens(text) {
		return Math.ceil(text.length / 4);
	}
	function buildJsonContent(blocks) {
		return JSON.stringify(blocks.map((b) => ({
			id: b.id,
			text: b.text
		})));
	}
	function isStructuralBoundary(block) {
		return /^h[1-6]$/.test(block.tag);
	}
	function buildChunks(blocks) {
		console.log("[ChunkBuilder] buildChunks called with", blocks.length, "blocks");
		if (blocks.length === 0) return [];
		const chunks = [];
		let currentBlocks = [];
		let currentTokens = 0;
		let chunkIndex = 0;
		function flushChunk() {
			if (currentBlocks.length > 0) {
				chunkIndex++;
				chunks.push({
					id: `chunk${chunkIndex}`,
					blocks: currentBlocks,
					jsonContent: buildJsonContent(currentBlocks),
					estimatedTokens: currentTokens
				});
				currentBlocks = [];
				currentTokens = 0;
			}
		}
		for (let i = 0; i < blocks.length; i++) {
			const block = blocks[i];
			const blockTokens = estimateTokens(block.text) + 20;
			const isBoundary = isStructuralBoundary(block);
			const targetTokens = chunks.length < 2 ? WARMUP_TARGET_TOKENS : TARGET_TOKENS;
			const wouldExceed = currentTokens + blockTokens > targetTokens;
			if (currentTokens + blockTokens > MAX_INPUT_TOKENS) {
				flushChunk();
				currentBlocks.push(block);
				currentTokens = blockTokens;
			} else if (wouldExceed && currentBlocks.length > 0) if (isBoundary) {
				flushChunk();
				currentBlocks.push(block);
				currentTokens = blockTokens;
			} else {
				const nextBoundary = findNextBoundary(blocks, i);
				if (nextBoundary && nextBoundary - i < 5) {
					for (let j = i; j <= nextBoundary; j++) {
						const b = blocks[j];
						currentBlocks.push(b);
						currentTokens += estimateTokens(b.text) + 20;
					}
					i = nextBoundary;
					flushChunk();
				} else {
					flushChunk();
					currentBlocks.push(block);
					currentTokens = blockTokens;
				}
			}
			else {
				currentBlocks.push(block);
				currentTokens += blockTokens;
			}
		}
		flushChunk();
		console.log("[ChunkBuilder] Built", chunks.length, "chunks");
		if (chunks.length > 0) console.log("[ChunkBuilder] Chunk sizes:", chunks.map((c) => ({
			id: c.id,
			blocks: c.blocks.length,
			tokens: c.estimatedTokens,
			blockIds: c.blocks.map((b) => b.id).join(",")
		})));
		return chunks;
	}
	function findNextBoundary(blocks, startIndex) {
		for (let i = startIndex + 1; i < blocks.length; i++) if (isStructuralBoundary(blocks[i])) return i;
		return null;
	}
	//#endregion
	//#region node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability.js
	var require_Readability = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		/**
		* Public constructor.
		* @param {HTMLDocument} doc     The document to parse.
		* @param {Object}       options The options object.
		*/
		function Readability(doc, options) {
			if (options && options.documentElement) {
				doc = options;
				options = arguments[2];
			} else if (!doc || !doc.documentElement) throw new Error("First argument to Readability constructor should be a document object.");
			options = options || {};
			this._doc = doc;
			this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
			this._articleTitle = null;
			this._articleByline = null;
			this._articleDir = null;
			this._articleSiteName = null;
			this._attempts = [];
			this._metadata = {};
			this._debug = !!options.debug;
			this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
			this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
			this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
			this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(options.classesToPreserve || []);
			this._keepClasses = !!options.keepClasses;
			this._serializer = options.serializer || function(el) {
				return el.innerHTML;
			};
			this._disableJSONLD = !!options.disableJSONLD;
			this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
			this._linkDensityModifier = options.linkDensityModifier || 0;
			this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
			if (this._debug) {
				let logNode = function(node) {
					if (node.nodeType == node.TEXT_NODE) return `${node.nodeName} ("${node.textContent}")`;
					let attrPairs = Array.from(node.attributes || [], function(attr) {
						return `${attr.name}="${attr.value}"`;
					}).join(" ");
					return `<${node.localName} ${attrPairs}>`;
				};
				this.log = function() {
					if (typeof console !== "undefined") {
						let args = Array.from(arguments, (arg) => {
							if (arg && arg.nodeType == this.ELEMENT_NODE) return logNode(arg);
							return arg;
						});
						args.unshift("Reader: (Readability)");
						console.log(...args);
					} else if (typeof dump !== "undefined") {
						var msg = Array.prototype.map.call(arguments, function(x) {
							return x && x.nodeName ? logNode(x) : x;
						}).join(" ");
						dump("Reader: (Readability) " + msg + "\n");
					}
				};
			} else this.log = function() {};
		}
		Readability.prototype = {
			FLAG_STRIP_UNLIKELYS: 1,
			FLAG_WEIGHT_CLASSES: 2,
			FLAG_CLEAN_CONDITIONALLY: 4,
			ELEMENT_NODE: 1,
			TEXT_NODE: 3,
			DEFAULT_MAX_ELEMS_TO_PARSE: 0,
			DEFAULT_N_TOP_CANDIDATES: 5,
			DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
			DEFAULT_CHAR_THRESHOLD: 500,
			REGEXPS: {
				unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
				okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
				positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
				negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
				extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
				byline: /byline|author|dateline|writtenby|p-author/i,
				replaceFonts: /<(\/?)font[^>]*>/gi,
				normalize: /\s{2,}/g,
				videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
				shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
				nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
				prevLink: /(prev|earl|old|new|<|«)/i,
				tokenize: /\W+/g,
				whitespace: /^\s*$/,
				hasContent: /\S$/,
				hashUrl: /^#.+/,
				srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
				b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
				commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
				jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
				adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
				loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
			},
			UNLIKELY_ROLES: [
				"menu",
				"menubar",
				"complementary",
				"navigation",
				"alert",
				"alertdialog",
				"dialog"
			],
			DIV_TO_P_ELEMS: new Set([
				"BLOCKQUOTE",
				"DL",
				"DIV",
				"IMG",
				"OL",
				"P",
				"PRE",
				"TABLE",
				"UL"
			]),
			ALTER_TO_DIV_EXCEPTIONS: [
				"DIV",
				"ARTICLE",
				"SECTION",
				"P",
				"OL",
				"UL"
			],
			PRESENTATIONAL_ATTRIBUTES: [
				"align",
				"background",
				"bgcolor",
				"border",
				"cellpadding",
				"cellspacing",
				"frame",
				"hspace",
				"rules",
				"style",
				"valign",
				"vspace"
			],
			DEPRECATED_SIZE_ATTRIBUTE_ELEMS: [
				"TABLE",
				"TH",
				"TD",
				"HR",
				"PRE"
			],
			PHRASING_ELEMS: [
				"ABBR",
				"AUDIO",
				"B",
				"BDO",
				"BR",
				"BUTTON",
				"CITE",
				"CODE",
				"DATA",
				"DATALIST",
				"DFN",
				"EM",
				"EMBED",
				"I",
				"IMG",
				"INPUT",
				"KBD",
				"LABEL",
				"MARK",
				"MATH",
				"METER",
				"NOSCRIPT",
				"OBJECT",
				"OUTPUT",
				"PROGRESS",
				"Q",
				"RUBY",
				"SAMP",
				"SCRIPT",
				"SELECT",
				"SMALL",
				"SPAN",
				"STRONG",
				"SUB",
				"SUP",
				"TEXTAREA",
				"TIME",
				"VAR",
				"WBR"
			],
			CLASSES_TO_PRESERVE: ["page"],
			HTML_ESCAPE_MAP: {
				lt: "<",
				gt: ">",
				amp: "&",
				quot: "\"",
				apos: "'"
			},
			/**
			* Run any post-process modifications to article content as necessary.
			*
			* @param Element
			* @return void
			**/
			_postProcessContent(articleContent) {
				this._fixRelativeUris(articleContent);
				this._simplifyNestedElements(articleContent);
				if (!this._keepClasses) this._cleanClasses(articleContent);
			},
			/**
			* Iterates over a NodeList, calls `filterFn` for each node and removes node
			* if function returned `true`.
			*
			* If function is not passed, removes all the nodes in node list.
			*
			* @param NodeList nodeList The nodes to operate on
			* @param Function filterFn the function to use as a filter
			* @return void
			*/
			_removeNodes(nodeList, filterFn) {
				if (this._docJSDOMParser && nodeList._isLiveNodeList) throw new Error("Do not pass live node lists to _removeNodes");
				for (var i = nodeList.length - 1; i >= 0; i--) {
					var node = nodeList[i];
					var parentNode = node.parentNode;
					if (parentNode) {
						if (!filterFn || filterFn.call(this, node, i, nodeList)) parentNode.removeChild(node);
					}
				}
			},
			/**
			* Iterates over a NodeList, and calls _setNodeTag for each node.
			*
			* @param NodeList nodeList The nodes to operate on
			* @param String newTagName the new tag name to use
			* @return void
			*/
			_replaceNodeTags(nodeList, newTagName) {
				if (this._docJSDOMParser && nodeList._isLiveNodeList) throw new Error("Do not pass live node lists to _replaceNodeTags");
				for (const node of nodeList) this._setNodeTag(node, newTagName);
			},
			/**
			* Iterate over a NodeList, which doesn't natively fully implement the Array
			* interface.
			*
			* For convenience, the current object context is applied to the provided
			* iterate function.
			*
			* @param  NodeList nodeList The NodeList.
			* @param  Function fn       The iterate function.
			* @return void
			*/
			_forEachNode(nodeList, fn) {
				Array.prototype.forEach.call(nodeList, fn, this);
			},
			/**
			* Iterate over a NodeList, and return the first node that passes
			* the supplied test function
			*
			* For convenience, the current object context is applied to the provided
			* test function.
			*
			* @param  NodeList nodeList The NodeList.
			* @param  Function fn       The test function.
			* @return void
			*/
			_findNode(nodeList, fn) {
				return Array.prototype.find.call(nodeList, fn, this);
			},
			/**
			* Iterate over a NodeList, return true if any of the provided iterate
			* function calls returns true, false otherwise.
			*
			* For convenience, the current object context is applied to the
			* provided iterate function.
			*
			* @param  NodeList nodeList The NodeList.
			* @param  Function fn       The iterate function.
			* @return Boolean
			*/
			_someNode(nodeList, fn) {
				return Array.prototype.some.call(nodeList, fn, this);
			},
			/**
			* Iterate over a NodeList, return true if all of the provided iterate
			* function calls return true, false otherwise.
			*
			* For convenience, the current object context is applied to the
			* provided iterate function.
			*
			* @param  NodeList nodeList The NodeList.
			* @param  Function fn       The iterate function.
			* @return Boolean
			*/
			_everyNode(nodeList, fn) {
				return Array.prototype.every.call(nodeList, fn, this);
			},
			_getAllNodesWithTag(node, tagNames) {
				if (node.querySelectorAll) return node.querySelectorAll(tagNames.join(","));
				return [].concat.apply([], tagNames.map(function(tag) {
					var collection = node.getElementsByTagName(tag);
					return Array.isArray(collection) ? collection : Array.from(collection);
				}));
			},
			/**
			* Removes the class="" attribute from every element in the given
			* subtree, except those that match CLASSES_TO_PRESERVE and
			* the classesToPreserve array from the options object.
			*
			* @param Element
			* @return void
			*/
			_cleanClasses(node) {
				var classesToPreserve = this._classesToPreserve;
				var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
				if (className) node.setAttribute("class", className);
				else node.removeAttribute("class");
				for (node = node.firstElementChild; node; node = node.nextElementSibling) this._cleanClasses(node);
			},
			/**
			* Tests whether a string is a URL or not.
			*
			* @param {string} str The string to test
			* @return {boolean} true if str is a URL, false if not
			*/
			_isUrl(str) {
				try {
					new URL(str);
					return true;
				} catch {
					return false;
				}
			},
			/**
			* Converts each <a> and <img> uri in the given element to an absolute URI,
			* ignoring #ref URIs.
			*
			* @param Element
			* @return void
			*/
			_fixRelativeUris(articleContent) {
				var baseURI = this._doc.baseURI;
				var documentURI = this._doc.documentURI;
				function toAbsoluteURI(uri) {
					if (baseURI == documentURI && uri.charAt(0) == "#") return uri;
					try {
						return new URL(uri, baseURI).href;
					} catch (ex) {}
					return uri;
				}
				var links = this._getAllNodesWithTag(articleContent, ["a"]);
				this._forEachNode(links, function(link) {
					var href = link.getAttribute("href");
					if (href) if (href.indexOf("javascript:") === 0) if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
						var text = this._doc.createTextNode(link.textContent);
						link.parentNode.replaceChild(text, link);
					} else {
						var container = this._doc.createElement("span");
						while (link.firstChild) container.appendChild(link.firstChild);
						link.parentNode.replaceChild(container, link);
					}
					else link.setAttribute("href", toAbsoluteURI(href));
				});
				var medias = this._getAllNodesWithTag(articleContent, [
					"img",
					"picture",
					"figure",
					"video",
					"audio",
					"source"
				]);
				this._forEachNode(medias, function(media) {
					var src = media.getAttribute("src");
					var poster = media.getAttribute("poster");
					var srcset = media.getAttribute("srcset");
					if (src) media.setAttribute("src", toAbsoluteURI(src));
					if (poster) media.setAttribute("poster", toAbsoluteURI(poster));
					if (srcset) {
						var newSrcset = srcset.replace(this.REGEXPS.srcsetUrl, function(_, p1, p2, p3) {
							return toAbsoluteURI(p1) + (p2 || "") + p3;
						});
						media.setAttribute("srcset", newSrcset);
					}
				});
			},
			_simplifyNestedElements(articleContent) {
				var node = articleContent;
				while (node) {
					if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
						if (this._isElementWithoutContent(node)) {
							node = this._removeAndGetNext(node);
							continue;
						} else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
							var child = node.children[0];
							for (var i = 0; i < node.attributes.length; i++) child.setAttributeNode(node.attributes[i].cloneNode());
							node.parentNode.replaceChild(child, node);
							node = child;
							continue;
						}
					}
					node = this._getNextNode(node);
				}
			},
			/**
			* Get the article title as an H1.
			*
			* @return string
			**/
			_getArticleTitle() {
				var doc = this._doc;
				var curTitle = "";
				var origTitle = "";
				try {
					curTitle = origTitle = doc.title.trim();
					if (typeof curTitle !== "string") curTitle = origTitle = this._getInnerText(doc.getElementsByTagName("title")[0]);
				} catch (e) {}
				var titleHadHierarchicalSeparators = false;
				function wordCount(str) {
					return str.split(/\s+/).length;
				}
				if (/ [\|\-\\\/>»] /.test(curTitle)) {
					titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
					let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
					curTitle = origTitle.substring(0, allSeparators.pop().index);
					if (wordCount(curTitle) < 3) curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
				} else if (curTitle.includes(": ")) {
					var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
					var trimmedTitle = curTitle.trim();
					if (!this._someNode(headings, function(heading) {
						return heading.textContent.trim() === trimmedTitle;
					})) {
						curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
						if (wordCount(curTitle) < 3) curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
						else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) curTitle = origTitle;
					}
				} else if (curTitle.length > 150 || curTitle.length < 15) {
					var hOnes = doc.getElementsByTagName("h1");
					if (hOnes.length === 1) curTitle = this._getInnerText(hOnes[0]);
				}
				curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
				var curTitleWordCount = wordCount(curTitle);
				if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) curTitle = origTitle;
				return curTitle;
			},
			/**
			* Prepare the HTML document for readability to scrape it.
			* This includes things like stripping javascript, CSS, and handling terrible markup.
			*
			* @return void
			**/
			_prepDocument() {
				var doc = this._doc;
				this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
				if (doc.body) this._replaceBrs(doc.body);
				this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
			},
			/**
			* Finds the next node, starting from the given node, and ignoring
			* whitespace in between. If the given node is an element, the same node is
			* returned.
			*/
			_nextNode(node) {
				var next = node;
				while (next && next.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next.textContent)) next = next.nextSibling;
				return next;
			},
			/**
			* Replaces 2 or more successive <br> elements with a single <p>.
			* Whitespace between <br> elements are ignored. For example:
			*   <div>foo<br>bar<br> <br><br>abc</div>
			* will become:
			*   <div>foo<br>bar<p>abc</p></div>
			*/
			_replaceBrs(elem) {
				this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
					var next = br.nextSibling;
					var replaced = false;
					while ((next = this._nextNode(next)) && next.tagName == "BR") {
						replaced = true;
						var brSibling = next.nextSibling;
						next.remove();
						next = brSibling;
					}
					if (replaced) {
						var p = this._doc.createElement("p");
						br.parentNode.replaceChild(p, br);
						next = p.nextSibling;
						while (next) {
							if (next.tagName == "BR") {
								var nextElem = this._nextNode(next.nextSibling);
								if (nextElem && nextElem.tagName == "BR") break;
							}
							if (!this._isPhrasingContent(next)) break;
							var sibling = next.nextSibling;
							p.appendChild(next);
							next = sibling;
						}
						while (p.lastChild && this._isWhitespace(p.lastChild)) p.lastChild.remove();
						if (p.parentNode.tagName === "P") this._setNodeTag(p.parentNode, "DIV");
					}
				});
			},
			_setNodeTag(node, tag) {
				this.log("_setNodeTag", node, tag);
				if (this._docJSDOMParser) {
					node.localName = tag.toLowerCase();
					node.tagName = tag.toUpperCase();
					return node;
				}
				var replacement = node.ownerDocument.createElement(tag);
				while (node.firstChild) replacement.appendChild(node.firstChild);
				node.parentNode.replaceChild(replacement, node);
				if (node.readability) replacement.readability = node.readability;
				for (var i = 0; i < node.attributes.length; i++) replacement.setAttributeNode(node.attributes[i].cloneNode());
				return replacement;
			},
			/**
			* Prepare the article node for display. Clean out any inline styles,
			* iframes, forms, strip extraneous <p> tags, etc.
			*
			* @param Element
			* @return void
			**/
			_prepArticle(articleContent) {
				this._cleanStyles(articleContent);
				this._markDataTables(articleContent);
				this._fixLazyImages(articleContent);
				this._cleanConditionally(articleContent, "form");
				this._cleanConditionally(articleContent, "fieldset");
				this._clean(articleContent, "object");
				this._clean(articleContent, "embed");
				this._clean(articleContent, "footer");
				this._clean(articleContent, "link");
				this._clean(articleContent, "aside");
				var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
				this._forEachNode(articleContent.children, function(topCandidate) {
					this._cleanMatchedNodes(topCandidate, function(node, matchString) {
						return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
					});
				});
				this._clean(articleContent, "iframe");
				this._clean(articleContent, "input");
				this._clean(articleContent, "textarea");
				this._clean(articleContent, "select");
				this._clean(articleContent, "button");
				this._cleanHeaders(articleContent);
				this._cleanConditionally(articleContent, "table");
				this._cleanConditionally(articleContent, "ul");
				this._cleanConditionally(articleContent, "div");
				this._replaceNodeTags(this._getAllNodesWithTag(articleContent, ["h1"]), "h2");
				this._removeNodes(this._getAllNodesWithTag(articleContent, ["p"]), function(paragraph) {
					return this._getAllNodesWithTag(paragraph, [
						"img",
						"embed",
						"object",
						"iframe"
					]).length === 0 && !this._getInnerText(paragraph, false);
				});
				this._forEachNode(this._getAllNodesWithTag(articleContent, ["br"]), function(br) {
					var next = this._nextNode(br.nextSibling);
					if (next && next.tagName == "P") br.remove();
				});
				this._forEachNode(this._getAllNodesWithTag(articleContent, ["table"]), function(table) {
					var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
					if (this._hasSingleTagInsideElement(tbody, "TR")) {
						var row = tbody.firstElementChild;
						if (this._hasSingleTagInsideElement(row, "TD")) {
							var cell = row.firstElementChild;
							cell = this._setNodeTag(cell, this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV");
							table.parentNode.replaceChild(cell, table);
						}
					}
				});
			},
			/**
			* Initialize a node with the readability object. Also checks the
			* className/id for special names to add to its score.
			*
			* @param Element
			* @return void
			**/
			_initializeNode(node) {
				node.readability = { contentScore: 0 };
				switch (node.tagName) {
					case "DIV":
						node.readability.contentScore += 5;
						break;
					case "PRE":
					case "TD":
					case "BLOCKQUOTE":
						node.readability.contentScore += 3;
						break;
					case "ADDRESS":
					case "OL":
					case "UL":
					case "DL":
					case "DD":
					case "DT":
					case "LI":
					case "FORM":
						node.readability.contentScore -= 3;
						break;
					case "H1":
					case "H2":
					case "H3":
					case "H4":
					case "H5":
					case "H6":
					case "TH":
						node.readability.contentScore -= 5;
						break;
				}
				node.readability.contentScore += this._getClassWeight(node);
			},
			_removeAndGetNext(node) {
				var nextNode = this._getNextNode(node, true);
				node.remove();
				return nextNode;
			},
			/**
			* Traverse the DOM from node to node, starting at the node passed in.
			* Pass true for the second parameter to indicate this node itself
			* (and its kids) are going away, and we want the next node over.
			*
			* Calling this in a loop will traverse the DOM depth-first.
			*
			* @param {Element} node
			* @param {boolean} ignoreSelfAndKids
			* @return {Element}
			*/
			_getNextNode(node, ignoreSelfAndKids) {
				if (!ignoreSelfAndKids && node.firstElementChild) return node.firstElementChild;
				if (node.nextElementSibling) return node.nextElementSibling;
				do
					node = node.parentNode;
				while (node && !node.nextElementSibling);
				return node && node.nextElementSibling;
			},
			_textSimilarity(textA, textB) {
				var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
				var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
				if (!tokensA.length || !tokensB.length) return 0;
				return 1 - tokensB.filter((token) => !tokensA.includes(token)).join(" ").length / tokensB.join(" ").length;
			},
			/**
			* Checks whether an element node contains a valid byline
			*
			* @param node {Element}
			* @param matchString {string}
			* @return boolean
			*/
			_isValidByline(node, matchString) {
				var rel = node.getAttribute("rel");
				var itemprop = node.getAttribute("itemprop");
				var bylineLength = node.textContent.trim().length;
				return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
			},
			_getNodeAncestors(node, maxDepth) {
				maxDepth = maxDepth || 0;
				var i = 0, ancestors = [];
				while (node.parentNode) {
					ancestors.push(node.parentNode);
					if (maxDepth && ++i === maxDepth) break;
					node = node.parentNode;
				}
				return ancestors;
			},
			/***
			* grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
			*         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
			*
			* @param page a document to run upon. Needs to be a full document, complete with body.
			* @return Element
			**/
			_grabArticle(page) {
				this.log("**** grabArticle ****");
				var doc = this._doc;
				var isPaging = page !== null;
				page = page ? page : this._doc.body;
				if (!page) {
					this.log("No body found in document. Abort.");
					return null;
				}
				var pageCacheHtml = page.innerHTML;
				while (true) {
					this.log("Starting grabArticle loop");
					var stripUnlikelyCandidates = this._flagIsActive(this.FLAG_STRIP_UNLIKELYS);
					var elementsToScore = [];
					var node = this._doc.documentElement;
					let shouldRemoveTitleHeader = true;
					while (node) {
						if (node.tagName === "HTML") this._articleLang = node.getAttribute("lang");
						var matchString = node.className + " " + node.id;
						if (!this._isProbablyVisible(node)) {
							this.log("Removing hidden node - " + matchString);
							node = this._removeAndGetNext(node);
							continue;
						}
						if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
							node = this._removeAndGetNext(node);
							continue;
						}
						if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
							var endOfSearchMarkerNode = this._getNextNode(node, true);
							var next = this._getNextNode(node);
							var itemPropNameNode = null;
							while (next && next != endOfSearchMarkerNode) {
								var itemprop = next.getAttribute("itemprop");
								if (itemprop && itemprop.includes("name")) {
									itemPropNameNode = next;
									break;
								} else next = this._getNextNode(next);
							}
							this._articleByline = (itemPropNameNode ?? node).textContent.trim();
							node = this._removeAndGetNext(node);
							continue;
						}
						if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
							this.log("Removing header: ", node.textContent.trim(), this._articleTitle.trim());
							shouldRemoveTitleHeader = false;
							node = this._removeAndGetNext(node);
							continue;
						}
						if (stripUnlikelyCandidates) {
							if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
								this.log("Removing unlikely candidate - " + matchString);
								node = this._removeAndGetNext(node);
								continue;
							}
							if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
								this.log("Removing content with role " + node.getAttribute("role") + " - " + matchString);
								node = this._removeAndGetNext(node);
								continue;
							}
						}
						if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
							node = this._removeAndGetNext(node);
							continue;
						}
						if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) elementsToScore.push(node);
						if (node.tagName === "DIV") {
							var p = null;
							var childNode = node.firstChild;
							while (childNode) {
								var nextSibling = childNode.nextSibling;
								if (this._isPhrasingContent(childNode)) {
									if (p !== null) p.appendChild(childNode);
									else if (!this._isWhitespace(childNode)) {
										p = doc.createElement("p");
										node.replaceChild(p, childNode);
										p.appendChild(childNode);
									}
								} else if (p !== null) {
									while (p.lastChild && this._isWhitespace(p.lastChild)) p.lastChild.remove();
									p = null;
								}
								childNode = nextSibling;
							}
							if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < .25) {
								var newNode = node.children[0];
								node.parentNode.replaceChild(newNode, node);
								node = newNode;
								elementsToScore.push(node);
							} else if (!this._hasChildBlockElement(node)) {
								node = this._setNodeTag(node, "P");
								elementsToScore.push(node);
							}
						}
						node = this._getNextNode(node);
					}
					/**
					* Loop through all paragraphs, and assign a score to them based on how content-y they look.
					* Then add their score to their parent node.
					*
					* A score is determined by things like number of commas, class names, etc. Maybe eventually link density.
					**/
					var candidates = [];
					this._forEachNode(elementsToScore, function(elementToScore) {
						if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") return;
						var innerText = this._getInnerText(elementToScore);
						if (innerText.length < 25) return;
						var ancestors = this._getNodeAncestors(elementToScore, 5);
						if (ancestors.length === 0) return;
						var contentScore = 0;
						contentScore += 1;
						contentScore += innerText.split(this.REGEXPS.commas).length;
						contentScore += Math.min(Math.floor(innerText.length / 100), 3);
						this._forEachNode(ancestors, function(ancestor, level) {
							if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") return;
							if (typeof ancestor.readability === "undefined") {
								this._initializeNode(ancestor);
								candidates.push(ancestor);
							}
							if (level === 0) var scoreDivider = 1;
							else if (level === 1) scoreDivider = 2;
							else scoreDivider = level * 3;
							ancestor.readability.contentScore += contentScore / scoreDivider;
						});
					});
					var topCandidates = [];
					for (var c = 0, cl = candidates.length; c < cl; c += 1) {
						var candidate = candidates[c];
						var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
						candidate.readability.contentScore = candidateScore;
						this.log("Candidate:", candidate, "with score " + candidateScore);
						for (var t = 0; t < this._nbTopCandidates; t++) {
							var aTopCandidate = topCandidates[t];
							if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
								topCandidates.splice(t, 0, candidate);
								if (topCandidates.length > this._nbTopCandidates) topCandidates.pop();
								break;
							}
						}
					}
					var topCandidate = topCandidates[0] || null;
					var neededToCreateTopCandidate = false;
					var parentOfTopCandidate;
					if (topCandidate === null || topCandidate.tagName === "BODY") {
						topCandidate = doc.createElement("DIV");
						neededToCreateTopCandidate = true;
						while (page.firstChild) {
							this.log("Moving child out:", page.firstChild);
							topCandidate.appendChild(page.firstChild);
						}
						page.appendChild(topCandidate);
						this._initializeNode(topCandidate);
					} else if (topCandidate) {
						var alternativeCandidateAncestors = [];
						for (var i = 1; i < topCandidates.length; i++) if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= .75) alternativeCandidateAncestors.push(this._getNodeAncestors(topCandidates[i]));
						var MINIMUM_TOPCANDIDATES = 3;
						if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
							parentOfTopCandidate = topCandidate.parentNode;
							while (parentOfTopCandidate.tagName !== "BODY") {
								var listsContainingThisAncestor = 0;
								for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) listsContainingThisAncestor += Number(alternativeCandidateAncestors[ancestorIndex].includes(parentOfTopCandidate));
								if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
									topCandidate = parentOfTopCandidate;
									break;
								}
								parentOfTopCandidate = parentOfTopCandidate.parentNode;
							}
						}
						if (!topCandidate.readability) this._initializeNode(topCandidate);
						parentOfTopCandidate = topCandidate.parentNode;
						var lastScore = topCandidate.readability.contentScore;
						var scoreThreshold = lastScore / 3;
						while (parentOfTopCandidate.tagName !== "BODY") {
							if (!parentOfTopCandidate.readability) {
								parentOfTopCandidate = parentOfTopCandidate.parentNode;
								continue;
							}
							var parentScore = parentOfTopCandidate.readability.contentScore;
							if (parentScore < scoreThreshold) break;
							if (parentScore > lastScore) {
								topCandidate = parentOfTopCandidate;
								break;
							}
							lastScore = parentOfTopCandidate.readability.contentScore;
							parentOfTopCandidate = parentOfTopCandidate.parentNode;
						}
						parentOfTopCandidate = topCandidate.parentNode;
						while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
							topCandidate = parentOfTopCandidate;
							parentOfTopCandidate = topCandidate.parentNode;
						}
						if (!topCandidate.readability) this._initializeNode(topCandidate);
					}
					var articleContent = doc.createElement("DIV");
					if (isPaging) articleContent.id = "readability-content";
					var siblingScoreThreshold = Math.max(10, topCandidate.readability.contentScore * .2);
					parentOfTopCandidate = topCandidate.parentNode;
					var siblings = parentOfTopCandidate.children;
					for (var s = 0, sl = siblings.length; s < sl; s++) {
						var sibling = siblings[s];
						var append = false;
						this.log("Looking at sibling node:", sibling, sibling.readability ? "with score " + sibling.readability.contentScore : "");
						this.log("Sibling has score", sibling.readability ? sibling.readability.contentScore : "Unknown");
						if (sibling === topCandidate) append = true;
						else {
							var contentBonus = 0;
							if (sibling.className === topCandidate.className && topCandidate.className !== "") contentBonus += topCandidate.readability.contentScore * .2;
							if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) append = true;
							else if (sibling.nodeName === "P") {
								var linkDensity = this._getLinkDensity(sibling);
								var nodeContent = this._getInnerText(sibling);
								var nodeLength = nodeContent.length;
								if (nodeLength > 80 && linkDensity < .25) append = true;
								else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) append = true;
							}
						}
						if (append) {
							this.log("Appending node:", sibling);
							if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
								this.log("Altering sibling:", sibling, "to div.");
								sibling = this._setNodeTag(sibling, "DIV");
							}
							articleContent.appendChild(sibling);
							siblings = parentOfTopCandidate.children;
							s -= 1;
							sl -= 1;
						}
					}
					if (this._debug) this.log("Article content pre-prep: " + articleContent.innerHTML);
					this._prepArticle(articleContent);
					if (this._debug) this.log("Article content post-prep: " + articleContent.innerHTML);
					if (neededToCreateTopCandidate) {
						topCandidate.id = "readability-page-1";
						topCandidate.className = "page";
					} else {
						var div = doc.createElement("DIV");
						div.id = "readability-page-1";
						div.className = "page";
						while (articleContent.firstChild) div.appendChild(articleContent.firstChild);
						articleContent.appendChild(div);
					}
					if (this._debug) this.log("Article content after paging: " + articleContent.innerHTML);
					var parseSuccessful = true;
					var textLength = this._getInnerText(articleContent, true).length;
					if (textLength < this._charThreshold) {
						parseSuccessful = false;
						page.innerHTML = pageCacheHtml;
						this._attempts.push({
							articleContent,
							textLength
						});
						if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
						else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) this._removeFlag(this.FLAG_WEIGHT_CLASSES);
						else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
						else {
							this._attempts.sort(function(a, b) {
								return b.textLength - a.textLength;
							});
							if (!this._attempts[0].textLength) return null;
							articleContent = this._attempts[0].articleContent;
							parseSuccessful = true;
						}
					}
					if (parseSuccessful) {
						var ancestors = [parentOfTopCandidate, topCandidate].concat(this._getNodeAncestors(parentOfTopCandidate));
						this._someNode(ancestors, function(ancestor) {
							if (!ancestor.tagName) return false;
							var articleDir = ancestor.getAttribute("dir");
							if (articleDir) {
								this._articleDir = articleDir;
								return true;
							}
							return false;
						});
						return articleContent;
					}
				}
			},
			/**
			* Converts some of the common HTML entities in string to their corresponding characters.
			*
			* @param str {string} - a string to unescape.
			* @return string without HTML entity.
			*/
			_unescapeHtmlEntities(str) {
				if (!str) return str;
				var htmlEscapeMap = this.HTML_ESCAPE_MAP;
				return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
					return htmlEscapeMap[tag];
				}).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
					var num = parseInt(hex || numStr, hex ? 16 : 10);
					if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) num = 65533;
					return String.fromCodePoint(num);
				});
			},
			/**
			* Try to extract metadata from JSON-LD object.
			* For now, only Schema.org objects of type Article or its subtypes are supported.
			* @return Object with any metadata that could be extracted (possibly none)
			*/
			_getJSONLD(doc) {
				var scripts = this._getAllNodesWithTag(doc, ["script"]);
				var metadata;
				this._forEachNode(scripts, function(jsonLdElement) {
					if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") try {
						var content = jsonLdElement.textContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
						var parsed = JSON.parse(content);
						if (Array.isArray(parsed)) {
							parsed = parsed.find((it) => {
								return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
							});
							if (!parsed) return;
						}
						var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
						if (!(typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex))) return;
						if (!parsed["@type"] && Array.isArray(parsed["@graph"])) parsed = parsed["@graph"].find((it) => {
							return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
						});
						if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) return;
						metadata = {};
						if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
							var title = this._getArticleTitle();
							var nameMatches = this._textSimilarity(parsed.name, title) > .75;
							if (this._textSimilarity(parsed.headline, title) > .75 && !nameMatches) metadata.title = parsed.headline;
							else metadata.title = parsed.name;
						} else if (typeof parsed.name === "string") metadata.title = parsed.name.trim();
						else if (typeof parsed.headline === "string") metadata.title = parsed.headline.trim();
						if (parsed.author) {
							if (typeof parsed.author.name === "string") metadata.byline = parsed.author.name.trim();
							else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") metadata.byline = parsed.author.filter(function(author) {
								return author && typeof author.name === "string";
							}).map(function(author) {
								return author.name.trim();
							}).join(", ");
						}
						if (typeof parsed.description === "string") metadata.excerpt = parsed.description.trim();
						if (parsed.publisher && typeof parsed.publisher.name === "string") metadata.siteName = parsed.publisher.name.trim();
						if (typeof parsed.datePublished === "string") metadata.datePublished = parsed.datePublished.trim();
					} catch (err) {
						this.log(err.message);
					}
				});
				return metadata ? metadata : {};
			},
			/**
			* Attempts to get excerpt and byline metadata for the article.
			*
			* @param {Object} jsonld — object containing any metadata that
			* could be extracted from JSON-LD object.
			*
			* @return Object with optional "excerpt" and "byline" properties
			*/
			_getArticleMetadata(jsonld) {
				var metadata = {};
				var values = {};
				var metaElements = this._doc.getElementsByTagName("meta");
				var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
				var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
				this._forEachNode(metaElements, function(element) {
					var elementName = element.getAttribute("name");
					var elementProperty = element.getAttribute("property");
					var content = element.getAttribute("content");
					if (!content) return;
					var matches = null;
					var name = null;
					if (elementProperty) {
						matches = elementProperty.match(propertyPattern);
						if (matches) {
							name = matches[0].toLowerCase().replace(/\s/g, "");
							values[name] = content.trim();
						}
					}
					if (!matches && elementName && namePattern.test(elementName)) {
						name = elementName;
						if (content) {
							name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
							values[name] = content.trim();
						}
					}
				});
				metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
				if (!metadata.title) metadata.title = this._getArticleTitle();
				const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
				metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
				metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
				metadata.siteName = jsonld.siteName || values["og:site_name"];
				metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
				metadata.title = this._unescapeHtmlEntities(metadata.title);
				metadata.byline = this._unescapeHtmlEntities(metadata.byline);
				metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
				metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
				metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
				return metadata;
			},
			/**
			* Check if node is image, or if node contains exactly only one image
			* whether as a direct child or as its descendants.
			*
			* @param Element
			**/
			_isSingleImage(node) {
				while (node) {
					if (node.tagName === "IMG") return true;
					if (node.children.length !== 1 || node.textContent.trim() !== "") return false;
					node = node.children[0];
				}
				return false;
			},
			/**
			* Find all <noscript> that are located after <img> nodes, and which contain only one
			* <img> element. Replace the first image with the image from inside the <noscript> tag,
			* and remove the <noscript> tag. This improves the quality of the images we use on
			* some sites (e.g. Medium).
			*
			* @param Element
			**/
			_unwrapNoscriptImages(doc) {
				var imgs = Array.from(doc.getElementsByTagName("img"));
				this._forEachNode(imgs, function(img) {
					for (var i = 0; i < img.attributes.length; i++) {
						var attr = img.attributes[i];
						switch (attr.name) {
							case "src":
							case "srcset":
							case "data-src":
							case "data-srcset": return;
						}
						if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) return;
					}
					img.remove();
				});
				var noscripts = Array.from(doc.getElementsByTagName("noscript"));
				this._forEachNode(noscripts, function(noscript) {
					if (!this._isSingleImage(noscript)) return;
					var tmp = doc.createElement("div");
					tmp.innerHTML = noscript.innerHTML;
					var prevElement = noscript.previousElementSibling;
					if (prevElement && this._isSingleImage(prevElement)) {
						var prevImg = prevElement;
						if (prevImg.tagName !== "IMG") prevImg = prevElement.getElementsByTagName("img")[0];
						var newImg = tmp.getElementsByTagName("img")[0];
						for (var i = 0; i < prevImg.attributes.length; i++) {
							var attr = prevImg.attributes[i];
							if (attr.value === "") continue;
							if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
								if (newImg.getAttribute(attr.name) === attr.value) continue;
								var attrName = attr.name;
								if (newImg.hasAttribute(attrName)) attrName = "data-old-" + attrName;
								newImg.setAttribute(attrName, attr.value);
							}
						}
						noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
					}
				});
			},
			/**
			* Removes script tags from the document.
			*
			* @param Element
			**/
			_removeScripts(doc) {
				this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
			},
			/**
			* Check if this node has only whitespace and a single element with given tag
			* Returns false if the DIV node contains non-empty text nodes
			* or if it contains no element with given tag or more than 1 element.
			*
			* @param Element
			* @param string tag of child element
			**/
			_hasSingleTagInsideElement(element, tag) {
				if (element.children.length != 1 || element.children[0].tagName !== tag) return false;
				return !this._someNode(element.childNodes, function(node) {
					return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
				});
			},
			_isElementWithoutContent(node) {
				return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
			},
			/**
			* Determine whether element has any children block level elements.
			*
			* @param Element
			*/
			_hasChildBlockElement(element) {
				return this._someNode(element.childNodes, function(node) {
					return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
				});
			},
			/***
			* Determine if a node qualifies as phrasing content.
			* https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
			**/
			_isPhrasingContent(node) {
				return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
			},
			_isWhitespace(node) {
				return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
			},
			/**
			* Get the inner text of a node - cross browser compatibly.
			* This also strips out any excess whitespace to be found.
			*
			* @param Element
			* @param Boolean normalizeSpaces (default: true)
			* @return string
			**/
			_getInnerText(e, normalizeSpaces) {
				normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
				var textContent = e.textContent.trim();
				if (normalizeSpaces) return textContent.replace(this.REGEXPS.normalize, " ");
				return textContent;
			},
			/**
			* Get the number of times a string s appears in the node e.
			*
			* @param Element
			* @param string - what to split on. Default is ","
			* @return number (integer)
			**/
			_getCharCount(e, s) {
				s = s || ",";
				return this._getInnerText(e).split(s).length - 1;
			},
			/**
			* Remove the style attribute on every e and under.
			* TODO: Test if getElementsByTagName(*) is faster.
			*
			* @param Element
			* @return void
			**/
			_cleanStyles(e) {
				if (!e || e.tagName.toLowerCase() === "svg") return;
				for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
				if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
					e.removeAttribute("width");
					e.removeAttribute("height");
				}
				var cur = e.firstElementChild;
				while (cur !== null) {
					this._cleanStyles(cur);
					cur = cur.nextElementSibling;
				}
			},
			/**
			* Get the density of links as a percentage of the content
			* This is the amount of text that is inside a link divided by the total text in the node.
			*
			* @param Element
			* @return number (float)
			**/
			_getLinkDensity(element) {
				var textLength = this._getInnerText(element).length;
				if (textLength === 0) return 0;
				var linkLength = 0;
				this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
					var href = linkNode.getAttribute("href");
					var coefficient = href && this.REGEXPS.hashUrl.test(href) ? .3 : 1;
					linkLength += this._getInnerText(linkNode).length * coefficient;
				});
				return linkLength / textLength;
			},
			/**
			* Get an elements class/id weight. Uses regular expressions to tell if this
			* element looks good or bad.
			*
			* @param Element
			* @return number (Integer)
			**/
			_getClassWeight(e) {
				if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) return 0;
				var weight = 0;
				if (typeof e.className === "string" && e.className !== "") {
					if (this.REGEXPS.negative.test(e.className)) weight -= 25;
					if (this.REGEXPS.positive.test(e.className)) weight += 25;
				}
				if (typeof e.id === "string" && e.id !== "") {
					if (this.REGEXPS.negative.test(e.id)) weight -= 25;
					if (this.REGEXPS.positive.test(e.id)) weight += 25;
				}
				return weight;
			},
			/**
			* Clean a node of all elements of type "tag".
			* (Unless it's a youtube/vimeo video. People love movies.)
			*
			* @param Element
			* @param string tag to clean
			* @return void
			**/
			_clean(e, tag) {
				var isEmbed = [
					"object",
					"embed",
					"iframe"
				].includes(tag);
				this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
					if (isEmbed) {
						for (var i = 0; i < element.attributes.length; i++) if (this._allowedVideoRegex.test(element.attributes[i].value)) return false;
						if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) return false;
					}
					return true;
				});
			},
			/**
			* Check if a given node has one of its ancestor tag name matching the
			* provided one.
			* @param  HTMLElement node
			* @param  String      tagName
			* @param  Number      maxDepth
			* @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
			* @return Boolean
			*/
			_hasAncestorTag(node, tagName, maxDepth, filterFn) {
				maxDepth = maxDepth || 3;
				tagName = tagName.toUpperCase();
				var depth = 0;
				while (node.parentNode) {
					if (maxDepth > 0 && depth > maxDepth) return false;
					if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) return true;
					node = node.parentNode;
					depth++;
				}
				return false;
			},
			/**
			* Return an object indicating how many rows and columns this table has.
			*/
			_getRowAndColumnCount(table) {
				var rows = 0;
				var columns = 0;
				var trs = table.getElementsByTagName("tr");
				for (var i = 0; i < trs.length; i++) {
					var rowspan = trs[i].getAttribute("rowspan") || 0;
					if (rowspan) rowspan = parseInt(rowspan, 10);
					rows += rowspan || 1;
					var columnsInThisRow = 0;
					var cells = trs[i].getElementsByTagName("td");
					for (var j = 0; j < cells.length; j++) {
						var colspan = cells[j].getAttribute("colspan") || 0;
						if (colspan) colspan = parseInt(colspan, 10);
						columnsInThisRow += colspan || 1;
					}
					columns = Math.max(columns, columnsInThisRow);
				}
				return {
					rows,
					columns
				};
			},
			/**
			* Look for 'data' (as opposed to 'layout') tables, for which we use
			* similar checks as
			* https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
			*/
			_markDataTables(root) {
				var tables = root.getElementsByTagName("table");
				for (var i = 0; i < tables.length; i++) {
					var table = tables[i];
					if (table.getAttribute("role") == "presentation") {
						table._readabilityDataTable = false;
						continue;
					}
					if (table.getAttribute("datatable") == "0") {
						table._readabilityDataTable = false;
						continue;
					}
					if (table.getAttribute("summary")) {
						table._readabilityDataTable = true;
						continue;
					}
					var caption = table.getElementsByTagName("caption")[0];
					if (caption && caption.childNodes.length) {
						table._readabilityDataTable = true;
						continue;
					}
					var dataTableDescendants = [
						"col",
						"colgroup",
						"tfoot",
						"thead",
						"th"
					];
					var descendantExists = function(tag) {
						return !!table.getElementsByTagName(tag)[0];
					};
					if (dataTableDescendants.some(descendantExists)) {
						this.log("Data table because found data-y descendant");
						table._readabilityDataTable = true;
						continue;
					}
					if (table.getElementsByTagName("table")[0]) {
						table._readabilityDataTable = false;
						continue;
					}
					var sizeInfo = this._getRowAndColumnCount(table);
					if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
						table._readabilityDataTable = false;
						continue;
					}
					if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
						table._readabilityDataTable = true;
						continue;
					}
					table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
				}
			},
			_fixLazyImages(root) {
				this._forEachNode(this._getAllNodesWithTag(root, [
					"img",
					"picture",
					"figure"
				]), function(elem) {
					if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
						var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
						if (parts[1] === "image/svg+xml") return;
						var srcCouldBeRemoved = false;
						for (var i = 0; i < elem.attributes.length; i++) {
							var attr = elem.attributes[i];
							if (attr.name === "src") continue;
							if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
								srcCouldBeRemoved = true;
								break;
							}
						}
						if (srcCouldBeRemoved) {
							var b64starts = parts[0].length;
							if (elem.src.length - b64starts < 133) elem.removeAttribute("src");
						}
					}
					if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) return;
					for (var j = 0; j < elem.attributes.length; j++) {
						attr = elem.attributes[j];
						if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") continue;
						var copyTo = null;
						if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) copyTo = "srcset";
						else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) copyTo = "src";
						if (copyTo) {
							if (elem.tagName === "IMG" || elem.tagName === "PICTURE") elem.setAttribute(copyTo, attr.value);
							else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
								var img = this._doc.createElement("img");
								img.setAttribute(copyTo, attr.value);
								elem.appendChild(img);
							}
						}
					}
				});
			},
			_getTextDensity(e, tags) {
				var textLength = this._getInnerText(e, true).length;
				if (textLength === 0) return 0;
				var childrenLength = 0;
				var children = this._getAllNodesWithTag(e, tags);
				this._forEachNode(children, (child) => childrenLength += this._getInnerText(child, true).length);
				return childrenLength / textLength;
			},
			/**
			* Clean an element of all tags of type "tag" if they look fishy.
			* "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
			*
			* @return void
			**/
			_cleanConditionally(e, tag) {
				if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) return;
				this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
					var isDataTable = function(t) {
						return t._readabilityDataTable;
					};
					var isList = tag === "ul" || tag === "ol";
					if (!isList) {
						var listLength = 0;
						var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
						this._forEachNode(listNodes, (list) => listLength += this._getInnerText(list).length);
						isList = listLength / this._getInnerText(node).length > .9;
					}
					if (tag === "table" && isDataTable(node)) return false;
					if (this._hasAncestorTag(node, "table", -1, isDataTable)) return false;
					if (this._hasAncestorTag(node, "code")) return false;
					if ([...node.getElementsByTagName("table")].some((tbl) => tbl._readabilityDataTable)) return false;
					var weight = this._getClassWeight(node);
					this.log("Cleaning Conditionally", node);
					if (weight + 0 < 0) return true;
					if (this._getCharCount(node, ",") < 10) {
						var p = node.getElementsByTagName("p").length;
						var img = node.getElementsByTagName("img").length;
						var li = node.getElementsByTagName("li").length - 100;
						var input = node.getElementsByTagName("input").length;
						var headingDensity = this._getTextDensity(node, [
							"h1",
							"h2",
							"h3",
							"h4",
							"h5",
							"h6"
						]);
						var embedCount = 0;
						var embeds = this._getAllNodesWithTag(node, [
							"object",
							"embed",
							"iframe"
						]);
						for (var i = 0; i < embeds.length; i++) {
							for (var j = 0; j < embeds[i].attributes.length; j++) if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) return false;
							if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) return false;
							embedCount++;
						}
						var innerText = this._getInnerText(node);
						if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) return true;
						var contentLength = innerText.length;
						var linkDensity = this._getLinkDensity(node);
						var textishTags = [
							"SPAN",
							"LI",
							"TD"
						].concat(Array.from(this.DIV_TO_P_ELEMS));
						var textDensity = this._getTextDensity(node, textishTags);
						var isFigureChild = this._hasAncestorTag(node, "figure");
						const shouldRemoveNode = () => {
							const errs = [];
							if (!isFigureChild && img > 1 && p / img < .5) errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
							if (!isList && li > p) errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
							if (input > Math.floor(p / 3)) errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
							if (!isList && !isFigureChild && headingDensity < .9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) errs.push(`Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`);
							if (!isList && weight < 25 && linkDensity > .2 + this._linkDensityModifier) errs.push(`Low weight and a little linky. (linkDensity=${linkDensity})`);
							if (weight >= 25 && linkDensity > .5 + this._linkDensityModifier) errs.push(`High weight and mostly links. (linkDensity=${linkDensity})`);
							if (embedCount === 1 && contentLength < 75 || embedCount > 1) errs.push(`Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`);
							if (img === 0 && textDensity === 0) errs.push(`No useful content. (img=${img}, textDensity=${textDensity})`);
							if (errs.length) {
								this.log("Checks failed", errs);
								return true;
							}
							return false;
						};
						var haveToRemove = shouldRemoveNode();
						if (isList && haveToRemove) {
							for (var x = 0; x < node.children.length; x++) if (node.children[x].children.length > 1) return haveToRemove;
							if (img == node.getElementsByTagName("li").length) return false;
						}
						return haveToRemove;
					}
					return false;
				});
			},
			/**
			* Clean out elements that match the specified conditions
			*
			* @param Element
			* @param Function determines whether a node should be removed
			* @return void
			**/
			_cleanMatchedNodes(e, filter) {
				var endOfSearchMarkerNode = this._getNextNode(e, true);
				var next = this._getNextNode(e);
				while (next && next != endOfSearchMarkerNode) if (filter.call(this, next, next.className + " " + next.id)) next = this._removeAndGetNext(next);
				else next = this._getNextNode(next);
			},
			/**
			* Clean out spurious headers from an Element.
			*
			* @param Element
			* @return void
			**/
			_cleanHeaders(e) {
				let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
				this._removeNodes(headingNodes, function(node) {
					let shouldRemove = this._getClassWeight(node) < 0;
					if (shouldRemove) this.log("Removing header with low class weight:", node);
					return shouldRemove;
				});
			},
			/**
			* Check if this node is an H1 or H2 element whose content is mostly
			* the same as the article title.
			*
			* @param Element  the node to check.
			* @return boolean indicating whether this is a title-like header.
			*/
			_headerDuplicatesTitle(node) {
				if (node.tagName != "H1" && node.tagName != "H2") return false;
				var heading = this._getInnerText(node, false);
				this.log("Evaluating similarity of header:", heading, this._articleTitle);
				return this._textSimilarity(this._articleTitle, heading) > .75;
			},
			_flagIsActive(flag) {
				return (this._flags & flag) > 0;
			},
			_removeFlag(flag) {
				this._flags = this._flags & ~flag;
			},
			_isProbablyVisible(node) {
				return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
			},
			/**
			* Runs readability.
			*
			* Workflow:
			*  1. Prep the document by removing script tags, css, etc.
			*  2. Build readability's DOM tree.
			*  3. Grab the article content from the current dom tree.
			*  4. Replace the current DOM tree with the new one.
			*  5. Read peacefully.
			*
			* @return void
			**/
			parse() {
				if (this._maxElemsToParse > 0) {
					var numTags = this._doc.getElementsByTagName("*").length;
					if (numTags > this._maxElemsToParse) throw new Error("Aborting parsing document; " + numTags + " elements found");
				}
				this._unwrapNoscriptImages(this._doc);
				var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
				this._removeScripts(this._doc);
				this._prepDocument();
				var metadata = this._getArticleMetadata(jsonLd);
				this._metadata = metadata;
				this._articleTitle = metadata.title;
				var articleContent = this._grabArticle();
				if (!articleContent) return null;
				this.log("Grabbed: " + articleContent.innerHTML);
				this._postProcessContent(articleContent);
				if (!metadata.excerpt) {
					var paragraphs = articleContent.getElementsByTagName("p");
					if (paragraphs.length) metadata.excerpt = paragraphs[0].textContent.trim();
				}
				var textContent = articleContent.textContent;
				return {
					title: this._articleTitle,
					byline: metadata.byline || this._articleByline,
					dir: this._articleDir,
					lang: this._articleLang,
					content: this._serializer(articleContent),
					textContent,
					length: textContent.length,
					excerpt: metadata.excerpt,
					siteName: metadata.siteName || this._articleSiteName,
					publishedTime: metadata.publishedTime
				};
			}
		};
		if (typeof module === "object") module.exports = Readability;
	}));
	//#endregion
	//#region node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability-readerable.js
	var require_Readability_readerable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		var REGEXPS = {
			unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
			okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
		};
		function isNodeVisible(node) {
			return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
		}
		/**
		* Decides whether or not the document is reader-able without parsing the whole thing.
		* @param {Object} options Configuration object.
		* @param {number} [options.minContentLength=140] The minimum node content length used to decide if the document is readerable.
		* @param {number} [options.minScore=20] The minumum cumulated 'score' used to determine if the document is readerable.
		* @param {Function} [options.visibilityChecker=isNodeVisible] The function used to determine if a node is visible.
		* @return {boolean} Whether or not we suspect Readability.parse() will suceeed at returning an article object.
		*/
		function isProbablyReaderable(doc, options = {}) {
			if (typeof options == "function") options = { visibilityChecker: options };
			options = Object.assign({
				minScore: 20,
				minContentLength: 140,
				visibilityChecker: isNodeVisible
			}, options);
			var nodes = doc.querySelectorAll("p, pre, article");
			var brNodes = doc.querySelectorAll("div > br");
			if (brNodes.length) {
				var set = new Set(nodes);
				[].forEach.call(brNodes, function(node) {
					set.add(node.parentNode);
				});
				nodes = Array.from(set);
			}
			var score = 0;
			return [].some.call(nodes, function(node) {
				if (!options.visibilityChecker(node)) return false;
				var matchString = node.className + " " + node.id;
				if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) return false;
				if (node.matches("li p")) return false;
				var textContentLength = node.textContent.trim().length;
				if (textContentLength < options.minContentLength) return false;
				score += Math.sqrt(textContentLength - options.minContentLength);
				if (score > options.minScore) return true;
				return false;
			});
		}
		if (typeof module === "object") module.exports = isProbablyReaderable;
	}));
	//#endregion
	//#region src/entrypoints/utils/contentDetector.ts
	var import_readability = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = {
			Readability: require_Readability(),
			isProbablyReaderable: require_Readability_readerable()
		};
	})))();
	/** 最小参与评分的文本长度 */
	var MIN_TEXT_LENGTH = 50;
	var POSITIVE_TOKENS = new Set([
		"article",
		"post",
		"entry",
		"rich",
		"story",
		"main",
		"post-content-block",
		"post-content-wrapper",
		"article-container",
		"article-wrapper"
	]);
	var POSITIVE_COMPOUND_RE = /(?:^|[\s\_-])(article|post|entry|blog|page|story|rich)[\_-](content|body|text|inner|main)(?:[\s\_-]|$)/i;
	var NEGATIVE_CONTAINER_TOKENS = new Set([
		"nav",
		"navigation",
		"navbar",
		"menu",
		"sidebar",
		"side-bar",
		"aside",
		"footer",
		"header",
		"comment",
		"comments",
		"disqus",
		"discourse",
		"widget",
		"ad",
		"ads",
		"advert",
		"banner",
		"social",
		"share",
		"sharing",
		"related",
		"recommended",
		"cookie",
		"popup",
		"modal",
		"newsletter",
		"subscribe",
		"cta",
		"promo",
		"breadcrumb",
		"pagination",
		"toolbar",
		"mbox",
		"callout",
		"pullquote"
	]);
	var META_TOKENS = new Set([
		"metadata",
		"meta",
		"author",
		"byline",
		"timestamp",
		"tag",
		"tags",
		"category",
		"categories",
		"topics",
		"topic",
		"date",
		"time",
		"reading-time",
		"post-meta",
		"entry-meta",
		"article-meta"
	]);
	var POSITIVE_ID_RE = /(?:article|content|post|entry|rich|blog|story|main|body)/i;
	var NEGATIVE_CONTAINER_ID_RE = /(?:nav|menu|sidebar|footer|header|comment|widget|ad|banner|social|share|related|cookie|popup|modal|disqus|discourse)/i;
	var META_ID_RE = /(?:author|byline|timestamp|tag|category|topic|date|meta)/i;
	var CONSENT_SDK_ID_RE = /(?:onetrust|cookiebot|trustarc|quantcast|consent|gdpr|cookielaw|cookie-law|cookie|privacy)/i;
	var CONSENT_SDK_CLASS_RE = /(?:onetrust|\bot-sdk|ot-pc|ot-cookie|cookiebot|trustarc|quantcast|qc-cmp|cookie-banner|consent-banner|gdpr-banner|privacy-banner|\bcookie[s]?\b)/i;
	/**
	* 噪声类元素文本长度安全阀：超过此长度的元素不视为 consent SDK 容器。
	*
	* webclaw 借鉴：cookie/consent/gdpr 类容器若 textContent > 5000 字符，
	* 很可能是长 FAQ / 长隐私政策正文，不应被绝对排除。
	*
	* 回归 case: #cookiesModal (Bootstrap modal 含 cookie policy tabs) 有 ~50k
	* 字符文本，因 id 含 "cookie" 被排除为 consent SDK，但它实际是页面正文，
	* 排除后 detectArticleRoot 选不到 root，用户看到 "No translatable content"。
	*/
	var CONSENT_SAFE_VALVE = 5e3;
	var _consentSafeValveMemo = /* @__PURE__ */ new WeakSet();
	/**
	* 检查元素是否因文本过长而豁免 consent SDK 判定。
	* 用 WeakSet 缓存，同一元素不会重复计算 textContent。
	*/
	function isConsentSafeValve(el) {
		if (_consentSafeValveMemo.has(el)) return true;
		if ((el.textContent || "").length > CONSENT_SAFE_VALVE) {
			_consentSafeValveMemo.add(el);
			return true;
		}
		return false;
	}
	/**
	* 元素 (或其任意祖先) 是否是隐私同意 / Cookie / 广告 SDK 容器。
	* 用于在 detectArticleRoot 里绝对排除这类高密度但非正文的容器。
	*
	* 安全阀：若元素 textContent > 5000 字符，即使命中 consent SDK 模式也不排除，
	* 防止误杀长隐私政策 / 长 FAQ 等正文内容。
	*/
	function isConsentSdkContainer(el) {
		let current = el;
		while (current) {
			const tag = current.tagName.toLowerCase();
			if (tag === "body" || tag === "html") return false;
			const id = current.id || "";
			if (id && CONSENT_SDK_ID_RE.test(id)) {
				if (isConsentSafeValve(el)) return false;
				return true;
			}
			const cls = typeof current.className === "string" ? current.className : "";
			if (cls && CONSENT_SDK_CLASS_RE.test(cls)) {
				if (isConsentSafeValve(el)) return false;
				return true;
			}
			current = current.parentElement;
		}
		return false;
	}
	var STRUCTURE_BOOST = {
		article: 1.3,
		main: 1.2,
		section: 1.02
	};
	function tokenizeClass(el) {
		if (!el.className || typeof el.className !== "string") return [];
		return el.className.toLowerCase().split(/[\s-_]+/).filter(Boolean);
	}
	function collectSignals(el) {
		let positive = false;
		let negative = false;
		let meta = false;
		for (const token of tokenizeClass(el)) {
			if (POSITIVE_TOKENS.has(token)) positive = true;
			if (NEGATIVE_CONTAINER_TOKENS.has(token)) negative = true;
			if (META_TOKENS.has(token)) meta = true;
		}
		if (typeof el.className === "string" && POSITIVE_COMPOUND_RE.test(el.className)) positive = true;
		if (el.id) {
			if (POSITIVE_ID_RE.test(el.id)) positive = true;
			if (NEGATIVE_CONTAINER_ID_RE.test(el.id)) negative = true;
			if (META_ID_RE.test(el.id)) meta = true;
		}
		return {
			positive,
			negative,
			meta
		};
	}
	function scoreElement(el) {
		const text = (el.textContent || "").trim();
		if (text.length < MIN_TEXT_LENGTH) return 0;
		const aEls = el.querySelectorAll("a");
		const linkCount = aEls.length;
		let linkTextLength = 0;
		for (let i = 0; i < aEls.length; i++) {
			const children = aEls[i].childNodes;
			for (let j = 0; j < children.length; j++) if (children[j].nodeType === 3) linkTextLength += (children[j].textContent || "").length;
		}
		let score = Math.max(0, text.length - linkTextLength) / (linkCount + 1) * Math.log(text.length + 1);
		const linkRatio = linkTextLength / Math.max(text.length, 1);
		score *= 1 / (1 + linkRatio * 2);
		const { positive, negative, meta } = collectSignals(el);
		const tag = el.tagName.toLowerCase();
		const role = el.getAttribute("role");
		let structureBoost = 1;
		if (tag === "article" || role === "article") structureBoost *= STRUCTURE_BOOST.article;
		else if (tag === "main") structureBoost *= STRUCTURE_BOOST.main;
		else if (tag === "section") structureBoost *= STRUCTURE_BOOST.section;
		let classMultiplier = 1;
		if (positive) classMultiplier *= 1.2;
		if (negative) classMultiplier *= .5;
		if (meta) classMultiplier *= .92;
		const childCount = el.children?.length || 0;
		const densityPerChild = text.length / Math.max(childCount, 1);
		let containerPenalty = 1;
		if (childCount > 20 && densityPerChild < 25) containerPenalty *= .85;
		let siblingBoost = 1;
		const parent = el.parentElement;
		if (parent) {
			const siblings = parent.children;
			let maxSiblingText = 0;
			let total = 0;
			for (let i = 0; i < siblings.length; i++) {
				const len = (siblings[i].textContent || "").length;
				total += len;
				if (len > maxSiblingText) maxSiblingText = len;
			}
			const myLen = text.length;
			if (maxSiblingText > 0 && myLen < maxSiblingText * .7) siblingBoost *= .85;
			if (siblings.length > 3) {
				const avg = total / siblings.length;
				if (avg > 0 && Math.abs(myLen - avg) / avg < .25) siblingBoost *= .9;
			}
		}
		let depthBoost = 1;
		let depth = 0;
		let p = el.parentElement;
		while (p) {
			depth++;
			p = p.parentElement;
		}
		if (depth < 3) depthBoost = .95;
		if (depth > 7) depthBoost *= .9;
		let globalRatioBoost = 1;
		const bodyEl = el.ownerDocument?.body;
		if (bodyEl && bodyEl !== el) {
			const bodyText = (bodyEl.textContent || "").length;
			if (bodyText > 0) {
				const ratio = text.length / bodyText;
				if (ratio >= .4) globalRatioBoost = 1.3;
				else if (ratio >= .25) globalRatioBoost = 1.15;
				else if (ratio < .05) globalRatioBoost = Math.max(.1, ratio / .05);
			}
		}
		return score * structureBoost * classMultiplier * containerPenalty * siblingBoost * depthBoost * globalRatioBoost;
	}
	function collectCandidates(doc) {
		const seen = /* @__PURE__ */ new Set();
		const candidates = [];
		function add(el) {
			if (!el || seen.has(el) || el === doc.body || el === doc.documentElement) return;
			if (isConsentSdkContainer(el)) return;
			seen.add(el);
			candidates.push(el);
		}
		const semantic = doc.querySelectorAll("article, main");
		for (let i = 0; i < semantic.length; i++) add(semantic[i]);
		const roles = doc.querySelectorAll("[role=\"main\"], [role=\"article\"], [role=\"region\"]");
		for (let i = 0; i < roles.length; i++) add(roles[i]);
		const nodes = doc.querySelectorAll("div, section, article, main");
		for (let i = 0; i < nodes.length; i++) {
			const el = nodes[i];
			const hasToken = tokenizeClass(el).some((t) => POSITIVE_TOKENS.has(t));
			const hasCompound = typeof el.className === "string" && POSITIVE_COMPOUND_RE.test(el.className);
			const idHit = el.id && POSITIVE_ID_RE.test(el.id);
			if (hasToken || hasCompound || idHit) add(el);
		}
		const td = doc.querySelectorAll("td");
		for (let i = 0; i < td.length; i++) {
			const t = td[i];
			if ((t.textContent || "").trim().length > 1e3) add(t);
		}
		const original = candidates.slice();
		for (let i = 0; i < original.length; i++) {
			let p = original[i].parentElement;
			for (let j = 0; j < 2 && p && p !== doc.body; j++) {
				add(p);
				p = p.parentElement;
			}
		}
		if (candidates.length < 3) {
			const children = doc.body.children;
			for (let i = 0; i < children.length; i++) {
				const c = children[i];
				if (c.tagName === "DIV" || c.tagName === "SECTION") add(c);
			}
		}
		return candidates;
	}
	/**
	* 当评分算法无法给出可靠根节点时，使用 @mozilla/readability 提取正文，
	* 并在原始 DOM 中定位对应的容器作为 fallback 根节点。
	*
	* 适用场景：页面没有 article/main 语义标签，且内容被切成多个高密度小碎片
	* （如 developers.googleblog.com 的 .inner-block-content.rich-content），
	* 评分算法容易选错。Readability 的启发式规则能更稳定地找到主文章区域。
	*/
	/**
	* 检测 best 是否只是“多个同级 section 构成文章”中的一个小节。
	*
	* 很多学术/技术站点把文章切成多个 <section> 或 <div> 同级块，
	* contentDetector 的评分会选中其中一个密度最高的小节，导致只翻译局部。
	* 当 best 的父容器包含 ≥3 个长度相当的文本块，且 best 仅占父容器一小部分时，
	* 认为页面是碎片化的，应启用 Readability fallback。
	*/
	function isFragmentedArticleRoot(best, doc) {
		const parent = best.parentElement;
		if (!parent || parent === doc.body || parent === doc.documentElement) return false;
		const bestTag = best.tagName.toLowerCase();
		if (bestTag !== "section" && bestTag !== "div") return false;
		const siblings = Array.from(parent.children).filter((c) => {
			const tag = c.tagName.toLowerCase();
			return (tag === "section" || tag === "div") && (c.textContent || "").trim().length > 100;
		});
		if (siblings.length < 3) return false;
		const bestLen = (best.textContent || "").length;
		const totalLen = siblings.reduce((sum, c) => sum + (c.textContent || "").length, 0);
		if (totalLen === 0) return false;
		return bestLen / totalLen < .3;
	}
	function tryReadabilityRoot(doc) {
		try {
			const clone = doc.documentElement.cloneNode(true);
			const cloneDoc = doc.implementation.createHTMLDocument(doc.title);
			cloneDoc.documentElement.replaceWith(clone);
			const article = new import_readability.Readability(cloneDoc).parse();
			if (!article || !article.textContent || article.textContent.trim().length < 200) return null;
			const paragraphs = article.textContent.split(/\n+/).map((s) => s.trim()).filter(Boolean);
			const signature = paragraphs.find((p) => p.length >= 40) || paragraphs[0];
			if (!signature) return null;
			let matchedTextNode = null;
			const signatureCandidates = [signature];
			const words = signature.split(/\s+/);
			for (let i = Math.min(words.length - 1, 6); i >= 2; i--) {
				const prefix = words.slice(0, i).join(" ");
				if (prefix.length >= 12) signatureCandidates.push(prefix);
			}
			for (const candidate of signatureCandidates) {
				const treeWalker = doc.createTreeWalker(doc.body, typeof NodeFilter !== "undefined" ? NodeFilter.SHOW_TEXT : 4, null);
				while (treeWalker.nextNode()) {
					const node = treeWalker.currentNode;
					if (node.textContent && node.textContent.includes(candidate)) {
						matchedTextNode = node;
						break;
					}
				}
				if (matchedTextNode) break;
			}
			if (!matchedTextNode) return null;
			let root = matchedTextNode.parentElement;
			let candidate = matchedTextNode.parentElement;
			const coverageThreshold = article.textContent.length * .8;
			while (candidate && candidate !== doc.documentElement && candidate !== doc.body?.parentElement) {
				const tag = candidate.tagName.toLowerCase();
				if (tag === "article" || tag === "main" || tag === "section" || tag === "div" || tag === "body") {
					root = candidate;
					if ((candidate.textContent || "").length >= coverageThreshold) break;
				}
				candidate = candidate.parentElement;
			}
			if (root && isConsentSdkContainer(root)) return null;
			return root;
		} catch (e) {
			console.warn("[ContentDetector] Readability fallback failed:", e);
			return null;
		}
	}
	function detectArticleRoot(doc) {
		const candidates = collectCandidates(doc);
		if (!candidates.length) return null;
		let best = null;
		let bestScore = -1;
		for (const el of candidates) {
			const s = scoreElement(el);
			if (s > bestScore) {
				bestScore = s;
				best = el;
			}
		}
		let shouldTryReadability = false;
		if (best && doc.body) {
			const bodyText = (doc.body.textContent || "").length;
			const bestTextLen = (best.textContent || "").length;
			const ratio = bodyText > 0 ? bestTextLen / bodyText : 0;
			if (bestScore < 300 || ratio < .15) shouldTryReadability = true;
			else if (isFragmentedArticleRoot(best, doc)) {
				console.log(`[ContentDetector] Best candidate looks like a fragmented section, trying Readability fallback`);
				shouldTryReadability = true;
			}
		} else shouldTryReadability = true;
		if (shouldTryReadability) {
			const readabilityRoot = tryReadabilityRoot(doc);
			if (readabilityRoot) {
				const s = scoreElement(readabilityRoot);
				const readabilityTextLen = (readabilityRoot.textContent || "").length;
				if (readabilityTextLen >= (best ? (best.textContent || "").length : 0) * .5) {
					bestScore = Math.max(s, 301);
					best = readabilityRoot;
					console.log(`[ContentDetector] Readability fallback root: <${best.tagName}> .${(best.className || "").split(/\s+/)[0]} (score: ${bestScore.toFixed(1)}, raw: ${s.toFixed(1)}, textLen: ${readabilityTextLen})`);
				}
			}
		}
		if (bestScore < 300) {
			console.log(`[ContentDetector] Best score ${bestScore.toFixed(1)} < threshold 300, fallback to body`);
			return null;
		}
		if (best && isConsentSdkContainer(best)) {
			console.log(`[ContentDetector] Best candidate is a consent/cookie SDK container, ignoring (score: ${bestScore.toFixed(1)})`);
			return null;
		}
		console.log(`[ContentDetector] Best: <${best.tagName}> .${(best.className || "").split(/\s+/)[0]} (score: ${bestScore.toFixed(1)})`);
		return best;
	}
	//#endregion
	//#region src/entrypoints/utils/contentHelper.ts
	var ARTICLE_SELECTORS = [
		".article-body",
		".article-content",
		".article-text",
		".story-body",
		".story-content",
		".u-rich-text-blog",
		".rich-text",
		".blog-content",
		".post-content",
		".entry-content",
		".page-content",
		"article",
		"[role=\"article\"]",
		"[role=\"main\"]",
		"main",
		".main-content",
		".content-body"
	];
	/**
	* 对于 bankingdive.com 这类把 <article> 当作整页 wrapper 的站点，
	* 直接用 <article> 会把页眉（h1、导语、分享菜单、署名、图片说明）
	* 和正文混在一起进同一个 chunk：模型拿到一份头重脚轻的输入，往
	* 往往正文翻译甚至直接截断。
	*
	* 策略：优先 .article-body 等具体容器，但当具体容器**外层是
	* <article> 且 <article> 里有不在该容器内的 h1/h2 标题**时，向上
	* 扩展到 <article>（TreeWalker 会一并遍历到 .first-page-pdf 里的 h1）。
	*
	* 校验：仅当 <article> 内**不在**该容器内、且有非空文本的 h1/h2
	* 才扩展。空标题（<h1></h1> 或全空格/装饰性 svg）不触发扩展，
	* 避免无谓把整页包装带回来。
	*/
	function hasValidHeadingOutside(container, ancestor) {
		const headings = ancestor.querySelectorAll("h1, h2");
		for (const h of Array.from(headings)) {
			if (container.contains(h)) continue;
			if ((h.textContent || "").trim().length < 4) continue;
			return h;
		}
		return null;
	}
	function refineArticleRoot(candidate) {
		const SPECIFIC_SELECTORS = [
			".article-body",
			".article-content",
			".article-text",
			".story-body",
			".story-content",
			".post-content"
		];
		if (SPECIFIC_SELECTORS.some((sel) => candidate.matches?.(sel))) {
			const articleAncestor = candidate.closest("article");
			if (articleAncestor && articleAncestor !== candidate) {
				const heading = hasValidHeadingOutside(candidate, articleAncestor);
				if (heading) {
					console.log("[ContentHelper] Bumping root up to <article> to capture heading:", heading.textContent?.slice(0, 40));
					return articleAncestor;
				}
			}
			return candidate;
		}
		for (const sel of SPECIFIC_SELECTORS) {
			const inner = candidate.querySelector(sel);
			if (inner && candidate.contains(inner)) {
				if (candidate.tagName.toLowerCase() === "article") {
					const heading = hasValidHeadingOutside(inner, candidate);
					if (heading) {
						console.log("[ContentHelper] Keeping outer <article> to preserve heading outside inner body:", heading.textContent?.slice(0, 40));
						return candidate;
					}
				}
				console.log("[ContentHelper] Refining article root to inner:", sel);
				return inner;
			}
		}
		return candidate;
	}
	function hasMeaningfulContent(el) {
		return (el.textContent || "").trim().length > 0;
	}
	/**
	* 穿透纯包装层：当 parent 的文本和 child 相同（parent 只是 wrapper）时向上穿。
	* 不负责"hero/content 是否同一篇文章"等业务判断 —— 那是 chooseBestRoot 的事。
	*
	* 保留 nav/footer/header 等 class 的守卫：这些不是 wrapper，遇到就停。
	*/
	function expandWrappers(el) {
		let current = el;
		const MAX_UP = 6;
		for (let i = 0; i < MAX_UP; i++) {
			const parent = current.parentElement;
			if (!parent) break;
			const tag = parent.tagName.toLowerCase();
			if (tag === "body" || tag === "html") break;
			const classes = `${parent.className || ""} ${parent.id || ""}`;
			if (/nav|menu|sidebar|footer|header|comment|widget/i.test(classes)) break;
			if ((parent.textContent || "").trim().length <= (current.textContent || "").trim().length) {
				current = parent;
				continue;
			}
			break;
		}
		return current;
	}
	var scoreCache = /* @__PURE__ */ new WeakMap();
	/**
	* 对一个候选容器评分。评分不是黑盒：reasons 记录每个因子的贡献，
	* 日志一眼看出为什么选了/没选这个节点。
	*/
	function scoreArticleContainer(container) {
		const cached = scoreCache.get(container);
		if (cached) return cached;
		let score = 0;
		const reasons = [];
		const h1Count = container.querySelectorAll("h1").length;
		if (h1Count === 1) {
			score += 20;
			reasons.push("+20 single h1");
		} else if (h1Count > 1) {
			score -= 10;
			reasons.push(`-10 multiple h1 (${h1Count})`);
		}
		const h2Count = container.querySelectorAll("h2").length;
		if (h2Count >= 2) {
			score += 10;
			reasons.push(`+10 sections (h2=${h2Count})`);
		}
		const textLength = (container.textContent ?? "").trim().length;
		const textScore = Math.min(30, textLength / 800);
		score += textScore;
		reasons.push(`+${textScore.toFixed(1)} text length (${textLength})`);
		const pCount = container.querySelectorAll("p").length;
		const pScore = Math.min(20, pCount);
		score += pScore;
		reasons.push(`+${pScore} paragraphs (${pCount})`);
		const figures = container.querySelectorAll("img, figure").length;
		const figScore = Math.min(5, figures);
		score += figScore;
		reasons.push(`+${figScore} images (${figures})`);
		if (container.querySelector("[rel=author], .author, .byline, [class*=author]")) {
			score += 8;
			reasons.push("+8 author");
		}
		if (container.querySelector("time, [class*=date], [class*=publish]")) {
			score += 6;
			reasons.push("+6 time");
		}
		const navCount = container.querySelectorAll("nav, .menu, .sidebar, footer, header").length;
		if (navCount > 0) {
			const penalty = navCount * 8;
			score -= penalty;
			reasons.push(`-${penalty} nav elements (${navCount})`);
		}
		const buttons = container.querySelectorAll("button, a.btn").length;
		if (buttons > 10) {
			score -= 15;
			reasons.push(`-15 too many buttons (${buttons})`);
		}
		if (container.querySelector("[class*=related], [class*=recommend]")) {
			score -= 8;
			reasons.push("-8 related/recommend section");
		}
		const liCount = container.querySelectorAll("li").length;
		if (liCount > 80) {
			score -= 10;
			reasons.push(`-10 too many li (${liCount})`);
		}
		const result = {
			score,
			reasons
		};
		scoreCache.set(container, result);
		return result;
	}
	/**
	* 对 candidate / parent / grandParent 三层评分，选最高分。
	* 把"hero 和正文分属兄弟 section"这类判断从规则改为评分：
	* 如果 parent（包含 hero + 正文）的分数比 candidate（只含正文）高，就选 parent。
	*
	* 守卫：candidate 已有 h1 时直接返回。h1 是文章主标题，candidate 有 h1
	* 说明它就是文章根（如 .post-content 自己带 h1），不需要向上找。
	* 只有 candidate 缺 h1（如 claude.com 的 h1 在 hero section）时才向上评分。
	*/
	function chooseBestRoot(candidate) {
		if (candidate.querySelector("h1")) return candidate;
		const list = [];
		let p = candidate;
		while (p) {
			const tag = p.tagName.toLowerCase();
			if (tag === "body" || tag === "html") break;
			list.push(p);
			if (p.querySelector("h1")) break;
			p = p.parentElement;
		}
		let best = list[0];
		let bestScore = -Infinity;
		for (const node of list) {
			const result = scoreArticleContainer(node);
			console.log(`[ContentHelper] Candidate <${node.tagName}> .${(node.className || "").slice(0, 40)} score=${result.score.toFixed(1)}`, result.reasons);
			if (result.score > bestScore) {
				best = node;
				bestScore = result.score;
			}
		}
		return best;
	}
	function findArticleRoot(doc) {
		const siteRule = matchSiteRule(window.location.href)?.siteRule;
		if (siteRule?.articleRootSelector) {
			const el = doc.querySelector(siteRule.articleRootSelector);
			if (el && hasMeaningfulContent(el)) {
				console.log(`[ContentHelper] Site rule articleRootSelector: ${siteRule.articleRootSelector} → <${el.tagName}> .${(el.className || "").slice(0, 40)}`);
				return el;
			}
			console.warn(`[ContentHelper] Site rule articleRootSelector "${siteRule.articleRootSelector}" matched no meaningful element, falling back to Layer 1`);
		}
		for (const selector of ARTICLE_SELECTORS) {
			const els = Array.from(doc.querySelectorAll(selector));
			let bestInSelector = null;
			let bestLen = 0;
			for (const el of els) {
				const len = (el.textContent || "").trim().length;
				if (len > 0 && len > bestLen) {
					bestLen = len;
					bestInSelector = el;
				}
			}
			if (bestInSelector) {
				const expanded = expandWrappers(refineArticleRoot(bestInSelector));
				const best = chooseBestRoot(expanded);
				if (best !== expanded) console.log(`[ContentHelper] Chose <${best.tagName}> .${(best.className || "").slice(0, 40)} over <${expanded.tagName}> .${(expanded.className || "").slice(0, 40)} by scoring`);
				return best;
			}
		}
		const detected = detectArticleRoot(doc);
		if (detected && hasMeaningfulContent(detected)) return detected;
		return doc.body || doc.documentElement;
	}
	/**
	* 隐藏文章根节点之外的弹窗 / overlay / cookie banner。
	*
	* walker 只遍历 effectiveRoot 子树, body 层级的 modal (登录弹窗、
	* cookie 同意浮层、newsletter 订阅弹窗等) 不会被遇到。这些元素
	* 会遮挡译文, 需要在翻译前单独标记为 data-fanyi-remove 隐藏掉。
	*
	* 用宽泛的 CSS 选择器先圈定候选, 再用 isOverlayElement 精确判定,
	* 避免对全文档做 getComputedStyle 扫描。
	*/
	function hideBodyOverlays(doc, articleRoot) {
		const candidates = doc.querySelectorAll("[class*=\"modal\"], [class*=\"popup\"], [class*=\"overlay\"], [class*=\"dialog\"], [class*=\"backdrop\"], [class*=\"lightbox\"], [class*=\"cookie\"], [id*=\"modal\"], [id*=\"popup\"], [id*=\"overlay\"], [id*=\"dialog\"], [id*=\"cookie\"], [role=\"dialog\"]");
		for (const el of candidates) {
			const tag = el.tagName.toLowerCase();
			if (tag === "body" || tag === "html") continue;
			if (articleRoot.contains(el)) continue;
			if (el === articleRoot) continue;
			if (el.hasAttribute("data-fanyi-remove")) continue;
			{
				const cls = el.classList;
				let isExtensionUi = cls.contains("selection-translator");
				if (!isExtensionUi) {
					for (let i = 0; i < cls.length; i++) if (cls[i].startsWith("fanyi-")) {
						isExtensionUi = true;
						break;
					}
				}
				if (isExtensionUi) continue;
			}
			if (isOverlayElement(el)) el.setAttribute("data-fanyi-remove", "true");
		}
	}
	/** 优先字段名：这些字段通常是正文（不分大小写）。 */
	var DATA_ISLAND_PRIORITY_FIELDS = /^(articleBody|text|content|description|body|html|markdown|summary|excerpt|plaintext)$/i;
	/** 跳过字段名：导航/元数据/技术字段（不分大小写）。 */
	var DATA_ISLAND_SKIP_FIELDS = /^(url|href|src|image|icon|logo|type|@type|@context|id|key|name|slug|tag|category|author|date|published|modified|created|updated|locale|lang|language|version|site|domain|host|path|query|method|status|code|token|csrf|nonce)$/i;
	/** 短于此长度的字符串不算正文（过滤标题、面包屑、按钮文案）。 */
	var DATA_ISLAND_MIN_TEXT_LEN = 50;
	/**
	* 递归遍历 JSON 数据，提取正文字符串。
	* - 命中 PRIORITY_FIELDS 的字段：长度 ≥ 1 即采集（标题、description 可能短）
	* - 其他字段：长度 ≥ DATA_ISLAND_MIN_TEXT_LEN 才采集（避免短字段污染）
	* - SKIP_FIELDS 字段：跳过
	*/
	function walkDataIsland(obj, fieldName, texts, seen) {
		if (obj == null || typeof obj === "number" || typeof obj === "boolean") return;
		if (typeof obj === "string") {
			const trimmed = obj.trim();
			if (trimmed.length === 0) return;
			if (seen.has(trimmed)) return;
			if (fieldName && DATA_ISLAND_SKIP_FIELDS.test(fieldName)) return;
			if (!(fieldName && DATA_ISLAND_PRIORITY_FIELDS.test(fieldName)) && trimmed.length < DATA_ISLAND_MIN_TEXT_LEN) return;
			seen.add(trimmed);
			texts.push(trimmed);
			return;
		}
		if (Array.isArray(obj)) {
			for (const item of obj) walkDataIsland(item, fieldName, texts, seen);
			return;
		}
		if (typeof obj === "object") {
			const record = obj;
			for (const key of Object.keys(record)) walkDataIsland(record[key], key, texts, seen);
		}
	}
	/**
	* 从 SPA 数据岛提取正文 TextBlock。
	*
	* 候选 script（按优先级）：
	* 1. #__NEXT_DATA__（Next.js SSR 数据）
	* 2. #__NUXT_DATA__（Nuxt SSR 数据）
	* 3. <script type="application/json">（通用，排除前两者）
	*
	* 解析失败的 script 静默跳过；提取到的字符串去重后包装成 TextBlock。
	* 不修改 DOM，返回的 xpath 是占位符 `/data-island/[i]`。
	*/
	function extractFromDataIsland(doc) {
		const candidates = [];
		const nextData = doc.getElementById("__NEXT_DATA__");
		if (nextData?.textContent) candidates.push(nextData.textContent);
		const nuxtData = doc.getElementById("__NUXT_DATA__");
		if (nuxtData?.textContent) candidates.push(nuxtData.textContent);
		const scripts = doc.querySelectorAll("script[type=\"application/json\"]");
		for (const s of Array.from(scripts)) {
			if (s.id === "__NEXT_DATA__" || s.id === "__NUXT_DATA__") continue;
			if (s.textContent) candidates.push(s.textContent);
		}
		if (candidates.length === 0) return [];
		const texts = [];
		const seen = /* @__PURE__ */ new Set();
		for (const candidate of candidates) try {
			walkDataIsland(JSON.parse(candidate), void 0, texts, seen);
		} catch {}
		if (texts.length === 0) return [];
		console.log(`[ContentHelper] Extracted ${texts.length} blocks from data island (${candidates.length} script(s) scanned)`);
		return texts.map((text, i) => ({
			id: `data-island-${i}`,
			xpath: `/data-island/${i}`,
			tag: "p",
			text
		}));
	}
	function prepareDocument(root) {
		const effectiveRoot = root instanceof Document ? findArticleRoot(root) : root;
		if (root instanceof Document) hideBodyOverlays(root, effectiveRoot);
		let blocks = extractBlocks(effectiveRoot);
		if (blocks.length === 0 && root instanceof Document && effectiveRoot !== root.body) {
			console.warn(`[ContentHelper] Detected root <${effectiveRoot.tagName}> yielded 0 blocks, falling back to <body>`);
			blocks = extractBlocks(root.body || root.documentElement);
		}
		if (blocks.length === 0 && root instanceof Document) blocks = extractFromDataIsland(root);
		if (blocks.length === 0) throw new Error("No translatable content found");
		const fullText = blocks.map((b) => b.text).join("\n\n");
		const chunks = buildChunks(blocks);
		return {
			blocks,
			chunks,
			fullText
		};
	}
	var world_default = {
		methods: {
			one: {},
			two: {},
			three: {},
			four: {}
		},
		model: {
			one: {},
			two: {},
			three: {}
		},
		compute: {},
		hooks: []
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/methods/compute.js
	var isArray$10 = (input) => Object.prototype.toString.call(input) === "[object Array]";
	var fns$4 = { 
	/** add metadata to term objects */
compute: function(input) {
		const { world } = this;
		const compute = world.compute;
		if (typeof input === "string" && compute.hasOwnProperty(input)) compute[input](this);
		else if (isArray$10(input)) input.forEach((name) => {
			if (world.compute.hasOwnProperty(name)) compute[name](this);
			else console.warn("no compute:", input);
		});
		else if (typeof input === "function") input(this);
		else console.warn("no compute:", input);
		return this;
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/methods/loops.js
	var forEach = function(cb) {
		this.fullPointer.forEach((ptr, i) => {
			cb(this.update([ptr]), i);
		});
		return this;
	};
	var map = function(cb, empty) {
		const res = this.fullPointer.map((ptr, i) => {
			const out = cb(this.update([ptr]), i);
			if (out === void 0) return this.none();
			return out;
		});
		if (res.length === 0) return empty || this.update([]);
		if (res[0] !== void 0) {
			if (typeof res[0] === "string") return res;
			if (typeof res[0] === "object" && (res[0] === null || !res[0].isView)) return res;
		}
		let all = [];
		res.forEach((ptr) => {
			all = all.concat(ptr.fullPointer);
		});
		return this.toView(all);
	};
	var filter = function(cb) {
		let ptrs = this.fullPointer;
		ptrs = ptrs.filter((ptr, i) => {
			return cb(this.update([ptr]), i);
		});
		return this.update(ptrs);
	};
	var find = function(cb) {
		const found = this.fullPointer.find((ptr, i) => {
			return cb(this.update([ptr]), i);
		});
		return this.update([found]);
	};
	var some = function(cb) {
		return this.fullPointer.some((ptr, i) => {
			return cb(this.update([ptr]), i);
		});
	};
	var random = function(n = 1) {
		let ptrs = this.fullPointer;
		let r = Math.floor(Math.random() * ptrs.length);
		if (r + n > this.length) {
			r = this.length - n;
			r = r < 0 ? 0 : r;
		}
		ptrs = ptrs.slice(r, r + n);
		return this.update(ptrs);
	};
	var loops_default = {
		forEach,
		map,
		filter,
		find,
		some,
		random
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/methods/utils.js
	var utils = {
		/** */
		termList: function() {
			return this.methods.one.termList(this.docs);
		},
		/** return individual terms*/
		terms: function(n) {
			const m = this.match(".");
			return typeof n === "number" ? m.eq(n) : m;
		},
		/** */
		groups: function(group) {
			if (group || group === 0) return this.update(this._groups[group] || []);
			const res = {};
			Object.keys(this._groups).forEach((k) => {
				res[k] = this.update(this._groups[k]);
			});
			return res;
		},
		/** */
		eq: function(n) {
			let ptr = this.pointer;
			if (!ptr) ptr = this.docs.map((_doc, i) => [i]);
			if (ptr[n]) return this.update([ptr[n]]);
			return this.none();
		},
		/** */
		first: function() {
			return this.eq(0);
		},
		/** */
		last: function() {
			const n = this.fullPointer.length - 1;
			return this.eq(n);
		},
		/** grab term[0] for every match */
		firstTerms: function() {
			return this.match("^.");
		},
		/** grab the last term for every match  */
		lastTerms: function() {
			return this.match(".$");
		},
		/** */
		slice: function(min, max) {
			let pntrs = this.pointer || this.docs.map((_o, n) => [n]);
			pntrs = pntrs.slice(min, max);
			return this.update(pntrs);
		},
		/** return a view of the entire document */
		all: function() {
			return this.update().toView();
		},
		/**  */
		fullSentences: function() {
			const ptrs = this.fullPointer.map((a) => [a[0]]);
			return this.update(ptrs).toView();
		},
		/** return a view of no parts of the document */
		none: function() {
			return this.update([]);
		},
		/** are these two views looking at the same words? */
		isDoc: function(b) {
			if (!b || !b.isView) return false;
			const aPtr = this.fullPointer;
			const bPtr = b.fullPointer;
			if (!aPtr.length === bPtr.length) return false;
			return aPtr.every((ptr, i) => {
				if (!bPtr[i]) return false;
				return ptr[0] === bPtr[i][0] && ptr[1] === bPtr[i][1] && ptr[2] === bPtr[i][2];
			});
		},
		/** how many seperate terms does the document have? */
		wordCount: function() {
			return this.docs.reduce((count, terms) => {
				count += terms.filter((t) => t.text !== "").length;
				return count;
			}, 0);
		},
		isFull: function() {
			const ptrs = this.pointer;
			if (!ptrs) return true;
			if (ptrs.length === 0 || ptrs[0][0] !== 0) return false;
			let wantTerms = 0;
			let haveTerms = 0;
			this.document.forEach((terms) => wantTerms += terms.length);
			this.docs.forEach((terms) => haveTerms += terms.length);
			return wantTerms === haveTerms;
		},
		getNth: function(n) {
			if (typeof n === "number") return this.eq(n);
			else if (typeof n === "string") return this.if(n);
			return this;
		}
	};
	utils.group = utils.groups;
	utils.fullSentence = utils.fullSentences;
	utils.sentence = utils.fullSentences;
	utils.lastTerm = utils.lastTerms;
	utils.firstTerm = utils.firstTerms;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/methods/index.js
	var methods$14 = Object.assign({}, utils, fns$4, loops_default);
	methods$14.get = methods$14.eq;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/View.js
	var View = class View {
		constructor(document, pointer, groups = {}) {
			[
				["document", document],
				["world", world_default],
				["_groups", groups],
				["_cache", null],
				["viewType", "View"]
			].forEach((a) => {
				Object.defineProperty(this, a[0], {
					value: a[1],
					writable: true
				});
			});
			this.ptrs = pointer;
		}
		get docs() {
			let docs = this.document;
			if (this.ptrs) docs = world_default.methods.one.getDoc(this.ptrs, this.document);
			return docs;
		}
		get pointer() {
			return this.ptrs;
		}
		get methods() {
			return this.world.methods;
		}
		get model() {
			return this.world.model;
		}
		get hooks() {
			return this.world.hooks;
		}
		get isView() {
			return true;
		}
		get found() {
			return this.docs.length > 0;
		}
		get length() {
			return this.docs.length;
		}
		get fullPointer() {
			const { docs, ptrs, document } = this;
			return (ptrs || docs.map((_d, n) => [n])).map((a) => {
				let [n, start, end, id, endId] = a;
				start = start || 0;
				end = end || (document[n] || []).length;
				if (document[n] && document[n][start]) {
					id = id || document[n][start].id;
					if (document[n][end - 1]) endId = endId || document[n][end - 1].id;
				}
				return [
					n,
					start,
					end,
					id,
					endId
				];
			});
		}
		update(pointer) {
			const m = new View(this.document, pointer);
			if (this._cache && pointer && pointer.length > 0) {
				const cache = [];
				pointer.forEach((ptr, i) => {
					const [n, start, end] = ptr;
					if (ptr.length === 1) cache[i] = this._cache[n];
					else if (start === 0 && this.document[n].length === end) cache[i] = this._cache[n];
				});
				if (cache.length > 0) m._cache = cache;
			}
			m.world = this.world;
			return m;
		}
		toView(pointer) {
			return new View(this.document, pointer || this.pointer);
		}
		fromText(input) {
			const { methods } = this;
			const doc = new View(methods.one.tokenize.fromString(input, this.world));
			doc.world = this.world;
			doc.compute([
				"normal",
				"freeze",
				"lexicon"
			]);
			if (this.world.compute.preTagger) doc.compute("preTagger");
			doc.compute("unfreeze");
			return doc;
		}
		clone() {
			let document = this.document.slice(0);
			document = document.map((terms) => {
				return terms.map((term) => {
					term = Object.assign({}, term);
					term.tags = new Set(term.tags);
					return term;
				});
			});
			const m = this.update(this.pointer);
			m.document = document;
			m._cache = this._cache;
			return m;
		}
	};
	Object.assign(View.prototype, methods$14);
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/_version.js
	var _version_default = "14.15.1";
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/extend.js
	var isObject$6 = function(item) {
		return item && typeof item === "object" && !Array.isArray(item);
	};
	var isArray$9 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	function mergeDeep(model, plugin) {
		if (isObject$6(plugin)) for (const key in plugin) if (isObject$6(plugin[key])) {
			if (!model[key]) Object.assign(model, { [key]: {} });
			mergeDeep(model[key], plugin[key]);
		} else Object.assign(model, { [key]: plugin[key] });
		return model;
	}
	function mergeQuick(model, plugin) {
		for (const key in plugin) {
			model[key] = model[key] || {};
			Object.assign(model[key], plugin[key]);
		}
		return model;
	}
	var addIrregulars = function(model, conj) {
		const m = model.two.models || {};
		Object.keys(conj).forEach((k) => {
			if (conj[k].pastTense) {
				if (m.toPast) m.toPast.ex[k] = conj[k].pastTense;
				if (m.fromPast) m.fromPast.ex[conj[k].pastTense] = k;
			}
			if (conj[k].presentTense) {
				if (m.toPresent) m.toPresent.ex[k] = conj[k].presentTense;
				if (m.fromPresent) m.fromPresent.ex[conj[k].presentTense] = k;
			}
			if (conj[k].gerund) {
				if (m.toGerund) m.toGerund.ex[k] = conj[k].gerund;
				if (m.fromGerund) m.fromGerund.ex[conj[k].gerund] = k;
			}
			if (conj[k].comparative) {
				if (m.toComparative) m.toComparative.ex[k] = conj[k].comparative;
				if (m.fromComparative) m.fromComparative.ex[conj[k].comparative] = k;
			}
			if (conj[k].superlative) {
				if (m.toSuperlative) m.toSuperlative.ex[k] = conj[k].superlative;
				if (m.fromSuperlative) m.fromSuperlative.ex[conj[k].superlative] = k;
			}
		});
	};
	var extend = function(plugin, world, View, nlp) {
		if (isArray$9(plugin)) {
			plugin.forEach((p) => extend(p, world, View, nlp));
			return;
		}
		const { methods, model, compute, hooks } = world;
		if (plugin.methods) mergeQuick(methods, plugin.methods);
		if (plugin.model) mergeDeep(model, plugin.model);
		if (plugin.irregulars) addIrregulars(model, plugin.irregulars);
		if (plugin.compute) Object.assign(compute, plugin.compute);
		if (hooks) world.hooks = hooks.concat(plugin.hooks || []);
		if (plugin.api) plugin.api(View);
		if (plugin.lib) Object.keys(plugin.lib).forEach((k) => nlp[k] = plugin.lib[k]);
		if (plugin.tags) nlp.addTags(plugin.tags);
		if (plugin.words) nlp.addWords(plugin.words);
		if (plugin.frozen) nlp.addWords(plugin.frozen, true);
		if (plugin.mutate) plugin.mutate(world, nlp);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/_lib.js
	/** log the decision-making to console */
	var verbose = function(set) {
		const env = typeof process === "undefined" || !process.env ? self.env || {} : process.env;
		env.DEBUG_TAGS = set === "tagger" || set === true ? true : "";
		env.DEBUG_MATCH = set === "match" || set === true ? true : "";
		env.DEBUG_CHUNKS = set === "chunker" || set === true ? true : "";
		return this;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/API/inputs.js
	var isObject$5 = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	var isArray$8 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var fromJson = function(json) {
		return json.map((o) => {
			return o.terms.map((term) => {
				if (isArray$8(term.tags)) term.tags = new Set(term.tags);
				return term;
			});
		});
	};
	var preTokenized = function(arr) {
		return arr.map((a) => {
			return a.map((str) => {
				return {
					text: str,
					normal: str,
					pre: "",
					post: " ",
					tags: /* @__PURE__ */ new Set()
				};
			});
		});
	};
	var inputs = function(input, View, world) {
		const { methods } = world;
		const doc = new View([]);
		doc.world = world;
		if (typeof input === "number") input = String(input);
		if (!input) return doc;
		if (typeof input === "string") return new View(methods.one.tokenize.fromString(input, world));
		if (isObject$5(input) && input.isView) return new View(input.document, input.ptrs);
		if (isArray$8(input)) {
			if (isArray$8(input[0])) return new View(preTokenized(input));
			return new View(fromJson(input));
		}
		return doc;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/nlp.js
	var world = Object.assign({}, world_default);
	var nlp = function(input, lex) {
		if (lex) nlp.addWords(lex);
		const doc = inputs(input, View, world);
		if (input) doc.compute(world.hooks);
		return doc;
	};
	Object.defineProperty(nlp, "_world", {
		value: world,
		writable: true
	});
	/** don't run the POS-tagger */
	nlp.tokenize = function(input, lex) {
		const { compute } = this._world;
		if (lex) nlp.addWords(lex);
		const doc = inputs(input, View, world);
		if (compute.contractions) doc.compute([
			"alias",
			"normal",
			"machine",
			"contractions"
		]);
		return doc;
	};
	/** extend compromise functionality */
	nlp.plugin = function(plugin) {
		extend(plugin, this._world, View, this);
		return this;
	};
	nlp.extend = nlp.plugin;
	/** reach-into compromise internals */
	nlp.world = function() {
		return this._world;
	};
	nlp.model = function() {
		return this._world.model;
	};
	nlp.methods = function() {
		return this._world.methods;
	};
	nlp.hooks = function() {
		return this._world.hooks;
	};
	/** log the decision-making to console */
	nlp.verbose = verbose;
	/** current library release version */
	nlp.version = _version_default;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/cache/methods/cacheDoc.js
	var createCache = function(document) {
		return document.map((terms) => {
			const items = /* @__PURE__ */ new Set();
			terms.forEach((term) => {
				if (term.normal !== "") items.add(term.normal);
				if (term.switch) items.add(`%${term.switch}%`);
				if (term.implicit) items.add(term.implicit);
				if (term.machine) items.add(term.machine);
				if (term.root) items.add(term.root);
				if (term.alias) term.alias.forEach((str) => items.add(str));
				const tags = Array.from(term.tags);
				for (let t = 0; t < tags.length; t += 1) items.add("#" + tags[t]);
			});
			return items;
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/cache/methods/index.js
	var methods_default$6 = { one: { cacheDoc: createCache } };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/cache/api.js
	var methods$13 = {
		/** */
		cache: function() {
			this._cache = this.methods.one.cacheDoc(this.document);
			return this;
		},
		/** */
		uncache: function() {
			this._cache = null;
			return this;
		}
	};
	var addAPI$3 = function(View) {
		Object.assign(View.prototype, methods$13);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/cache/plugin.js
	var plugin_default$15 = {
		api: addAPI$3,
		compute: { cache: function(view) {
			view._cache = view.methods.one.cacheDoc(view.document);
		} },
		methods: methods_default$6
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/case.js
	var case_default = {
		/** */
		toLowerCase: function() {
			this.termList().forEach((t) => {
				t.text = t.text.toLowerCase();
			});
			return this;
		},
		/** */
		toUpperCase: function() {
			this.termList().forEach((t) => {
				t.text = t.text.toUpperCase();
			});
			return this;
		},
		/** */
		toTitleCase: function() {
			this.termList().forEach((t) => {
				t.text = t.text.replace(/^ *[a-z\u00C0-\u00FF]/, (x) => x.toUpperCase());
			});
			return this;
		},
		/** */
		toCamelCase: function() {
			this.docs.forEach((terms) => {
				terms.forEach((t, i) => {
					if (i !== 0) t.text = t.text.replace(/^ *[a-z\u00C0-\u00FF]/, (x) => x.toUpperCase());
					if (i !== terms.length - 1) t.post = "";
				});
			});
			return this;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/lib/insert.js
	var isTitleCase$4 = (str) => /^\p{Lu}[\p{Ll}'’]/u.test(str) || /^\p{Lu}$/u.test(str);
	var toTitleCase$2 = (str) => str.replace(/^\p{Ll}/u, (x) => x.toUpperCase());
	var toLowerCase$1 = (str) => str.replace(/^\p{Lu}/u, (x) => x.toLowerCase());
	var spliceArr = (parent, index, child) => {
		child.forEach((term) => term.dirty = true);
		if (parent) {
			const args = [index, 0].concat(child);
			Array.prototype.splice.apply(parent, args);
		}
		return parent;
	};
	var endSpace = function(terms) {
		const hasSpace = / $/;
		const hasDash = /[-–—]/;
		const lastTerm = terms[terms.length - 1];
		if (lastTerm && !hasSpace.test(lastTerm.post) && !hasDash.test(lastTerm.post)) lastTerm.post += " ";
	};
	var movePunct = (source, end, needle) => {
		const juicy = /[-.?!,;:)–—'"]/g;
		const wasLast = source[end - 1];
		if (!wasLast) return;
		const post = wasLast.post;
		if (juicy.test(post)) {
			const punct = post.match(juicy).join("");
			const last = needle[needle.length - 1];
			last.post = punct + last.post;
			wasLast.post = wasLast.post.replace(juicy, "");
		}
	};
	var moveTitleCase = function(home, start, needle) {
		const from = home[start];
		if (start !== 0 || !isTitleCase$4(from.text)) return;
		needle[0].text = toTitleCase$2(needle[0].text);
		const old = home[start];
		if (old.tags.has("ProperNoun") || old.tags.has("Acronym")) return;
		if (isTitleCase$4(old.text) && old.text.length > 1) old.text = toLowerCase$1(old.text);
	};
	var cleanPrepend = function(home, ptr, needle, document) {
		const [n, start, end] = ptr;
		if (start === 0) endSpace(needle);
		else if (end === document[n].length) endSpace(needle);
		else {
			endSpace(needle);
			endSpace([home[ptr[1]]]);
		}
		moveTitleCase(home, start, needle);
		spliceArr(home, start, needle);
	};
	var cleanAppend = function(home, ptr, needle, document) {
		const [n, , end] = ptr;
		const total = (document[n] || []).length;
		if (end < total) {
			movePunct(home, end, needle);
			endSpace(needle);
		} else if (total === end) {
			endSpace(home);
			movePunct(home, end, needle);
			if (document[n + 1]) needle[needle.length - 1].post += " ";
		}
		spliceArr(home, ptr[2], needle);
		ptr[4] = needle[needle.length - 1].id;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/compute/uuid.js
	var index$1 = 0;
	var pad3 = (str) => {
		str = str.length < 3 ? "0" + str : str;
		return str.length < 3 ? "0" + str : str;
	};
	var toId = function(term) {
		let [n, i] = term.index || [0, 0];
		index$1 += 1;
		index$1 = index$1 > 46655 ? 0 : index$1;
		n = n > 46655 ? 0 : n;
		i = i > 1294 ? 0 : i;
		let id = pad3(index$1.toString(36));
		id += pad3(n.toString(36));
		let tx = i.toString(36);
		tx = tx.length < 2 ? "0" + tx : tx;
		id += tx;
		const r = parseInt(Math.random() * 36, 10);
		id += r.toString(36);
		return term.normal + "|" + id.toUpperCase();
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/insert.js
	var expand$3 = function(m) {
		if (m.has("@hasContraction") && typeof m.contractions === "function") m.grow("@hasContraction").contractions().expand();
	};
	var isArray$7 = (arr) => Object.prototype.toString.call(arr) === "[object Array]";
	var addIds$2 = function(terms) {
		terms = terms.map((term) => {
			term.id = toId(term);
			return term;
		});
		return terms;
	};
	var getTerms = function(input, world) {
		const { methods } = world;
		if (typeof input === "string") return methods.one.tokenize.fromString(input, world)[0];
		if (typeof input === "object" && input.isView) return input.clone().docs[0] || [];
		if (isArray$7(input)) return isArray$7(input[0]) ? input[0] : input;
		return [];
	};
	var insert = function(input, view, prepend) {
		const { document, world } = view;
		view.uncache();
		const ptrs = view.fullPointer;
		const selfPtrs = view.fullPointer;
		view.forEach((m, i) => {
			const ptr = m.fullPointer[0];
			const [n] = ptr;
			const home = document[n];
			let terms = getTerms(input, world);
			if (terms.length === 0) return;
			terms = addIds$2(terms);
			if (prepend) {
				expand$3(view.update([ptr]).firstTerm());
				cleanPrepend(home, ptr, terms, document);
			} else {
				expand$3(view.update([ptr]).lastTerm());
				cleanAppend(home, ptr, terms, document);
			}
			if (document[n] && document[n][ptr[1]]) ptr[3] = document[n][ptr[1]].id;
			selfPtrs[i] = ptr;
			ptr[2] += terms.length;
			ptrs[i] = ptr;
		});
		const doc = view.toView(ptrs);
		view.ptrs = selfPtrs;
		doc.compute([
			"id",
			"index",
			"freeze",
			"lexicon"
		]);
		if (doc.world.compute.preTagger) doc.compute("preTagger");
		doc.compute("unfreeze");
		return doc;
	};
	var fns$3 = {
		insertAfter: function(input) {
			return insert(input, this, false);
		},
		insertBefore: function(input) {
			return insert(input, this, true);
		}
	};
	fns$3.append = fns$3.insertAfter;
	fns$3.prepend = fns$3.insertBefore;
	fns$3.insert = fns$3.insertAfter;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/replace.js
	var dollarStub = /\$[0-9a-z]+/g;
	var fns$2 = {};
	var isTitleCase$3 = (str) => /^\p{Lu}[\p{Ll}'’]/u.test(str) || /^\p{Lu}$/u.test(str);
	var toTitleCase$1 = (str) => str.replace(/^\p{Ll}/u, (x) => x.toUpperCase());
	var toLowerCase = (str) => str.replace(/^\p{Lu}/u, (x) => x.toLowerCase());
	var replaceByFn = function(main, fn, keep) {
		main.forEach((m) => {
			const out = fn(m);
			m.replaceWith(out, keep);
		});
		return main;
	};
	var subDollarSign = function(input, main) {
		if (typeof input !== "string") return input;
		const groups = main.groups();
		input = input.replace(dollarStub, (a) => {
			const num = a.replace(/\$/, "");
			if (groups.hasOwnProperty(num)) return groups[num].text();
			return a;
		});
		return input;
	};
	fns$2.replaceWith = function(input, keep = {}) {
		let ptrs = this.fullPointer;
		const main = this;
		this.uncache();
		if (typeof input === "function") return replaceByFn(main, input, keep);
		const terms = main.docs[0];
		if (!terms) return main;
		const isOriginalPossessive = keep.possessives && terms[terms.length - 1].tags.has("Possessive");
		const isOriginalTitleCase = keep.case && isTitleCase$3(terms[0].text);
		input = subDollarSign(input, main);
		const original = this.update(ptrs);
		ptrs = ptrs.map((ptr) => ptr.slice(0, 3));
		const oldTags = (original.docs[0] || []).map((term) => Array.from(term.tags));
		const originalPre = original.docs[0][0].pre;
		const originalPost = original.docs[0][original.docs[0].length - 1].post;
		if (typeof input === "string") input = this.fromText(input).compute("id");
		main.insertAfter(input);
		if (original.has("@hasContraction") && main.contractions) main.grow("@hasContraction+").contractions().expand();
		main.delete(original);
		if (isOriginalPossessive) {
			const tmp = main.docs[0];
			const term = tmp[tmp.length - 1];
			if (!term.tags.has("Possessive")) {
				term.text += "'s";
				term.normal += "'s";
				term.tags.add("Possessive");
			}
		}
		if (originalPre && main.docs[0]) main.docs[0][0].pre = originalPre;
		if (originalPost && main.docs[0]) {
			const lastOne = main.docs[0][main.docs[0].length - 1];
			if (!lastOne.post.trim()) lastOne.post = originalPost;
		}
		const m = main.toView(ptrs).compute([
			"index",
			"freeze",
			"lexicon"
		]);
		if (m.world.compute.preTagger) m.compute("preTagger");
		m.compute("unfreeze");
		if (keep.tags) m.terms().forEach((term, i) => {
			term.tagSafe(oldTags[i]);
		});
		if (!m.docs[0] || !m.docs[0][0]) return m;
		if (keep.case) {
			const transformCase = isOriginalTitleCase ? toTitleCase$1 : toLowerCase;
			m.docs[0][0].text = transformCase(m.docs[0][0].text);
		}
		return m;
	};
	fns$2.replace = function(match, input, keep) {
		if (match && !input) return this.replaceWith(match, keep);
		const m = this.match(match);
		if (!m.found) return this;
		this.soften();
		return m.replaceWith(input, keep);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/lib/remove.js
	var repairPunct = function(terms, len) {
		const last = terms.length - 1;
		const from = terms[last];
		const to = terms[last - len];
		if (to && from) {
			to.post += from.post;
			to.post = to.post.replace(/ +([.?!,;:])/, "$1");
			to.post = to.post.replace(/[,;:]+([.?!])/, "$1");
		}
	};
	var pluckOut = function(document, nots) {
		nots.forEach((ptr) => {
			const [n, start, end] = ptr;
			const len = end - start;
			if (!document[n]) return;
			if (end === document[n].length && end > 1) repairPunct(document[n], len);
			document[n].splice(start, len);
		});
		for (let i = document.length - 1; i >= 0; i -= 1) if (document[i].length === 0) {
			document.splice(i, 1);
			if (i === document.length && document[i - 1]) {
				const terms = document[i - 1];
				const lastTerm = terms[terms.length - 1];
				if (lastTerm) lastTerm.post = lastTerm.post.trimEnd();
			}
		}
		return document;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/remove.js
	var fixPointers$1 = function(ptrs, gonePtrs) {
		ptrs = ptrs.map((ptr) => {
			const [n] = ptr;
			if (!gonePtrs[n]) return ptr;
			gonePtrs[n].forEach((no) => {
				const len = no[2] - no[1];
				if (ptr[1] <= no[1] && ptr[2] >= no[2]) ptr[2] -= len;
			});
			return ptr;
		});
		ptrs.forEach((ptr, i) => {
			if (ptr[1] === 0 && ptr[2] == 0) for (let n = i + 1; n < ptrs.length; n += 1) {
				ptrs[n][0] -= 1;
				if (ptrs[n][0] < 0) ptrs[n][0] = 0;
			}
		});
		ptrs = ptrs.filter((ptr) => ptr[2] - ptr[1] > 0);
		ptrs = ptrs.map((ptr) => {
			ptr[3] = null;
			ptr[4] = null;
			return ptr;
		});
		return ptrs;
	};
	var methods$12 = { 
	/** */
remove: function(reg) {
		const { indexN } = this.methods.one.pointer;
		this.uncache();
		let self = this.all();
		let not = this;
		if (reg) {
			self = this;
			not = this.match(reg);
		}
		const isFull = !self.ptrs;
		if (not.has("@hasContraction") && not.contractions) not.grow("@hasContraction").contractions().expand();
		let ptrs = self.fullPointer;
		const nots = not.fullPointer.reverse();
		const document = pluckOut(this.document, nots);
		const gonePtrs = indexN(nots);
		ptrs = fixPointers$1(ptrs, gonePtrs);
		self.ptrs = ptrs;
		self.document = document;
		self.compute("index");
		if (isFull) self.ptrs = void 0;
		if (!reg) {
			this.ptrs = [];
			return self.none();
		}
		return self.toView(ptrs);
	} };
	methods$12.delete = methods$12.remove;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/whitespace.js
	var methods$11 = {
		/** add this punctuation or whitespace before each match: */
		pre: function(str, concat) {
			if (str === void 0 && this.found) return this.docs[0][0].pre;
			this.docs.forEach((terms) => {
				const term = terms[0];
				if (concat === true) term.pre += str;
				else term.pre = str;
			});
			return this;
		},
		/** add this punctuation or whitespace after each match: */
		post: function(str, concat) {
			if (str === void 0) {
				const last = this.docs[this.docs.length - 1];
				return last[last.length - 1].post;
			}
			this.docs.forEach((terms) => {
				const term = terms[terms.length - 1];
				if (concat === true) term.post += str;
				else term.post = str;
			});
			return this;
		},
		/** remove whitespace from start/end */
		trim: function() {
			if (!this.found) return this;
			const docs = this.docs;
			const start = docs[0][0];
			start.pre = start.pre.trimStart();
			const last = docs[docs.length - 1];
			const end = last[last.length - 1];
			end.post = end.post.trimEnd();
			return this;
		},
		/** connect words with hyphen, and remove whitespace */
		hyphenate: function() {
			this.docs.forEach((terms) => {
				terms.forEach((t, i) => {
					if (i !== 0) t.pre = "";
					if (terms[i + 1]) t.post = "-";
				});
			});
			return this;
		},
		/** remove hyphens between words, and set whitespace */
		dehyphenate: function() {
			const hasHyphen = /[-–—]/;
			this.docs.forEach((terms) => {
				terms.forEach((t) => {
					if (hasHyphen.test(t.post)) t.post = " ";
				});
			});
			return this;
		},
		/** add quotations around these matches */
		toQuotations: function(start, end) {
			start = start || `"`;
			end = end || `"`;
			this.docs.forEach((terms) => {
				terms[0].pre = start + terms[0].pre;
				const last = terms[terms.length - 1];
				last.post = end + last.post;
			});
			return this;
		},
		/** add brackets around these matches */
		toParentheses: function(start, end) {
			start = start || `(`;
			end = end || `)`;
			this.docs.forEach((terms) => {
				terms[0].pre = start + terms[0].pre;
				const last = terms[terms.length - 1];
				last.post = end + last.post;
			});
			return this;
		}
	};
	methods$11.deHyphenate = methods$11.dehyphenate;
	methods$11.toQuotation = methods$11.toQuotations;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/lib/_sort.js
	/** alphabetical order */
	var alpha = (a, b) => {
		if (a.normal < b.normal) return -1;
		if (a.normal > b.normal) return 1;
		return 0;
	};
	/** count the # of characters of each match */
	var length = (a, b) => {
		const left = a.normal.trim().length;
		const right = b.normal.trim().length;
		if (left < right) return 1;
		if (left > right) return -1;
		return 0;
	};
	/** count the # of terms in each match */
	var wordCount$1 = (a, b) => {
		if (a.words < b.words) return 1;
		if (a.words > b.words) return -1;
		return 0;
	};
	/** count the # of terms in each match */
	var sequential = (a, b) => {
		if (a[0] < b[0]) return 1;
		if (a[0] > b[0]) return -1;
		return a[1] > b[1] ? 1 : -1;
	};
	/** sort by # of duplicates in the document*/
	var byFreq = function(arr) {
		const counts = {};
		arr.forEach((o) => {
			counts[o.normal] = counts[o.normal] || 0;
			counts[o.normal] += 1;
		});
		arr.sort((a, b) => {
			const left = counts[a.normal];
			const right = counts[b.normal];
			if (left < right) return 1;
			if (left > right) return -1;
			return 0;
		});
		return arr;
	};
	var _sort_default = {
		alpha,
		length,
		wordCount: wordCount$1,
		sequential,
		byFreq
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/sort.js
	var seqNames = new Set([
		"index",
		"sequence",
		"seq",
		"sequential",
		"chron",
		"chronological"
	]);
	var freqNames = new Set([
		"freq",
		"frequency",
		"topk",
		"repeats"
	]);
	var alphaNames = new Set(["alpha", "alphabetical"]);
	var customSort = function(view, fn) {
		let ptrs = view.fullPointer;
		ptrs = ptrs.sort((a, b) => {
			a = view.update([a]);
			b = view.update([b]);
			return fn(a, b);
		});
		view.ptrs = ptrs;
		return view;
	};
	/** re-arrange the order of the matches (in place) */
	var sort = function(input) {
		const { docs, pointer } = this;
		this.uncache();
		if (typeof input === "function") return customSort(this, input);
		input = input || "alpha";
		const ptrs = pointer || docs.map((_d, n) => [n]);
		let arr = docs.map((terms, n) => {
			return {
				index: n,
				words: terms.length,
				normal: terms.map((t) => t.machine || t.normal || "").join(" "),
				pointer: ptrs[n]
			};
		});
		if (seqNames.has(input)) input = "sequential";
		if (alphaNames.has(input)) input = "alpha";
		if (freqNames.has(input)) {
			arr = _sort_default.byFreq(arr);
			return this.update(arr.map((o) => o.pointer));
		}
		if (typeof _sort_default[input] === "function") {
			arr = arr.sort(_sort_default[input]);
			return this.update(arr.map((o) => o.pointer));
		}
		return this;
	};
	/** reverse the order of the matches, but not the words or index */
	var reverse$1 = function() {
		let ptrs = this.pointer || this.docs.map((_d, n) => [n]);
		ptrs = [].concat(ptrs);
		ptrs = ptrs.reverse();
		if (this._cache) this._cache = this._cache.reverse();
		return this.update(ptrs);
	};
	/** remove any duplicate matches */
	var unique = function() {
		const already = /* @__PURE__ */ new Set();
		return this.filter((m) => {
			const txt = m.text("machine");
			if (already.has(txt)) return false;
			already.add(txt);
			return true;
		});
	};
	var sort_default = {
		unique,
		reverse: reverse$1,
		sort
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/concat.js
	var isArray$6 = (arr) => Object.prototype.toString.call(arr) === "[object Array]";
	var combineDocs = function(homeDocs, inputDocs) {
		if (homeDocs.length > 0) {
			const end = homeDocs[homeDocs.length - 1];
			const last = end[end.length - 1];
			if (/ /.test(last.post) === false) last.post += " ";
		}
		homeDocs = homeDocs.concat(inputDocs);
		return homeDocs;
	};
	var combineViews = function(home, input) {
		if (home.document === input.document) {
			const ptrs = home.fullPointer.concat(input.fullPointer);
			return home.toView(ptrs).compute("index");
		}
		input.fullPointer.forEach((a) => {
			a[0] += home.document.length;
		});
		home.document = combineDocs(home.document, input.docs);
		return home.all();
	};
	var concat_default = { concat: function(input) {
		if (typeof input === "string") {
			const more = this.fromText(input);
			if (!this.found || !this.ptrs) this.document = this.document.concat(more.document);
			else {
				const ptrs = this.fullPointer;
				const at = ptrs[ptrs.length - 1][0];
				this.document.splice(at, 0, ...more.document);
			}
			return this.all().compute("index");
		}
		if (typeof input === "object" && input.isView) return combineViews(this, input);
		if (isArray$6(input)) {
			const docs = combineDocs(this.document, input);
			this.document = docs;
			return this.all();
		}
		return this;
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/harden.js
	var harden = function() {
		this.ptrs = this.fullPointer;
		return this;
	};
	var soften = function() {
		let ptr = this.ptrs;
		if (!ptr || ptr.length < 1) return this;
		ptr = ptr.map((a) => a.slice(0, 3));
		this.ptrs = ptr;
		return this;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/api/index.js
	var methods$10 = Object.assign({}, case_default, fns$3, fns$2, methods$12, methods$11, sort_default, concat_default, {
		harden,
		soften
	});
	var addAPI$2 = function(View) {
		Object.assign(View.prototype, methods$10);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/change/plugin.js
	var plugin_default$14 = {
		api: addAPI$2,
		compute: { id: function(view) {
			const docs = view.docs;
			for (let n = 0; n < docs.length; n += 1) for (let i = 0; i < docs[n].length; i += 1) {
				const term = docs[n][i];
				term.id = term.id || toId(term);
			}
		} }
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/model/contractions.js
	var contractions_default = [
		{
			word: "@",
			out: ["at"]
		},
		{
			word: "arent",
			out: ["are", "not"]
		},
		{
			word: "alot",
			out: ["a", "lot"]
		},
		{
			word: "brb",
			out: [
				"be",
				"right",
				"back"
			]
		},
		{
			word: "cannot",
			out: ["can", "not"]
		},
		{
			word: "dun",
			out: ["do", "not"]
		},
		{
			word: "can't",
			out: ["can", "not"]
		},
		{
			word: "shan't",
			out: ["should", "not"]
		},
		{
			word: "won't",
			out: ["will", "not"]
		},
		{
			word: "that's",
			out: ["that", "is"]
		},
		{
			word: "what's",
			out: ["what", "is"]
		},
		{
			word: "let's",
			out: ["let", "us"]
		},
		{
			word: "dunno",
			out: [
				"do",
				"not",
				"know"
			]
		},
		{
			word: "gonna",
			out: ["going", "to"]
		},
		{
			word: "gotta",
			out: [
				"have",
				"got",
				"to"
			]
		},
		{
			word: "gimme",
			out: ["give", "me"]
		},
		{
			word: "outta",
			out: ["out", "of"]
		},
		{
			word: "tryna",
			out: ["trying", "to"]
		},
		{
			word: "gtg",
			out: [
				"got",
				"to",
				"go"
			]
		},
		{
			word: "im",
			out: ["i", "am"]
		},
		{
			word: "imma",
			out: ["I", "will"]
		},
		{
			word: "imo",
			out: [
				"in",
				"my",
				"opinion"
			]
		},
		{
			word: "irl",
			out: [
				"in",
				"real",
				"life"
			]
		},
		{
			word: "ive",
			out: ["i", "have"]
		},
		{
			word: "rn",
			out: ["right", "now"]
		},
		{
			word: "tbh",
			out: [
				"to",
				"be",
				"honest"
			]
		},
		{
			word: "wanna",
			out: ["want", "to"]
		},
		{
			word: `c'mere`,
			out: ["come", "here"]
		},
		{
			word: `c'mon`,
			out: ["come", "on"]
		},
		{
			word: "shoulda",
			out: ["should", "have"]
		},
		{
			word: "coulda",
			out: ["coulda", "have"]
		},
		{
			word: "woulda",
			out: ["woulda", "have"]
		},
		{
			word: "musta",
			out: ["must", "have"]
		},
		{
			word: "tis",
			out: ["it", "is"]
		},
		{
			word: "twas",
			out: ["it", "was"]
		},
		{
			word: `y'know`,
			out: ["you", "know"]
		},
		{
			word: "ne'er",
			out: ["never"]
		},
		{
			word: "o'er",
			out: ["over"]
		},
		{
			after: "ll",
			out: ["will"]
		},
		{
			after: "ve",
			out: ["have"]
		},
		{
			after: "re",
			out: ["are"]
		},
		{
			after: "m",
			out: ["am"]
		},
		{
			before: "c",
			out: ["ce"]
		},
		{
			before: "m",
			out: ["me"]
		},
		{
			before: "n",
			out: ["ne"]
		},
		{
			before: "qu",
			out: ["que"]
		},
		{
			before: "s",
			out: ["se"]
		},
		{
			before: "t",
			out: ["tu"]
		},
		{
			word: "shouldnt",
			out: ["should", "not"]
		},
		{
			word: "couldnt",
			out: ["could", "not"]
		},
		{
			word: "wouldnt",
			out: ["would", "not"]
		},
		{
			word: "hasnt",
			out: ["has", "not"]
		},
		{
			word: "wasnt",
			out: ["was", "not"]
		},
		{
			word: "isnt",
			out: ["is", "not"]
		},
		{
			word: "cant",
			out: ["can", "not"]
		},
		{
			word: "dont",
			out: ["do", "not"]
		},
		{
			word: "wont",
			out: ["will", "not"]
		},
		{
			word: "howd",
			out: ["how", "did"]
		},
		{
			word: "whatd",
			out: ["what", "did"]
		},
		{
			word: "whend",
			out: ["when", "did"]
		},
		{
			word: "whered",
			out: ["where", "did"]
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/model/number-suffix.js
	var t$1 = true;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/model/index.js
	var model_default$3 = { one: {
		contractions: contractions_default,
		numberSuffixes: {
			"st": t$1,
			"nd": t$1,
			"rd": t$1,
			"th": t$1,
			"am": t$1,
			"pm": t$1,
			"max": t$1,
			"°": t$1,
			"s": t$1,
			"e": t$1,
			"er": t$1,
			"ère": t$1,
			"ème": t$1
		}
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/_splice.js
	var insertContraction$1 = function(document, point, words) {
		const [n, w] = point;
		if (!words || words.length === 0) return;
		words = words.map((word, i) => {
			word.implicit = word.text;
			word.machine = word.text;
			word.pre = "";
			word.post = "";
			word.text = "";
			word.normal = "";
			word.index = [n, w + i];
			return word;
		});
		if (words[0]) {
			words[0].pre = document[n][w].pre;
			words[words.length - 1].post = document[n][w].post;
			words[0].text = document[n][w].text;
			words[0].normal = document[n][w].normal;
		}
		document[n].splice(w, 1, ...words);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/apostrophe-d.js
	var hasContraction$3 = /'/;
	var alwaysDid = new Set([
		"what",
		"how",
		"when",
		"where",
		"why"
	]);
	var useWould = new Set([
		"be",
		"go",
		"start",
		"think",
		"need"
	]);
	var useHad = new Set(["been", "gone"]);
	var _apostropheD$1 = function(terms, i) {
		const before = terms[i].normal.split(hasContraction$3)[0];
		if (alwaysDid.has(before)) return [before, "did"];
		if (terms[i + 1]) {
			if (useHad.has(terms[i + 1].normal)) return [before, "had"];
			if (useWould.has(terms[i + 1].normal)) return [before, "would"];
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/apostrophe-t.js
	var apostropheT$1 = function(terms, i) {
		if (terms[i].normal === "ain't" || terms[i].normal === "aint") return null;
		return [terms[i].normal.replace(/n't/, ""), "not"];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/french.js
	var hasContraction$2 = /'/;
	var isFeminine = /(e|é|aison|sion|tion)$/;
	var isMasculine = /(age|isme|acle|ege|oire)$/;
	var preL = (terms, i) => {
		const after = terms[i].normal.split(hasContraction$2)[1];
		if (after && after.endsWith("e")) return ["la", after];
		return ["le", after];
	};
	var preD = (terms, i) => {
		const after = terms[i].normal.split(hasContraction$2)[1];
		if (after && isFeminine.test(after) && !isMasculine.test(after)) return ["du", after];
		else if (after && after.endsWith("s")) return ["des", after];
		return ["de", after];
	};
	var preJ = (terms, i) => {
		return ["je", terms[i].normal.split(hasContraction$2)[1]];
	};
	var french_default = {
		preJ,
		preL,
		preD
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/number-range.js
	var isRange = /^([0-9.]{1,4}[a-z]{0,2}) ?[-–—] ?([0-9]{1,4}[a-z]{0,2})$/i;
	var timeRange = /^([0-9]{1,2}(:[0-9][0-9])?(am|pm)?) ?[-–—] ?([0-9]{1,2}(:[0-9][0-9])?(am|pm)?)$/i;
	var phoneNum = /^[0-9]{3}-[0-9]{4}$/;
	var numberRange = function(terms, i) {
		const term = terms[i];
		let parts = term.text.match(isRange);
		if (parts !== null) {
			if (term.tags.has("PhoneNumber") === true || phoneNum.test(term.text)) return null;
			return [
				parts[1],
				"to",
				parts[2]
			];
		} else {
			parts = term.text.match(timeRange);
			if (parts !== null) return [
				parts[1],
				"to",
				parts[4]
			];
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/number-unit.js
	var numUnit = /^([+-]?[0-9][.,0-9]*)([a-z°²³µ/]+)$/;
	var numberUnit = function(terms, i, world) {
		const notUnit = world.model.one.numberSuffixes || {};
		const parts = terms[i].text.match(numUnit);
		if (parts !== null) {
			const unit = parts[2].toLowerCase().trim();
			if (notUnit.hasOwnProperty(unit)) return null;
			return [parts[1], unit];
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/compute/contractions/index.js
	var byApostrophe$1 = /'/;
	var numDash = /^[0-9][^-–—]*[-–—].*?[0-9]/;
	var reTag$1 = function(terms, view, start, len) {
		const tmp = view.update();
		tmp.document = [terms];
		let end = start + len;
		if (start > 0) start -= 1;
		if (terms[end]) end += 1;
		tmp.ptrs = [[
			0,
			start,
			end
		]];
	};
	var byEnd$1 = {
		t: (terms, i) => apostropheT$1(terms, i),
		d: (terms, i) => _apostropheD$1(terms, i)
	};
	var byStart = {
		j: (terms, i) => french_default.preJ(terms, i),
		l: (terms, i) => french_default.preL(terms, i),
		d: (terms, i) => french_default.preD(terms, i)
	};
	var knownOnes = function(list, term, before, after) {
		for (let i = 0; i < list.length; i += 1) {
			const o = list[i];
			if (o.word === term.normal) return o.out;
			else if (after !== null && after === o.after) return [before].concat(o.out);
			else if (before !== null && before === o.before && after && after.length > 2) return o.out.concat(after);
		}
		return null;
	};
	var toDocs$1 = function(words, view) {
		const doc = view.fromText(words.join(" "));
		doc.compute(["id", "alias"]);
		return doc.docs[0];
	};
	var thereHas = function(terms, i) {
		for (let k = i + 1; k < 5; k += 1) {
			if (!terms[k]) break;
			if (terms[k].normal === "been") return ["there", "has"];
		}
		return ["there", "is"];
	};
	var contractions = (view) => {
		const { world, document } = view;
		const { model, methods } = world;
		const list = model.one.contractions || [];
		document.forEach((terms, n) => {
			for (let i = terms.length - 1; i >= 0; i -= 1) {
				let before = null;
				let after = null;
				if (byApostrophe$1.test(terms[i].normal) === true) {
					const res = terms[i].normal.split(byApostrophe$1);
					before = res[0];
					after = res[1];
				}
				let words = knownOnes(list, terms[i], before, after);
				if (!words && byEnd$1.hasOwnProperty(after)) words = byEnd$1[after](terms, i, world);
				if (!words && byStart.hasOwnProperty(before)) words = byStart[before](terms, i);
				if (before === "there" && after === "s") words = thereHas(terms, i);
				if (words) {
					words = toDocs$1(words, view);
					insertContraction$1(document, [n, i], words);
					reTag$1(document[n], view, i, words.length);
					continue;
				}
				if (numDash.test(terms[i].normal)) {
					words = numberRange(terms, i);
					if (words) {
						words = toDocs$1(words, view);
						insertContraction$1(document, [n, i], words);
						methods.one.setTag(words, "NumberRange", world);
						if (words[2] && words[2].tags.has("Time")) methods.one.setTag([words[0]], "Time", world, null, "time-range");
						reTag$1(document[n], view, i, words.length);
					}
					continue;
				}
				words = numberUnit(terms, i, world);
				if (words) {
					words = toDocs$1(words, view);
					insertContraction$1(document, [n, i], words);
					methods.one.setTag([words[1]], "Unit", world, null, "contraction-unit");
				}
			}
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/contraction-one/plugin.js
	var plugin$1 = {
		model: model_default$3,
		compute: { contractions },
		hooks: ["contractions"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/freeze/compute.js
	var freeze = function(view) {
		const world = view.world;
		const { model, methods } = view.world;
		const setTag = methods.one.setTag;
		const { frozenLex } = model.one;
		const multi = model.one._multiCache || {};
		view.docs.forEach((terms) => {
			for (let i = 0; i < terms.length; i += 1) {
				const t = terms[i];
				const word = t.machine || t.normal;
				if (multi[word] !== void 0 && terms[i + 1]) {
					const end = i + multi[word] - 1;
					for (let k = end; k > i; k -= 1) {
						const words = terms.slice(i, k + 1);
						const str = words.map((term) => term.machine || term.normal).join(" ");
						if (frozenLex.hasOwnProperty(str) === true) {
							setTag(words, frozenLex[str], world, false, "1-frozen-multi-lexicon");
							words.forEach((term) => term.frozen = true);
							continue;
						}
					}
				}
				if (frozenLex[word] !== void 0 && frozenLex.hasOwnProperty(word)) {
					setTag([t], frozenLex[word], world, false, "1-freeze-lexicon");
					t.frozen = true;
					continue;
				}
			}
		});
	};
	var unfreeze = function(view) {
		view.docs.forEach((ts) => {
			ts.forEach((term) => {
				delete term.frozen;
			});
		});
		return view;
	};
	var compute_default$5 = {
		frozen: freeze,
		freeze,
		unfreeze
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/freeze/debug.js
	var blue = (str) => "\x1B[34m" + str + "\x1B[0m";
	var dim = (str) => "\x1B[3m\x1B[2m" + str + "\x1B[0m";
	var debug$2 = function(view) {
		view.docs.forEach((terms) => {
			console.log(blue("\n  ┌─────────"));
			terms.forEach((t) => {
				let str = `  ${dim("│")}  `;
				const txt = t.implicit || t.text || "-";
				if (t.frozen === true) str += `${blue(txt)} ❄️`;
				else str += dim(txt);
				console.log(str);
			});
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/freeze/plugin.js
	var plugin_default$13 = {
		compute: compute_default$5,
		mutate: (world) => {
			const methods = world.methods.one;
			methods.termMethods.isFrozen = (term) => term.frozen === true;
			methods.debug.freeze = debug$2;
			methods.debug.frozen = debug$2;
		},
		api: function(View) {
			View.prototype.freeze = function() {
				this.docs.forEach((ts) => {
					ts.forEach((term) => {
						term.frozen = true;
					});
				});
				return this;
			};
			View.prototype.unfreeze = function() {
				this.compute("unfreeze");
			};
			View.prototype.isFrozen = function() {
				return this.match("@isFrozen+");
			};
		},
		hooks: ["freeze"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/compute/multi-word.js
	var multiWord = function(terms, start_i, world) {
		const { model, methods } = world;
		const setTag = methods.one.setTag;
		const multi = model.one._multiCache || {};
		const { lexicon } = model.one || {};
		const t = terms[start_i];
		const word = t.machine || t.normal;
		if (multi[word] !== void 0 && terms[start_i + 1]) {
			const end = start_i + multi[word] - 1;
			for (let i = end; i > start_i; i -= 1) {
				const words = terms.slice(start_i, i + 1);
				if (words.length <= 1) return false;
				const str = words.map((term) => term.machine || term.normal).join(" ");
				if (lexicon.hasOwnProperty(str) === true) {
					const tag = lexicon[str];
					setTag(words, tag, world, false, "1-multi-lexicon");
					if (tag && tag.length === 2 && (tag[0] === "PhrasalVerb" || tag[1] === "PhrasalVerb")) setTag([words[1]], "Particle", world, false, "1-phrasal-particle");
					return true;
				}
			}
			return false;
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/compute/single-word.js
	var prefix$3 = /^(under|over|mis|re|un|dis|semi|pre|post)-?/;
	var allowPrefix = new Set([
		"Verb",
		"Infinitive",
		"PastTense",
		"Gerund",
		"PresentTense",
		"Adjective",
		"Participle"
	]);
	var checkLexicon = function(terms, i, world) {
		const { model, methods } = world;
		const setTag = methods.one.setTag;
		const { lexicon } = model.one;
		const t = terms[i];
		const word = t.machine || t.normal;
		if (lexicon[word] !== void 0 && lexicon.hasOwnProperty(word)) {
			setTag([t], lexicon[word], world, false, "1-lexicon");
			return true;
		}
		if (t.alias) {
			const found = t.alias.find((str) => lexicon.hasOwnProperty(str));
			if (found) {
				setTag([t], lexicon[found], world, false, "1-lexicon-alias");
				return true;
			}
		}
		if (prefix$3.test(word) === true) {
			const stem = word.replace(prefix$3, "");
			if (lexicon.hasOwnProperty(stem) && stem.length > 3) {
				if (allowPrefix.has(lexicon[stem])) {
					setTag([t], lexicon[stem], world, false, "1-lexicon-prefix");
					return true;
				}
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/compute/index.js
	var lexicon$2 = function(view) {
		const world = view.world;
		view.docs.forEach((terms) => {
			for (let i = 0; i < terms.length; i += 1) if (terms[i].tags.size === 0) {
				let found = null;
				found = found || multiWord(terms, i, world);
				found = found || checkLexicon(terms, i, world);
			}
		});
	};
	var compute_default$4 = { lexicon: lexicon$2 };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/methods/expand.js
	var expand$2 = function(words) {
		const lex = {};
		const _multi = {};
		Object.keys(words).forEach((word) => {
			const tag = words[word];
			word = word.toLowerCase().trim();
			word = word.replace(/'s\b/, "");
			const split = word.split(/ /);
			if (split.length > 1) {
				if (_multi[split[0]] === void 0 || split.length > _multi[split[0]]) _multi[split[0]] = split.length;
			}
			lex[word] = lex[word] || tag;
		});
		delete lex[""];
		delete lex[null];
		delete lex[" "];
		return {
			lex,
			_multi
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/methods/index.js
	var methods_default$5 = { one: { expandLexicon: expand$2 } };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lexicon/lib.js
	/** insert new words/phrases into the lexicon */
	var addWords = function(words, isFrozen = false) {
		const world = this.world();
		const { methods, model } = world;
		if (!words) return;
		Object.keys(words).forEach((k) => {
			if (typeof words[k] === "string" && words[k].startsWith("#")) words[k] = words[k].replace(/^#/, "");
		});
		if (isFrozen === true) {
			const { lex, _multi } = methods.one.expandLexicon(words, world);
			Object.assign(model.one._multiCache, _multi);
			Object.assign(model.one.frozenLex, lex);
			return;
		}
		if (methods.two.expandLexicon) {
			const { lex, _multi } = methods.two.expandLexicon(words, world);
			Object.assign(model.one.lexicon, lex);
			Object.assign(model.one._multiCache, _multi);
		}
		const { lex, _multi } = methods.one.expandLexicon(words, world);
		Object.assign(model.one.lexicon, lex);
		Object.assign(model.one._multiCache, _multi);
	};
	var plugin_default$12 = {
		model: { one: {
			lexicon: {},
			_multiCache: {},
			frozenLex: {}
		} },
		methods: methods_default$5,
		compute: compute_default$4,
		lib: { addWords },
		hooks: ["lexicon"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lookup/api/buildTrie/index.js
	var tokenize = function(phrase, world) {
		const { methods, model } = world;
		return methods.one.tokenize.splitTerms(phrase, model).map((t) => methods.one.tokenize.splitWhitespace(t, model)).map((term) => term.text.toLowerCase());
	};
	var buildTrie = function(phrases, world) {
		const goNext = [{}];
		const endAs = [null];
		const failTo = [0];
		const xs = [];
		let n = 0;
		phrases.forEach(function(phrase) {
			let curr = 0;
			const words = tokenize(phrase, world);
			for (let i = 0; i < words.length; i++) {
				const word = words[i];
				if (goNext[curr] && goNext[curr].hasOwnProperty(word)) curr = goNext[curr][word];
				else {
					n++;
					goNext[curr][word] = n;
					goNext[n] = {};
					curr = n;
					endAs[n] = null;
				}
			}
			endAs[curr] = [words.length];
		});
		for (const word in goNext[0]) {
			n = goNext[0][word];
			failTo[n] = 0;
			xs.push(n);
		}
		while (xs.length) {
			const r = xs.shift();
			const keys = Object.keys(goNext[r]);
			for (let i = 0; i < keys.length; i += 1) {
				const word = keys[i];
				const s = goNext[r][word];
				xs.push(s);
				n = failTo[r];
				while (n > 0 && !goNext[n].hasOwnProperty(word)) n = failTo[n];
				if (goNext.hasOwnProperty(n)) {
					const fs = goNext[n][word];
					failTo[s] = fs;
					if (endAs[fs]) {
						endAs[s] = endAs[s] || [];
						endAs[s] = endAs[s].concat(endAs[fs]);
					}
				} else failTo[s] = 0;
			}
		}
		return {
			goNext,
			endAs,
			failTo
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lookup/api/scan.js
	var scanWords = function(terms, trie, opts) {
		let n = 0;
		const results = [];
		for (let i = 0; i < terms.length; i++) {
			const word = terms[i][opts.form] || terms[i].normal;
			while (n > 0 && (trie.goNext[n] === void 0 || !trie.goNext[n].hasOwnProperty(word))) n = trie.failTo[n] || 0;
			if (!trie.goNext[n].hasOwnProperty(word)) continue;
			n = trie.goNext[n][word];
			if (trie.endAs[n]) {
				const arr = trie.endAs[n];
				for (let o = 0; o < arr.length; o++) {
					const len = arr[o];
					const term = terms[i - len + 1];
					const [no, start] = term.index;
					results.push([
						no,
						start,
						start + len,
						term.id
					]);
				}
			}
		}
		return results;
	};
	var cacheMiss = function(words, cache) {
		for (let i = 0; i < words.length; i += 1) if (cache.has(words[i]) === true) return false;
		return true;
	};
	var scan = function(view, trie, opts) {
		let results = [];
		opts.form = opts.form || "normal";
		const docs = view.docs;
		if (!trie.goNext || !trie.goNext[0]) {
			console.error("Compromise invalid lookup trie");
			return view.none();
		}
		const firstWords = Object.keys(trie.goNext[0]);
		for (let i = 0; i < docs.length; i++) {
			if (view._cache && view._cache[i] && cacheMiss(firstWords, view._cache[i]) === true) continue;
			const terms = docs[i];
			const found = scanWords(terms, trie, opts);
			if (found.length > 0) results = results.concat(found);
		}
		return view.update(results);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lookup/api/index.js
	var isObject$4 = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	function api_default$1(View) {
		/** find all matches in this document */
		View.prototype.lookup = function(input, opts = {}) {
			if (!input) return this.none();
			if (typeof input === "string") input = [input];
			const trie = isObject$4(input) ? input : buildTrie(input, this.world);
			let res = scan(this, trie, opts);
			res = res.settle();
			return res;
		};
	}
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lookup/api/buildTrie/compress.js
	var truncate = (list, val) => {
		for (let i = list.length - 1; i >= 0; i -= 1) if (list[i] !== val) {
			list = list.slice(0, i + 1);
			return list;
		}
		return list;
	};
	var compress = function(trie) {
		trie.goNext = trie.goNext.map((o) => {
			if (Object.keys(o).length === 0) return;
			return o;
		});
		trie.goNext = truncate(trie.goNext, void 0);
		trie.failTo = truncate(trie.failTo, 0);
		trie.endAs = truncate(trie.endAs, null);
		return trie;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/lookup/plugin.js
	/** pre-compile a list of matches to lookup */
	var lib = { 
	/** turn an array or object into a compressed trie*/
buildTrie: function(input) {
		return compress(buildTrie(input, this.world()));
	} };
	lib.compile = lib.buildTrie;
	var plugin_default$11 = {
		api: api_default$1,
		lib
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/_lib.js
	var relPointer = function(ptrs, parent) {
		if (!parent) return ptrs;
		ptrs.forEach((ptr) => {
			const n = ptr[0];
			if (parent[n]) {
				ptr[0] = parent[n][0];
				ptr[1] += parent[n][1];
				ptr[2] += parent[n][1];
			}
		});
		return ptrs;
	};
	var fixPointers = function(res, parent) {
		let { ptrs } = res;
		const { byGroup } = res;
		ptrs = relPointer(ptrs, parent);
		Object.keys(byGroup).forEach((k) => {
			byGroup[k] = relPointer(byGroup[k], parent);
		});
		return {
			ptrs,
			byGroup
		};
	};
	var parseRegs = function(regs, opts, world) {
		const one = world.methods.one;
		if (typeof regs === "number") regs = String(regs);
		if (typeof regs === "string") {
			regs = one.killUnicode(regs, world);
			regs = one.parseMatch(regs, opts, world);
		}
		return regs;
	};
	var isObject$3 = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	var isView = (val) => val && isObject$3(val) && val.isView === true;
	var isNet = (val) => val && isObject$3(val) && val.isNet === true;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/match.js
	var match = function(regs, group, opts) {
		const one = this.methods.one;
		if (isView(regs)) return this.intersection(regs);
		if (isNet(regs)) return this.sweep(regs, { tagger: false }).view.settle();
		regs = parseRegs(regs, opts, this.world);
		const todo = {
			regs,
			group
		};
		const { ptrs, byGroup } = fixPointers(one.match(this.docs, todo, this._cache), this.fullPointer);
		const view = this.toView(ptrs);
		view._groups = byGroup;
		return view;
	};
	var matchOne = function(regs, group, opts) {
		const one = this.methods.one;
		if (isView(regs)) return this.intersection(regs).eq(0);
		if (isNet(regs)) return this.sweep(regs, {
			tagger: false,
			matchOne: true
		}).view;
		regs = parseRegs(regs, opts, this.world);
		const todo = {
			regs,
			group,
			justOne: true
		};
		const { ptrs, byGroup } = fixPointers(one.match(this.docs, todo, this._cache), this.fullPointer);
		const view = this.toView(ptrs);
		view._groups = byGroup;
		return view;
	};
	var has = function(regs, group, opts) {
		const one = this.methods.one;
		if (isView(regs)) return this.intersection(regs).fullPointer.length > 0;
		if (isNet(regs)) return this.sweep(regs, { tagger: false }).view.found;
		regs = parseRegs(regs, opts, this.world);
		const todo = {
			regs,
			group,
			justOne: true
		};
		return one.match(this.docs, todo, this._cache).ptrs.length > 0;
	};
	var ifFn = function(regs, group, opts) {
		const one = this.methods.one;
		if (isView(regs)) return this.filter((m) => m.intersection(regs).found);
		if (isNet(regs)) {
			const m = this.sweep(regs, { tagger: false }).view.settle();
			return this.if(m);
		}
		regs = parseRegs(regs, opts, this.world);
		const todo = {
			regs,
			group,
			justOne: true
		};
		let ptrs = this.fullPointer;
		const cache = this._cache || [];
		ptrs = ptrs.filter((ptr, i) => {
			const m = this.update([ptr]);
			return one.match(m.docs, todo, cache[i]).ptrs.length > 0;
		});
		const view = this.update(ptrs);
		if (this._cache) view._cache = ptrs.map((ptr) => cache[ptr[0]]);
		return view;
	};
	var ifNo = function(regs, group, opts) {
		const { methods } = this;
		const one = methods.one;
		if (isView(regs)) return this.filter((m) => !m.intersection(regs).found);
		if (isNet(regs)) {
			const m = this.sweep(regs, { tagger: false }).view.settle();
			return this.ifNo(m);
		}
		regs = parseRegs(regs, opts, this.world);
		const cache = this._cache || [];
		const view = this.filter((m, i) => {
			const todo = {
				regs,
				group,
				justOne: true
			};
			return one.match(m.docs, todo, cache[i]).ptrs.length === 0;
		});
		if (this._cache) view._cache = view.ptrs.map((ptr) => cache[ptr[0]]);
		return view;
	};
	var match_default = {
		matchOne,
		match,
		has,
		if: ifFn,
		ifNo
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/lookaround.js
	var before = function(regs, group, opts) {
		const { indexN } = this.methods.one.pointer;
		const pre = [];
		const byN = indexN(this.fullPointer);
		Object.keys(byN).forEach((k) => {
			const first = byN[k].sort((a, b) => a[1] > b[1] ? 1 : -1)[0];
			if (first[1] > 0) pre.push([
				first[0],
				0,
				first[1]
			]);
		});
		const preWords = this.toView(pre);
		if (!regs) return preWords;
		return preWords.match(regs, group, opts);
	};
	var after = function(regs, group, opts) {
		const { indexN } = this.methods.one.pointer;
		const post = [];
		const byN = indexN(this.fullPointer);
		const document = this.document;
		Object.keys(byN).forEach((k) => {
			const [n, , end] = byN[k].sort((a, b) => a[1] > b[1] ? -1 : 1)[0];
			if (end < document[n].length) post.push([
				n,
				end,
				document[n].length
			]);
		});
		const postWords = this.toView(post);
		if (!regs) return postWords;
		return postWords.match(regs, group, opts);
	};
	var growLeft = function(regs, group, opts) {
		if (typeof regs === "string") regs = this.world.methods.one.parseMatch(regs, opts, this.world);
		regs[regs.length - 1].end = true;
		const ptrs = this.fullPointer;
		this.forEach((m, n) => {
			const more = m.before(regs, group);
			if (more.found) {
				const terms = more.terms();
				ptrs[n][1] -= terms.length;
				ptrs[n][3] = terms.docs[0][0].id;
			}
		});
		return this.update(ptrs);
	};
	var growRight = function(regs, group, opts) {
		if (typeof regs === "string") regs = this.world.methods.one.parseMatch(regs, opts, this.world);
		regs[0].start = true;
		const ptrs = this.fullPointer;
		this.forEach((m, n) => {
			const more = m.after(regs, group);
			if (more.found) {
				const terms = more.terms();
				ptrs[n][2] += terms.length;
				ptrs[n][4] = null;
			}
		});
		return this.update(ptrs);
	};
	var grow = function(regs, group, opts) {
		return this.growRight(regs, group, opts).growLeft(regs, group, opts);
	};
	var lookaround_default = {
		before,
		after,
		growLeft,
		growRight,
		grow
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/split.js
	var combine = function(left, right) {
		return [
			left[0],
			left[1],
			right[2]
		];
	};
	var isArray$5 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var getDoc$2 = (reg, view, group) => {
		if (typeof reg === "string" || isArray$5(reg)) return view.match(reg, group);
		if (!reg) return view.none();
		return reg;
	};
	var addIds$1 = function(ptr, view) {
		const [n, start, end] = ptr;
		if (view.document[n] && view.document[n][start]) {
			ptr[3] = ptr[3] || view.document[n][start].id;
			if (view.document[n][end - 1]) ptr[4] = ptr[4] || view.document[n][end - 1].id;
		}
		return ptr;
	};
	var methods$9 = {};
	methods$9.splitOn = function(m, group) {
		const { splitAll } = this.methods.one.pointer;
		const splits = getDoc$2(m, this, group).fullPointer;
		const all = splitAll(this.fullPointer, splits);
		let res = [];
		all.forEach((o) => {
			res.push(o.passthrough);
			res.push(o.before);
			res.push(o.match);
			res.push(o.after);
		});
		res = res.filter((p) => p);
		res = res.map((p) => addIds$1(p, this));
		return this.update(res);
	};
	methods$9.splitBefore = function(m, group) {
		const { splitAll } = this.methods.one.pointer;
		const splits = getDoc$2(m, this, group).fullPointer;
		const all = splitAll(this.fullPointer, splits);
		for (let i = 0; i < all.length; i += 1) if (!all[i].after && all[i + 1] && all[i + 1].before) {
			if (all[i].match && all[i].match[0] === all[i + 1].before[0]) {
				all[i].after = all[i + 1].before;
				delete all[i + 1].before;
			}
		}
		let res = [];
		all.forEach((o) => {
			res.push(o.passthrough);
			res.push(o.before);
			if (o.match && o.after) res.push(combine(o.match, o.after));
			else res.push(o.match);
		});
		res = res.filter((p) => p);
		res = res.map((p) => addIds$1(p, this));
		return this.update(res);
	};
	methods$9.splitAfter = function(m, group) {
		const { splitAll } = this.methods.one.pointer;
		const splits = getDoc$2(m, this, group).fullPointer;
		const all = splitAll(this.fullPointer, splits);
		let res = [];
		all.forEach((o) => {
			res.push(o.passthrough);
			if (o.before && o.match) res.push(combine(o.before, o.match));
			else {
				res.push(o.before);
				res.push(o.match);
			}
			res.push(o.after);
		});
		res = res.filter((p) => p);
		res = res.map((p) => addIds$1(p, this));
		return this.update(res);
	};
	methods$9.split = methods$9.splitAfter;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/join.js
	var isNeighbour = function(ptrL, ptrR) {
		if (!ptrL || !ptrR) return false;
		if (ptrL[0] !== ptrR[0]) return false;
		return ptrL[2] === ptrR[1];
	};
	var mergeIf = function(doc, lMatch, rMatch) {
		const world = doc.world;
		const parseMatch = world.methods.one.parseMatch;
		lMatch = lMatch || ".$";
		rMatch = rMatch || "^.";
		const leftMatch = parseMatch(lMatch, {}, world);
		const rightMatch = parseMatch(rMatch, {}, world);
		leftMatch[leftMatch.length - 1].end = true;
		rightMatch[0].start = true;
		const ptrs = doc.fullPointer;
		const res = [ptrs[0]];
		for (let i = 1; i < ptrs.length; i += 1) {
			const ptrL = res[res.length - 1];
			const ptrR = ptrs[i];
			const left = doc.update([ptrL]);
			const right = doc.update([ptrR]);
			if (isNeighbour(ptrL, ptrR) && left.has(leftMatch) && right.has(rightMatch)) res[res.length - 1] = [
				ptrL[0],
				ptrL[1],
				ptrR[2],
				ptrL[3],
				ptrR[4]
			];
			else res.push(ptrR);
		}
		return doc.update(res);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/api/index.js
	var methods$7 = Object.assign({}, match_default, lookaround_default, methods$9, {
		joinIf: function(lMatch, rMatch) {
			return mergeIf(this, lMatch, rMatch);
		},
		join: function() {
			return mergeIf(this);
		}
	});
	methods$7.lookBehind = methods$7.before;
	methods$7.lookBefore = methods$7.before;
	methods$7.lookAhead = methods$7.after;
	methods$7.lookAfter = methods$7.after;
	methods$7.notIf = methods$7.ifNo;
	var matchAPI = function(View) {
		Object.assign(View.prototype, methods$7);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/01-parseBlocks.js
	var bySlashes = /(?:^|\s)([![^]*(?:<[^<]*>)?\/.*?[^\\/]\/[?\]+*$~]*)(?:\s|$)/;
	var byParentheses = /([!~[^]*(?:<[^<]*>)?\([^)]+[^\\)]\)[?\]+*$~]*)(?:\s|$)/;
	var byWord = / /g;
	var isBlock = (str) => {
		return /^[![^]*(<[^<]*>)?\(/.test(str) && /\)[?\]+*$~]*$/.test(str);
	};
	var isReg = (str) => {
		return /^[![^]*(<[^<]*>)?\//.test(str) && /\/[?\]+*$~]*$/.test(str);
	};
	var cleanUp = function(arr) {
		arr = arr.map((str) => str.trim());
		arr = arr.filter((str) => str);
		return arr;
	};
	var parseBlocks = function(txt) {
		const arr = txt.split(bySlashes);
		let res = [];
		arr.forEach((str) => {
			if (isReg(str)) {
				res.push(str);
				return;
			}
			res = res.concat(str.split(byParentheses));
		});
		res = cleanUp(res);
		let final = [];
		res.forEach((str) => {
			if (isBlock(str)) final.push(str);
			else if (isReg(str)) final.push(str);
			else final = final.concat(str.split(byWord));
		});
		final = cleanUp(final);
		return final;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/02-parseToken.js
	var hasMinMax = /\{([0-9]+)?(, *[0-9]*)?\}/;
	var andSign = /&&/;
	var captureName = /* @__PURE__ */ new RegExp(/^<\s*(\S+)\s*>/);
	var titleCase$2 = (str) => str.charAt(0).toUpperCase() + str.substring(1);
	var end = (str) => str.charAt(str.length - 1);
	var start = (str) => str.charAt(0);
	var stripStart = (str) => str.substring(1);
	var stripEnd = (str) => str.substring(0, str.length - 1);
	var stripBoth = function(str) {
		str = stripStart(str);
		str = stripEnd(str);
		return str;
	};
	var parseToken = function(w, opts) {
		const obj = {};
		for (let i = 0; i < 2; i += 1) {
			if (end(w) === "$") {
				obj.end = true;
				w = stripEnd(w);
			}
			if (start(w) === "^") {
				obj.start = true;
				w = stripStart(w);
			}
			if (end(w) === "?") {
				obj.optional = true;
				w = stripEnd(w);
			}
			if (start(w) === "[" || end(w) === "]") {
				obj.group = null;
				if (start(w) === "[") obj.groupStart = true;
				if (end(w) === "]") obj.groupEnd = true;
				w = w.replace(/^\[/, "");
				w = w.replace(/\]$/, "");
				if (start(w) === "<") {
					const res = captureName.exec(w);
					if (res.length >= 2) {
						obj.group = res[1];
						w = w.replace(res[0], "");
					}
				}
			}
			if (end(w) === "+") {
				obj.greedy = true;
				w = stripEnd(w);
			}
			if (w !== "*" && end(w) === "*" && w !== "\\*") {
				obj.greedy = true;
				w = stripEnd(w);
			}
			if (start(w) === "!") {
				obj.negative = true;
				w = stripStart(w);
			}
			if (start(w) === "~" && end(w) === "~" && w.length > 2) {
				w = stripBoth(w);
				obj.fuzzy = true;
				obj.min = opts.fuzzy || .85;
				if (/\(/.test(w) === false) {
					obj.word = w;
					return obj;
				}
			}
			if (start(w) === "/" && end(w) === "/") {
				w = stripBoth(w);
				if (opts.caseSensitive) obj.use = "text";
				obj.regex = new RegExp(w);
				return obj;
			}
			if (hasMinMax.test(w) === true) w = w.replace(hasMinMax, (_a, b, c) => {
				if (c === void 0) {
					obj.min = Number(b);
					obj.max = Number(b);
				} else {
					c = c.replace(/, */, "");
					if (b === void 0) {
						obj.min = 0;
						obj.max = Number(c);
					} else {
						obj.min = Number(b);
						obj.max = Number(c || 999);
					}
				}
				obj.greedy = true;
				if (!obj.min) obj.optional = true;
				return "";
			});
			if (start(w) === "(" && end(w) === ")") {
				if (andSign.test(w)) {
					obj.choices = w.split(andSign);
					obj.operator = "and";
				} else {
					obj.choices = w.split("|");
					obj.operator = "or";
				}
				obj.choices[0] = stripStart(obj.choices[0]);
				const last = obj.choices.length - 1;
				obj.choices[last] = stripEnd(obj.choices[last]);
				obj.choices = obj.choices.map((s) => s.trim());
				obj.choices = obj.choices.filter((s) => s);
				obj.choices = obj.choices.map((str) => {
					return str.split(/ /g).map((s) => parseToken(s, opts));
				});
				w = "";
			}
			if (start(w) === "{" && end(w) === "}") {
				w = stripBoth(w);
				obj.root = w;
				if (/\//.test(w)) {
					const split = obj.root.split(/\//);
					obj.root = split[0];
					obj.pos = split[1];
					if (obj.pos === "adj") obj.pos = "Adjective";
					obj.pos = obj.pos.charAt(0).toUpperCase() + obj.pos.substr(1).toLowerCase();
					if (split[2] !== void 0) obj.sense = split[2];
				}
				return obj;
			}
			if (start(w) === "<" && end(w) === ">") {
				w = stripBoth(w);
				obj.chunk = titleCase$2(w);
				obj.greedy = true;
				return obj;
			}
			if (start(w) === "%" && end(w) === "%") {
				w = stripBoth(w);
				obj.switch = w;
				return obj;
			}
		}
		if (start(w) === "#") {
			obj.tag = stripStart(w);
			obj.tag = titleCase$2(obj.tag);
			return obj;
		}
		if (start(w) === "@") {
			obj.method = stripStart(w);
			return obj;
		}
		if (w === ".") {
			obj.anything = true;
			return obj;
		}
		if (w === "*") {
			obj.anything = true;
			obj.greedy = true;
			obj.optional = true;
			return obj;
		}
		if (w) {
			w = w.replace("\\*", "*");
			w = w.replace("\\.", ".");
			if (opts.caseSensitive) obj.use = "text";
			else w = w.toLowerCase();
			obj.word = w;
		}
		return obj;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/03-splitHyphens.js
	var hasDash$2 = /[a-z0-9][-–—][a-z]/i;
	var splitHyphens$1 = function(regs, world) {
		const prefixes = world.model.one.prefixes;
		for (let i = regs.length - 1; i >= 0; i -= 1) {
			const reg = regs[i];
			if (reg.word && hasDash$2.test(reg.word)) {
				let words = reg.word.split(/[-–—]/g);
				if (prefixes.hasOwnProperty(words[0])) continue;
				words = words.filter((w) => w).reverse();
				regs.splice(i, 1);
				words.forEach((w) => {
					const obj = Object.assign({}, reg);
					obj.word = w;
					regs.splice(i, 0, obj);
				});
			}
		}
		return regs;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/04-inflect-root.js
	var addVerbs = function(token, world) {
		const { all } = world.methods.two.transform.verb || {};
		const str = token.root;
		if (!all) return [];
		return all(str, world.model);
	};
	var addNoun = function(token, world) {
		const { all } = world.methods.two.transform.noun || {};
		if (!all) return [token.root];
		return all(token.root, world.model);
	};
	var addAdjective = function(token, world) {
		const { all } = world.methods.two.transform.adjective || {};
		if (!all) return [token.root];
		return all(token.root, world.model);
	};
	var inflectRoot = function(regs, world) {
		regs = regs.map((token) => {
			if (token.root) if (world.methods.two && world.methods.two.transform) {
				let choices = [];
				if (token.pos) {
					if (token.pos === "Verb") choices = choices.concat(addVerbs(token, world));
					else if (token.pos === "Noun") choices = choices.concat(addNoun(token, world));
					else if (token.pos === "Adjective") choices = choices.concat(addAdjective(token, world));
				} else {
					choices = choices.concat(addVerbs(token, world));
					choices = choices.concat(addNoun(token, world));
					choices = choices.concat(addAdjective(token, world));
				}
				choices = choices.filter((str) => str);
				if (choices.length > 0) {
					token.operator = "or";
					token.fastOr = new Set(choices);
				}
			} else {
				token.machine = token.root;
				delete token.id;
				delete token.root;
			}
			return token;
		});
		return regs;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/05-postProcess.js
	var nameGroups = function(regs) {
		let index = 0;
		let inGroup = null;
		for (let i = 0; i < regs.length; i++) {
			const token = regs[i];
			if (token.groupStart === true) {
				inGroup = token.group;
				if (inGroup === null) {
					inGroup = String(index);
					index += 1;
				}
			}
			if (inGroup !== null) token.group = inGroup;
			if (token.groupEnd === true) inGroup = null;
		}
		return regs;
	};
	var doFastOrMode = function(tokens) {
		return tokens.map((token) => {
			if (token.choices !== void 0) {
				if (token.operator !== "or") return token;
				if (token.fuzzy === true) return token;
				if (token.choices.every((block) => {
					if (block.length !== 1) return false;
					const reg = block[0];
					if (reg.fuzzy === true) return false;
					if (reg.start || reg.end) return false;
					if (reg.word !== void 0 && reg.negative !== true && reg.optional !== true && reg.method !== true) return true;
					return false;
				}) === true) {
					token.fastOr = /* @__PURE__ */ new Set();
					token.choices.forEach((block) => {
						token.fastOr.add(block[0].word);
					});
					delete token.choices;
				}
			}
			return token;
		});
	};
	var fuzzyOr = function(regs) {
		return regs.map((reg) => {
			if (reg.fuzzy && reg.choices) reg.choices.forEach((r) => {
				if (r.length === 1 && r[0].word) {
					r[0].fuzzy = true;
					r[0].min = reg.min;
				}
			});
			return reg;
		});
	};
	var postProcess = function(regs) {
		regs = nameGroups(regs);
		regs = doFastOrMode(regs);
		regs = fuzzyOr(regs);
		return regs;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/parseMatch/index.js
	/** parse a match-syntax string into json */
	var syntax = function(input, opts, world) {
		if (input === null || input === void 0 || input === "") return [];
		opts = opts || {};
		if (typeof input === "number") input = String(input);
		let tokens = parseBlocks(input);
		tokens = tokens.map((str) => parseToken(str, opts));
		tokens = splitHyphens$1(tokens, world);
		tokens = inflectRoot(tokens, world);
		tokens = postProcess(tokens, opts);
		return tokens;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/01-failFast.js
	var anyIntersection = function(setA, setB) {
		for (const elem of setB) if (setA.has(elem)) return true;
		return false;
	};
	var failFast = function(regs, cache) {
		for (let i = 0; i < regs.length; i += 1) {
			const reg = regs[i];
			if (reg.optional === true || reg.negative === true || reg.fuzzy === true) continue;
			if (reg.word !== void 0 && cache.has(reg.word) === false) return true;
			if (reg.tag !== void 0 && cache.has("#" + reg.tag) === false) return true;
			if (reg.fastOr && anyIntersection(reg.fastOr, cache) === false) return false;
		}
		return false;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/term/_fuzzy.js
	var editDistance = function(strA, strB) {
		const aLength = strA.length, bLength = strB.length;
		if (aLength === 0) return bLength;
		if (bLength === 0) return aLength;
		const limit = (bLength > aLength ? bLength : aLength) + 1;
		if (Math.abs(aLength - bLength) > (limit || 100)) return limit || 100;
		const matrix = [];
		for (let i = 0; i < limit; i++) {
			matrix[i] = [i];
			matrix[i].length = limit;
		}
		for (let i = 0; i < limit; i++) matrix[0][i] = i;
		let j, a_index, b_index, cost, min, t;
		for (let i = 1; i <= aLength; ++i) {
			a_index = strA[i - 1];
			for (j = 1; j <= bLength; ++j) {
				if (i === j && matrix[i][j] > 4) return aLength;
				b_index = strB[j - 1];
				cost = a_index === b_index ? 0 : 1;
				min = matrix[i - 1][j] + 1;
				if ((t = matrix[i][j - 1] + 1) < min) min = t;
				if ((t = matrix[i - 1][j - 1] + cost) < min) min = t;
				if (i > 1 && j > 1 && a_index === strB[j - 2] && strA[i - 2] === b_index && (t = matrix[i - 2][j - 2] + cost) < min) matrix[i][j] = t;
				else matrix[i][j] = min;
			}
		}
		return matrix[aLength][bLength];
	};
	var fuzzyMatch = function(strA, strB, minLength = 3) {
		if (strA === strB) return 1;
		if (strA.length < minLength || strB.length < minLength) return 0;
		const steps = editDistance(strA, strB);
		const length = Math.max(strA.length, strB.length);
		return 1 - (length === 0 ? 0 : steps / length);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/termMethods.js
	var startQuote = /([\u0022\uFF02\u0027\u201C\u2018\u201F\u201B\u201E\u2E42\u201A\u00AB\u2039\u2035\u2036\u2037\u301D\u0060\u301F])/;
	var endQuote = /([\u0022\uFF02\u0027\u201D\u2019\u00BB\u203A\u2032\u2033\u2034\u301E\u00B4])/;
	var hasHyphen$1 = /^[-–—]$/;
	var hasDash$1 = / [-–—]{1,3} /;
	/** search the term's 'post' punctuation  */
	var hasPost = (term, punct) => term.post.indexOf(punct) !== -1;
	/** search the term's 'pre' punctuation  */
	var methods$6 = {
		/** does it have a quotation symbol?  */
		hasQuote: (term) => startQuote.test(term.pre) || endQuote.test(term.post),
		/** does it have a comma?  */
		hasComma: (term) => hasPost(term, ","),
		/** does it end in a period? */
		hasPeriod: (term) => hasPost(term, ".") === true && hasPost(term, "...") === false,
		/** does it end in an exclamation */
		hasExclamation: (term) => hasPost(term, "!"),
		/** does it end with a question mark? */
		hasQuestionMark: (term) => hasPost(term, "?") || hasPost(term, "¿"),
		/** is there a ... at the end? */
		hasEllipses: (term) => hasPost(term, "..") || hasPost(term, "…"),
		/** is there a semicolon after term word? */
		hasSemicolon: (term) => hasPost(term, ";"),
		/** is there a colon after term word? */
		hasColon: (term) => hasPost(term, ":"),
		/** is there a slash '/' in term word? */
		hasSlash: (term) => /\//.test(term.text),
		/** a hyphen connects two words like-term */
		hasHyphen: (term) => hasHyphen$1.test(term.post) || hasHyphen$1.test(term.pre),
		/** a dash separates words - like that */
		hasDash: (term) => hasDash$1.test(term.post) || hasDash$1.test(term.pre),
		/** is it multiple words combinded */
		hasContraction: (term) => Boolean(term.implicit),
		/** is it an acronym */
		isAcronym: (term) => term.tags.has("Acronym"),
		/** does it have any tags */
		isKnown: (term) => term.tags.size > 0,
		/** uppercase first letter, then a lowercase */
		isTitleCase: (term) => /^\p{Lu}[a-z'\u00C0-\u00FF]/u.test(term.text),
		/** uppercase all letters */
		isUpperCase: (term) => /^\p{Lu}+$/u.test(term.text)
	};
	methods$6.hasQuotation = methods$6.hasQuote;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/term/doesMatch.js
	var wrapMatch = function() {};
	/** ignore optional/greedy logic, straight-up term match*/
	var doesMatch$1 = function(term, reg, index, length) {
		if (reg.anything === true) return true;
		if (reg.start === true && index !== 0) return false;
		if (reg.end === true && index !== length - 1) return false;
		if (reg.id !== void 0 && reg.id === term.id) return true;
		if (reg.word !== void 0) {
			if (reg.use) return reg.word === term[reg.use];
			if (term.machine !== null && term.machine === reg.word) return true;
			if (term.alias !== void 0 && term.alias.hasOwnProperty(reg.word)) return true;
			if (reg.fuzzy === true) {
				if (reg.word === term.root) return true;
				if (fuzzyMatch(reg.word, term.normal) >= reg.min) return true;
			}
			if (term.alias && term.alias.some((str) => str === reg.word)) return true;
			return reg.word === term.text || reg.word === term.normal;
		}
		if (reg.tag !== void 0) return term.tags.has(reg.tag) === true;
		if (reg.method !== void 0) {
			if (typeof methods$6[reg.method] === "function" && methods$6[reg.method](term) === true) return true;
			return false;
		}
		if (reg.pre !== void 0) return term.pre && term.pre.includes(reg.pre);
		if (reg.post !== void 0) return term.post && term.post.includes(reg.post);
		if (reg.regex !== void 0) {
			let str = term.normal;
			if (reg.use) str = term[reg.use];
			return reg.regex.test(str);
		}
		if (reg.chunk !== void 0) return term.chunk === reg.chunk;
		if (reg.switch !== void 0) return term.switch === reg.switch;
		if (reg.machine !== void 0) return term.normal === reg.machine || term.machine === reg.machine || term.root === reg.machine;
		if (reg.sense !== void 0) return term.sense === reg.sense;
		if (reg.fastOr !== void 0) {
			if (reg.pos && !term.tags.has(reg.pos)) return null;
			const str = term.root || term.implicit || term.machine || term.normal;
			return reg.fastOr.has(str) || reg.fastOr.has(term.text);
		}
		if (reg.choices !== void 0) {
			if (reg.operator === "and") return reg.choices.every((r) => wrapMatch(term, r, index, length));
			return reg.choices.some((r) => wrapMatch(term, r, index, length));
		}
		return false;
	};
	wrapMatch = function(t, reg, index, length) {
		const result = doesMatch$1(t, reg, index, length);
		if (reg.negative === true) return !result;
		return result;
	};
	var doesMatch_default = wrapMatch;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/logic/greedy.js
	var getGreedy = function(state, endReg) {
		const reg = Object.assign({}, state.regs[state.r], {
			start: false,
			end: false
		});
		const start = state.t;
		for (; state.t < state.terms.length; state.t += 1) {
			if (endReg && doesMatch_default(state.terms[state.t], endReg, state.start_i + state.t, state.phrase_length)) return state.t;
			const count = state.t - start + 1;
			if (reg.max !== void 0 && count === reg.max) return state.t;
			if (doesMatch_default(state.terms[state.t], reg, state.start_i + state.t, state.phrase_length) === false) {
				if (reg.min !== void 0 && count < reg.min) return null;
				return state.t;
			}
		}
		return state.t;
	};
	var greedyTo = function(state, nextReg) {
		let t = state.t;
		if (!nextReg) return state.terms.length;
		for (; t < state.terms.length; t += 1) if (doesMatch_default(state.terms[t], nextReg, state.start_i + t, state.phrase_length) === true) return t;
		return null;
	};
	var isEndGreedy = function(reg, state) {
		if (reg.end === true && reg.greedy === true) {
			if (state.start_i + state.t < state.phrase_length - 1) {
				const tmpReg = Object.assign({}, reg, { end: false });
				if (doesMatch_default(state.terms[state.t], tmpReg, state.start_i + state.t, state.phrase_length) === true) return true;
			}
		}
		return false;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/_lib.js
	var getGroup$1 = function(state, term_index) {
		if (state.groups[state.inGroup]) return state.groups[state.inGroup];
		state.groups[state.inGroup] = {
			start: term_index,
			length: 0
		};
		return state.groups[state.inGroup];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/astrix.js
	var doAstrix = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const skipto = greedyTo(state, regs[state.r + 1]);
		if (skipto === null || skipto === 0) return null;
		if (reg.min !== void 0 && skipto - state.t < reg.min) return null;
		if (reg.max !== void 0 && skipto - state.t > reg.max) {
			state.t = state.t + reg.max;
			return true;
		}
		if (state.hasGroup === true) {
			const g = getGroup$1(state, state.t);
			g.length = skipto - state.t;
		}
		state.t = skipto;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/logic/and-or.js
	var isArray$4 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var doOrBlock = function(state, skipN = 0) {
		const block = state.regs[state.r];
		let wasFound = false;
		for (let c = 0; c < block.choices.length; c += 1) {
			const regs = block.choices[c];
			if (!isArray$4(regs)) return false;
			wasFound = regs.every((cr, w_index) => {
				let extra = 0;
				const t = state.t + w_index + skipN + extra;
				if (state.terms[t] === void 0) return false;
				const foundBlock = doesMatch_default(state.terms[t], cr, t + state.start_i, state.phrase_length);
				if (foundBlock === true && cr.greedy === true) for (let i = 1; i < state.terms.length; i += 1) {
					const term = state.terms[t + i];
					if (term) if (doesMatch_default(term, cr, state.start_i + i, state.phrase_length) === true) extra += 1;
					else break;
				}
				skipN += extra;
				return foundBlock;
			});
			if (wasFound) {
				skipN += regs.length;
				break;
			}
		}
		if (wasFound && block.greedy === true) return doOrBlock(state, skipN);
		return skipN;
	};
	var doAndBlock = function(state) {
		let longest = 0;
		if (state.regs[state.r].choices.every((block) => {
			const allWords = block.every((cr, w_index) => {
				const tryTerm = state.t + w_index;
				if (state.terms[tryTerm] === void 0) return false;
				return doesMatch_default(state.terms[tryTerm], cr, tryTerm, state.phrase_length);
			});
			if (allWords === true && block.length > longest) longest = block.length;
			return allWords;
		}) === true) return longest;
		return false;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/or-block.js
	var orBlock = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const skipNum = doOrBlock(state);
		if (skipNum) {
			if (reg.negative === true) return null;
			if (state.hasGroup === true) {
				const g = getGroup$1(state, state.t);
				g.length += skipNum;
			}
			if (reg.end === true) {
				const end = state.phrase_length;
				if (state.t + state.start_i + skipNum !== end) return null;
			}
			state.t += skipNum;
			return true;
		} else if (!reg.optional) return null;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/and-block.js
	var andBlock = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const skipNum = doAndBlock(state);
		if (skipNum) {
			if (reg.negative === true) return null;
			if (state.hasGroup === true) {
				const g = getGroup$1(state, state.t);
				g.length += skipNum;
			}
			if (reg.end === true) {
				const end = state.phrase_length - 1;
				if (state.t + state.start_i !== end) return null;
			}
			state.t += skipNum;
			return true;
		} else if (!reg.optional) return null;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/logic/negative-greedy.js
	var negGreedy = function(state, reg, nextReg) {
		let skip = 0;
		for (let t = state.t; t < state.terms.length; t += 1) {
			let found = doesMatch_default(state.terms[t], reg, state.start_i + state.t, state.phrase_length);
			if (found) break;
			if (nextReg) {
				found = doesMatch_default(state.terms[t], nextReg, state.start_i + state.t, state.phrase_length);
				if (found) break;
			}
			skip += 1;
			if (reg.max !== void 0 && skip === reg.max) break;
		}
		if (skip === 0) return false;
		if (reg.min && reg.min > skip) return false;
		state.t += skip;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/negative.js
	var doNegative = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const tmpReg = Object.assign({}, reg);
		tmpReg.negative = false;
		if (doesMatch_default(state.terms[state.t], tmpReg, state.start_i + state.t, state.phrase_length)) return false;
		if (reg.optional) {
			const nextReg = regs[state.r + 1];
			if (nextReg) {
				if (doesMatch_default(state.terms[state.t], nextReg, state.start_i + state.t, state.phrase_length)) state.r += 1;
				else if (nextReg.optional && regs[state.r + 2]) {
					if (doesMatch_default(state.terms[state.t], regs[state.r + 2], state.start_i + state.t, state.phrase_length)) state.r += 2;
				}
			}
		}
		if (reg.greedy) return negGreedy(state, tmpReg, regs[state.r + 1]);
		state.t += 1;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/optional-match.js
	var foundOptional = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const term = state.terms[state.t];
		const nextRegMatched = doesMatch_default(term, regs[state.r + 1], state.start_i + state.t, state.phrase_length);
		if (reg.negative || nextRegMatched) {
			const nextTerm = state.terms[state.t + 1];
			if (!nextTerm || !doesMatch_default(nextTerm, regs[state.r + 1], state.start_i + state.t, state.phrase_length)) state.r += 1;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/greedy-match.js
	var greedyMatch = function(state) {
		const { regs, phrase_length } = state;
		const reg = regs[state.r];
		state.t = getGreedy(state, regs[state.r + 1]);
		if (state.t === null) return null;
		if (reg.min && reg.min > state.t) return null;
		if (reg.end === true && state.start_i + state.t !== phrase_length) return null;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/contraction-skip.js
	var contractionSkip = function(state) {
		const term = state.terms[state.t];
		const reg = state.regs[state.r];
		if (term.implicit && state.terms[state.t + 1]) {
			if (!state.terms[state.t + 1].implicit) return;
			if (reg.word === term.normal) state.t += 1;
			if (reg.method === "hasContraction") state.t += 1;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/steps/simple-match.js
	var setGroup = function(state, startAt) {
		const reg = state.regs[state.r];
		const g = getGroup$1(state, startAt);
		if (state.t > 1 && reg.greedy) g.length += state.t - startAt;
		else g.length++;
	};
	var simpleMatch = function(state) {
		const { regs } = state;
		const reg = regs[state.r];
		const term = state.terms[state.t];
		const startAt = state.t;
		if (reg.optional && regs[state.r + 1] && reg.negative) return true;
		if (reg.optional && regs[state.r + 1]) foundOptional(state);
		if (term.implicit && state.terms[state.t + 1]) contractionSkip(state);
		state.t += 1;
		if (reg.end === true && state.t !== state.terms.length && reg.greedy !== true) return null;
		if (reg.greedy === true) {
			if (!greedyMatch(state)) return null;
		}
		if (state.hasGroup === true) setGroup(state, startAt);
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/02-from-here.js
	/** 
	* try a sequence of match tokens ('regs') 
	* on a sequence of terms, 
	* starting at this certain term.
	*/
	var tryHere = function(terms, regs, start_i, phrase_length) {
		if (terms.length === 0 || regs.length === 0) return null;
		const state = {
			t: 0,
			terms,
			r: 0,
			regs,
			groups: {},
			start_i,
			phrase_length,
			inGroup: null
		};
		for (; state.r < regs.length; state.r += 1) {
			const reg = regs[state.r];
			state.hasGroup = Boolean(reg.group);
			if (state.hasGroup === true) state.inGroup = reg.group;
			else state.inGroup = null;
			if (!state.terms[state.t]) {
				if (regs.slice(state.r).some((remain) => !remain.optional) === false) break;
				return null;
			}
			if (reg.anything === true && reg.greedy === true) {
				if (!doAstrix(state)) return null;
				continue;
			}
			if (reg.choices !== void 0 && reg.operator === "or") {
				if (!orBlock(state)) return null;
				continue;
			}
			if (reg.choices !== void 0 && reg.operator === "and") {
				if (!andBlock(state)) return null;
				continue;
			}
			if (reg.anything === true) {
				if (reg.negative && reg.anything) return null;
				if (!simpleMatch(state)) return null;
				continue;
			}
			if (isEndGreedy(reg, state) === true) {
				if (!simpleMatch(state)) return null;
				continue;
			}
			if (reg.negative) {
				if (!doNegative(state)) return null;
				continue;
			}
			if (doesMatch_default(state.terms[state.t], reg, state.start_i + state.t, state.phrase_length) === true) {
				if (!simpleMatch(state)) return null;
				continue;
			}
			if (reg.optional === true) continue;
			return null;
		}
		const pntr = [
			null,
			start_i,
			state.t + start_i
		];
		if (pntr[1] === pntr[2]) return null;
		const groups = {};
		Object.keys(state.groups).forEach((k) => {
			const o = state.groups[k];
			const start = start_i + o.start;
			groups[k] = [
				null,
				start,
				start + o.length
			];
		});
		return {
			pointer: pntr,
			groups
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/03-getGroup.js
	var getGroup = function(res, group) {
		const ptrs = [];
		const byGroup = {};
		if (res.length === 0) return {
			ptrs,
			byGroup
		};
		if (typeof group === "number") group = String(group);
		if (group) res.forEach((r) => {
			if (r.groups[group]) ptrs.push(r.groups[group]);
		});
		else res.forEach((r) => {
			ptrs.push(r.pointer);
			Object.keys(r.groups).forEach((k) => {
				byGroup[k] = byGroup[k] || [];
				byGroup[k].push(r.groups[k]);
			});
		});
		return {
			ptrs,
			byGroup
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/03-notIf.js
	var notIf$1 = function(results, not, docs) {
		results = results.filter((res) => {
			const [n, start, end] = res.pointer;
			const terms = docs[n].slice(start, end);
			for (let i = 0; i < terms.length; i += 1) if (tryHere(terms.slice(i), not, i, terms.length) !== null) return false;
			return true;
		});
		return results;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/methods/match/index.js
	var addSentence = function(res, n) {
		res.pointer[0] = n;
		Object.keys(res.groups).forEach((k) => {
			res.groups[k][0] = n;
		});
		return res;
	};
	var handleStart = function(terms, regs, n) {
		let res = tryHere(terms, regs, 0, terms.length);
		if (res) {
			res = addSentence(res, n);
			return res;
		}
		return null;
	};
	var runMatch$1 = function(docs, todo, cache) {
		cache = cache || [];
		const { regs, group, justOne } = todo;
		let results = [];
		if (!regs || regs.length === 0) return {
			ptrs: [],
			byGroup: {}
		};
		const minLength = regs.filter((r) => r.optional !== true && r.negative !== true).length;
		docs: for (let n = 0; n < docs.length; n += 1) {
			const terms = docs[n];
			if (cache[n] && failFast(regs, cache[n])) continue;
			if (regs[0].start === true) {
				const foundStart = handleStart(terms, regs, n, group);
				if (foundStart) results.push(foundStart);
				continue;
			}
			for (let i = 0; i < terms.length; i += 1) {
				const slice = terms.slice(i);
				if (slice.length < minLength) break;
				let res = tryHere(slice, regs, i, terms.length);
				if (res) {
					res = addSentence(res, n);
					results.push(res);
					if (justOne === true) break docs;
					const end = res.pointer[2];
					if (Math.abs(end - 1) > i) i = Math.abs(end - 1);
				}
			}
		}
		if (regs[regs.length - 1].end === true) results = results.filter((res) => {
			return docs[res.pointer[0]].length === res.pointer[2];
		});
		if (todo.notIf) results = notIf$1(results, todo.notIf, docs);
		results = getGroup(results, group);
		results.ptrs.forEach((ptr) => {
			const [n, start, end] = ptr;
			ptr[3] = docs[n][start].id;
			ptr[4] = docs[n][end - 1].id;
		});
		return results;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/match/plugin.js
	var plugin_default$10 = {
		api: matchAPI,
		methods: { one: {
			termMethods: methods$6,
			parseMatch: syntax,
			match: runMatch$1
		} },
		lib: { 
		/** pre-parse any match statements */
parseMatch: function(str, opts) {
			const world = this.world();
			const killUnicode = world.methods.one.killUnicode;
			if (killUnicode) str = killUnicode(str, world);
			return world.methods.one.parseMatch(str, opts, world);
		} }
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/html.js
	var isClass = /^\../;
	var isId = /^#./;
	var escapeXml = (str) => {
		str = str.replace(/&/g, "&amp;");
		str = str.replace(/</g, "&lt;");
		str = str.replace(/>/g, "&gt;");
		str = str.replace(/"/g, "&quot;");
		str = str.replace(/'/g, "&apos;");
		return str;
	};
	var toTag = function(k) {
		let start = "";
		let end = "</span>";
		k = escapeXml(k);
		if (isClass.test(k)) start = `<span class="${k.replace(/^\./, "")}"`;
		else if (isId.test(k)) start = `<span id="${k.replace(/^#/, "")}"`;
		else {
			start = `<${k}`;
			end = `</${k}>`;
		}
		start += ">";
		return {
			start,
			end
		};
	};
	var getIndex = function(doc, obj) {
		const starts = {};
		const ends = {};
		Object.keys(obj).forEach((k) => {
			let res = obj[k];
			const tag = toTag(k);
			if (typeof res === "string") res = doc.match(res);
			res.docs.forEach((terms) => {
				if (terms.every((t) => t.implicit)) return;
				const a = terms[0].id;
				starts[a] = starts[a] || [];
				starts[a].push(tag.start);
				const b = terms[terms.length - 1].id;
				ends[b] = ends[b] || [];
				ends[b].push(tag.end);
			});
		});
		return {
			starts,
			ends
		};
	};
	var html = function(obj) {
		const { starts, ends } = getIndex(this, obj);
		let out = "";
		this.docs.forEach((terms) => {
			for (let i = 0; i < terms.length; i += 1) {
				const t = terms[i];
				if (starts.hasOwnProperty(t.id)) out += starts[t.id].join("");
				out += t.pre || "";
				out += t.text || "";
				if (ends.hasOwnProperty(t.id)) out += ends[t.id].join("");
				out += t.post || "";
			}
		});
		return out;
	};
	var html_default = { html };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/_text.js
	var trimEnd = /[,:;)\]*.?~!\u0022\uFF02\u201D\u2019\u00BB\u203A\u2032\u2033\u2034\u301E\u00B4—-]+$/;
	var trimStart = /^[(['"*~\uFF02\u201C\u2018\u201F\u201B\u201E\u2E42\u201A\u00AB\u2039\u2035\u2036\u2037\u301D\u0060\u301F]+/;
	var punctToKill = /[,:;)('"\u201D\]]/;
	var isHyphen = /^[-–—]$/;
	var hasSpace = / /;
	var textFromTerms = function(terms, opts, keepSpace = true) {
		let txt = "";
		terms.forEach((t) => {
			let pre = t.pre || "";
			let post = t.post || "";
			if (opts.punctuation === "some") {
				pre = pre.replace(trimStart, "");
				if (isHyphen.test(post)) post = " ";
				post = post.replace(punctToKill, "");
				post = post.replace(/\?!+/, "?");
				post = post.replace(/!+/, "!");
				post = post.replace(/\?+/, "?");
				post = post.replace(/\.{2,}/, "");
				if (t.tags.has("Abbreviation")) post = post.replace(/\./, "");
			}
			if (opts.whitespace === "some") {
				pre = pre.replace(/\s/, "");
				post = post.replace(/\s+/, " ");
			}
			if (!opts.keepPunct) {
				pre = pre.replace(trimStart, "");
				if (post === "-") post = " ";
				else post = post.replace(trimEnd, "");
			}
			let word = t[opts.form || "text"] || t.normal || "";
			if (opts.form === "implicit") word = t.implicit || t.text;
			if (opts.form === "root" && t.implicit) word = t.root || t.implicit || t.normal;
			if ((opts.form === "machine" || opts.form === "implicit" || opts.form === "root") && t.implicit) {
				if (!post || !hasSpace.test(post)) post += " ";
			}
			txt += pre + word + post;
		});
		if (keepSpace === false) txt = txt.trim();
		if (opts.lowerCase === true) txt = txt.toLowerCase();
		return txt;
	};
	var textFromDoc = function(docs, opts) {
		let text = "";
		if (!docs || !docs[0] || !docs[0][0]) return text;
		for (let i = 0; i < docs.length; i += 1) text += textFromTerms(docs[i], opts, true);
		if (!opts.keepSpace) text = text.trim();
		if (opts.keepEndPunct === false) {
			if (!docs[0][0].tags.has("Emoticon")) text = text.replace(trimStart, "");
			const last = docs[docs.length - 1];
			if (!last[last.length - 1].tags.has("Emoticon")) text = text.replace(trimEnd, "");
			if (text.endsWith(`'`) && !text.endsWith(`s'`)) text = text.replace(/'/, "");
		}
		if (opts.cleanWhitespace === true) text = text.trim();
		return text;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/_fmts.js
	var fmts = {
		text: { form: "text" },
		normal: {
			whitespace: "some",
			punctuation: "some",
			case: "some",
			unicode: "some",
			form: "normal"
		},
		machine: {
			keepSpace: false,
			whitespace: "some",
			punctuation: "some",
			case: "none",
			unicode: "some",
			form: "machine"
		},
		root: {
			keepSpace: false,
			whitespace: "some",
			punctuation: "some",
			case: "some",
			unicode: "some",
			form: "root"
		},
		implicit: { form: "implicit" }
	};
	fmts.clean = fmts.normal;
	fmts.reduced = fmts.root;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/hash.js
	var k = [];
	var i$1 = 0;
	for (; i$1 < 64;) k[i$1] = 0 | Math.sin(++i$1 % Math.PI) * 4294967296;
	var md5 = function(s) {
		let b, c, d, j = decodeURI(encodeURI(s)) + "", a = j.length;
		const h = [
			b = 1732584193,
			c = 4023233417,
			~b,
			~c
		], words = [];
		s = --a / 4 + 2 | 15;
		words[--s] = a * 8;
		for (; ~a;) words[a >> 2] |= j.charCodeAt(a) << 8 * a--;
		for (i$1 = j = 0; i$1 < s; i$1 += 16) {
			a = h;
			for (; j < 64; a = [
				d = a[3],
				b + ((d = a[0] + [
					b & c | ~b & d,
					d & b | ~d & c,
					b ^ c ^ d,
					c ^ (b | ~d)
				][a = j >> 4] + k[j] + ~~words[i$1 | [
					j,
					5 * j + 1,
					3 * j + 5,
					7 * j
				][a] & 15]) << (a = [
					7,
					12,
					17,
					22,
					5,
					9,
					14,
					20,
					4,
					11,
					16,
					23,
					6,
					10,
					15,
					21
				][4 * a + j++ % 4]) | d >>> -a),
				b,
				c
			]) {
				b = a[1] | 0;
				c = a[2];
			}
			for (j = 4; j;) h[--j] += a[j];
		}
		for (s = ""; j < 32;) s += (h[j >> 3] >> (1 ^ j++) * 4 & 15).toString(16);
		return s;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/json.js
	var defaults$1 = {
		text: true,
		terms: true
	};
	var opts = {
		case: "none",
		unicode: "some",
		form: "machine",
		punctuation: "some"
	};
	var merge = function(a, b) {
		return Object.assign({}, a, b);
	};
	var fns$1 = {
		text: (terms) => textFromTerms(terms, { keepPunct: true }, false),
		normal: (terms) => textFromTerms(terms, merge(fmts.normal, { keepPunct: true }), false),
		implicit: (terms) => textFromTerms(terms, merge(fmts.implicit, { keepPunct: true }), false),
		machine: (terms) => textFromTerms(terms, opts, false),
		root: (terms) => textFromTerms(terms, merge(opts, { form: "root" }), false),
		hash: (terms) => md5(textFromTerms(terms, { keepPunct: true }, false)),
		offset: (terms) => {
			const len = fns$1.text(terms).length;
			return {
				index: terms[0].offset.index,
				start: terms[0].offset.start,
				length: len
			};
		},
		terms: (terms) => {
			return terms.map((t) => {
				const term = Object.assign({}, t);
				term.tags = Array.from(t.tags);
				return term;
			});
		},
		confidence: (_terms, view, i) => view.eq(i).confidence(),
		syllables: (_terms, view, i) => view.eq(i).syllables(),
		sentence: (_terms, view, i) => view.eq(i).fullSentence().text(),
		dirty: (terms) => terms.some((t) => t.dirty === true)
	};
	fns$1.sentences = fns$1.sentence;
	fns$1.clean = fns$1.normal;
	fns$1.reduced = fns$1.root;
	var toJSON = function(view, option) {
		option = option || {};
		if (typeof option === "string") option = {};
		option = Object.assign({}, defaults$1, option);
		if (option.offset) view.compute("offset");
		return view.docs.map((terms, i) => {
			const res = {};
			Object.keys(option).forEach((k) => {
				if (option[k] && fns$1[k]) res[k] = fns$1[k](terms, view, i);
			});
			return res;
		});
	};
	var methods$4 = { 
	/** return data */
json: function(n) {
		const res = toJSON(this, n);
		if (typeof n === "number") return res[n];
		return res;
	} };
	methods$4.data = methods$4.json;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/debug.js
	var isClientSide = () => typeof window !== "undefined" && window.document;
	var debug$1 = function(fmt) {
		const debugMethods = this.methods.one.debug || {};
		if (fmt && debugMethods.hasOwnProperty(fmt)) {
			debugMethods[fmt](this);
			return this;
		}
		if (isClientSide()) {
			debugMethods.clientSide(this);
			return this;
		}
		debugMethods.tags(this);
		return this;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/wrap.js
	var toText = function(term) {
		const pre = term.pre || "";
		const post = term.post || "";
		return pre + term.text + post;
	};
	var findStarts = function(doc, obj) {
		const starts = {};
		Object.keys(obj).forEach((reg) => {
			doc.match(reg).fullPointer.forEach((a) => {
				starts[a[3]] = {
					fn: obj[reg],
					end: a[2]
				};
			});
		});
		return starts;
	};
	var wrap = function(doc, obj) {
		const starts = findStarts(doc, obj);
		let text = "";
		doc.docs.forEach((terms, n) => {
			for (let i = 0; i < terms.length; i += 1) {
				const t = terms[i];
				if (starts.hasOwnProperty(t.id)) {
					const { fn, end } = starts[t.id];
					const m = doc.update([[
						n,
						i,
						end
					]]);
					text += terms[i].pre || "";
					text += fn(m);
					i = end - 1;
					text += terms[i].post || "";
				} else text += toText(t);
			}
		});
		return text;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/out.js
	var isObject$2 = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	var topk = function(arr) {
		const obj = {};
		arr.forEach((a) => {
			obj[a] = obj[a] || 0;
			obj[a] += 1;
		});
		return Object.keys(obj).map((k) => {
			return {
				normal: k,
				count: obj[k]
			};
		}).sort((a, b) => a.count > b.count ? -1 : 0);
	};
	/** some named output formats */
	var out = function(method) {
		if (isObject$2(method)) return wrap(this, method);
		if (method === "text") return this.text();
		if (method === "normal") return this.text("normal");
		if (method === "root") return this.text("root");
		if (method === "machine" || method === "reduced") return this.text("machine");
		if (method === "hash" || method === "md5") return md5(this.text());
		if (method === "json") return this.json();
		if (method === "offset" || method === "offsets") {
			this.compute("offset");
			return this.json({ offset: true });
		}
		if (method === "array") return this.docs.map((terms) => {
			return terms.reduce((str, t) => {
				return str + t.pre + t.text + t.post;
			}, "").trim();
		}).filter((str) => str);
		if (method === "freq" || method === "frequency" || method === "topk") return topk(this.json({ normal: true }).map((o) => o.normal));
		if (method === "terms") {
			let list = [];
			this.docs.forEach((terms) => {
				let words = terms.map((t) => t.text);
				words = words.filter((t) => t);
				list = list.concat(words);
			});
			return list;
		}
		if (method === "tags") return this.docs.map((terms) => {
			return terms.reduce((h, t) => {
				h[t.implicit || t.normal] = Array.from(t.tags);
				return h;
			}, {});
		});
		if (method === "debug") return this.debug();
		return this.text();
	};
	var methods$3 = {
		/** */
		debug: debug$1,
		/** */
		out,
		/** */
		wrap: function(obj) {
			return wrap(this, obj);
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/text.js
	var isObject$1 = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/api/index.js
	var methods$2 = Object.assign({}, methods$3, { 
	/** */
text: function(fmt) {
		let opts = {};
		if (fmt && typeof fmt === "string" && fmts.hasOwnProperty(fmt)) opts = Object.assign({}, fmts[fmt]);
		else if (fmt && isObject$1(fmt)) opts = Object.assign({}, fmt);
		if (opts.keepSpace === void 0 && !this.isFull()) opts.keepSpace = false;
		if (opts.keepEndPunct === void 0 && this.pointer) {
			const ptr = this.pointer[0];
			if (ptr && ptr[1]) opts.keepEndPunct = false;
			else opts.keepEndPunct = true;
		}
		if (opts.keepPunct === void 0) opts.keepPunct = true;
		if (opts.keepSpace === void 0) opts.keepSpace = true;
		return textFromDoc(this.docs, opts);
	} }, methods$4, html_default);
	var addAPI$1 = function(View) {
		Object.assign(View.prototype, methods$2);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/debug/client-side.js
	var logClientSide = function(view) {
		console.log("%c -=-=- ", "background-color:#6699cc;");
		view.forEach((m) => {
			console.groupCollapsed(m.text());
			const out = m.docs[0].map((t) => {
				let text = t.text || "-";
				if (t.implicit) text = "[" + t.implicit + "]";
				const tags = "[" + Array.from(t.tags).join(", ") + "]";
				return {
					text,
					tags
				};
			});
			console.table(out, ["text", "tags"]);
			console.groupEnd();
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/debug/_color.js
	var reset = "\x1B[0m";
	var cli = {
		green: (str) => "\x1B[32m" + str + reset,
		red: (str) => "\x1B[31m" + str + reset,
		blue: (str) => "\x1B[34m" + str + reset,
		magenta: (str) => "\x1B[35m" + str + reset,
		cyan: (str) => "\x1B[36m" + str + reset,
		yellow: (str) => "\x1B[33m" + str + reset,
		black: (str) => "\x1B[30m" + str + reset,
		dim: (str) => "\x1B[2m" + str + reset,
		i: (str) => "\x1B[3m" + str + reset
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/debug/tags.js
	var tagString = function(tags, model) {
		if (model.one.tagSet) tags = tags.map((tag) => {
			if (!model.one.tagSet.hasOwnProperty(tag)) return tag;
			return cli[model.one.tagSet[tag].color || "blue"](tag);
		});
		return tags.join(", ");
	};
	var showTags = function(view) {
		const { docs, model } = view;
		if (docs.length === 0) console.log(cli.blue("\n     ──────"));
		docs.forEach((terms) => {
			console.log(cli.blue("\n  ┌─────────"));
			terms.forEach((t) => {
				const tags = [...t.tags || []];
				let text = t.text || "-";
				if (t.sense) text = `{${t.normal}/${t.sense}}`;
				if (t.implicit) text = "[" + t.implicit + "]";
				text = cli.yellow(text);
				let word = "'" + text + "'";
				if (t.reference) {
					const str = view.update([t.reference]).text("normal");
					word += ` - ${cli.dim(cli.i("[" + str + "]"))}`;
				}
				word = word.padEnd(18);
				const str = cli.blue("  │ ") + cli.i(word) + "  - " + tagString(tags, model);
				console.log(str);
			});
		});
		console.log("\n");
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/debug/chunks.js
	var showChunks = function(view) {
		const { docs } = view;
		console.log("");
		docs.forEach((terms) => {
			const out = [];
			terms.forEach((term) => {
				if (term.chunk === "Noun") out.push(cli.blue(term.implicit || term.normal));
				else if (term.chunk === "Verb") out.push(cli.green(term.implicit || term.normal));
				else if (term.chunk === "Adjective") out.push(cli.yellow(term.implicit || term.normal));
				else if (term.chunk === "Pivot") out.push(cli.red(term.implicit || term.normal));
				else out.push(term.implicit || term.normal);
			});
			console.log(out.join(" "), "\n");
		});
		console.log("\n");
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/methods/debug/highlight.js
	var split = (txt, offset, index) => {
		const buff = index * 9;
		const start = offset.start + buff;
		const end = start + offset.length;
		return [
			txt.substring(0, start),
			txt.substring(start, end),
			txt.substring(end, txt.length)
		];
	};
	var spliceIn = function(txt, offset, index) {
		const parts = split(txt, offset, index);
		return `${parts[0]}${cli.blue(parts[1])}${parts[2]}`;
	};
	var showHighlight = function(doc) {
		if (!doc.found) return;
		const bySentence = {};
		doc.fullPointer.forEach((ptr) => {
			bySentence[ptr[0]] = bySentence[ptr[0]] || [];
			bySentence[ptr[0]].push(ptr);
		});
		Object.keys(bySentence).forEach((k) => {
			let txt = doc.update([[Number(k)]]).text();
			doc.update(bySentence[k]).json({ offset: true }).forEach((obj, i) => {
				txt = spliceIn(txt, obj.offset, i);
			});
			console.log(txt);
		});
		console.log("\n");
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/output/plugin.js
	var plugin_default$9 = {
		api: addAPI$1,
		methods: { one: {
			hash: md5,
			debug: {
				tags: showTags,
				clientSide: logClientSide,
				chunks: showChunks,
				highlight: showHighlight
			}
		} }
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/lib/_lib.js
	var doesOverlap = function(a, b) {
		if (a[0] !== b[0]) return false;
		const [, startA, endA] = a;
		const [, startB, endB] = b;
		if (startA <= startB && endA > startB) return true;
		if (startB <= startA && endB > startA) return true;
		return false;
	};
	var getExtent = function(ptrs) {
		let min = ptrs[0][1];
		let max = ptrs[0][2];
		ptrs.forEach((ptr) => {
			if (ptr[1] < min) min = ptr[1];
			if (ptr[2] > max) max = ptr[2];
		});
		return [
			ptrs[0][0],
			min,
			max
		];
	};
	var indexN = function(ptrs) {
		const byN = {};
		ptrs.forEach((ref) => {
			byN[ref[0]] = byN[ref[0]] || [];
			byN[ref[0]].push(ref);
		});
		return byN;
	};
	var uniquePtrs = function(arr) {
		const obj = {};
		for (let i = 0; i < arr.length; i += 1) obj[arr[i].join(",")] = arr[i];
		return Object.values(obj);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/lib/split.js
	var pivotBy = function(full, m) {
		const [n, start] = full;
		const mStart = m[1];
		const mEnd = m[2];
		const res = {};
		if (start < mStart) res.before = [
			n,
			start,
			mStart < full[2] ? mStart : full[2]
		];
		res.match = m;
		if (full[2] > mEnd) res.after = [
			n,
			mEnd,
			full[2]
		];
		return res;
	};
	var doesMatch = function(full, m) {
		return full[1] <= m[1] && m[2] <= full[2];
	};
	var splitAll = function(full, m) {
		const byN = indexN(m);
		const res = [];
		full.forEach((ptr) => {
			const [n] = ptr;
			let matches = byN[n] || [];
			matches = matches.filter((p) => doesMatch(ptr, p));
			if (matches.length === 0) {
				res.push({ passthrough: ptr });
				return;
			}
			matches = matches.sort((a, b) => a[1] - b[1]);
			let carry = ptr;
			matches.forEach((p, i) => {
				const found = pivotBy(carry, p);
				if (!matches[i + 1]) res.push(found);
				else {
					res.push({
						before: found.before,
						match: found.match
					});
					if (found.after) carry = found.after;
				}
			});
		});
		return res;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/methods/getDoc.js
	var max$1 = 20;
	var blindSweep = function(id, doc, n) {
		for (let i = 0; i < max$1; i += 1) {
			if (doc[n - i]) {
				const index = doc[n - i].findIndex((term) => term.id === id);
				if (index !== -1) return [n - i, index];
			}
			if (doc[n + i]) {
				const index = doc[n + i].findIndex((term) => term.id === id);
				if (index !== -1) return [n + i, index];
			}
		}
		return null;
	};
	var repairEnding = function(ptr, document) {
		const [n, start, , , endId] = ptr;
		const terms = document[n];
		const newEnd = terms.findIndex((t) => t.id === endId);
		if (newEnd === -1) {
			ptr[2] = document[n].length;
			ptr[4] = terms.length ? terms[terms.length - 1].id : null;
		} else ptr[2] = newEnd;
		return document[n].slice(start, ptr[2] + 1);
	};
	/** return a subset of the document, from a pointer */
	var getDoc$1 = function(ptrs, document) {
		let doc = [];
		ptrs.forEach((ptr, i) => {
			if (!ptr) return;
			let [n, start, end, id, endId] = ptr;
			let terms = document[n] || [];
			if (start === void 0) start = 0;
			if (end === void 0) end = terms.length;
			if (id && (!terms[start] || terms[start].id !== id)) {
				const wild = blindSweep(id, document, n);
				if (wild !== null) {
					const len = end - start;
					terms = document[wild[0]].slice(wild[1], wild[1] + len);
					const startId = terms[0] ? terms[0].id : null;
					ptrs[i] = [
						wild[0],
						wild[1],
						wild[1] + len,
						startId
					];
				}
			} else terms = terms.slice(start, end);
			if (terms.length === 0) return;
			if (start === end) return;
			if (endId && terms[terms.length - 1].id !== endId) terms = repairEnding(ptr, document);
			doc.push(terms);
		});
		doc = doc.filter((a) => a.length > 0);
		return doc;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/methods/index.js
	var termList = function(docs) {
		const arr = [];
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) arr.push(docs[i][t]);
		return arr;
	};
	var methods_default$4 = { one: {
		termList,
		getDoc: getDoc$1,
		pointer: {
			indexN,
			splitAll
		}
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/lib/union.js
	var getUnion = function(a, b) {
		const both = a.concat(b);
		const byN = indexN(both);
		let res = [];
		both.forEach((ptr) => {
			const [n] = ptr;
			if (byN[n].length === 1) {
				res.push(ptr);
				return;
			}
			const hmm = byN[n].filter((m) => doesOverlap(ptr, m));
			hmm.push(ptr);
			const range = getExtent(hmm);
			res.push(range);
		});
		res = uniquePtrs(res);
		return res;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/lib/difference.js
	var subtract = function(refs, not) {
		const res = [];
		splitAll(refs, not).forEach((o) => {
			if (o.passthrough) res.push(o.passthrough);
			if (o.before) res.push(o.before);
			if (o.after) res.push(o.after);
		});
		return res;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/lib/intersection.js
	var intersection = function(a, b) {
		const start = a[1] < b[1] ? b[1] : a[1];
		const end = a[2] > b[2] ? b[2] : a[2];
		if (start < end) return [
			a[0],
			start,
			end
		];
		return null;
	};
	var getIntersection = function(a, b) {
		const byN = indexN(b);
		const res = [];
		a.forEach((ptr) => {
			let hmm = byN[ptr[0]] || [];
			hmm = hmm.filter((p) => doesOverlap(ptr, p));
			if (hmm.length === 0) return;
			hmm.forEach((h) => {
				const overlap = intersection(ptr, h);
				if (overlap) res.push(overlap);
			});
		});
		return res;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/api/index.js
	var isArray$3 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var getDoc = (m, view) => {
		if (typeof m === "string" || isArray$3(m)) return view.match(m);
		if (!m) return view.none();
		return m;
	};
	var addIds = function(ptrs, docs) {
		return ptrs.map((ptr) => {
			const [n, start] = ptr;
			if (docs[n] && docs[n][start]) ptr[3] = docs[n][start].id;
			return ptr;
		});
	};
	var methods$1 = {};
	methods$1.union = function(m) {
		m = getDoc(m, this);
		let ptrs = getUnion(this.fullPointer, m.fullPointer);
		ptrs = addIds(ptrs, this.document);
		return this.toView(ptrs);
	};
	methods$1.and = methods$1.union;
	methods$1.intersection = function(m) {
		m = getDoc(m, this);
		let ptrs = getIntersection(this.fullPointer, m.fullPointer);
		ptrs = addIds(ptrs, this.document);
		return this.toView(ptrs);
	};
	methods$1.not = function(m) {
		m = getDoc(m, this);
		let ptrs = subtract(this.fullPointer, m.fullPointer);
		ptrs = addIds(ptrs, this.document);
		return this.toView(ptrs);
	};
	methods$1.difference = methods$1.not;
	methods$1.complement = function() {
		let ptrs = subtract(this.all().fullPointer, this.fullPointer);
		ptrs = addIds(ptrs, this.document);
		return this.toView(ptrs);
	};
	methods$1.settle = function() {
		let ptrs = this.fullPointer;
		ptrs.forEach((ptr) => {
			ptrs = getUnion(ptrs, [ptr]);
		});
		ptrs = addIds(ptrs, this.document);
		return this.update(ptrs);
	};
	var addAPI = function(View) {
		Object.assign(View.prototype, methods$1);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/pointers/plugin.js
	var plugin_default$8 = {
		methods: methods_default$4,
		api: addAPI
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/lib.js
	var lib_default$2 = { buildNet: function(matches) {
		const net = this.methods().one.buildNet(matches, this.world());
		net.isNet = true;
		return net;
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/api.js
	var api$3 = function(View) {
		/** speedy match a sequence of matches */
		View.prototype.sweep = function(net, opts = {}) {
			const { world, docs } = this;
			const { methods } = world;
			let found = methods.one.bulkMatch(docs, net, this.methods, opts);
			if (opts.tagger !== false) methods.one.bulkTagger(found, docs, this.world);
			found = found.map((o) => {
				const ptr = o.pointer;
				const term = docs[ptr[0]][ptr[1]];
				const len = ptr[2] - ptr[1];
				if (term.index) o.pointer = [
					term.index[0],
					term.index[1],
					ptr[1] + len
				];
				return o;
			});
			const ptrs = found.map((o) => o.pointer);
			found = found.map((obj) => {
				obj.view = this.update([obj.pointer]);
				delete obj.regs;
				delete obj.needs;
				delete obj.pointer;
				delete obj._expanded;
				return obj;
			});
			return {
				view: this.update(ptrs),
				found
			};
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/buildNet/01-parse.js
	var getTokenNeeds = function(reg) {
		if (reg.optional === true || reg.negative === true) return null;
		if (reg.tag) return "#" + reg.tag;
		if (reg.word) return reg.word;
		if (reg.switch) return `%${reg.switch}%`;
		return null;
	};
	var getNeeds = function(regs) {
		const needs = [];
		regs.forEach((reg) => {
			needs.push(getTokenNeeds(reg));
			if (reg.operator === "and" && reg.choices) reg.choices.forEach((oneSide) => {
				oneSide.forEach((r) => {
					needs.push(getTokenNeeds(r));
				});
			});
		});
		return needs.filter((str) => str);
	};
	var getWants = function(regs) {
		const wants = [];
		let count = 0;
		regs.forEach((reg) => {
			if (reg.operator === "or" && !reg.optional && !reg.negative) {
				if (reg.fastOr) Array.from(reg.fastOr).forEach((w) => {
					wants.push(w);
				});
				if (reg.choices) reg.choices.forEach((rs) => {
					rs.forEach((r) => {
						const n = getTokenNeeds(r);
						if (n) wants.push(n);
					});
				});
				count += 1;
			}
		});
		return {
			wants,
			count
		};
	};
	var parse$2 = function(matches, world) {
		const parseMatch = world.methods.one.parseMatch;
		matches.forEach((obj) => {
			obj.regs = parseMatch(obj.match, {}, world);
			if (typeof obj.ifNo === "string") obj.ifNo = [obj.ifNo];
			if (obj.notIf) obj.notIf = parseMatch(obj.notIf, {}, world);
			obj.needs = getNeeds(obj.regs);
			const { wants, count } = getWants(obj.regs);
			obj.wants = wants;
			obj.minWant = count;
			obj.minWords = obj.regs.filter((o) => !o.optional).length;
		});
		return matches;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/buildNet/index.js
	var buildNet = function(matches, world) {
		matches = parse$2(matches, world);
		const hooks = {};
		matches.forEach((obj) => {
			obj.needs.forEach((str) => {
				hooks[str] = Array.isArray(hooks[str]) ? hooks[str] : [];
				hooks[str].push(obj);
			});
			obj.wants.forEach((str) => {
				hooks[str] = Array.isArray(hooks[str]) ? hooks[str] : [];
				hooks[str].push(obj);
			});
		});
		Object.keys(hooks).forEach((k) => {
			const already = {};
			hooks[k] = hooks[k].filter((obj) => {
				if (typeof already[obj.match] === "boolean") return false;
				already[obj.match] = true;
				return true;
			});
		});
		return {
			hooks,
			always: matches.filter((o) => o.needs.length === 0 && o.wants.length === 0)
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/sweep/01-getHooks.js
	var getHooks = function(docCaches, hooks) {
		return docCaches.map((set, i) => {
			let maybe = [];
			Object.keys(hooks).forEach((k) => {
				if (docCaches[i].has(k)) maybe = maybe.concat(hooks[k]);
			});
			const already = {};
			maybe = maybe.filter((m) => {
				if (typeof already[m.match] === "boolean") return false;
				already[m.match] = true;
				return true;
			});
			return maybe;
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/sweep/02-trim-down.js
	var localTrim = function(maybeList, docCache) {
		return maybeList.map((list, n) => {
			const haves = docCache[n];
			list = list.filter((obj) => {
				return obj.needs.every((need) => haves.has(need));
			});
			list = list.filter((obj) => {
				if (obj.ifNo !== void 0 && obj.ifNo.some((no) => haves.has(no)) === true) return false;
				return true;
			});
			list = list.filter((obj) => {
				if (obj.wants.length === 0) return true;
				return obj.wants.filter((str) => haves.has(str)).length >= obj.minWant;
			});
			return list;
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/sweep/04-runMatch.js
	var runMatch = function(maybeList, document, docCache, methods, opts) {
		const results = [];
		for (let n = 0; n < maybeList.length; n += 1) for (let i = 0; i < maybeList[n].length; i += 1) {
			const m = maybeList[n][i];
			const res = methods.one.match([document[n]], m);
			if (res.ptrs.length > 0) {
				res.ptrs.forEach((ptr) => {
					ptr[0] = n;
					const todo = Object.assign({}, m, { pointer: ptr });
					if (m.unTag !== void 0) todo.unTag = m.unTag;
					results.push(todo);
				});
				if (opts.matchOne === true) return [results[0]];
			}
		}
		return results;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/sweep/index.js
	var tooSmall = function(maybeList, document) {
		return maybeList.map((arr, i) => {
			const termCount = document[i].length;
			arr = arr.filter((o) => {
				return termCount >= o.minWords;
			});
			return arr;
		});
	};
	var sweep = function(document, net, methods, opts = {}) {
		const docCache = methods.one.cacheDoc(document);
		let maybeList = getHooks(docCache, net.hooks);
		maybeList = localTrim(maybeList, docCache, document);
		if (net.always.length > 0) maybeList = maybeList.map((arr) => arr.concat(net.always));
		maybeList = tooSmall(maybeList, document);
		return runMatch(maybeList, document, docCache, methods, opts);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/tagger/canBe.js
	var canBe$1 = function(terms, tag, model) {
		const tagSet = model.one.tagSet;
		if (!tagSet.hasOwnProperty(tag)) return true;
		const not = tagSet[tag].not || [];
		for (let i = 0; i < terms.length; i += 1) {
			const term = terms[i];
			for (let k = 0; k < not.length; k += 1) if (term.tags.has(not[k]) === true) return false;
		}
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/methods/tagger/index.js
	var tagger$1 = function(list, document, world) {
		const { model, methods } = world;
		const { getDoc, setTag, unTag } = methods.one;
		const looksPlural = methods.two.looksPlural;
		if (list.length === 0) return list;
		if ((typeof process === "undefined" || !process.env ? self.env || {} : process.env).DEBUG_TAGS) console.log(`\n\n  \x1b[32m→ ${list.length} post-tagger:\x1b[0m`);
		return list.map((todo) => {
			if (!todo.tag && !todo.chunk && !todo.unTag) return;
			const reason = todo.reason || todo.match;
			const terms = getDoc([todo.pointer], document)[0];
			if (todo.safe === true) {
				if (canBe$1(terms, todo.tag, model) === false) return;
				if (terms[terms.length - 1].post === "-") return;
			}
			if (todo.tag !== void 0) {
				setTag(terms, todo.tag, world, todo.safe, `[post] '${reason}'`);
				if (todo.tag === "Noun" && looksPlural) {
					const term = terms[terms.length - 1];
					if (looksPlural(term.text)) setTag([term], "Plural", world, todo.safe, "quick-plural");
					else setTag([term], "Singular", world, todo.safe, "quick-singular");
				}
				if (todo.freeze === true) terms.forEach((term) => term.frozen = true);
			}
			if (todo.unTag !== void 0) unTag(terms, todo.unTag, world, todo.safe, reason);
			if (todo.chunk) terms.forEach((t) => t.chunk = todo.chunk);
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/sweep/plugin.js
	var plugin_default$7 = {
		lib: lib_default$2,
		api: api$3,
		methods: { one: {
			buildNet,
			bulkMatch: sweep,
			bulkTagger: tagger$1
		} }
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/setTag.js
	var isMulti = / /;
	var addChunk = function(term, tag) {
		if (tag === "Noun") term.chunk = tag;
		if (tag === "Verb") term.chunk = tag;
	};
	var tagTerm = function(term, tag, tagSet, isSafe) {
		if (term.tags.has(tag) === true) return null;
		if (tag === ".") return null;
		if (term.frozen === true) isSafe = true;
		const known = tagSet[tag];
		if (known) {
			if (known.not && known.not.length > 0) for (let o = 0; o < known.not.length; o += 1) {
				if (isSafe === true && term.tags.has(known.not[o])) return null;
				term.tags.delete(known.not[o]);
			}
			if (known.parents && known.parents.length > 0) for (let o = 0; o < known.parents.length; o += 1) {
				term.tags.add(known.parents[o]);
				addChunk(term, known.parents[o]);
			}
		}
		term.tags.add(tag);
		term.dirty = true;
		addChunk(term, tag);
		return true;
	};
	var multiTag = function(terms, tagString, tagSet, isSafe) {
		const tags = tagString.split(isMulti);
		terms.forEach((term, i) => {
			let tag = tags[i];
			if (tag) {
				tag = tag.replace(/^#/, "");
				tagTerm(term, tag, tagSet, isSafe);
			}
		});
	};
	var isArray$2 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var log$1 = (terms, tag, reason = "") => {
		const yellow = (str) => "\x1B[33m\x1B[3m" + str + "\x1B[0m";
		const i = (str) => "\x1B[3m" + str + "\x1B[0m";
		const word = terms.map((t) => {
			return t.text || "[" + t.implicit + "]";
		}).join(" ");
		if (typeof tag !== "string" && tag.length > 2) tag = tag.slice(0, 2).join(", #") + " +";
		tag = typeof tag !== "string" ? tag.join(", #") : tag;
		console.log(` ${yellow(word).padEnd(24)} \x1b[32m→\x1b[0m #${tag.padEnd(22)}  ${i(reason)}`);
	};
	var setTag = function(terms, tag, world = {}, isSafe, reason) {
		const tagSet = world.model.one.tagSet || {};
		if (!tag) return;
		const env = typeof process === "undefined" || !process.env ? self.env || {} : process.env;
		if (env && env.DEBUG_TAGS) log$1(terms, tag, reason);
		if (isArray$2(tag) === true) {
			tag.forEach((tg) => setTag(terms, tg, world, isSafe));
			return;
		}
		if (typeof tag !== "string") {
			console.warn(`compromise: Invalid tag '${tag}'`);
			return;
		}
		tag = tag.trim();
		if (isMulti.test(tag)) {
			multiTag(terms, tag, tagSet, isSafe);
			return;
		}
		tag = tag.replace(/^#/, "");
		for (let i = 0; i < terms.length; i += 1) tagTerm(terms[i], tag, tagSet, isSafe);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/unTag.js
	var unTag = function(terms, tag, tagSet) {
		tag = tag.trim().replace(/^#/, "");
		for (let i = 0; i < terms.length; i += 1) {
			const term = terms[i];
			if (term.frozen === true) continue;
			if (tag === "*") {
				term.tags.clear();
				continue;
			}
			const known = tagSet[tag];
			if (known && known.children.length > 0) for (let o = 0; o < known.children.length; o += 1) term.tags.delete(known.children[o]);
			term.tags.delete(tag);
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/canBe.js
	var canBe = function(term, tag, tagSet) {
		if (!tagSet.hasOwnProperty(tag)) return true;
		const not = tagSet[tag].not || [];
		for (let i = 0; i < not.length; i += 1) if (term.tags.has(not[i])) return false;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/grad-school@0.0.5/node_modules/grad-school/builds/grad-school.mjs
	var e = function(e) {
		return e.children = e.children || [], e._cache = e._cache || {}, e.props = e.props || {}, e._cache.parents = e._cache.parents || [], e._cache.children = e._cache.children || [], e;
	}, t = /^ *(#|\/\/)/, n$1 = function(t) {
		let n = t.trim().split(/->/), r = [];
		n.forEach(((t) => {
			r = r.concat(function(t) {
				if (!(t = t.trim())) return null;
				if (/^\[/.test(t) && /\]$/.test(t)) {
					let n = (t = (t = t.replace(/^\[/, "")).replace(/\]$/, "")).split(/,/);
					return n = n.map(((e) => e.trim())).filter(((e) => e)), n = n.map(((t) => e({ id: t }))), n;
				}
				return [e({ id: t })];
			}(t));
		})), r = r.filter(((e) => e));
		let i = r[0];
		for (let e = 1; e < r.length; e += 1) i.children.push(r[e]), i = r[e];
		return r[0];
	}, r = (e, t) => {
		let n = [], r = [e];
		for (; r.length > 0;) {
			let e = r.pop();
			n.push(e), e.children && e.children.forEach(((n) => {
				t && t(e, n), r.push(n);
			}));
		}
		return n;
	}, i = (e) => "[object Array]" === Object.prototype.toString.call(e), c = (e) => (e = e || "").trim(), s$1 = function(c = []) {
		return "string" == typeof c ? function(r) {
			let i = r.split(/\r?\n/), c = [];
			i.forEach(((e) => {
				if (!e.trim() || t.test(e)) return;
				let r = ((e) => {
					const t = /^( {2}|\t)/;
					let n = 0;
					for (; t.test(e);) e = e.replace(t, ""), n += 1;
					return n;
				})(e);
				c.push({
					indent: r,
					node: n$1(e)
				});
			}));
			let s = function(e) {
				let t = { children: [] };
				return e.forEach(((n, r) => {
					0 === n.indent ? t.children = t.children.concat(n.node) : e[r - 1] && function(e, t) {
						let n = e[t].indent;
						for (; t >= 0; t -= 1) if (e[t].indent < n) return e[t];
						return e[0];
					}(e, r).node.children.push(n.node);
				})), t;
			}(c);
			return s = e(s), s;
		}(c) : i(c) ? function(t) {
			let n = {};
			t.forEach(((e) => {
				n[e.id] = e;
			}));
			let r = e({});
			return t.forEach(((t) => {
				if ((t = e(t)).parent) if (n.hasOwnProperty(t.parent)) {
					let e = n[t.parent];
					delete t.parent, e.children.push(t);
				} else console.warn(`[Grad] - missing node '${t.parent}'`);
				else r.children.push(t);
			})), r;
		}(c) : (r(s = c).forEach(e), s);
		var s;
	}, h = (e) => "\x1B[31m" + e + "\x1B[0m", o = (e) => "\x1B[2m" + e + "\x1B[0m", l = function(e, t) {
		let n = "-> ";
		t && (n = o("→ "));
		let i = "";
		return r(e).forEach(((e, r) => {
			let c = e.id || "";
			if (t && (c = h(c)), 0 === r && !e.id) return;
			let s = e._cache.parents.length;
			i += "    ".repeat(s) + n + c + "\n";
		})), i;
	}, a = function(e) {
		let t = r(e);
		t.forEach(((e) => {
			delete (e = Object.assign({}, e)).children;
		}));
		let n = t[0];
		return n && !n.id && 0 === Object.keys(n.props).length && t.shift(), t;
	}, p$2 = {
		text: l,
		txt: l,
		array: a,
		flat: a
	}, d = function(e, t) {
		return "nested" === t || "json" === t ? e : "debug" === t ? (console.log(l(e, !0)), null) : p$2.hasOwnProperty(t) ? p$2[t](e) : e;
	}, u = (e) => {
		r(e, ((e, t) => {
			e.id && (e._cache.parents = e._cache.parents || [], t._cache.parents = e._cache.parents.concat([e.id]));
		}));
	}, f = (e, t) => (Object.keys(t).forEach(((n) => {
		if (t[n] instanceof Set) {
			let r = e[n] || /* @__PURE__ */ new Set();
			e[n] = new Set([...r, ...t[n]]);
		} else if (((e) => e && "object" == typeof e && !Array.isArray(e))(t[n])) {
			let r = e[n] || {};
			e[n] = Object.assign({}, t[n], r);
		} else i(t[n]) ? e[n] = t[n].concat(e[n] || []) : void 0 === e[n] && (e[n] = t[n]);
	})), e), j = /\//;
	var g$2 = class g$2 {
		constructor(e = {}) {
			Object.defineProperty(this, "json", {
				enumerable: !1,
				value: e,
				writable: !0
			});
		}
		get children() {
			return this.json.children;
		}
		get id() {
			return this.json.id;
		}
		get found() {
			return this.json.id || this.json.children.length > 0;
		}
		props(e = {}) {
			let t = this.json.props || {};
			return "string" == typeof e && (t[e] = !0), this.json.props = Object.assign(t, e), this;
		}
		get(t) {
			if (t = c(t), !j.test(t)) return new g$2(this.json.children.find(((e) => e.id === t)));
			return new g$2(((e, t) => {
				let n = ((e) => "string" != typeof e ? e : (e = e.replace(/^\//, "")).split(/\//))(t = t || "");
				for (let t = 0; t < n.length; t += 1) {
					let r = e.children.find(((e) => e.id === n[t]));
					if (!r) return null;
					e = r;
				}
				return e;
			})(this.json, t) || e({}));
		}
		add(t, n = {}) {
			if (i(t)) return t.forEach(((e) => this.add(c(e), n))), this;
			t = c(t);
			let r = e({
				id: t,
				props: n
			});
			return this.json.children.push(r), new g$2(r);
		}
		remove(e) {
			return e = c(e), this.json.children = this.json.children.filter(((t) => t.id !== e)), this;
		}
		nodes() {
			return r(this.json).map(((e) => (delete (e = Object.assign({}, e)).children, e)));
		}
		cache() {
			return ((e) => {
				let t = r(e, ((e, t) => {
					e.id && (e._cache.parents = e._cache.parents || [], e._cache.children = e._cache.children || [], t._cache.parents = e._cache.parents.concat([e.id]));
				})), n = {};
				t.forEach(((e) => {
					e.id && (n[e.id] = e);
				})), t.forEach(((e) => {
					e._cache.parents.forEach(((t) => {
						n.hasOwnProperty(t) && n[t]._cache.children.push(e.id);
					}));
				})), e._cache.children = Object.keys(n);
			})(this.json), this;
		}
		list() {
			return r(this.json);
		}
		fillDown() {
			var e;
			return e = this.json, r(e, ((e, t) => {
				t.props = f(t.props, e.props);
			})), this;
		}
		depth() {
			u(this.json);
			let e = r(this.json), t = e.length > 1 ? 1 : 0;
			return e.forEach(((e) => {
				if (0 === e._cache.parents.length) return;
				let n = e._cache.parents.length + 1;
				n > t && (t = n);
			})), t;
		}
		out(e) {
			return u(this.json), d(this.json, e);
		}
		debug() {
			return u(this.json), d(this.json, "debug"), this;
		}
	};
	var _ = function(e) {
		return new g$2(s$1(e));
	};
	_.prototype.plugin = function(e) {
		e(this);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/addTags/_colors.js
	var colors = {
		Noun: "blue",
		Verb: "green",
		Negative: "green",
		Date: "red",
		Value: "red",
		Adjective: "magenta",
		Preposition: "cyan",
		Conjunction: "cyan",
		Determiner: "cyan",
		Hyphenated: "cyan",
		Adverb: "cyan"
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/addTags/02-fmt.js
	var getColor = function(node) {
		if (colors.hasOwnProperty(node.id)) return colors[node.id];
		if (colors.hasOwnProperty(node.is)) return colors[node.is];
		return colors[node._cache.parents.find((c) => colors[c])];
	};
	var fmt = function(nodes) {
		const res = {};
		nodes.forEach((node) => {
			const { not, also, is, novel } = node.props;
			let parents = node._cache.parents;
			if (also) parents = parents.concat(also);
			res[node.id] = {
				is,
				not,
				novel,
				also,
				parents,
				children: node._cache.children,
				color: getColor(node)
			};
		});
		Object.keys(res).forEach((k) => {
			const nots = new Set(res[k].not);
			res[k].not.forEach((not) => {
				if (res[not]) res[not].children.forEach((tag) => nots.add(tag));
			});
			res[k].not = Array.from(nots);
		});
		return res;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/addTags/01-validate.js
	var toArr = function(input) {
		if (!input) return [];
		if (typeof input === "string") return [input];
		return input;
	};
	var addImplied = function(tags, already) {
		Object.keys(tags).forEach((k) => {
			if (tags[k].isA) tags[k].is = tags[k].isA;
			if (tags[k].notA) tags[k].not = tags[k].notA;
			if (tags[k].is && typeof tags[k].is === "string") {
				if (!already.hasOwnProperty(tags[k].is) && !tags.hasOwnProperty(tags[k].is)) tags[tags[k].is] = {};
			}
			if (tags[k].not && typeof tags[k].not === "string" && !tags.hasOwnProperty(tags[k].not)) {
				if (!already.hasOwnProperty(tags[k].not) && !tags.hasOwnProperty(tags[k].not)) tags[tags[k].not] = {};
			}
		});
		return tags;
	};
	var validate = function(tags, already) {
		tags = addImplied(tags, already);
		Object.keys(tags).forEach((k) => {
			tags[k].children = toArr(tags[k].children);
			tags[k].not = toArr(tags[k].not);
		});
		Object.keys(tags).forEach((k) => {
			(tags[k].not || []).forEach((no) => {
				if (tags[no] && tags[no].not) tags[no].not.push(k);
			});
		});
		return tags;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/addTags/index.js
	var compute = function(allTags) {
		return _(Object.keys(allTags).map((k) => {
			const o = allTags[k];
			const props = {
				not: new Set(o.not),
				also: o.also,
				is: o.is,
				novel: o.novel
			};
			return {
				id: k,
				parent: o.is,
				props,
				children: []
			};
		})).cache().fillDown().out("array");
	};
	var fromUser = function(tags) {
		Object.keys(tags).forEach((k) => {
			tags[k] = Object.assign({}, tags[k]);
			tags[k].novel = true;
		});
		return tags;
	};
	var addTags$1 = function(tags, already) {
		if (Object.keys(already).length > 0) tags = fromUser(tags);
		tags = validate(tags, already);
		return fmt(compute(Object.assign({}, already, tags)));
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/methods/index.js
	var methods_default$2 = { one: {
		setTag,
		unTag,
		addTags: addTags$1,
		canBe
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/api/tag.js
	var isArray$1 = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var fns = {
		/** add a given tag, to all these terms */
		tag: function(input, reason = "", isSafe) {
			if (!this.found || !input) return this;
			const terms = this.termList();
			if (terms.length === 0) return this;
			const { methods, verbose, world } = this;
			if (verbose === true) console.log(" +  ", input, reason || "");
			if (isArray$1(input)) input.forEach((tag) => methods.one.setTag(terms, tag, world, isSafe, reason));
			else methods.one.setTag(terms, input, world, isSafe, reason);
			this.uncache();
			return this;
		},
		/** add a given tag, only if it is consistent */
		tagSafe: function(input, reason = "") {
			return this.tag(input, reason, true);
		},
		/** remove a given tag from all these terms */
		unTag: function(input, reason) {
			if (!this.found || !input) return this;
			const terms = this.termList();
			if (terms.length === 0) return this;
			const { methods, verbose, model } = this;
			if (verbose === true) console.log(" -  ", input, reason || "");
			const tagSet = model.one.tagSet;
			if (isArray$1(input)) input.forEach((tag) => methods.one.unTag(terms, tag, tagSet));
			else methods.one.unTag(terms, input, tagSet);
			this.uncache();
			return this;
		},
		/** return only the terms that can be this tag  */
		canBe: function(tag) {
			tag = tag.replace(/^#/, "");
			const tagSet = this.model.one.tagSet;
			const canBe = this.methods.one.canBe;
			const nope = [];
			this.document.forEach((terms, n) => {
				terms.forEach((term, i) => {
					if (!canBe(term, tag, tagSet)) nope.push([
						n,
						i,
						i + 1
					]);
				});
			});
			const noDoc = this.update(nope);
			return this.difference(noDoc);
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/api/index.js
	var tagAPI = function(View) {
		Object.assign(View.prototype, fns);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/lib.js
	var addTags = function(tags) {
		const { model, methods } = this.world();
		const tagSet = model.one.tagSet;
		const fn = methods.one.addTags;
		const res = fn(tags, tagSet);
		model.one.tagSet = res;
		return this;
	};
	var lib_default$1 = { addTags };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/compute/tagRank.js
	var boringTags = new Set(["Auxiliary", "Possessive"]);
	var sortByKids = function(tags, tagSet) {
		tags = tags.sort((a, b) => {
			if (boringTags.has(a) || !tagSet.hasOwnProperty(b)) return 1;
			if (boringTags.has(b) || !tagSet.hasOwnProperty(a)) return -1;
			let kids = tagSet[a].children || [];
			const aKids = kids.length;
			kids = tagSet[b].children || [];
			return aKids - kids.length;
		});
		return tags;
	};
	var tagRank = function(view) {
		const { document, world } = view;
		const tagSet = world.model.one.tagSet;
		document.forEach((terms) => {
			terms.forEach((term) => {
				term.tagRank = sortByKids(Array.from(term.tags), tagSet);
			});
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tag/plugin.js
	var plugin_default$6 = {
		model: { one: { tagSet: {} } },
		compute: { tagRank },
		methods: methods_default$2,
		api: tagAPI,
		lib: lib_default$1
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/01-simple-split.js
	var initSplit = /([.!?\u203D\u2E18\u203C\u2047-\u2049\u3002]+\s)/g;
	var splitsOnly = /^[.!?\u203D\u2E18\u203C\u2047-\u2049\u3002]+\s$/;
	var newLine = /((?:\r?\n|\r)+)/;
	var basicSplit = function(text) {
		const all = [];
		const lines = text.split(newLine);
		for (let i = 0; i < lines.length; i++) {
			const arr = lines[i].split(initSplit);
			for (let o = 0; o < arr.length; o++) {
				if (arr[o + 1] && splitsOnly.test(arr[o + 1]) === true) {
					arr[o] += arr[o + 1];
					arr[o + 1] = "";
				}
				if (arr[o] !== "") all.push(arr[o]);
			}
		}
		return all;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/02-simple-merge.js
	var hasLetter$1 = /[a-z0-9\u00C0-\u00FF\u00a9\u00ae\u2000-\u3300\ud000-\udfff]/i;
	var hasSomething$1 = /\S/;
	var notEmpty = function(splits) {
		const chunks = [];
		for (let i = 0; i < splits.length; i++) {
			const s = splits[i];
			if (s === void 0 || s === "") continue;
			if (hasSomething$1.test(s) === false || hasLetter$1.test(s) === false) {
				if (chunks[chunks.length - 1]) {
					chunks[chunks.length - 1] += s;
					continue;
				} else if (splits[i + 1]) {
					splits[i + 1] = s + splits[i + 1];
					continue;
				}
			}
			chunks.push(s);
		}
		return chunks;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/03-smart-merge.js
	var hasNewline = function(c) {
		return Boolean(c.match(/\n$/));
	};
	var smartMerge = function(chunks, world) {
		const isSentence = world.methods.one.tokenize.isSentence;
		const abbrevs = world.model.one.abbreviations || /* @__PURE__ */ new Set();
		const sentences = [];
		for (let i = 0; i < chunks.length; i++) {
			const c = chunks[i];
			if (chunks[i + 1] && !isSentence(c, abbrevs) && !hasNewline(c)) chunks[i + 1] = c + (chunks[i + 1] || "");
			else if (c && c.length > 0) {
				sentences.push(c);
				chunks[i] = "";
			}
		}
		return sentences;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/04-quote-merge.js
	var MAX_QUOTE = 280;
	var pairs = {
		"\"": "\"",
		"＂": "＂",
		"“": "”",
		"‟": "”",
		"„": "”",
		"⹂": "”",
		"‚": "’",
		"«": "»",
		"‹": "›",
		"‵": "′",
		"‶": "″",
		"‷": "‴",
		"〝": "〞",
		"〟": "〞"
	};
	var openQuote = RegExp("[" + Object.keys(pairs).join("") + "]", "g");
	var closeQuote = RegExp("[" + Object.values(pairs).join("") + "]", "g");
	var closesQuote = function(str) {
		if (!str) return false;
		const m = str.match(closeQuote);
		if (m !== null && m.length === 1) return true;
		return false;
	};
	var quoteMerge = function(splits) {
		const arr = [];
		for (let i = 0; i < splits.length; i += 1) {
			const m = splits[i].match(openQuote);
			if (m !== null && m.length === 1) {
				if (closesQuote(splits[i + 1]) && splits[i + 1].length < MAX_QUOTE) {
					splits[i] += splits[i + 1];
					arr.push(splits[i]);
					splits[i + 1] = "";
					i += 1;
					continue;
				}
				if (closesQuote(splits[i + 2])) {
					const toAdd = splits[i + 1] + splits[i + 2];
					if (toAdd.length < MAX_QUOTE) {
						splits[i] += toAdd;
						arr.push(splits[i]);
						splits[i + 1] = "";
						splits[i + 2] = "";
						i += 2;
						continue;
					}
				}
			}
			arr.push(splits[i]);
		}
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/05-parens-merge.js
	var MAX_LEN = 250;
	var hasOpen = /\(/g;
	var hasClosed = /\)/g;
	var mergeParens = function(splits) {
		const arr = [];
		for (let i = 0; i < splits.length; i += 1) {
			const m = splits[i].match(hasOpen);
			if (m !== null && m.length === 1) {
				if (splits[i + 1] && splits[i + 1].length < MAX_LEN) {
					if (splits[i + 1].match(hasClosed) !== null && m.length === 1 && !hasOpen.test(splits[i + 1])) {
						splits[i] += splits[i + 1];
						arr.push(splits[i]);
						splits[i + 1] = "";
						i += 1;
						continue;
					}
				}
			}
			arr.push(splits[i]);
		}
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/index.js
	var hasSomething = /\S/;
	var startWhitespace = /^\s+/;
	var splitSentences = function(text, world) {
		text = text || "";
		text = String(text);
		if (!text || typeof text !== "string" || hasSomething.test(text) === false) return [];
		text = text.replace("\xA0", " ");
		let sentences = notEmpty(basicSplit(text));
		sentences = smartMerge(sentences, world);
		sentences = quoteMerge(sentences);
		sentences = mergeParens(sentences);
		if (sentences.length === 0) return [text];
		for (let i = 1; i < sentences.length; i += 1) {
			const ws = sentences[i].match(startWhitespace);
			if (ws !== null) {
				sentences[i - 1] += ws[0];
				sentences[i] = sentences[i].replace(startWhitespace, "");
			}
		}
		return sentences;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/02-terms/01-hyphens.js
	var hasHyphen = function(str, model) {
		const parts = str.split(/[-–—]/);
		if (parts.length <= 1) return false;
		const { prefixes, suffixes } = model.one;
		if (parts[0].length === 1 && /[a-z]/i.test(parts[0])) return false;
		if (prefixes.hasOwnProperty(parts[0])) return false;
		parts[1] = parts[1].trim().replace(/[.?!]$/, "");
		if (suffixes.hasOwnProperty(parts[1])) return false;
		if (/^([a-z\u00C0-\u00FF`"'/]+)[-–—]([a-z0-9\u00C0-\u00FF].*)/i.test(str) === true) return true;
		if (/^[('"]?([0-9]{1,4})[-–—]([a-z\u00C0-\u00FF`"'/-]+[)'"]?$)/i.test(str) === true) return true;
		return false;
	};
	var splitHyphens = function(word) {
		const arr = [];
		const hyphens = word.split(/[-–—]/);
		let whichDash = "-";
		const found = word.match(/[-–—]/);
		if (found && found[0]) whichDash = found;
		for (let o = 0; o < hyphens.length; o++) if (o === hyphens.length - 1) arr.push(hyphens[o]);
		else arr.push(hyphens[o] + whichDash);
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/02-terms/03-ranges.js
	var combineRanges = function(arr) {
		const startRange = /^[0-9]{1,4}(:[0-9][0-9])?([a-z]{1,2})? ?[-–—] ?$/;
		const endRange = /^[0-9]{1,4}([a-z]{1,2})? ?$/;
		for (let i = 0; i < arr.length - 1; i += 1) if (arr[i + 1] && startRange.test(arr[i]) && endRange.test(arr[i + 1])) {
			arr[i] = arr[i] + arr[i + 1];
			arr[i + 1] = null;
		}
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/02-terms/02-slashes.js
	var isSlash = /\p{L} ?\/ ?\p{L}+$/u;
	var combineSlashes = function(arr) {
		for (let i = 1; i < arr.length - 1; i++) if (isSlash.test(arr[i])) {
			arr[i - 1] += arr[i] + arr[i + 1];
			arr[i] = null;
			arr[i + 1] = null;
		}
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/02-terms/index.js
	var wordlike = /\S/;
	var isBoundary = /^[!?.]+$/;
	var naiiveSplit = /(\S+)/;
	var notWord = [
		".",
		"?",
		"!",
		":",
		";",
		"-",
		"–",
		"—",
		"--",
		"...",
		"(",
		")",
		"[",
		"]",
		"\"",
		"'",
		"`",
		"«",
		"»",
		"*",
		"•"
	];
	notWord = notWord.reduce((h, c) => {
		h[c] = true;
		return h;
	}, {});
	var isArray = function(arr) {
		return Object.prototype.toString.call(arr) === "[object Array]";
	};
	var splitWords = function(str, model) {
		let result = [];
		let arr = [];
		str = str || "";
		if (typeof str === "number") str = String(str);
		if (isArray(str)) return str;
		const words = str.split(naiiveSplit);
		for (let i = 0; i < words.length; i++) {
			if (hasHyphen(words[i], model) === true) {
				arr = arr.concat(splitHyphens(words[i]));
				continue;
			}
			arr.push(words[i]);
		}
		let carry = "";
		for (let i = 0; i < arr.length; i++) {
			const word = arr[i];
			if (wordlike.test(word) === true && notWord.hasOwnProperty(word) === false && isBoundary.test(word) === false) {
				if (result.length > 0) {
					result[result.length - 1] += carry;
					result.push(word);
				} else result.push(carry + word);
				carry = "";
			} else carry += word;
		}
		if (carry) {
			if (result.length === 0) result[0] = "";
			result[result.length - 1] += carry;
		}
		result = combineSlashes(result);
		result = combineRanges(result);
		result = result.filter((s) => s);
		return result;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/03-whitespace/tokenize.js
	var isLetter = /\p{Letter}/u;
	var isNumber = /[\p{Number}\p{Currency_Symbol}]/u;
	var hasAcronym = /^[a-z]\.([a-z]\.)+/i;
	var chillin = /[sn]['’]$/;
	var normalizePunctuation = function(str, model) {
		const { prePunctuation, postPunctuation, emoticons } = model.one;
		let original = str;
		let pre = "";
		let post = "";
		const chars = Array.from(str);
		if (emoticons.hasOwnProperty(str.trim())) return {
			str: str.trim(),
			pre,
			post: " "
		};
		let len = chars.length;
		for (let i = 0; i < len; i += 1) {
			const c = chars[0];
			if (prePunctuation[c] === true) continue;
			if ((c === "+" || c === "-") && isNumber.test(chars[1])) break;
			if (c === "'" && c.length === 3 && isNumber.test(chars[1])) break;
			if (isLetter.test(c) || isNumber.test(c)) break;
			pre += chars.shift();
		}
		len = chars.length;
		for (let i = 0; i < len; i += 1) {
			const c = chars[chars.length - 1];
			if (postPunctuation[c] === true) continue;
			if (isLetter.test(c) || isNumber.test(c)) break;
			if (c === "." && hasAcronym.test(original) === true) continue;
			if (c === "'" && chillin.test(original) === true) continue;
			post = chars.pop() + post;
		}
		str = chars.join("");
		if (str === "") {
			original = original.replace(/ *$/, (after) => {
				post = after || "";
				return "";
			});
			str = original;
			pre = "";
		}
		return {
			str,
			pre,
			post
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/03-whitespace/index.js
	var parseTerm = (txt, model) => {
		const { str, pre, post } = normalizePunctuation(txt, model);
		return {
			text: str,
			pre,
			post,
			tags: /* @__PURE__ */ new Set()
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/unicode.js
	var killUnicode = function(str, world) {
		const unicode = world.model.one.unicode || {};
		str = str || "";
		const chars = str.split("");
		chars.forEach((s, i) => {
			if (unicode[s]) chars[i] = unicode[s];
		});
		return chars.join("");
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/normal/01-cleanup.js
	/** some basic operations on a string to reduce noise */
	var clean = function(str) {
		str = str || "";
		str = str.toLowerCase();
		str = str.trim();
		const original = str;
		str = str.replace(/[,;.!?]+$/, "");
		str = str.replace(/\u2026/g, "...");
		str = str.replace(/\u2013/g, "-");
		if (/^[:;]/.test(str) === false) {
			str = str.replace(/\.{3,}$/g, "");
			str = str.replace(/[",.!:;?)]+$/g, "");
			str = str.replace(/^['"(]+/g, "");
		}
		str = str.replace(/[\u200B-\u200D\uFEFF]/g, "");
		str = str.trim();
		if (str === "") str = original;
		str = str.replace(/([0-9]),([0-9])/g, "$1$2");
		return str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/normal/02-acronyms.js
	var periodAcronym$1 = /([A-Z]\.)+[A-Z]?,?$/;
	var oneLetterAcronym$1 = /^[A-Z]\.,?$/;
	var noPeriodAcronym$1 = /[A-Z]{2,}('s|,)?$/;
	var lowerCaseAcronym$1 = /([a-z]\.)+[a-z]\.?$/;
	var isAcronym$2 = function(str) {
		if (periodAcronym$1.test(str) === true) return true;
		if (lowerCaseAcronym$1.test(str) === true) return true;
		if (oneLetterAcronym$1.test(str) === true) return true;
		if (noPeriodAcronym$1.test(str) === true) return true;
		return false;
	};
	var doAcronym = function(str) {
		if (isAcronym$2(str)) str = str.replace(/\./g, "");
		return str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/normal/index.js
	var normalize = function(term, world) {
		const killUnicode = world.methods.one.killUnicode;
		let str = term.text || "";
		str = clean(str);
		str = killUnicode(str, world);
		str = doAcronym(str);
		term.normal = str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/parse.js
	var parse$1 = function(input, world) {
		const { methods, model } = world;
		const { splitSentences, splitTerms, splitWhitespace } = methods.one.tokenize;
		input = input || "";
		input = splitSentences(input, world).map((txt) => {
			let terms = splitTerms(txt, model);
			terms = terms.map((t) => splitWhitespace(t, model));
			terms.forEach((t) => {
				normalize(t, world);
			});
			return terms;
		});
		return input;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/01-sentences/is-sentence.js
	var isAcronym$1 = /[ .][A-Z]\.? *$/i;
	var hasEllipse = /(?:\u2026|\.{2,}) *$/;
	var hasLetter = /\p{L}/u;
	var hasPeriod = /\. *$/;
	var leadInit = /^[A-Z]\. $/;
	/** does this look like a sentence? */
	var isSentence = function(str, abbrevs) {
		if (hasLetter.test(str) === false) return false;
		if (isAcronym$1.test(str) === true) return false;
		if (str.length === 3 && leadInit.test(str)) return false;
		if (hasEllipse.test(str) === true) return false;
		const words = str.replace(/[.!?\u203D\u2E18\u203C\u2047-\u2049] *$/, "").split(" ");
		const lastWord = words[words.length - 1].toLowerCase();
		if (abbrevs.hasOwnProperty(lastWord) === true && hasPeriod.test(str) === true) return false;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/methods/index.js
	var methods_default$1 = { one: {
		killUnicode,
		tokenize: {
			splitSentences,
			isSentence,
			splitTerms: splitWords,
			splitWhitespace: parseTerm,
			fromString: parse$1
		}
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/aliases.js
	var aliases = {
		"&": "and",
		"@": "at",
		"%": "percent",
		"plz": "please",
		"bein": "being"
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/lexicon.js
	var list = [
		[[
			"approx",
			"apt",
			"bc",
			"cyn",
			"eg",
			"esp",
			"est",
			"etc",
			"ex",
			"exp",
			"prob",
			"pron",
			"gal",
			"min",
			"pseud",
			"fig",
			"jd",
			"lat",
			"lng",
			"vol",
			"fm",
			"def",
			"misc",
			"plz",
			"ea",
			"ps",
			"sec",
			"pt",
			"pref",
			"pl",
			"pp",
			"qt",
			"fr",
			"sq",
			"nee",
			"ss",
			"tel",
			"temp",
			"vet",
			"ver",
			"fem",
			"masc",
			"eng",
			"adj",
			"vb",
			"rb",
			"inf",
			"situ",
			"vivo",
			"vitro",
			"wr"
		]],
		[[
			"dl",
			"ml",
			"gal",
			"qt",
			"pt",
			"tbl",
			"tsp",
			"tbsp",
			"km",
			"dm",
			"cm",
			"mm",
			"mi",
			"td",
			"hr",
			"hrs",
			"kg",
			"hg",
			"dg",
			"cg",
			"mg",
			"µg",
			"lb",
			"oz",
			"sq ft",
			"hz",
			"mps",
			"mph",
			"kmph",
			"kb",
			"mb",
			"tb",
			"lx",
			"lm",
			"fl oz",
			"yb"
		], "Unit"],
		[[
			"ad",
			"al",
			"arc",
			"ba",
			"bl",
			"ca",
			"cca",
			"col",
			"corp",
			"ft",
			"fy",
			"ie",
			"lit",
			"ma",
			"md",
			"pd",
			"tce"
		], "Noun"],
		[[
			"adj",
			"adm",
			"adv",
			"asst",
			"atty",
			"bldg",
			"brig",
			"capt",
			"cmdr",
			"comdr",
			"cpl",
			"det",
			"dr",
			"esq",
			"gen",
			"gov",
			"hon",
			"jr",
			"llb",
			"lt",
			"maj",
			"messrs",
			"mlle",
			"mme",
			"mr",
			"mrs",
			"ms",
			"mstr",
			"phd",
			"prof",
			"pvt",
			"rep",
			"reps",
			"res",
			"rev",
			"sen",
			"sens",
			"sfc",
			"sgt",
			"sir",
			"sr",
			"supt",
			"surg"
		], "Honorific"],
		[[
			"jan",
			"feb",
			"mar",
			"apr",
			"jun",
			"jul",
			"aug",
			"sep",
			"sept",
			"oct",
			"nov",
			"dec"
		], "Month"],
		[[
			"dept",
			"univ",
			"assn",
			"bros",
			"inc",
			"ltd",
			"co"
		], "Organization"],
		[[
			"rd",
			"st",
			"dist",
			"mt",
			"ave",
			"blvd",
			"cl",
			"cres",
			"hwy",
			"ariz",
			"cal",
			"calif",
			"colo",
			"conn",
			"fla",
			"fl",
			"ga",
			"ida",
			"ia",
			"kan",
			"kans",
			"minn",
			"neb",
			"nebr",
			"okla",
			"penna",
			"penn",
			"pa",
			"dak",
			"tenn",
			"tex",
			"ut",
			"vt",
			"va",
			"wis",
			"wisc",
			"wy",
			"wyo",
			"usafa",
			"alta",
			"ont",
			"que",
			"sask"
		], "Place"]
	];
	var abbreviations = {};
	var lexicon$1 = {};
	list.forEach((a) => {
		a[0].forEach((w) => {
			abbreviations[w] = true;
			lexicon$1[w] = "Abbreviation";
			if (a[1] !== void 0) lexicon$1[w] = [lexicon$1[w], a[1]];
		});
	});
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/prefixes.js
	var prefixes_default$1 = [
		"anti",
		"bi",
		"co",
		"contra",
		"de",
		"extra",
		"infra",
		"inter",
		"intra",
		"macro",
		"micro",
		"mis",
		"mono",
		"multi",
		"peri",
		"pre",
		"pro",
		"proto",
		"pseudo",
		"re",
		"sub",
		"supra",
		"trans",
		"tri",
		"un",
		"out",
		"ex"
	].reduce((h, str) => {
		h[str] = true;
		return h;
	}, {});
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/suffixes.js
	var suffixes_default$1 = {
		"like": true,
		"ish": true,
		"less": true,
		"able": true,
		"elect": true,
		"type": true,
		"designate": true
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/unicode.js
	var compact = {
		"!": "¡",
		"?": "¿Ɂ",
		"\"": "“”\"❝❞",
		"'": "‘‛❛❜’",
		"-": "—–",
		a: "ªÀÁÂÃÄÅàáâãäåĀāĂăĄąǍǎǞǟǠǡǺǻȀȁȂȃȦȧȺΆΑΔΛάαλАаѦѧӐӑӒӓƛæ",
		b: "ßþƀƁƂƃƄƅɃΒβϐϦБВЪЬвъьѢѣҌҍ",
		c: "¢©ÇçĆćĈĉĊċČčƆƇƈȻȼͻͼϲϹϽϾСсєҀҁҪҫ",
		d: "ÐĎďĐđƉƊȡƋƌ",
		e: "ÈÉÊËèéêëĒēĔĕĖėĘęĚěƐȄȅȆȇȨȩɆɇΈΕΞΣέεξϵЀЁЕеѐёҼҽҾҿӖӗễ",
		f: "ƑƒϜϝӺӻҒғſ",
		g: "ĜĝĞğĠġĢģƓǤǥǦǧǴǵ",
		h: "ĤĥĦħƕǶȞȟΉΗЂЊЋНнђћҢңҤҥҺһӉӊ",
		I: "ÌÍÎÏ",
		i: "ìíîïĨĩĪīĬĭĮįİıƖƗȈȉȊȋΊΐΪίιϊІЇіїi̇",
		j: "ĴĵǰȷɈɉϳЈј",
		k: "ĶķĸƘƙǨǩΚκЌЖКжкќҚқҜҝҞҟҠҡ",
		l: "ĹĺĻļĽľĿŀŁłƚƪǀǏǐȴȽΙӀӏ",
		m: "ΜϺϻМмӍӎ",
		n: "ÑñŃńŅņŇňŉŊŋƝƞǸǹȠȵΝΠήηϞЍИЙЛПийлпѝҊҋӅӆӢӣӤӥπ",
		o: "ÒÓÔÕÖØðòóôõöøŌōŎŏŐőƟƠơǑǒǪǫǬǭǾǿȌȍȎȏȪȫȬȭȮȯȰȱΌΘΟθοσόϕϘϙϬϴОФоѲѳӦӧӨөӪӫ",
		p: "ƤΡρϷϸϼРрҎҏÞ",
		q: "Ɋɋ",
		r: "ŔŕŖŗŘřƦȐȑȒȓɌɍЃГЯгяѓҐґ",
		s: "ŚśŜŝŞşŠšƧƨȘșȿЅѕ",
		t: "ŢţŤťŦŧƫƬƭƮȚțȶȾΓΤτϮТт",
		u: "ÙÚÛÜùúûüŨũŪūŬŭŮůŰűŲųƯưƱƲǓǔǕǖǗǘǙǚǛǜȔȕȖȗɄΰυϋύ",
		v: "νѴѵѶѷ",
		w: "ŴŵƜωώϖϢϣШЩшщѡѿ",
		x: "×ΧχϗϰХхҲҳӼӽӾӿ",
		y: "ÝýÿŶŷŸƳƴȲȳɎɏΎΥΫγψϒϓϔЎУучўѰѱҮүҰұӮӯӰӱӲӳ",
		z: "ŹźŻżŽžƵƶȤȥɀΖ"
	};
	var unicode = {};
	Object.keys(compact).forEach(function(k) {
		compact[k].split("").forEach(function(s) {
			unicode[s] = k;
		});
	});
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/model/index.js
	var model_default$2 = { one: {
		aliases,
		abbreviations,
		prefixes: prefixes_default$1,
		suffixes: suffixes_default$1,
		prePunctuation: {
			"#": true,
			"@": true,
			"_": true,
			"°": true,
			"​": true,
			"‌": true,
			"‍": true,
			"﻿": true
		},
		postPunctuation: {
			"%": true,
			"_": true,
			"°": true,
			"​": true,
			"‌": true,
			"‍": true,
			"﻿": true
		},
		lexicon: lexicon$1,
		unicode,
		emoticons: {
			"<3": true,
			"</3": true,
			"<\\3": true,
			":^P": true,
			":^p": true,
			":^O": true,
			":^3": true
		}
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/alias.js
	var hasSlash = /\//;
	var hasDomain = /[a-z]\.[a-z]/i;
	var isMath = /[0-9]/;
	var addAliases = function(term, world) {
		const str = term.normal || term.text || term.machine;
		const aliases = world.model.one.aliases;
		if (aliases.hasOwnProperty(str)) {
			term.alias = term.alias || [];
			term.alias.push(aliases[str]);
		}
		if (hasSlash.test(str) && !hasDomain.test(str) && !isMath.test(str)) {
			const arr = str.split(hasSlash);
			if (arr.length <= 3) arr.forEach((word) => {
				word = word.trim();
				if (word !== "") {
					term.alias = term.alias || [];
					term.alias.push(word);
				}
			});
		}
		return term;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/machine.js
	var hasDash = /^\p{Letter}+-\p{Letter}+$/u;
	var doMachine = function(term) {
		let str = term.implicit || term.normal || term.text;
		str = str.replace(/['’]s$/, "");
		str = str.replace(/s['’]$/, "s");
		str = str.replace(/([aeiou][ktrp])in'$/, "$1ing");
		if (hasDash.test(str)) str = str.replace(/-/g, "");
		str = str.replace(/^[#@]/, "");
		if (str !== term.normal) term.machine = str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/freq.js
	var freq = function(view) {
		const docs = view.docs;
		const counts = {};
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) {
			const term = docs[i][t];
			const word = term.machine || term.normal;
			counts[word] = counts[word] || 0;
			counts[word] += 1;
		}
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) {
			const term = docs[i][t];
			term.freq = counts[term.machine || term.normal];
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/offset.js
	var offset = function(view) {
		let elapsed = 0;
		let index = 0;
		const docs = view.document;
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) {
			const term = docs[i][t];
			term.offset = {
				index,
				start: elapsed + term.pre.length,
				length: term.text.length
			};
			elapsed += term.pre.length + term.text.length + term.post.length;
			index += 1;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/reindex.js
	var index = function(view) {
		const document = view.document;
		for (let n = 0; n < document.length; n += 1) for (let i = 0; i < document[n].length; i += 1) document[n][i].index = [n, i];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/wordCount.js
	var wordCount = function(view) {
		let n = 0;
		const docs = view.docs;
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) {
			if (docs[i][t].normal === "") continue;
			n += 1;
			docs[i][t].wordCount = n;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/compute/index.js
	var termLoop = function(view, fn) {
		const docs = view.docs;
		for (let i = 0; i < docs.length; i += 1) for (let t = 0; t < docs[i].length; t += 1) fn(docs[i][t], view.world);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/tokenize/plugin.js
	var plugin_default$5 = {
		compute: {
			alias: (view) => termLoop(view, addAliases),
			machine: (view) => termLoop(view, doMachine),
			normal: (view) => termLoop(view, normalize),
			freq,
			offset,
			index,
			wordCount
		},
		methods: methods_default$1,
		model: model_default$2,
		hooks: [
			"alias",
			"machine",
			"index",
			"id"
		]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/typeahead/compute.js
	var typeahead = function(view) {
		const prefixes = view.model.one.typeahead;
		const docs = view.docs;
		if (docs.length === 0 || Object.keys(prefixes).length === 0) return;
		const lastPhrase = docs[docs.length - 1] || [];
		const lastTerm = lastPhrase[lastPhrase.length - 1];
		if (lastTerm.post) return;
		if (prefixes.hasOwnProperty(lastTerm.normal)) {
			const found = prefixes[lastTerm.normal];
			lastTerm.implicit = found;
			lastTerm.machine = found;
			lastTerm.typeahead = true;
			if (view.compute.preTagger) view.last().unTag("*").compute(["lexicon", "preTagger"]);
		}
	};
	var compute_default$3 = { typeahead };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/typeahead/api.js
	var autoFill = function() {
		const docs = this.docs;
		if (docs.length === 0) return this;
		const lastPhrase = docs[docs.length - 1] || [];
		const term = lastPhrase[lastPhrase.length - 1];
		if (term.typeahead === true && term.machine) {
			term.text = term.machine;
			term.normal = term.machine;
		}
		return this;
	};
	var api$2 = function(View) {
		View.prototype.autoFill = autoFill;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/typeahead/lib/allPrefixes.js
	var getPrefixes = function(arr, opts, world) {
		let index = {};
		const collisions = [];
		const existing = world.prefixes || {};
		arr.forEach((str) => {
			str = str.toLowerCase().trim();
			let max = str.length;
			if (opts.max && max > opts.max) max = opts.max;
			for (let size = opts.min; size < max; size += 1) {
				const prefix = str.substring(0, size);
				if (opts.safe && world.model.one.lexicon.hasOwnProperty(prefix)) continue;
				if (existing.hasOwnProperty(prefix) === true) {
					collisions.push(prefix);
					continue;
				}
				if (index.hasOwnProperty(prefix) === true) {
					collisions.push(prefix);
					continue;
				}
				index[prefix] = str;
			}
		});
		index = Object.assign({}, existing, index);
		collisions.forEach((str) => {
			delete index[str];
		});
		return index;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/1-one/typeahead/lib/index.js
	var isObject = (val) => {
		return Object.prototype.toString.call(val) === "[object Object]";
	};
	var defaults = {
		safe: true,
		min: 3
	};
	var prepare = function(words = [], opts = {}) {
		const model = this.model();
		opts = Object.assign({}, defaults, opts);
		if (isObject(words)) {
			Object.assign(model.one.lexicon, words);
			words = Object.keys(words);
		}
		const prefixes = getPrefixes(words, opts, this.world());
		Object.keys(prefixes).forEach((str) => {
			if (model.one.typeahead.hasOwnProperty(str)) {
				delete model.one.typeahead[str];
				return;
			}
			model.one.typeahead[str] = prefixes[str];
		});
		return this;
	};
	var plugin_default$4 = {
		model: { one: { typeahead: {} } },
		api: api$2,
		lib: { typeahead: prepare },
		compute: compute_default$3,
		hooks: ["typeahead"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/one.js
	nlp.extend(plugin_default$14);
	nlp.extend(plugin_default$9);
	nlp.extend(plugin_default$10);
	nlp.extend(plugin_default$8);
	nlp.extend(plugin_default$6);
	nlp.plugin(plugin$1);
	nlp.extend(plugin_default$5);
	nlp.extend(plugin_default$13);
	nlp.plugin(plugin_default$15);
	nlp.extend(plugin_default$11);
	nlp.extend(plugin_default$4);
	nlp.extend(plugin_default$12);
	nlp.extend(plugin_default$7);
	var one_default = nlp;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/irregulars/plurals.js
	var plurals_default = {
		addendum: "addenda",
		corpus: "corpora",
		criterion: "criteria",
		curriculum: "curricula",
		genus: "genera",
		memorandum: "memoranda",
		opus: "opera",
		ovum: "ova",
		phenomenon: "phenomena",
		referendum: "referenda",
		alga: "algae",
		alumna: "alumnae",
		antenna: "antennae",
		formula: "formulae",
		larva: "larvae",
		nebula: "nebulae",
		vertebra: "vertebrae",
		analysis: "analyses",
		axis: "axes",
		diagnosis: "diagnoses",
		parenthesis: "parentheses",
		prognosis: "prognoses",
		synopsis: "synopses",
		thesis: "theses",
		neurosis: "neuroses",
		appendix: "appendices",
		index: "indices",
		matrix: "matrices",
		ox: "oxen",
		sex: "sexes",
		alumnus: "alumni",
		bacillus: "bacilli",
		cactus: "cacti",
		fungus: "fungi",
		hippopotamus: "hippopotami",
		libretto: "libretti",
		modulus: "moduli",
		nucleus: "nuclei",
		octopus: "octopi",
		radius: "radii",
		stimulus: "stimuli",
		syllabus: "syllabi",
		cookie: "cookies",
		calorie: "calories",
		auntie: "aunties",
		movie: "movies",
		pie: "pies",
		rookie: "rookies",
		tie: "ties",
		zombie: "zombies",
		leaf: "leaves",
		loaf: "loaves",
		thief: "thieves",
		foot: "feet",
		goose: "geese",
		tooth: "teeth",
		beau: "beaux",
		chateau: "chateaux",
		tableau: "tableaux",
		bus: "buses",
		gas: "gases",
		circus: "circuses",
		crisis: "crises",
		virus: "viruses",
		database: "databases",
		excuse: "excuses",
		abuse: "abuses",
		avocado: "avocados",
		barracks: "barracks",
		child: "children",
		clothes: "clothes",
		echo: "echoes",
		embargo: "embargoes",
		epoch: "epochs",
		deer: "deer",
		halo: "halos",
		man: "men",
		woman: "women",
		mosquito: "mosquitoes",
		mouse: "mice",
		person: "people",
		quiz: "quizzes",
		rodeo: "rodeos",
		shoe: "shoes",
		sombrero: "sombreros",
		stomach: "stomachs",
		tornado: "tornados",
		tuxedo: "tuxedos",
		volcano: "volcanoes"
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/lexicon/_data.js
	var _data_default$1 = {
		"Comparative": "true¦bett1f0;arth0ew0in0;er",
		"Superlative": "true¦earlier",
		"PresentTense": "true¦bests,sounds",
		"Condition": "true¦lest,unless",
		"PastTense": "true¦began,came,d4had,kneel3l2m0sa4we1;ea0sg2;nt;eap0i0;ed;id",
		"Participle": "true¦0:09;a06b01cZdXeat0fSgQhPoJprov0rHs7t6u4w1;ak0ithdra02o2r1;i02uY;k0v0;nd1pr04;ergoJoJ;ak0hHo3;e9h7lain,o6p5t4un3w1;o1um;rn;g,k;ol0reS;iQok0;ught,wn;ak0o1runk;ne,wn;en,wn;ewriNi1uJ;dd0s0;ut3ver1;do4se0t1;ak0h2;do2g1;roG;ne;ast0i7;iv0o1;ne,tt0;all0loBor1;bi3g2s1;ak0e0;iv0o9;dd0;ove,r1;a5eamt,iv0;hos0lu1;ng;e4i3lo2ui1;lt;wn;tt0;at0en,gun;r2w1;ak0ok0;is0;en",
		"Gerund": "true¦accord0be0doin,go0result0stain0;ing",
		"Expression": "true¦a0Yb0Uc0Sd0Oe0Mfarew0Lg0FhZjeez,lWmVnToOpLsJtIuFvEw7y0;a5e3i1u0;ck,p;k04p0;ee,pee;a0p,s;!h;!a,h,y;a5h2o1t0;af,f;rd up,w;atsoever,e1o0;a,ops;e,w;hoo,t;ery w06oi0L;gh,h0;! 0h,m;huh,oh;here nPsk,ut tut;h0ic;eesh,hh,it,oo;ff,h1l0ow,sst;ease,s,z;ew,ooey;h1i,mg,o0uch,w,y;h,o,ps;! 0h;hTmy go0wT;d,sh;a7evertheless,o0;!pe;eh,mm;ah,eh,m1ol0;!s;ao,fao;aCeBi9o2u0;h,mph,rra0zzC;h,y;l1o0;r6y9;la,y0;! 0;c1moCsmok0;es;ow;!p hip hoor0;ay;ck,e,llo,y;ha1i,lleluj0;ah;!ha;ah,ee4o1r0;eat scott,r;l1od0sh; grief,bye;ly;! whiz;ell;e0h,t cetera,ureka,ww,xcuse me;k,p;'oh,a0rat,uh;m0ng;mit,n0;!it;mon,o0;ngratulations,wabunga;a2oo1r0tw,ye;avo,r;!ya;h,m; 1h0ka,las,men,rgh,ye;!a,em,h,oy;la",
		"Negative": "true¦n0;ever,o0;n,t",
		"QuestionWord": "true¦how3wh0;at,e1ich,o0y;!m,se;n,re; come,'s",
		"Reflexive": "true¦h4it5my5o1the0your2;ir1m1;ne3ur0;sel0;f,ves;er0im0;self",
		"Plural": "true¦dick0gre0ones,records;ens",
		"Unit|Noun": "true¦cEfDgChBinchAk9lb,m6newt5oz,p4qt,t1y0;ardEd;able1b0ea1sp;!l,sp;spo1;a,t,x;on9;!b,g,i1l,m,p0;h,s;!les;!b,elvin,g,m;!es;g,z;al,b;eet,oot,t;m,up0;!s",
		"Value": "true¦a few",
		"Imperative": "true¦bewa0come he0;re",
		"Plural|Verb": "true¦leaves",
		"Demonym": "true¦0:15;1:12;a0Vb0Oc0Dd0Ce08f07g04h02iYjVkTlPmLnIomHpEqatari,rCs7t5u4v3welAz2;am0Gimbabwe0;enezuel0ietnam0I;gAkrai1;aiwTex0hai,rinida0Ju2;ni0Prkmen;a5cotti4e3ingapoOlovak,oma0Spaniard,udRw2y0W;ede,iss;negal0Cr09;sh;mo0uT;o5us0Jw2;and0;a2eru0Fhilippi0Nortugu07uerto r0S;kist3lesti1na2raguay0;ma1;ani;ami00i2orweP;caragu0geri2;an,en;a3ex0Lo2;ngo0Drocc0;cedo1la2;gasy,y07;a4eb9i2;b2thua1;e0Cy0;o,t01;azakh,eny0o2uwaiI;re0;a2orda1;ma0Ap2;anO;celandic,nd4r2sraeli,ta01vo05;a2iB;ni0qi;i0oneU;aiAin2ondur0unO;di;amEe2hanai0reek,uatemal0;or2rm0;gi0;ilipino,ren8;cuadoVgyp4mira3ngli2sto1thiopi0urope0;shm0;ti;ti0;aPominUut3;a9h6o4roat3ub0ze2;ch;!i0;lom2ngol5;bi0;a6i2;le0n2;ese;lifor1m2na3;bo2eroo1;di0;angladeshi,el6o4r3ul2;gaE;azi9it;li2s1;vi0;aru2gi0;si0;fAl7merBngol0r5si0us2;sie,tr2;a2i0;li0;genti2me1;ne;ba1ge2;ri0;ni0;gh0r2;ic0;an",
		"Organization": "true¦0:4Q;a3Tb3Bc2Od2He2Df27g1Zh1Ti1Pj1Nk1Ll1Gm12n0Po0Mp0Cqu0Br02sTtHuCv9w3xiaomi,y1;amaha,m1Bou1w1B;gov,tu3C;a4e2iki1orld trade organizati33;leaRped0O;lls fargo,st1;fie2Hinghou2R;l1rner br3U;gree3Jl street journ2Im1E;an halOeriz2Xisa,o1;dafo2Yl1;kswagMvo;b4kip,n2ps,s1;a tod3Aps;es3Mi1;lev3Fted natio3C;er,s; mobi32aco beRd bOe9gi frida3Lh3im horto3Amz,o1witt3D;shi49y1;ota,s r 05;e 1in lizzy;b3carpen3Jdaily ma3Dguess w2holli0s1w2;mashing pumpki35uprem0;ho;ea1lack eyed pe3Xyr0Q;ch bo3Dtl0;l2n3Qs1xas instrumen1U;co,la m1F;efoni0Kus;a8cientology,e5ieme2Ymirnoff,np,o3pice gir6quare0Ata1ubaru;rbuc1to34;ks;ny,undgard1;en;a2x pisto1;ls;g1Wrs;few2Minsbur31lesfor03msu2E;adiohead,b8e4o1yana3C;man empi1Xyal 1;b1dutch she4;ank;a3d 1max,vl20;bu1c2Ahot chili peppe2Ylobst2N;ll;ders dige1Ll madrid;c,s;ant3Aizn2Q;a8bs,e5fiz2Ihilip4i3r1;emier 1udenti1D;leagTo2K;nk floyd,zza hut; morrBs;psi2tro1uge0E;br33chi0Tn33;!co;lant2Un1yp16; 2ason27da2P;ld navy,pec,range juli2xf1;am;us;aAb9e6fl,h5i4o1sa,vid3wa;k2tre dame,vart1;is;ia;ke,ntendo,ss0QvZ;l,s;c,st1Otflix,w1; 1sweek;kids on the block,york0D;a,c;nd22s2t1;ional aca2Po,we0U;a,c02d0S;aDcdonalCe9i6lb,o3tv,y1;spa1;ce;b1Tnsanto,ody blu0t1;ley cr1or0T;ue;c2t1;as,subisO;helin,rosoft;dica2rcedes benz,talli1;ca;id,re;ds;cs milk,tt19z24;a3e1g,ittle caesa1P; ore09novo,x1;is,mark,us; 1bour party;pres0Dz boy;atv,fc,kk,lm,m1od1O;art;iffy lu0Roy divisi0Jpmorgan1sa;! cha09;bm,hop,k3n1tv;g,te1;l,rpol;ea;a5ewlett pack1Vi3o1sbc,yundai;me dep1n1P;ot;tac1zbollah;hi;lliburt08sbro;eneral 6hq,ithub,l5mb,o2reen d0Ou1;cci,ns n ros0;ldman sachs,o1;dye1g0H;ar;axo smith kli04encoW;electr0Nm1;oto0Z;a5bi,c barcelo4da,edex,i2leetwood m03o1rito l0G;rd,xcY;at,fa,nancial1restoZ; tim0;na;cebook,nnie mae;b0Asa,u3xxon1; m1m1;ob0J;!rosceptics;aiml0De5isney,o4u1;nkin donu2po0Zran dur1;an;ts;j,w jon0;a,f lepp12ll,peche mode,r spieg02stiny's chi1;ld;aJbc,hFiDloudflaCnn,o3r1;aigsli5eedence clearwater reviv1ossra09;al;c7inba6l4m1o0Est09;ca2p1;aq;st;dplSg1;ate;se;a c1o chanQ;ola;re;a,sco1tigroup;! systems;ev2i1;ck fil a,na daily;r1y;on;d2pital o1rls jr;ne;bury,ill1;ac;aEbc,eBf9l5mw,ni,o1p,rexiteeU;ei3mbardiIston 1;glo1pizza;be;ng;o2ue c1;roV;ckbuster video,omingda1;le; g1g1;oodriL;cht2e ge0rkshire hathaw1;ay;el;cardi,idu,nana republ3s1xt5y5;f,kin robbi1;ns;ic;bYcTdidSerosmith,iRlKmEnheuser busDol,ppleAr6s4u3v2y1;er;is,on;di,todesk;hland o1sociated E;il;b3g2m1;co;os;ys; compu1be0;te1;rs;ch;c,d,erican3t1;!r1;ak; ex1;pre1;ss; 5catel2ta1;ir;! lu1;ce1;nt;jazeera,qae1;da;g,rbnb;as;/dc,a3er,tivision1;! blizz1;ard;demy of scienc0;es;ba",
		"Possessive": "true¦its,my,our0thy;!s",
		"Noun|Verb": "true¦0:9W;1:AA;2:96;3:A3;4:9R;5:A2;6:9K;7:8N;8:7L;9:A8;A:93;B:8D;C:8X;a9Ob8Qc7Id6Re6Gf5Sg5Hh55i4Xj4Uk4Rl4Em40n3Vo3Sp2Squ2Rr21s0Jt02u00vVwGyFzD;ip,oD;ne,om;awn,e6Fie68;aOeMhJiHoErD;ap,e9Oink2;nd0rDuC;kDry,sh5Hth;!shop;ck,nDpe,re,sh;!d,g;e86iD;p,sD;k,p0t2;aDed,lco8W;r,th0;it,lk,rEsDt4ve,x;h,te;!ehou1ra9;aGen5FiFoD;iDmAte,w;ce,d;be,ew,sA;cuum,l4B;pDr7;da5gra6Elo6A;aReQhrPiOoMrGuEwiDy5Z;n,st;nDrn;e,n7O;aGeFiEoDu6;t,ub2;bu5ck4Jgg0m,p;at,k,nd;ck,de,in,nsDp,v7J;f0i8R;ll,ne,p,r4Yss,t94uD;ch,r;ck,de,e,le,me,p,re;e5Wow,u6;ar,e,ll,mp0st,xt;g,lDng2rg7Ps5x;k,ly;a0Sc0Ne0Kh0Fi0Dk0Cl0Am08n06o05pXquaBtKuFwD;ea88iD;ng,pe,t4;bGit,m,ppErD;fa3ge,pri1v2U;lDo6S;e6Py;!je8;aMeLiKoHrEuDy2;dy,ff,mb2;a85eEiDo5Pugg2;ke,ng;am,ss,t4;ckEop,p,rD;e,m;ing,pi2;ck,nk,t4;er,m,p;ck,ff,ge,in,ke,lEmp,nd,p2rDte,y;!e,t;k,l;aJeIiHlGoFrDur,y;ay,e56inDu3;g,k2;ns8Bt;a5Qit;ll,n,r87te;ed,ll;m,n,rk;b,uC;aDee1Tow;ke,p;a5Je4FiDo53;le,rk;eep,iDou4;ce,p,t;ateboa7Ii;de,gnDl2Vnk,p,ze;!al;aGeFiEoDuff2;ck,p,re,w;ft,p,v0;d,i3Ylt0;ck,de,pe,re,ve;aEed,nDrv1It;se,t2N;l,r4t;aGhedu2oBrD;aEeDibb2o3Z;en,w;pe,t4;le,n,r2M;cDfegua72il,mp2;k,rifi3;aZeHhy6LiGoEuD;b,in,le,n,s5X;a6ck,ll,oDpe,u5;f,t;de,ng,ot,p,s1W;aTcSdo,el,fQgPje8lOmMnLo17pJque6sFturn,vDwa6V;eDi27;al,r1;er74oFpe8tEuD;lt,me;!a55;l71rt;air,eaDly,o53;l,t;dezvo2Zt;aDedy;ke,rk;ea1i4G;a6Iist0r5N;act6Yer1Vo71uD;nd,se;a38o6F;ch,s6G;c1Dge,iEke,lly,nDp1Wt1W;ge,k,t;n,se;es6Biv0;a04e00hYiXlToNrEsy4uD;mp,n4rcha1sh;aKeIiHoDu4O;be,ceFdu3fi2grDje8mi1p,te6;amDe6W;!me;ed,ss;ce,de,nt;sDy;er6Cs;cti3i1;iHlFoEp,re,sDuCw0;e,i5Yt;l,p;iDl;ce,sh;nt,s5V;aEce,e32uD;g,mp,n7;ce,nDy;!t;ck,le,n17pe,tNvot;a1oD;ne,tograph;ak,eFnErDt;fu55mA;!c32;!l,r;ckJiInHrFsEtDu1y;ch,e9;s,te;k,tD;!y;!ic;nt,r,se;!a7;bje8ff0il,oErDutli3Qver4B;bAd0ie9;ze;a4ReFoDur1;d,tD;e,i3;ed,gle8tD;!work;aMeKiIoEuD;rd0;ck,d3Rld,nEp,uDve;nt,th;it5EkD;ey;lk,n4Brr5CsDx;s,ta2B;asuBn4UrDss;ge,it;il,nFp,rk3WsEtD;ch,t0;h,k,t0;da5n0oeuvB;aLeJiHoEuD;mp,st;aEbby,ck,g,oDve;k,t;d,n;cDe,ft,mAnIst;en1k;aDc0Pe4vK;ch,d,k,p,se;bFcEnd,p,t4uD;gh,n4;e,k;el,o2U;eEiDno4E;ck,d,ll,ss;el,y;aEo1OuD;i3mp;m,zz;mpJnEr46ssD;ue;c1Rdex,fluGha2k,se2HteDvoi3;nt,rD;e6fa3viD;ew;en3;a8le2A;aJeHiGoEuD;g,nt;l3Ano2Dok,pDr1u1;!e;ghli1Fke,nt,re,t;aDd7lp;d,t;ck,mGndFrEsh,tDu9;ch,e;bo3Xm,ne4Eve6;!le;!m0;aMear,ift,lKossJrFuD;arDe4Alp,n;antee,d;aFiEoDumb2;uCwth;ll,nd,p;de,sp;ip;aBoDue;ss,w;g,in,me,ng,s,te,ze;aZeWiRlNoJrFuD;ck,el,nDss,zz;c38d;aEoDy;st,wn;cDgme,me,nchi1;tuB;cFg,il,ld,rD;ce,e29mDwa31;!at;us;aFe0Vip,oDy;at,ck,od,wD;!er;g,ke,me,re,sh,vo1E;eGgFlEnDre,sh,t,x;an3i0Q;e,m,t0;ht,uB;ld;aEeDn3;d,l;r,tuB;ce,il,ll,rm,vo2W;cho,d7ffe8nMsKxFyeD;!baD;ll;cGerci1hFpDtra8;eriDo0W;en3me9;au6ibA;el,han7u1;caDtima5;pe;count0d,vy;a01eSiMoJrEuDye;b,el,mp,pli2X;aGeFiEoD;ne,p;ft,ll,nk,p,ve;am,ss;ft,g,in;cEd7ubt,wnloD;ad;k,u0E;ge6p,sFt4vD;e,iDor3;de;char7gui1h,liEpD;at4lay,u5;ke;al,bKcJfeIlGmaCposAsEtaD;il;e07iD;gn,re;ay,ega5iD;ght;at,ct;li04rea1;a5ut;b,ma7n3rDte;e,t;a0Eent0Dh06irc2l03oKrFuD;be,e,rDt;b,e,l,ve;aGeFoEuDy;sh;p,ss,wd;dAep;ck,ft,sh;at,de,in,lTmMnFordina5py,re,st,uDv0;gh,nDp2rt;s01t;ceHdu8fli8glomeIsFtDveN;a8rD;a6ol;e9tru8;ct;ntDrn;ra5;bHfoGmFpD;leDouCromi1;me9;aCe9it,u5;rt;at,iD;ne;lap1oD;r,ur;aEiDoud,ub;ck,p;im,w;aEeDip;at,ck,er;iGllen7nErD;ge,m,t;ge,nD;el;n,r;er,re;ke,ll,mp,noe,pGrXsFtEuDve;se,ti0I;alog,ch;h,t;!tuB;re;a03eZiXlToPrHuEyD;pa11;bb2ck2dgEff0mp,rDst,zz;den,n;et;anJeHiFoadEuD;i1sh;ca6;be,d7;ge;aDed;ch,k;ch,d;aFg,mb,nEoDrd0tt2x,ycott;k,st,t;d,e;rd,st;aFeCiDoYur;nk,tz;nd;me;as,d,ke,nd,opsy,tD;!ch,e;aFef,lt,nDt;d,efA;it;r,t;ck,il,lan3nIrFsEtt2;le;e,h;!gDk;aDe;in;!d,g,k;bu1c05dZge,iYlVnTppQrLsIttGucEwaD;rd;tiD;on;aDempt;ck;k,sD;i6ocia5;st;chFmD;!oD;ur;!iD;ve;eEroa4;ch;al;chDg0sw0;or;aEt0;er;rm;d,m,r;dreHvD;an3oD;ca5;te;ce;ss;cDe,he,t;eFoD;rd,u9;nt;nt,ss;se",
		"Actor": "true¦0:7B;1:7G;2:6A;3:7F;4:7O;5:7K;a6Nb62c4Ud4Be41f3Sg3Bh30i2Uj2Qkin2Pl2Km26n1Zo1Sp0Vqu0Tr0JsQtJuHvEw8yo6;gi,ut6;h,ub0;aAe9i8o7r6;estl0it0;m2rk0;fe,nn0t2Bza2H;atherm2ld0;ge earn0it0nder0rri1;eter7i6oyF;ll5Qp,s3Z;an,ina2U;n6s0;c6Uder03;aoisea23e9herapi5iktok0o8r6ut1yco6S;a6endseLo43;d0mp,nscri0Bvel0;ddl0u1G;a0Qchn7en6na4st0;ag0;i3Oo0D;aiXcUeRhPiMki0mu26oJpGquaFtBu7wee6;p0theart;lt2per7r6;f0ge6Iviv1;h6inten0Ist5Ivis1;ero,um2;a8ep7r6;ang0eam0;bro2Nc2Ofa2Nmo2Nsi20;ff0tesm2;tt0;ec7ir2Do6;kesp59u0M;ia5Jt3;l7me6An,rcere6ul;r,ss;di0oi5;n7s6;sy,t0;g0n0;am2ephe1Iow6;girl,m2r2Q;cretInior cit3Fr6;gea4v6;a4it1;hol4Xi7reen6ulpt1;wr2C;e01on;l1nt;aEe9o8u6;l0nn6;er up,ingE;g40le mod3Zof0;a4Zc8fug2Ppo32searQv6;ere4Uolution6;ary;e6luYru22;ptio3T;bbi,dic5Vpp0;arter6e2Z;back;aYeWhSiRlOoKr8sycho7u6;nk,p31;logi5;aGeDiBo6;d9fess1g7ph47s6;pe2Ktitu51;en6ramm0;it1y;igy,uc0;est4Nme mini0Unce6s3E;!ss;a7si6;de4;ch0;ctiti39nk0P;dca0Oet,li6pula50rnst42;c2Itic6;al scie6i2;nti5;a6umb0;nn0y6;er,ma4Lwright;lgrim,one0;a8iloso7otogra7ra6ysi1V;se;ph0;ntom,rmaci5;r6ssi1T;form0s4O;i3El,nel3Yr8st1tr6wn;i6on;arWot;ent4Wi42tn0;ccupa4ffBp8r7ut6;ca5l0B;ac4Iganiz0ig2Fph2;er3t6;i1Jomet6;ri5;ic0spring;aBe9ie4Xo7u6;n,rser3J;b6mad,vi4V;le2Vo4D;i6mesis,phew;ce,ghb1;nny,rr3t1X;aEeDiAo7u6yst1Y;m8si16;der3gul,m7n6th0;arDk;!my;ni7s6;f02s0Jt0;on,st0;chan1Qnt1rcha4;gi9k0n8rtyr,t6y1;e,riar6;ch;ag0iac;ci2stra3I;a7e2Aieutena4o6;rd,s0v0;bor0d7ndlo6ss,urea3Fwy0ym2;rd;!y;!s28;e8o7u6;ggl0;gg0urna2U;st0;c3Hdol,llu3Ummigra4n6; l9c1Qfa4habi42nov3s7ve6;nt1stig3;pe0Nt6;a1Fig3ru0M;aw;airFeBistoAo8u6ygie1K;man6sba2H;!ita8;bo,st6usekN;age,e3P;ri2;ir,r6;m7o6;!ine;it;dress0sty2C;aLeIhostGirl26ladi3oCrand7u6;e5ru;c9daug0Jfa8m7pa6s2Y;!re4;a,o6;th0;hi1B;al7d6lf0;!de3A;ie,k6te26;eep0;!wr6;it0;isha,n6;i6tl04;us;mbl0rden0;aDella,iAo7r6;eela2Nie1P;e,re6ster pare4;be1Hm2r6st0;unn0;an2ZgZlmm17nanci0r6tt0;e6st la2H; marsh2OfigXm2;rm0th0;conoEdDlectriCm8n7x6;amin0cellency,i2A;emy,trepreneur,vironmenta1J;c8p6;er1loye6;e,r;ee;ci2;it1;mi5;aKeBi8ork,ri7u6we02;de,tche2H;ft0v0;ct3eti7plom2Hre6va;ct1;ci2ti2;aDcor3fencCi0InAput9s7tectLvel6;op0;ce1Ge6ign0;rt0;ee,y;iz6;en;em2;c1Ml0;d8nc0redev7ug6;ht0;il;!dy;a06e04fo,hXitizenWlToBr9u6;r3stomer6;! representat6;ive;e3it6;ic;lJmGnAord9rpor1Nu7w6;boy,ork0;n6ri0;ciTte1Q;in3;fidantAgressSs9t6;e0Kr6;ibut1o6;ll0;tab13ul1O;!e;edi2m6pos0rade;a0EeQissi6;on0;leag8on7um6;ni5;el;ue;e6own;an0r6;ic,k;!s;a9e7i6um;ld;erle6f;ad0;ir7nce6plFract0;ll1;m2wI;lebri6o;ty;dBptAr6shi0;e7pe6;nt0;r,t6;ak0;ain;et;aMeLiJlogg0oErBu6;dd0Fild0rgl9siness6;m2p7w6;om2;ers05;ar;i7o6;!k0th0;cklay0de,gadi0;hemi2oge8y6;!frie6;nd;ym2;an;cyc6sR;li5;atbox0ings;by,nk0r6;b0on7te6;nd0;!e07;c04dWge4nQpLrHsFtAu7yatull6;ah;nt7t6;h1oG;!ie;h8t6;e6orney;nda4;ie5le6;te;sis00tron6;aut,om0;chbis8isto7tis6;an,t;crU;hop;ost9p6;ari6rentiS;ti6;on;le;a9cest1im3nou8y6;bo6;dy;nc0;ly5rc6;hi5;mi8v6;entur0is1;er;ni7r6;al;str3;at1;or;counBquaintanArob9t6;ivi5or,re6;ss;st;at;ce;ta4;nt",
		"Adj|Noun": "true¦0:16;a1Db17c0Ud0Re0Mf0Dg0Ah08i06ju05l02mWnUoSpNrIsBt7u4v1watershed;a1ision0Z;gabo4nilla,ria1;b0Vnt;ndergr1pstairs;adua14ou1;nd;a3e1oken,ri0;en,r1;min0rori13;boo,n;age,e5ilv0Flack,o3quat,ta2u1well;bordina0Xper5;b0Lndard;ciali0Yl1vereign;e,ve16;cret,n1ri0;ior;a4e2ou1ubbiL;nd,tiY;ar,bBl0Wnt0p1side11;resent0Vublican;ci0Qsh;a4eriodic0last0Zotenti0r1;emi2incip0o1;!fession0;er,um;rall4st,tie0U;ff1pposi0Hv0;ens0Oi0C;agg01ov1uts;el;a5e3iniatJo1;bi01der07r1;al,t0;di1tr0N;an,um;le,riG;attOi2u1;sh;ber0ght,qC;stice,veniT;de0mpressioYn1;cumbe0Edividu0no0Dsta0Eterim;alf,o1umdrum;bby,melF;en2old,ra1;ph0Bve;er0ious;a7e5i4l3u1;git03t1;ure;uid;ne;llow,m1;aFiL;ir,t,vo1;riOuriO;l3p00x1;c1ecutUpeV;ess;d1iK;er;ar2e1;mographUrivO;k,l2;hiGlassSo2rude,unn1;ing;m5n1operK;creCstitueOte2vertab1;le;mpor1nt;ary;ic,m2p1;anion,lex;er2u1;ni8;ci0;al;e5lank,o4r1;i2u1;te;ef;ttom,urgeois;st;cadem9d6l2ntarct9r1;ab,ct8;e3tern1;at1;ive;rt;oles1ult;ce1;nt;ic",
		"Adj|Past": "true¦0:4Q;1:4C;2:4H;3:4E;a44b3Tc36d2Je29f20g1Wh1Si1Jj1Gkno1Fl1Am15n12o0Xp0Mqu0Kr08sLtEuAv9w4yellow0;a7ea6o4rinkl0;r4u3Y;n,ri0;k31th3;rp0sh0tZ;ari0e1O;n5p4s0;d1li1Rset;cov3derstood,i4;fi0t0;a8e3Rhr7i6ouTr4urn0wi4C;a4imm0ou2G;ck0in0pp0;ed,r0;eat2Qi37;m0nn0r4;get0ni2T;aOcKeIhGimFm0Hoak0pDt7u4;bsid3Ogge44s4;pe4ta2Y;ct0nd0;a8e7i2Eok0r5u4;ff0mp0nn0;ength2Hip4;ed,p0;am0reotyp0;in0t0;eci4ik0oH;al3Efi0;pRul1;a4ock0ut;d0r0;a4c1Jle2t31;l0s3Ut0;a6or5r4;at4e25;ch0;r0tt3;t4ut0;is2Mur1;aEe5o4;tt0;cAdJf2Bg9je2l8m0Knew0p7qu6s4;eTpe2t4;or0ri2;e3Dir0;e1lac0;at0e2Q;i0Rul1;eiv0o4ycl0;mme2Lrd0v3;in0lli0ti2A;a4ot0;li28;aCer30iBlAo9r5u4;mp0zzl0;e6i2Oo4;ce2Fd4lo1Anou30pos0te2v0;uc0;fe1CocCp0Iss0;i2Kli1L;ann0e2CuS;ck0erc0ss0;ck0i2Hr4st0;allLk0;bse7c6pp13rgan2Dver4;lo4whelm0;ok0;cupi0;rv0;aJe5o4;t0uri1A;ed0gle2;a6e5ix0o4ut0ys1N;di1Nt15u26;as0Clt0;n4rk0;ag0ufact0A;e6i5o4;ad0ck0st,v0;cens0m04st0;ft,v4;el0;tt0wn;a5o15u4;dg0s1B;gg0;llumSmpAn4sol1;br0cre1Ldebt0f8jZspir0t5v4;it0olv0;e4ox0Y;gr1n4re23;d0si15;e2l1o1Wuri1;li0o01r4;ov0;a6e1o4um03;ok0r4;ri0Z;mm3rm0;i6r5u4;a1Bid0;a0Ui0Rown;ft0;aAe9i8l6oc0Ir4;a4i0oz0Y;ctHg19m0;avo0Ju4;st3;ni08tt0x0;ar0;d0il0sc4;in1;dCl1mBn9quipp0s8x4;agger1c6p4te0T;a0Se4os0;ct0rie1D;it0;cap0tabliZ;cha0XgFha1As4;ur0;a0Zbarra0N;i0Buc1;aMeDi5r4;a01i0;gni08miniSre2s4;a9c6grun0Ft4;o4re0Hu17;rt0;iplWou4;nt0r4;ag0;bl0;cBdRf9l8p7ra6t5v4;elop0ot0;ail0ermQ;ng0;re07;ay0ight0;e4in0o0M;rr0;ay0enTor1;m5t0z4;ed,zl0;ag0p4;en0;aPeLhIlHo9r6u4;lt4r0stom03;iv1;a5owd0u4;sh0;ck0mp0;d0loAm7n4ok0v3;centr1f5s4troC;id3olid1;us0;b5pl4;ic1;in0;r0ur0;assi9os0utt3;ar5i4;ll0;g0m0;lebr1n6r4;ti4;fi0;tralJ;g0lcul1;aDewild3iCl9o7r5urn4;ed,t;ok4uis0;en;il0r0t4und;tl0;e5i4;nd0;ss0;as0;ffl0k0laMs0tt3;bPcNdKfIg0lFmaz0nDppBrm0ss9u5wa4;rd0;g5thor4;iz0;me4;nt0;o6u4;m0r0;li0re4;ci1;im1ticip1;at0;a5leg0t3;er0;rm0;fe2;ct0;ju5o7va4;nc0;st0;ce4knowledg0;pt0;and5so4;rb0;on0;ed",
		"Singular": "true¦0:5J;1:5H;2:4W;3:4S;4:52;5:57;6:5L;7:56;8:5B;a52b4Lc3Nd35e2Xf2Og2Jh28in24j23k22l1Um1Ln1Ho1Bp0Rqu0Qr0FsZtMuHvCw9x r58yo yo;a9ha3Po3Q;f3i4Rt0Gy9;! arou39;arCeAideo ga2Qo9;cabu4Jl5C;gOr9t;di4Zt1Y;iety,ni4P;nBp30rAs 9;do43s5E;bani1in0;coordinat3Ader9;estima1to24we41; rex,aKeJhHiFoErBuAv9;! show;m2On2rntLto1D;agedy,ib9o4E;e,u9;n0ta46;ni1p2rq3L;c,er,m9;etF;ing9ree26;!y;am,mp3F;ct2le6x return;aNcMeKhor4QiJkHoGpin off,tDuBy9;ll9ner7st4T;ab2X;b9i1n28per bowl,rro1X;st3Ltot0;atAipe2Go1Lrate7udent9;! lo0I;i39u1;ft ser4Lmeo1I;elet5i9;ll,r3V;b38gn2Tte;ab2Jc9min3B;t,urity gua2N;e6ho2Y;bbatic0la3Jndwi0Qpi5;av5eDhetor2iAo9;de6om,w;tAv9;erb2C;e,u0;bDcBf9publ2r10spi1;er9orm3;e6r0;i9ord label;p2Ht0;a1u46;estion mark,ot2F;aPeMhoLiIlGoErAu9yram1F;ddi3HpErpo1Js3J;eBo9;bl3Zs9;pe3Jta1;dic1Rmi1Fp1Qroga8ss relea1F;p9rt0;py;a9ebisci1;q2Dte;cn2eAg9;!gy;!r;ne call,tocoK;anut,dAr9t0yo1;cen3Jsp3K;al,est0;nop4rAt9;e,hog5;adi11i2V;atme0bj3FcBpia1rde0thers,utspok5ve9wn3;n,r9;ti0Pview;cuAe9;an;pi3;arBitAot9umb3;a2Fhi2R;e,ra1;cot2ra8;aFeCiAo9ur0;nopo4p18rni2Nsq1Rti36uld;c,li11n0As9tt5;chief,si34;dAnu,t9;al,i3;al,ic;gna1mm0nd15rsupi0te9yf4;ri0;aDegCiBu9;ddi1n9;ch;me,p09; Be0M;bor14y9; 9er;up;eyno1itt5;el4ourn0;cBdices,itia8ni25sAtel0Lvert9;eb1J;e28titu1;en8i2T;aIeEighDoAu9;man right,s22;me9rmoFsp1Ftb0K;! r9;un; scho0YriY;a9i1N;d9v5; start,pho9;ne;ndful,sh brown,v5ze;aBelat0Ilaci3r9ul4yp1S;an9enadi3id;a1Cd slam,ny;df4r9;l2ni1I;aGeti1HiFlu1oCrAun9;er0;ee market,i9onti3;ga1;l4ur9;so9;me;ePref4;br2mi4;conoFffi7gg,lecto0Rmbas1EnCpidem2s1Zth2venBxAyel9;id;ampZempl0Nte6;i19t;er7terp9;ri9;se;my;eLiEoBr9ump tru0U;agonf4i9;er,ve thru;cAg7i4or,ssi3wn9;side;to0EumenE;aEgniDnn3sAvide9;nd;conte6incen8p9tri11;osi9;ti0C;ta0H;le0X;athBcAf9ni0terre6;ault 05err0;al,im0;!b9;ed;aWeThMiLlJoDr9;edit caBuc9;ib9;le;rd;efficDke,lCmmuniqLnsApi3rr0t0Xus9yo1;in;erv9uI;ato02;ic,lQ;ie6;er7i9oth;e6n2;ty,vil wM;aDeqCick5ocoBr9;istmas car9ysanthemum;ol;la1;ue;ndeli3racteri9;st2;iAllEr9;e0tifica1;liZ;hi3nFpErCt9ucus;erpi9hedr0;ll9;ar;!bohyd9ri3;ra1;it0;aAe,nib0t9;on;l,ry;aMeLiop2leJoHrDu9;nny,r9tterf4;g9i0;la9;ry;eakAi9;ck;fa9throB;st;dy,ro9wl;ugh;mi9;sh;an,l4;nkiArri3;er;ng;cSdMlInFppeti1rDsBtt2utop9;sy;ic;ce6pe9;ct;r9sen0;ay;ecAoma4tiA;ly;do1;i5l9;er7y;gy;en; hominDjAvan9;tage;ec8;ti9;ve;em;cCeAqui9;tt0;ta1;te;iAru0;al;de6;nt",
		"Person|Noun": "true¦a0Eb07c03dWeUfQgOhLjHkiGlFmCnBolive,p7r4s3trini06v1wa0;ng,rd,tts;an,enus,iol0;a,et;ky,onPumm09;ay,e1o0uby;bin,d,se;ed,x;a2e1o0;l,tt04;aLnJ;dYge,tR;at,orm;a0eloW;t0x,ya;!s;a9eo,iH;ng,tP;a2e1o0;lGy;an,w3;de,smi4y;a0erb,iOolBuntR;ll,z0;el;ail,e0iLuy;ne;a1ern,i0lo;elds,nn;ith,n0;ny;a0dEmir,ula,ve;rl;a4e3i1j,ol0;ly;ck,x0;ie;an,ja;i0wn;sy;am,h0liff,rystal;a0in,ristian;mbers,ri0;ty;a4e3i2o,r0ud;an0ook;dy;ll;nedict,rg;k0nks;er;l0rt;fredo,ma",
		"Actor|Verb": "true¦aCb8c5doctor,engineAfool,g3host,judge,m2nerd,p1recruit,scout,ushAvolunteAwi0;mp,tneA;arent,ilot;an,ime;eek,oof,r0uide;adu8oom;ha1o0;ach,nscript,ok;mpion,uffeur;o2u0;lly,tch0;er;ss;ddi1ffili0rchite1;ate;ct",
		"MaleName": "true¦0:H6;1:FZ;2:DS;3:GQ;4:CZ;5:FV;6:GM;7:FP;8:GW;9:ET;A:C2;B:GD;aF8bE1cCQdBMeASfA1g8Yh88i7Uj6Sk6Bl5Mm48n3So3Ip33qu31r26s1Et0Ru0Ov0CwTxSyHzC;aCor0;cChC1karia,nAT;!hDkC;!aF6;!ar7CeF5;aJevgenBSoEuC;en,rFVsCu3FvEF;if,uf;nDs6OusC;ouf,s6N;aCg;s,tC;an,h0;hli,nCrosE1ss09;is,nC;!iBU;avi2ho5;aPeNiDoCyaEL;jcieBJlfgang,odrFutR;lFnC;f8TsC;lCt1;ow;bGey,frEhe4QlC;aE5iCy;am,e,s;ed8iC;d,ed;eAur;i,ndeD2rn2sC;!l9t1;lDyC;l1ne;lDtC;!er;aCHy;aKernDAiFladDoC;jteB0lodymyr;!iC;mFQsDB;cFha0ktBZnceDrgCOvC;a0ek;!nC;t,zo;!e4StBV;lCnC7sily;!entC;in9J;ghE2lCm70nax,ri,sm0;riCyss87;ch,k;aWeRhNiLoGrEuDyC;!l2roEDs1;n6r6E;avD0eCist0oy,um0;ntCRvBKy;bFdAWmCny;!asDmCoharu;aFFie,y;!z;iA6y;mCt4;!my,othy;adEeoDia0SomC;!as;!dor91;!de4;dFrC;enBKrC;anBJeCy;ll,nBI;!dy;dgh,ha,iCnn2req,tsu5V;cDAka;aYcotWeThPiMlobod0oKpenc2tEurDvenAEyCzym1;ed,lvest2;aj,e9V;anFeDuC;!aA;fan17phEQvCwaA;e77ie;!islaCl9;v,w;lom1rBuC;leymaDHta;dDgmu9UlCm1yabonga;as,v8B;!dhart8Yn9;aEeClo75;lCrm0;d1t1;h9Jne,qu1Jun,wn,yne;aDbastiEDk2Yl5Mpp,rgCth,ymoCU;e1Dio;m4n;!tC;!ie,y;eDPlFmEnCq67tosCMul;dCj2UtiA5;e01ro;!iATkeB6mC4u5;!ik,vato9K;aZeUheC8iRoGuDyC;an,ou;b99dDf4peAssC;!elEG;ol00y;an,bLc7MdJel,geIh0lHmGnEry,sDyC;!ce;ar7Ocoe,s;!aCnBU;ld,n;an,eo;a7Ef;l7Jr;e3Eg2n9olfo,riC;go;bBNeDH;cCl9;ar87c86h54kCo;!ey,ie,y;cFeA3gDid,ubByCza;an8Ln06;g85iC;naC6s;ep;ch8Kfa5hHin2je8HlGmFndEoHpha5sDul,wi36yC;an,mo8O;h9Im4;alDSol3O;iD0on;f,ph;ul;e9CinC;cy,t1;aOeLhilJiFrCyoG;aDeC;m,st1;ka85v2O;eDoC;tr;r8GtC;er,ro;!ipCl6H;!p6U;dCLrcy,tC;ar,e9JrC;!o7;b9Udra8So9UscAHtri62ulCv8I;!ie,o7;ctav6Ji2lImHndrBRrGsDtCum6wB;is,to;aDc6k6m0vCwaBE;al79;ma;i,vR;ar,er;aDeksandr,ivC;er,i2;f,v;aNeLguyBiFoCu3O;aDel,j4l0ma0rC;beAm0;h,m;cFels,g5i9EkDlC;es,s;!au,h96l78olaC;!i,y;hCkCol76;ol75;al,d,il,ls1vC;ilAF;hom,tC;e,hC;anCy;!a5i5;aYeViLoGuDyC;l4Nr1;hamDr84staC;fa,p6E;ed,mG;di10e,hamEis4JntDritz,sCussa;es,he;e,y;ad,ed,mC;ad,ed;cGgu5hai,kFlEnDtchC;!e8O;a9Pik;house,o7t1;ae73eC3ha8Iolaj;ah,hDkC;!ey,y;aDeC;al,l;el,l;hDlv3rC;le,ri8Ev4T;di,met;ay0c00gn4hWjd,ks2NlTmadZnSrKsXtDuric7VxC;imilBKwe8B;eHhEi69tCus,y69;!eo,hCia7;ew,i67;eDiC;as,eu,s;us,w;j,o;cHiGkFlEqu8Qsha83tCv3;iCy;!m,n;in,on;el,o7us;a6Yo7us;!elCin,o7us;!l8o;frAEi5Zny,u5;achDcoCik;lm;ai,y;amDdi,e5VmC;oud;adCm6W;ou;aulCi9P;ay;aWeOiMloyd,oJuDyC;le,nd1;cFdEiDkCth2uk;a7e;gi,s,z;ov7Cv6Hw6H;!as,iC;a6Een;g0nn52renDuCvA4we7D;!iS;!zo;am,n4oC;n5r;a9Yevi,la5KnHoFst2thaEvC;eCi;nte;bo;nCpo8V;!a82el,id;!nC;aAy;mEnd1rDsz73urenCwr6K;ce,t;ry,s;ar,beAont;aOeIhalHiFla4onr63rDu5SylC;e,s;istCzysztof;i0oph2;er0ngsl9p,rC;ilA9k,ollos;ed,id;en0iGnDrmCv4Z;it;!dDnCt1;e2Ny;ri4Z;r,th;cp2j4mEna8BrDsp6them,uC;ri;im,l;al,il;a03eXiVoFuC;an,lCst3;en,iC;an,en,o,us;aQeOhKkub4AnIrGsDzC;ef;eDhCi9Wue;!ua;!f,ph;dCge;i,on;!aCny;h,s,th6J;anDnC;!ath6Hie,n72;!nC;!es;!l,sCy;ph;o,qu3;an,mC;!i,m6V;d,ffFns,rCs4;a7JemDmai7QoCry;me,ni1H;i9Dy;!e73rC;ey,y;cKdBkImHrEsDvi2yC;dBs1;on,p2;ed,oDrCv67;e6Qod;d,s61;al,es5Wis1;a,e,oCub;b,v;ob,qu13;aTbNchiMgLke53lija,nuKonut,rIsEtCv0;ai,suC;ki;aDha0i8XmaCsac;el,il;ac,iaC;h,s;a,vinCw3;!g;k,nngu6X;nac1Xor;ka;ai,rahC;im;aReLoIuCyd6;beAgGmFsC;eyDsC;a3e3;in,n;ber5W;h,o;m2raDsse3wC;a5Pie;c49t1K;a0Qct3XiGnDrC;beAman08;dr7VrC;iCy2N;!k,q1R;n0Tt3S;bKlJmza,nIo,rEsDyC;a5KdB;an,s0;lEo67r2IuCv9;hi5Hki,tC;a,o;an,ey;k,s;!im;ib;a08e00iUlenToQrMuCyorgy;iHnFsC;!taC;f,vC;!e,o;n6tC;er,h2;do,lC;herDlC;auCerQ;me;aEegCov2;!g,orC;!io,y;dy,h7C;dfr9nza3XrDttfC;ri6C;an,d47;!n;acoGlEno,oCuseppe;rgiCvan6O;!o,s;be6Ies,lC;es;mo;oFrC;aDha4HrCt;it,y;ld,rd8;ffErgC;!e7iCy;!os;!r9;bElBrCv3;eCla1Nr4Hth,y;th;e,rC;e3YielC;!i4;aXeSiQlOorrest,rCyod2E;aHedFiC;edDtC;s,z;ri18;!d42eri11riC;ck,k;nCs2;cEkC;ie,lC;in,yn;esLisC;!co,z3M;etch2oC;ri0yd;d5lConn;ip;deriFliEng,rC;dinaCg4nan0B;nd8;pe,x;co;bCdi,hd;iEriC;ce,zC;io;an,en,o;benez2dZfrYit0lTmMnJo3rFsteb0th0ugenEvCymBzra;an,eCge4D;ns,re3K;!e;gi,iDnCrol,v3w3;est8ie,st;cCk;!h,k;o0DriCzo;co,qC;ue;aHerGiDmC;aGe3A;lCrh0;!iC;a10o,s;s1y;nu5;beAd1iEliDm2t1viCwood;n,s;ot28s;!as,j5Hot,sC;ha;a3en;!dGg6mFoDua2QwC;a2Pin;arC;do;oZuZ;ie;a04eTiOmitrNoFrag0uEwDylC;an,l0;ay3Hig4D;a3Gdl9nc0st3;minFnDri0ugCvydGy2S;!lF;!a36nCov0;e1Eie,y;go,iDykC;as;cCk;!k;i,y;armuFetDll1mitri7neCon,rk;sh;er,m6riC;ch;id;andLepak,j0lbeAmetri4nIon,rGsEvDwCxt2;ay30ey;en,in;hawn,moC;nd;ek,riC;ck;is,nC;is,y;rt;re;an,le,mKnIrEvC;e,iC;!d;en,iEne0PrCyl;eCin,yl;l45n;n,o,us;!iCny;el,lo;iCon;an,en,on;a0Fe0Ch03iar0lRoJrFuDyrC;il,us;rtC;!is;aEistC;iaCob12;no;ig;dy,lInErC;ey,neliCy;s,us;nEor,rDstaC;nt3;ad;or;by,e,in,l3t1;aHeEiCyde;fCnt,ve;fo0Xt1;menDt4;us;s,t;rFuDyC;!t1;dCs;e,io;enC;ce;aHeGrisC;!toC;phCs;!eC;!r;st2t;d,rCs;b5leC;s,y;cDdrCs6;ic;il;lHmFrC;ey,lDroCy;ll;!o7t1;er1iC;lo;!eb,v3;a09eZiVjorn,laUoSrEuCyr1;ddy,rtKst2;er;aKeFiEuDyC;an,ce,on;ce,no;an,ce;nDtC;!t;dDtC;!on;an,on;dFnC;dDisC;lav;en,on;!foOl9y;bby,gd0rCyd;is;i0Lke;bElDshC;al;al,lL;ek;nIrCshoi;at,nEtC;!raC;m,nd;aDhaCie;rd;rd8;!iDjam3nCs1;ie,y;to;kaMlazs,nHrC;n9rDtC;!holomew;eCy;tt;ey;dCeD;ar,iC;le;ar1Nb1Dd16fon15gust3hm12i0Zja0Yl0Bm07nTputsiSrGsaFugustEveDyCziz;a0kh0;ry;o,us;hi;aMchiKiJjun,mHnEon,tCy0;em,hCie,ur8;ur;aDoC;!ld;ud,v;aCin;an,nd8;!el,ki;baCe;ld;ta;aq;aMdHgel8tCw6;hoFoC;iDnC;!i8y;ne;ny;er7rCy;eDzC;ej;!as,i,j,s,w;!s;s,tolC;iCy;!y;ar,iEmaCos;nu5r;el;ne,r,t;aVbSdBeJfHiGl01onFphonsEt1vC;aPin;on;e,o;so,zo;!sR;!onZrC;ed;c,jaHksFssaHxC;!andC;er,rC;e,os,u;andCei;ar,er,r;ndC;ro;en;eDrecC;ht;rt8;dd3in,n,sC;taC;ir;ni;dDm6;ar;an,en;ad,eC;d,t;in;so;aGi,olErDvC;ik;ian8;f8ph;!o;mCn;!a;dGeFraDuC;!bakr,lfazl;hCm;am;!l;allFel,oulaye,ulC;!lDrahm0;an;ah,o;ah;av,on",
		"Uncountable": "true¦0:2E;1:2L;2:33;a2Ub2Lc29d22e1Rf1Ng1Eh16i11j0Yk0Wl0Rm0Hn0Do0Cp03rZsLt9uran2Jv7w3you gu0E;a5his17i4oo3;d,l;ldlife,ne;rm8t1;apor,ernacul29i3;neg28ol1Otae;eDhBiAo8r4un3yranny;a,gst1B;aff2Oea1Ko4ue nor3;th;o08u3;bleshoot2Ose1Tt;night,othpas1Vwn3;foEsfoE;me off,n;er3und1;e,mod2S;a,nnis;aDcCeBhAi9ki8o7p6t4u3weepstak0;g1Unshi2Hshi;ati08e3;am,el;ace2Keci0;ap,cc1meth2C;n,ttl0;lk;eep,ingl0or1C;lf,na1Gri0;ene1Kisso1C;d0Wfe2l4nd,t3;i0Iurn;m1Ut;abi0e4ic3;e,ke15;c3i01laxa11search;ogni10rea10;a9e8hys7luto,o5re3ut2;amble,mis0s3ten20;en1Zs0L;l3rk;i28l0EyH; 16i28;a24tr0F;nt3ti0M;i0s;bstetri24vercrowd1Qxyg09;a5e4owada3utella;ys;ptu1Ows;il poliZtional securi2;aAe8o5u3;m3s1H;ps;n3o1K;ey,o3;gamy;a3cha0Elancholy,rchandi1Htallurgy;sl0t;chine3g1Aj1Hrs,thema1Q; learn1Cry;aught1e6i5ogi4u3;ck,g12;c,s1M;ce,ghtn18nguis1LteratWv1;ath1isVss;ara0EindergartPn3;icke0Aowled0Y;e3upit1;a3llyfiGwel0G;ns;ce,gnor6mp5n3;forma00ter3;net,sta07;atiSort3rov;an18;a7e6isto09o3ung1;ckey,mework,ne4o3rseradi8spitali2use arrest;ky;s2y;adquarteXre;ir,libut,ppiHs3;hi3te;sh;ene8l6o5r3um,ymnas11;a3eZ;niUss;lf,re;ut3yce0F;en; 3ti0W;edit0Hpo3;ol;aNicFlour,o4urnit3;ure;od,rgive3uri1wl;ness;arCcono0LducaBlectr9n7quip8thi0Pvery6x3;ist4per3;ti0B;en0J;body,o08th07;joy3tertain3;ment;ici2o3;ni0H;tiS;nings,th;emi02i6o4raugh3ynas2;ts;pe,wnstai3;rs;abet0ce,s3;honZrepu3;te;aDelciChAivi07l8o3urrency;al,ld w6mmenta5n3ral,ttIuscoB;fusiHt 3;ed;ry;ar;assi01oth0;es;aos,e3;eMwK;us;d,rO;a8i6lood,owlHread5u3;ntGtt1;er;!th;lliarJs3;on;g3ss;ga3;ge;cKdviJeroGirFmBn6ppeal court,r4spi3thleL;rin;ithmet3sen3;ic;i6y3;o4th3;ing;ne;se;en5n3;es2;ty;ds;craft;bi8d3nau7;yna3;mi6;ce;id,ous3;ti3;cs",
		"Infinitive": "true¦0:9G;1:9T;2:AD;3:90;4:9Z;5:84;6:AH;7:A9;8:92;9:A0;A:AG;B:AI;C:9V;D:8R;E:8O;F:97;G:6H;H:7D;a94b8Hc7Jd68e4Zf4Mg4Gh4Ai3Qj3Nk3Kl3Bm34nou48o2Vp2Equ2Dr1Es0CtZuTvRwI;aOeNiLors5rI;eJiI;ng,te;ak,st3;d5e8TthI;draw,er;a2d,ep;i2ke,nIrn;d1t;aIie;liADniAry;nJpI;ho8Llift;cov1dJear8Hfound8DlIplug,rav82tie,ve94;eaAo3X;erIo;cut,go,staAFvalA3w2G;aSeQhNoMrIu73;aIe72;ffi3Smp3nsI;aBfo7CpI;i8oD;pp3ugh5;aJiJrIwaD;eat5i2;nk;aImA0;ch,se;ck3ilor,keImp1r8L;! paD;a0Ic0He0Fh0Bi0Al08mugg3n07o05p02qu01tUuLwI;aJeeIim;p,t5;ll7Wy;bNccMffLggeCmmKppJrI;mouFpa6Zvi2;o0re6Y;ari0on;er,i4;e7Numb;li9KmJsiIveD;de,st;er9it;aMe8MiKrI;ang3eIi2;ng27w;fIng;f5le;b,gg1rI;t3ve;a4AiA;a4UeJit,l7DoI;il,of;ak,nd;lIot7Kw;icEve;atGeak,i0O;aIi6;m,y;ft,ng,t;aKi6CoJriIun;nk,v6Q;ot,rt5;ke,rp5tt1;eIll,nd,que8Gv1w;!k,m;aven9ul8W;dd5tis1Iy;a0FeKiJoI;am,t,ut;d,p5;a0Ab08c06d05f01group,hea00iZjoi4lXmWnVpTq3MsOtMup,vI;amp,eJiIo3B;sEve;l,rI;e,t;i8rI;ie2ofE;eLiKpo8PtIurfa4;o24rI;aHiBuctu8;de,gn,st;mb3nt;el,hra0lIreseF;a4e71;d1ew,o07;aHe3Fo2;a7eFiIo6Jy;e2nq41ve;mbur0nf38;r0t;inKleBocus,rJuI;el,rbiA;aBeA;an4e;aBu4;ei2k8Bla43oIyc3;gni39nci3up,v1;oot,uI;ff;ct,d,liIp;se,ze;tt3viA;aAenGit,o7;aWerUinpoiFlumm1LoTrLuI;b47ke,niArIt;poDsuI;aFe;eMoI;cKd,fe4XhibEmo7noJpo0sp1tru6vI;e,i6o5L;un4;la3Nu8;aGclu6dJf1occupy,sup0JvI;a6BeF;etermi4TiB;aGllu7rtr5Ksse4Q;cei2fo4NiAmea7plex,sIva6;eve8iCua6;mp1rItrol,ve;a6It6E;bOccuNmEpMutLverIwe;l07sJtu6Yu0wI;helm;ee,h1F;gr5Cnu2Cpa4;era7i4Ipo0;py,r;ey,seItaH;r2ss;aMe0ViJoIultiply;leCu6Pw;micJnIspla4;ce,g3us;!k;iIke,na9;m,ntaH;aPeLiIo0u3N;ke,ng1quIv5;eIi6S;fy;aKnIss5;d,gI;th5;rn,ve;ng2Gu1N;eep,idnJnI;e4Cow;ap;oHuI;gg3xtaI;po0;gno8mVnIrk;cTdRfQgeChPitia7ju8q1CsNtKun6EvI;a6eIo11;nt,rt,st;erJimi6BoxiPrI;odu4u6;aBn,pr03ru6C;iCpi8tIu8;all,il,ruB;abEibE;eCo3Eu0;iIul9;ca7;i7lu6;b5Xmer0pI;aLer4Uin9ly,oJrI;e3Ais6Bo2;rt,se,veI;riA;le,rt;aLeKiIoiCuD;de,jaInd1;ck;ar,iT;mp1ng,pp5raIve;ng5Mss;ath1et,iMle27oLrI;aJeIow;et;b,pp3ze;!ve5A;gg3ve;aTer45i5RlSorMrJuI;lf4Cndrai0r48;eJiIolic;ght5;e0Qsh5;b3XeLfeEgJsI;a3Dee;eIi2;!t;clo0go,shIwa4Z;ad3F;att1ee,i36;lt1st5;a0OdEl0Mm0FnXquip,rWsVtGvTxI;aRcPeDhOiNpJtIu6;ing0Yol;eKi8lIo0un9;aHoI;it,re;ct,di7l;st,t;a3oDu3B;e30lI;a10u6;lt,mi28;alua7oI;ke,l2;chew,pou0tab19;a0u4U;aYcVdTfSgQhan4joy,lPqOrNsuMtKvI;e0YisI;a9i50;er,i4rI;aHenGuC;e,re;iGol0F;ui8;ar9iC;a9eIra2ulf;nd1;or4;ang1oIu8;r0w;irc3lo0ou0ErJuI;mb1;oaGy4D;b3ct;bKer9pI;hasiIow1;ze;aKody,rI;a4oiI;d1l;lm,rk;ap0eBuI;ci40de;rIt;ma0Rn;a0Re04iKo,rIwind3;aw,ed9oI;wn;agno0e,ff1g,mi2Kne,sLvI;eIul9;rIst;ge,t;aWbVcQlod9mant3pNru3TsMtI;iIoDu37;lJngI;uiA;!l;ol2ua6;eJlIo0ro2;a4ea0;n0r0;a2Xe36lKoIu0S;uIv1;ra9;aIo0;im;a3Kur0;b3rm;af5b01cVduBep5fUliTmQnOpMrLsiCtaGvI;eIol2;lop;ch;a20i2;aDiBloIoD;re,y;oIy;te,un4;eJoI;liA;an;mEv1;a4i0Ao06raud,y;ei2iMla8oKrI;ee,yI;!pt;de,mIup3;missi34po0;de,ma7ph1;aJrief,uI;g,nk;rk;mp5rk5uF;a0Dea0h0Ai09l08oKrIurta1G;a2ea7ipp3uI;mb3;ales4e04habEinci6ll03m00nIrro6;cXdUfQju8no7qu1sLtKvI;eIin4;ne,r9y;aHin2Bribu7;er2iLoli2Epi8tJuI;lt,me;itu7raH;in;d1st;eKiJoIroFu0;rm;de,gu8rm;ss;eJoI;ne;mn,n0;eIlu6ur;al,i2;buCe,men4pI;eIi3ly;l,te;eBi6u6;r4xiC;ean0iT;rcumveFte;eJirp,oI;o0p;riAw;ncIre5t1ulk;el;a02eSi6lQoPrKuI;iXrIy;st,y;aLeaKiJoad5;en;ng;stfeLtX;ke;il,l11mba0WrrMth1;eIow;ed;!coQfrie1LgPhMliLqueaKstJtrIwild1;ay;ow;th;e2tt3;a2eJoI;ld;ad;!in,ui3;me;bysEckfi8ff3tI;he;b15c0Rd0Iff0Ggree,l0Cm09n03ppZrXsQttOuMvJwaE;it;eDoI;id;rt;gIto0X;meF;aIeCraB;ch,in;pi8sJtoI;niA;aKeIi04u8;mb3rt,ss;le;il;re;g0Hi0ou0rI;an9i2;eaKly,oiFrI;ai0o2;nt;r,se;aMi0GnJtI;icipa7;eJoIul;un4y;al;ly0;aJu0;se;lga08ze;iKlI;e9oIu6;t,w;gn;ix,oI;rd;a03jNmiKoJsoI;rb;pt,rn;niIt;st1;er;ouJuC;st;rn;cLhie2knowled9quiItiva7;es4re;ce;ge;eQliOoKrJusI;e,tom;ue;mIst;moJpI;any,liA;da7;ma7;te;pt;andPduBet,i6oKsI;coKol2;ve;liArt,uI;nd;sh;de;ct;on",
		"Person": "true¦0:1Q;a29b1Zc1Md1Ee18f15g13h0Ri0Qj0Nk0Jl0Gm09n06o05p00rPsItCusain bolt,v9w4xzibit,y1;anni,oko on2uji,v1;an,es;en,o;a3ednesday adams,i2o1;lfram,o0Q;ll ferrell,z khalifa;lt disn1Qr1;hol,r0G;a2i1oltai06;n dies0Zrginia wo17;lentino rossi,n goG;a4h3i2ripp,u1yra banks;lZpac shakur;ger woods,mba07;eresa may,or;kashi,t1ylor;um,ya1B;a5carlett johanss0h4i3lobodan milosevic,no2ocr1Lpider1uperm0Fwami; m0Em0E;op dogg,w whi1H;egfried,nbad;akespeaTerlock holm1Sia labeouf;ddam hussa16nt1;a cla11ig9;aAe6i5o3u1za;mi,n dmc,paul,sh limbau1;gh;bin hood,d stew16nald1thko;in0Mo;han0Yngo starr,valdo;ese witherspo0i1mbrandt;ll2nh1;old;ey,y;chmaninoff,ffi,iJshid,y roma1H;a4e3i2la16o1uff daddy;cahont0Ie;lar,p19;le,rZ;lm17ris hilt0;leg,prah winfr0Sra;a2e1iles cra1Bostradam0J; yo,l5tt06wmQ;pole0s;a5e4i2o1ubar03;by,lie5net,rriss0N;randa ju1tt romn0M;ly;rl0GssiaB;cklemo1rkov,s0ta hari,ya angelou;re;ady gaga,e1ibera0Pu;bron jam0Xch wale1e;sa;anye west,e3i1obe bryant;d cudi,efer suther1;la0P;ats,sha;a2effers0fk,k rowling,rr tolki1;en;ck the ripp0Mwaharlal nehru,y z;liTnez,ron m7;a7e5i3u1;lk hog5mphrey1sa01;! bog05;l1tl0H;de; m1dwig,nry 4;an;ile selassFlle ber4m3rrison1;! 1;ford;id,mo09;ry;ast0iannis,o1;odwPtye;ergus0lorence nightinga08r1;an1ederic chopN;s,z;ff5m2nya,ustaXzeki1;el;eril lagasse,i1;le zatop1nem;ek;ie;a6e4i2octor w1rake;ho;ck w1ego maradoC;olf;g1mi lovaOnzel washingt0;as;l1nHrth vadR;ai lNt0;a8h5lint0o1thulhu;n1olio;an,fuci1;us;on;aucKop2ristian baMy1;na;in;millo,ptain beefhe4r1;dinal wols2son1;! palmF;ey;art;a8e5hatt,i3oHro1;ck,n1;te;ll g1ng crosby;atB;ck,nazir bhut2rtil,yon1;ce;to;nksy,rack ob1;ama;l 6r3shton kutch2vril lavig8yn ra1;nd;er;chimed2istot1;le;es;capo2paci1;no;ne",
		"Adjective": "true¦0:AI;1:BS;2:BI;3:BA;4:A8;5:84;6:AV;7:AN;8:AF;9:7H;A:BQ;B:AY;C:BC;D:BH;E:9Y;aA2b9Ec8Fd7We79f6Ng6Eh61i4Xj4Wk4Tl4Im41n3Po36p2Oquart7Pr2Ds1Dt14uSvOwFye29;aMeKhIiHoF;man5oFrth7G;dADzy;despreB1n w97s86;acked1UoleF;!sa6;ather1PeFll o70ste1D;!k5;nt1Ist6Ate4;aHeGiFola5T;bBUce versa,gi3Lle;ng67rsa5R;ca1gBSluAV;lt0PnLpHrGsFttermoBL;ef9Ku3;b96ge1; Hb32pGsFtiAH;ca6ide d4R;er,i85;f52to da2;a0Fbeco0Hc0Bd04e02f01gu1XheaBGiXkn4OmUnTopp06pRrNsJtHus0wF;aFiel3K;nt0rra0P;app0eXoF;ld,uS;eHi37o5ApGuF;perv06spec39;e1ok9O;en,ttl0;eFu5;cogn06gul2RlGqu84sF;erv0olv0;at0en33;aFrecede0E;id,rallel0;am0otic0;aFet;rri0tF;ch0;nFq26vers3;sur0terFv7U;eFrupt0;st0;air,inish0orese98;mploy0n7Ov97xpF;ect0lain0;eHisFocume01ue;clFput0;os0;cid0rF;!a8Scov9ha8Jlyi8nea8Gprivileg0sMwF;aFei9I;t9y;hGircumcFonvin2U;is0;aFeck0;lleng0rt0;b20ppea85ssuGttend0uthorF;iz0;mi8;i4Ara;aLeIhoHip 25oGrF;anspare1encha1i2;geth9leADp notch,rpB;rny,ugh6H;ena8DmpGrFs6U;r49tia4;eCo8P;leFst4M;nt0;a0Dc09e07h06i04ki03l01mug,nobbi4XoVpRqueami4XtKuFymb94;bHccinAi generis,pFr5;erFre7N;! dup9b,vi70;du0li7Lp6IsFurb7J;eq9Atanda9X;aKeJi16o2QrGubboFy4Q;rn;aightFin5GungS; fFfF;or7V;adfa9Pri6;lwa6Ftu82;arHeGir6NlendBot Fry;on;c3Qe1S;k5se; call0lImb9phistic16rHuFviV;ndFth1B;proof;dBry;dFub6; o2A;e60ipF;pe4shod;ll0n d7R;g2HnF;ceEg6ist9;am3Se9;co1Zem5lfFn6Are7; suf4Xi43;aGholFient3A;ar5;rlFt4A;et;cr0me,tisfac7F;aOeIheumatoBiGoF;bu8Ztt7Gy3;ghtFv3; 1Sf6X;cJdu8PlInown0pro69sGtF;ard0;is47oF;lu2na1;e1Suc45;alcit8Xe1ondi2;bBci3mpa1;aSePicayu7laOoNrGuF;bl7Tnjabi;eKiIoF;b7VfGmi49pFxi2M;er,ort81;a7uD;maFor,sti7va2;!ry;ciDexis0Ima2CpaB;in55puli8G;cBid;ac2Ynt 3IrFti2;ma40tFv7W;!i3Z;i2YrFss7R;anoBtF; 5XiF;al,s5V;bSffQkPld OnMrLth9utKverF;!aIbMdHhGni75seas,t,wF;ei74rou74;a63e7A;ue;ll;do1Ger,si6A;d3Qg2Aotu5Z; bFbFe on o7g3Uli7;oa80;fashion0school;!ay; gua7XbFha5Uli7;eat;eHligGsF;ce7er0So1C;at0;diFse;a1e1;aOeNiMoGuF;anc0de; moEnHrthFt6V;!eFwe7L;a7Krn;chaGdescri7Iprof30sF;top;la1;ght5;arby,cessa4ighbor5wlyw0xt;k0usiaFv3;ti8;aQeNiLoHuF;dIltiF;facet0p6;deHlGnFot,rbBst;ochro4Xth5;dy;rn,st;ddle ag0nF;dbloZi,or;ag9diocEga,naGrFtropolit4Q;e,ry;ci8;cIgenta,inHj0Fkeshift,mmGnFri4Oscu61ver18;da5Dy;ali4Lo4U;!stream;abEho;aOeLiIoFumberi8;ngFuti1R;stan3RtF;erm,i4H;ghtGteraF;l,ry,te;heart0wei5O;ft JgFss9th3;al,eFi0M;nda4;nguBps0te5;apGind5noF;wi8;ut;ad0itte4uniW;ce co0Hgno6Mll0Cm04nHpso 2UrF;a2releF;va1; ZaYcoWdReQfOgrNhibi4Ri05nMoLsHtFvalu5M;aAeF;nDrdepe2K;a7iGolFuboI;ub6ve1;de,gF;nifica1;rdi5N;a2er;own;eriIiLluenVrF;ar0eq5H;pt,rt;eHiGoFul1O;or;e,reA;fiFpe26termi5E;ni2;mpFnsideCrreA;le2;ccuCdeq5Ene,ppr4J;fFsitu,vitro;ro1;mJpF;arHeGl15oFrop9;li2r11;n2LrfeA;ti3;aGeFi18;d4BnD;tuE;egGiF;c0YteC;al,iF;tiF;ma2;ld;aOelNiLoFuma7;a4meInHrrGsFur5;ti6;if4E;e58o3U; ma3GsF;ick;ghfalut2HspF;an49;li00pf33;i4llow0ndGrdFtM; 05coEworki8;sy,y;aLener44iga3Blob3oKrGuF;il1Nng ho;aFea1Fizzl0;cGtF;ef2Vis;ef2U;ld3Aod;iFuc2D;nf2R;aVeSiQlOoJrF;aGeFil5ug3;q43tf2O;gFnt3S;i6ra1;lk13oHrF; keeps,eFge0Vm9tu41;g0Ei2Ds3R;liF;sh;ag4Mowe4uF;e1or45;e4nF;al,i2;d Gmini7rF;ti6ve1;up;bl0lDmIr Fst pac0ux;oGreacF;hi8;ff;ed,ili0R;aXfVlTmQnOqu3rMthere3veryday,xF;aApIquisi2traHuF;be48lF;ta1;!va2L;edRlF;icF;it;eAstF;whi6; Famor0ough,tiE;rou2sui2;erGiF;ne1;ge1;dFe2Aoq34;er5;ficF;ie1;g9sF;t,ygF;oi8;er;aWeMiHoGrFue;ea4owY;ci6mina1ne,r31ti8ubQ;dact2Jfficult,m,sGverF;ge1se;creGePjoi1paCtF;a1inA;et,te; Nadp0WceMfiLgeneCliJmuEpeIreliAsGvoF;id,ut;pFtitu2ul1L;eCoF;nde1;ca2ghF;tf13;a1ni2;as0;facto;i5ngero0I;ar0Ce09h07i06l05oOrIuF;rmudgeon5stoma4teF;sy;ly;aIeHu1EystalF; cleFli7;ar;epy;fFv17z0;ty;erUgTloSmPnGrpoCunterclVveFy;rt;cLdJgr21jIsHtrF;aFi2;dic0Yry;eq1Yta1;oi1ug3;escenFuN;di8;a1QeFiD;it0;atoDmensuCpF;ass1SulF;so4;ni3ss3;e1niza1;ci1J;ockwiD;rcumspeAvil;eFintzy;e4wy;leGrtaF;in;ba2;diac,ef00;a00ePiLliJoGrFuck nak0;and new,isk,on22;gGldface,naF; fi05fi05;us;nd,tF;he;gGpartisFzarE;an;tiF;me;autifOhiNlLnHsFyoN;iWtselF;li8;eGiFt;gn;aFfi03;th;at0oF;v0w;nd;ul;ckwards,rF;e,rT; priori,b13c0Zd0Tf0Ng0Ihe0Hl09mp6nt06pZrTsQttracti0MuLvIwF;aGkF;wa1B;ke,re;ant garGeraF;ge;de;diIsteEtF;heFoimmu7;nt07;re;to4;hGlFtu2;eep;en;bitIchiv3roHtF;ifiFsy;ci3;ga1;ra4;ry;pFt;aHetizi8rF;oprF;ia2;llFre1;ed,i8;ng;iquFsy;at0e;ed;cohKiJkaHl,oGriFterX;ght;ne,of;li7;ne;ke,ve;olF;ic;ad;ain07gressiIi6rF;eeF;ab6;le;ve;fGraB;id;ectGlF;ue1;ioF;na2; JaIeGvF;erD;pt,qF;ua2;ma1;hoc,infinitum;cuCquiGtu3u2;al;esce1;ra2;erSjeAlPoNrKsGuF;nda1;e1olu2trF;aAuD;se;te;eaGuF;pt;st;aFve;rd;aFe;ze;ct;ra1;nt",
		"Pronoun": "true¦elle,h3i2me,she,th0us,we,you;e0ou;e,m,y;!l,t;e,im",
		"Preposition": "true¦aPbMcLdKexcept,fIinGmid,notwithstandiWoDpXqua,sCt7u4v2w0;/o,hereSith0;! whHin,oW;ersus,i0;a,s a vis;n1p0;!on;like,til;h1ill,oward0;!s;an,ereby,r0;ough0u;!oM;ans,ince,o that,uch G;f1n0ut;!to;!f;! 0to;effect,part;or,r0;om;espite,own,u3;hez,irca;ar1e0oBy;sides,tween;ri7;bo8cross,ft7lo6m4propos,round,s1t0;!op;! 0;a whole,long 0;as;id0ong0;!st;ng;er;ut",
		"SportsTeam": "true¦0:18;1:1E;2:1D;3:14;a1Db15c0Sd0Kfc dallas,g0Ihouston 0Hindiana0Gjacksonville jagua0k0El0Am01new UoRpKqueens parkJreal salt lake,sBt6utah jazz,vancouver whitecaps,w4yW;ashington 4h10;natio1Mredski2wizar0W;ampa bay 7e6o4;ronto 4ttenham hotspur;blue ja0Mrapto0;nnessee tita2xasD;buccanee0ra0K;a8eattle 6porting kansas0Wt4; louis 4oke0V;c1Drams;marine0s4;eah13ounH;cramento Rn 4;antonio spu0diego 4francisco gJjose earthquak1;char08paB; ran07;a9h6ittsburgh 5ortland t4;imbe0rail blaze0;pirat1steele0;il4oenix su2;adelphia 4li1;eagl1philNunE;dr1;akland 4klahoma city thunder,rlando magic;athle0Lrai4;de0;england 8orleans 7york 4;g5je3knYme3red bul0Xy4;anke1;ian3;pelica2sain3;patrio3revolut4;ion;anchEeAi4ontreal impact;ami 8lwaukee b7nnesota 4;t5vi4;kings;imberwolv1wi2;rewe0uc0J;dolphi2heat,marli2;mphis grizz4ts;li1;a6eic5os angeles 4;clippe0dodFlaB;esterV; galaxy,ke0;ansas city 4nF;chiefs,roya0D; pace0polis col3;astr05dynamo,rocke3texa2;olden state warrio0reen bay pac4;ke0;allas 8e4i04od6;nver 6troit 4;lio2pisto2ti4;ge0;broncYnugge3;cowbo5maver4;icZ;ys;arEelLhAincinnati 8leveland 6ol4;orado r4umbus crew sc;api7ocki1;brow2cavalie0guar4in4;dia2;bengaVre4;ds;arlotte horAicago 4;b5cubs,fire,wh4;iteB;ea0ulQ;diff4olina panthe0; city;altimore Alackburn rove0oston 6rooklyn 4uffalo bilN;ne3;ts;cel5red4; sox;tics;rs;oriol1rave2;rizona Ast8tlanta 4;brav1falco2h4;awA;ns;es;on villa,r4;os;c6di4;amondbac4;ks;ardi4;na4;ls",
		"Unit": "true¦a07b04cXdWexVfTgRhePinYjoule0BkMlJmDnan08oCp9quart0Bsq ft,t7volts,w6y2ze3°1µ0;g,s;c,f,n;dVear1o0;ttR; 0s 0;old;att,b;erNon0;!ne02;ascals,e1i0;cXnt00;rcent,tJ;hms,unceY;/s,e4i0m²,²,³;/h,cro2l0;e0liK;!²;grLsR;gCtJ;it1u0;menQx;erPreP;b5elvins,ilo1m0notO;/h,ph,²;!byGgrEmCs;ct0rtzL;aJogrC;allonJb0ig3rB;ps;a0emtEl oz,t4;hrenheit,radG;aby9;eci3m1;aratDe1m0oulombD;²,³;lsius,nti0;gr2lit1m0;et0;er8;am7;b1y0;te5;l,ps;c2tt0;os0;econd1;re0;!s",
		"Noun|Gerund": "true¦0:3O;1:3M;2:3N;3:3D;4:32;5:2V;6:3E;7:3K;8:36;9:3J;A:3B;a3Pb37c2Jd27e23f1Vg1Sh1Mi1Ij1Gk1Dl18m13n11o0Wp0Pques0Sr0EsTtNunderMvKwFyDzB;eroi0oB;ni0o3P;aw2eB;ar2l3;aEed4hispe5i5oCrB;ap8est3i1;n0ErB;ki0r31;i1r2s9tc9;isualizi0oB;lunt1Vti0;stan4ta6;aFeDhin6iCraBy8;c6di0i2vel1M;mi0p8;aBs1;c9si0;l6n2s1;aUcReQhOiMkatKl2Wmo6nowJpeItFuCwB;ea5im37;b35f0FrB;fi0vB;e2Mi2J;aAoryt1KrCuB;d2KfS;etc9ugg3;l3n4;bCi0;ebBi0;oar4;gnBnAt1;a3i0;ip8oB;p8rte2u1;a1r27t1;hCo5reBulp1;a2Qe2;edu3oo3;i3yi0;aKeEi4oCuB;li0n2;oBwi0;fi0;aFcEhear7laxi0nDpor1sB;pon4tructB;r2Iu5;de5;or4yc3;di0so2;p8ti0;aFeacek20laEoCrBublis9;a1Teten4in1oces7;iso2siB;tio2;n2yi0;ckaAin1rB;ki0t1O;fEpeDrganiCvB;erco24ula1;si0zi0;ni0ra1;fe5;avi0QeBur7;gotia1twor6;aDeCi2oB;de3nito5;a2dita1e1ssaA;int0XnBrke1;ifUufactu5;aEeaDiBodAyi0;cen7f1mi1stB;e2i0;r2si0;n4ug9;iCnB;ea4it1;c6l3;ogAuB;dAgg3stif12;ci0llust0VmDnBro2;nova1sp0NterBven1;ac1vie02;agi2plo4;aDea1iCoBun1;l4w3;ki0ri0;nd3rB;roWvB;es1;aCene0Lli4rBui4;ee1ie0N;rde2the5;aHeGiDlCorBros1un4;e0Pmat1;ir1oo4;gh1lCnBs9;anZdi0;i0li0;e3nX;r0Zscina1;a1du01nCxB;erci7plo5;chan1di0ginB;ee5;aLeHiGoub1rCum8wB;el3;aDeCiB;bb3n6vi0;a0Qs7;wi0;rTscoDvi0;ba1coZlBvelo8;eCiB;ve5;ga1;nGti0;aVelebUhSlPoDrBur3yc3;aBos7yi0;f1w3;aLdi0lJmFnBo6pi0ve5;dDsCvinB;ci0;trBul1;uc1;muniDpB;lBo7;ai2;ca1;lBo5;ec1;c9ti0;ap8eaCimToBubT;ni0t9;ni0ri0;aBee5;n1t1;ra1;m8rCs1te5;ri0;vi0;aPeNitMlLoGrDuB;dge1il4llBr8;yi0;an4eat9oadB;cas1;di0;a1mEokB;i0kB;ee8;pi0;bi0;es7oa1;c9i0;gin2lonAt1;gi0;bysit1c6ki0tt3;li0;ki0;bando2cGdverti7gi0pproac9rgDssuCtB;trac1;mi0;ui0;hi0;si0;coun1ti0;ti0;ni0;ng",
		"PhrasalVerb": "true¦0:92;1:96;2:8H;3:8V;4:8A;5:83;6:85;7:98;8:90;9:8G;A:8X;B:8R;C:8U;D:8S;E:70;F:97;G:8Y;H:81;I:7H;J:79;a9Fb7Uc6Rd6Le6Jf5Ig50h4Biron0j47k40l3Em31n2Yo2Wp2Cquiet Hr1Xs0KtZuXvacuu6QwNyammerBzK;ero Dip LonK;e0k0;by,ov9up;aQeMhLiKor0Mrit19;mp0n3Fpe0r5s5;ackAeel Di0S;aLiKn33;gh 3Wrd0;n Dr K;do1in,oJ;it 79k5lk Lrm 69sh Kt83v60;aw3do1o7up;aw3in,oC;rgeBsK;e 2herE;a00eYhViRoQrMuKypP;ckErn K;do1in,oJup;aLiKot0y 30;ckl7Zp F;ck HdK;e 5Y;n7Wp 3Es5K;ck MdLe Kghten 6me0p o0Rre0;aw3ba4do1in,up;e Iy 2;by,oG;ink Lrow K;aw3ba4in,up;ba4ov9up;aKe 77ll62;m 2r 5M;ckBke Llk K;ov9shit,u47;aKba4do1in,leave,o4Dup;ba4ft9pa69w3;a0Vc0Te0Mh0Ii0Fl09m08n07o06p01quar5GtQuOwK;earMiK;ngLtch K;aw3ba4o8K; by;cKi6Bm 2ss0;k 64;aReQiPoNrKud35;aigh2Det75iK;ke 7Sng K;al6Yup;p Krm2F;by,in,oG;c3Ln3Lr 2tc4O;p F;c3Jmp0nd LrKveAy 2O;e Ht 2L;ba4do1up;ar3GeNiMlLrKurB;ead0ingBuc5;a49it 6H;c5ll o3Cn 2;ak Fe1Xll0;a3Bber 2rt0und like;ap 5Vow Duggl5;ash 6Noke0;eep NiKow 6;cLp K;o6Dup;e 68;in,oK;ff,v9;de19gn 4NnKt 6Gz5;gKkE; al6Ale0;aMoKu5W;ot Kut0w 7M;aw3ba4f48oC;c2WdeEk6EveA;e Pll1Nnd Orv5tK; Ktl5J;do1foLin,o7upK;!on;ot,r5Z;aw3ba4do1in,o33up;oCto;al66out0rK;ap65ew 6J;ilAv5;aXeUiSoOuK;b 5Yle0n Kstl5;aLba4do1inKo2Ith4Nu5P;!to;c2Xr8w3;ll Mot LpeAuK;g3Ind17;a2Wf3Po7;ar8in,o7up;ng 68p oKs5;ff,p18;aKelAinEnt0;c6Hd K;o4Dup;c27t0;aZeYiWlToQrOsyc35uK;ll Mn5Kt K;aKba4do1in,oJto47up;pa4Dw3;a3Jdo1in,o21to45up;attleBess KiNop 2;ah2Fon;iLp Kr4Zu1Gwer 6N;do1in,o6Nup;nt0;aLuK;gEmp 6;ce u20y 6D;ck Kg0le 4An 6p5B;oJup;el 5NncilE;c53ir 39n0ss MtLy K;ba4oG; Hc2R;aw3ba4in,oJ;pKw4Y;e4Xt D;aLerd0oK;dAt53;il Hrrow H;aTeQiPoLuK;ddl5ll I;c1FnkeyMp 6uthAve K;aKdo1in,o4Lup;l4Nw3; wi4K;ss0x 2;asur5e3SlLss K;a21up;t 6;ke Ln 6rKs2Ax0;k 6ryA;do,fun,oCsure,up;a02eViQoLuK;ck0st I;aNc4Fg MoKse0;k Kse4D;aft9ba4do1forw37in56o0Zu46;in,oJ;d 6;e NghtMnLsKve 00;ten F;e 2k 2; 2e46;ar8do1in;aMt LvelK; oC;do1go,in,o7up;nEve K;in,oK;pKut;en;c5p 2sh LtchBughAy K;do1o59;in4Po7;eMick Lnock K;do1oCup;oCup;eLy K;in,up;l Ip K;aw3ba4do1f04in,oJto,up;aMoLuK;ic5mpE;ke3St H;c43zz 2;a01eWiToPuK;nLrrKsh 6;y 2;keLt K;ar8do1;r H;lKneErse3K;d Ke 2;ba4dKfast,o0Cup;ear,o1;de Lt K;ba4on,up;aw3o7;aKlp0;d Ml Ir Kt 2;fKof;rom;f11in,o03uW;cPm 2nLsh0ve Kz2P;at,it,to;d Lg KkerP;do1in,o2Tup;do1in,oK;ut,v9;k 2;aZeTive Rloss IoMrLunK; f0S;ab hold,in43ow 2U; Kof 2I;aMb1Mit,oLr8th1IuK;nd9;ff,n,v9;bo7ft9hQw3;aw3bKdo1in,oJrise,up,w3;a4ir2H;ar 6ek0t K;aLb1Fdo1in,oKr8up;ff,n,ut,v9;cLhKl2Fr8t,w3;ead;ross;d aKng 2;bo7;a0Ee07iYlUoQrMuK;ck Ke2N;ar8up;eLighten KownBy 2;aw3oG;eKshe27; 2z5;g 2lMol Krk I;aKwi20;bo7r8;d 6low 2;aLeKip0;sh0;g 6ke0mKrKtten H;e F;gRlPnNrLsKzzle0;h F;e Km 2;aw3ba4up;d0isK;h 2;e Kl 1T;aw3fPin,o7;ht ba4ure0;ePnLsK;s 2;cMd K;fKoG;or;e D;d04l 2;cNll Krm0t1G;aLbKdo1in,o09sho0Eth08victim;a4ehi2O;pa0C;e K;do1oGup;at Kdge0nd 12y5;in,o7up;aOi1HoNrK;aLess 6op KuN;aw3b03in,oC;gBwB; Ile0ubl1B;m 2;a0Ah05l02oOrLut K;aw3ba4do1oCup;ackBeep LoKy0;ss Dwd0;by,do1in,o0Uup;me NoLuntK; o2A;k 6l K;do1oG;aRbQforOin,oNtKu0O;hLoKrue;geth9;rough;ff,ut,v9;th,wK;ard;a4y;paKr8w3;rt;eaLose K;in,oCup;n 6r F;aNeLiK;ll0pE;ck Der Kw F;on,up;t 2;lRncel0rOsMtch LveE; in;o1Nup;h Dt K;doubt,oG;ry LvK;e 08;aw3oJ;l Km H;aLba4do1oJup;ff,n,ut;r8w3;a0Ve0MiteAl0Fo04rQuK;bblNckl05il0Dlk 6ndl05rLsKtMy FzzA;t 00;n 0HsK;t D;e I;ov9;anWeaUiLush K;oGup;ghQng K;aNba4do1forMin,oLuK;nd9p;n,ut;th;bo7lKr8w3;ong;teK;n 2;k K;do1in,o7up;ch0;arTg 6iRn5oPrNssMttlLunce Kx D;aw3ba4;e 6; ar8;e H;do1;k Dt 2;e 2;l 6;do1up;d 2;aPeed0oKurt0;cMw K;aw3ba4do1o7up;ck;k K;in,oC;ck0nk0stA; oQaNef 2lt0nd K;do1ov9up;er;up;r Lt K;do1in,oCup;do1o7;ff,nK;to;ck Pil0nMrgLsK;h D;ainBe D;g DkB; on;in,o7;aw3do1in,oCup;ff,ut;ay;ct FdQir0sk MuctionA; oG;ff;ar8o7;ouK;nd; o7;d K;do1oKup;ff,n;wn;o7up;ut",
		"ProperNoun": "true¦aIbDc8dalhousHe7f5gosford,h4iron maiden,kirby,landsdowne,m2nis,r1s0wembF;herwood,paldiB;iel,othwe1;cgi0ercedes,issy;ll;intBudsB;airview,lorence,ra0;mpt9nco;lmo,uro;a1h0;arlt6es5risti;rl0talina;et4i0;ng;arb3e0;et1nt0rke0;ley;on;ie;bid,jax",
		"Person|Place": "true¦a8d6h4jordan,k3orlando,s1vi0;ctor9rgin9;a0ydney;lvador,mara,ntia4;ent,obe;amil0ous0;ton;arw2ie0;go;lexandr1ust0;in;ia",
		"LastName": "true¦0:BR;1:BF;2:B5;3:BH;4:AX;5:9Y;6:B6;7:BK;8:B0;9:AV;A:AL;B:8Q;C:8G;D:7K;E:BM;F:AH;aBDb9Zc8Wd88e81f7Kg6Wh64i60j5Lk4Vl4Dm39n2Wo2Op25quispe,r1Ls0Pt0Ev03wTxSyKzG;aIhGimmerm6A;aGou,u;ng,o;khar5ytsE;aKeun9BiHoGun;koya32shiBU;!lG;diGmaz;rim,z;maGng;da,g52mo83sGzaC;aChiBV;iao,u;aLeJiHoGright,u;jcA5lff,ng;lGmm0nkl0sniewsC;kiB1liams33s3;bGiss,lt0;b,er,st0;a6Vgn0lHtG;anabe,s3;k0sh,tG;e2Non;aLeKiHoGukD;gt,lk5roby5;dHllalGnogr3Kr1Css0val3S;ba,ob1W;al,ov4;lasHsel8W;lJn dIrgBEsHzG;qu7;ilyEqu7siljE;en b6Aijk,yk;enzueAIverde;aPeix1VhKi2j8ka43oJrIsui,uG;om5UrG;c2n0un1;an,emblA7ynisC;dorAMlst3Km4rrAth;atch0i8UoG;mHrG;are84laci79;ps3sG;en,on;hirDkah9Mnaka,te,varA;a06ch01eYhUiRmOoMtIuHvGzabo;en9Jobod3N;ar7bot4lliv2zuC;aIeHoG;i7Bj4AyanAB;ele,in2FpheBvens25;l8rm0;kol5lovy5re7Tsa,to,uG;ng,sa;iGy72;rn5tG;!h;l71mHnGrbu;at9cla9Egh;moBo7M;aIeGimizu;hu,vchG;en8Luk;la,r1G;gu9infe5YmGoh,pulveA7rra5P;jGyG;on5;evi6iltz,miHneid0roed0uGwarz;be3Elz;dHtG;!t,z;!t;ar4Th8ito,ka4OlJnGr4saCto,unde19v4;ch7dHtGz;a5Le,os;b53e16;as,ihDm4Po0Y;aVeSiPoJuHyG;a6oo,u;bio,iz,sG;so,u;bKc8Fdrigue67ge10j9YmJosevelt,sItHux,wG;e,li6;a9Ch;enb4Usi;a54e4L;erts15i93;bei4JcHes,vGzzo;as,e9;ci,hards12;ag2es,iHut0yG;es,nol5N;s,t0;dImHnGsmu97v6C;tan1;ir7os;ic,u;aUeOhMiJoHrGut8;asad,if6Zochazk27;lishc2GpGrti72u10we76;e3Aov51;cHe45nG;as,to;as70hl0;aGillips;k,m,n6I;a3Hde3Wete0Bna,rJtG;ersHrovGters54;!a,ic;!en,on;eGic,kiBss3;i9ra,tz,z;h86k,padopoulIrk0tHvG;ic,l4N;el,te39;os;bMconn2Ag2TlJnei6PrHsbor6XweBzG;dem7Rturk;ella4DtGwe6N;ega,iz;iGof7Hs8I;vGyn1R;ei9;aSri1;aPeNiJoGune50ym2;rHvGwak;ak4Qik5otn66;odahl,r4S;cholsZeHkolGls4Jx3;ic,ov84;ls1miG;!n1;ils3mG;co4Xec;gy,kaGray2sh,var38;jiGmu9shiG;ma;a07c04eZiWoMuHyeG;rs;lJnIrGssoli6S;atGp03r7C;i,ov4;oz,te58;d0l0;h2lOnNo0RrHsGza1A;er,s;aKeJiIoz5risHtG;e56on;!on;!n7K;au,i9no,t5J;!lA;r1Btgome59;i3El0;cracFhhail5kkeHlG;l0os64;ls1;hmeJiIj30lHn3Krci0ssiGyer2N;!er;n0Po;er,j0;dDti;cartHlG;aughl8e2;hy;dQe7Egnu68i0jer3TkPmNnMrItHyG;er,r;ei,ic,su21thews;iHkDquAroqu8tinG;ez,s;a5Xc,nG;!o;ci5Vn;a5UmG;ad5;ar5e6Kin1;rig77s1;aVeOiLoJuHyG;!nch;k4nGo;d,gu;mbarGpe3Fvr4we;di;!nGu,yana2B;coln,dG;b21holm,strom;bedEfeKhIitn0kaHn8rGw35;oy;!j;m11tG;in1on1;bvGvG;re;iGmmy,ng,rs2Qu,voie,ws3;ne,t1F;aZeYh2iWlUnez50oNrJuHvar2woG;k,n;cerGmar68znets5;a,o34;aHem0isGyeziu;h23t3O;m0sni4Fus3KvG;ch4O;bay57ch,rh0Usk16vaIwalGzl5;czGsC;yk;cIlG;!cGen4K;huk;!ev4ic,s;e8uiveG;rt;eff0kGl4mu9nnun1;ucF;ll0nnedy;hn,llKminsCne,pIrHstra3Qto,ur,yGzl5;a,s0;j0Rls22;l2oG;or;oe;aPenOha6im14oHuG;ng,r4;e32hInHrge32u6vG;anD;es,ss3;anHnsG;en,on,t3;nesGs1R;en,s1;kiBnings,s1;cJkob4EnGrv0E;kDsG;en,sG;en0Ion;ks3obs2A;brahimDglesi5Nke5Fl0Qno07oneIshikHto,vanoG;u,v54;awa;scu;aVeOiNjaltal8oIrist50uG;!aGb0ghAynh;m2ng;a6dz4fIjgaa3Hk,lHpUrGwe,x3X;ak1Gvat;mAt;er,fm3WmG;ann;ggiBtchcock;iJmingw4BnHrGss;nand7re9;deGriks1;rs3;kkiHnG;on1;la,n1;dz4g1lvoQmOns0ZqNrMsJuIwHyG;asFes;kiB;g1ng;anHhiG;mo14;i,ov0J;di6p0r10t;ue;alaG;in1;rs1;aVeorgUheorghe,iSjonRoLrJuGw3;errGnnar3Co,staf3Ctierr7zm2;a,eG;ro;ayli6ee2Lg4iffithGub0;!s;lIme0UnHodGrbachE;e,m2;calvAzale0S;dGubE;bGs0E;erg;aj,i;bs3l,mGordaO;en7;iev3U;gnMlJmaIndFo,rGsFuthi0;cGdn0za;ia;ge;eaHlG;agh0i,o;no;e,on;aVerQiLjeldsted,lKoIrHuG;chs,entAji41ll0;eem2iedm2;ntaGrt8urni0wl0;na;emi6orA;lipIsHtzgeraG;ld;ch0h0;ovG;!ic;hatDnanIrG;arGei9;a,i;deY;ov4;b0rre1D;dKinsJriksIsGvaB;cob3GpGtra3D;inoza,osiQ;en,s3;te8;er,is3warG;ds;aXePiNjurhuMoKrisco15uHvorakG;!oT;arte,boHmitru,nn,rGt3C;and,ic;is;g2he0Omingu7nErd1ItG;to;us;aGcki2Hmitr2Ossanayake,x3;s,z; JbnaIlHmirGrvisFvi,w2;!ov4;gado,ic;th;bo0groot,jo6lHsilGvriA;va;a cruz,e3uG;ca;hl,mcevsCnIt2WviG;dGes,s;ov,s3;ielsGku22;!en;ki;a0Be06hRiobQlarkPoIrGunningh1H;awfo0RivGuz;elli;h1lKntJoIrGs2Nx;byn,reG;a,ia;ke,p0;i,rer2K;em2liB;ns;!e;anu;aOeMiu,oIristGu6we;eGiaG;ns1;i,ng,p9uHwGy;!dH;dGng;huJ;!n,onGu6;!g;kJnIpm2ttHudhGv7;ry;erjee,o14;!d,g;ma,raboG;rty;bJl0Cng4rG;eghetHnG;a,y;ti;an,ota1C;cerAlder3mpbeLrIstGvadi0B;iGro;llo;doHl0Er,t0uGvalho;so;so,zo;ll;a0Fe01hYiXlUoNrKuIyG;rLtyG;qi;chan2rG;ke,ns;ank5iem,oGyant;oks,wG;ne;gdan5nIruya,su,uchaHyKziG;c,n5;rd;darGik;enG;ko;ov;aGond15;nco,zG;ev4;ancFshw16;a08oGuiy2;umGwmG;ik;ckRethov1gu,ktPnNrG;gJisInG;ascoGds1;ni;ha;er,mG;anG;!n;gtGit7nP;ss3;asF;hi;er,hG;am;b4ch,ez,hRiley,kk0ldw8nMrIshHtAu0;es;ir;bInHtlGua;ett;es,i0;ieYosa;dGik;a9yoG;padhyG;ay;ra;k,ng;ic;bb0Acos09d07g04kht05lZnPrLsl2tJyG;aHd8;in;la;chis3kiG;ns3;aImstro6sl2;an;ng;ujo,ya;dJgelHsaG;ri;ovG;!a;ersJov,reG;aGjEws;ss1;en;en,on,s3;on;eksejEiyEmeiIvG;ar7es;ez;da;ev;arwHuilG;ar;al;ams,l0;er;ta;as",
		"Ordinal": "true¦eBf7nin5s3t0zeroE;enDhir1we0;lfCn7;d,t3;e0ixt8;cond,vent7;et0th;e6ie7;i2o0;r0urt3;tie4;ft1rst;ight0lev1;e0h,ie1;en0;th",
		"Cardinal": "true¦bEeBf5mEnine7one,s4t0zero;en,h2rDw0;e0o;lve,n5;irt6ousands,ree;even2ix2;i3o0;r1ur0;!t2;ty;ft0ve;e2y;ight0lev1;!e0y;en;illions",
		"Multiple": "true¦b3hundred,m3qu2se1t0;housand,r2;pt1xt1;adr0int0;illion",
		"City": "true¦0:74;1:61;2:6G;3:6J;4:5S;a68b53c4Id48e44f3Wg3Hh39i31j2Wk2Fl23m1Mn1Co19p0Wq0Ur0Os05tRuQvLwDxiBy9z5;a7h5i4Muri4O;a5e5ongsh0;ng3H;greb,nzib5G;ang2e5okoha3Sunfu;katerin3Hrev0;a5n0Q;m5Hn;arsBeAi6roclBu5;h0xi,zh5P;c7n5;d5nipeg,terth4;hoek,s1L;hi5Zkl3A;l63xford;aw;a8e6i5ladivost5Molgogr6L;en3lni6S;ni22r5;o3saill4N;lenc4Wncouv3Sr3ughn;lan bat1Crumqi,trecht;aFbilisi,eEheDiBo9r7u5;l21n63r5;in,ku;i5ondh62;es51poli;kyo,m2Zron1Pulo5;n,uS;an5jua3l2Tmisoa6Bra3;j4Tshui; hag62ssaloni2H;gucigal26hr0l av1U;briz,i6llinn,mpe56ng5rtu,shk2R;i3Esh0;an,chu1n0p2Eyu0;aEeDh8kopje,owe1Gt7u5;ra5zh4X;ba0Ht;aten is55ockholm,rasbou67uttga2V;an8e6i5;jiazhua1llo1m5Xy0;f50n5;ya1zh4H;gh3Kt4Q;att45o1Vv44;cramen16int ClBn5o paulo,ppo3Rrajevo; 7aa,t5;a 5o domin3E;a3fe,m1M;antonio,die3Cfrancisco,j5ped3Nsalvad0J;o5u0;se;em,t lake ci5Fz25;lou58peters24;a9e8i6o5;me,t59;ga,o5yadh;! de janei3F;cife,ims,nn3Jykjavik;b4Sip4lei2Inc2Pwalpindi;ingdao,u5;ez2i0Q;aFeEhDiCo9r7u6yong5;ya1;eb59ya1;a5etor3M;g52to;rt5zn0; 5la4Co;au prin0Melizabe24sa03;ls3Prae5Atts26;iladelph3Gnom pe1Aoenix;ki1tah tik3E;dua,lerYnaji,r4Ot5;na,r32;ak44des0Km1Mr6s5ttawa;a3Vlo;an,d06;a7ew5ing2Fovosibir1Jyc; 5cast36;del24orlea44taip14;g8iro4Wn5pl2Wshv33v0;ch6ji1t5;es,o1;a1o1;a6o5p4;ya;no,sa0W;aEeCi9o6u5;mb2Ani26sc3Y;gadishu,nt6s5;c13ul;evideo,pelli1Rre2Z;ami,l6n14s5;kolc,sissauga;an,waukee;cca,d5lbour2Mmph41ndo1Cssi3;an,ell2Xi3;cau,drAkass2Sl9n8r5shh4A;aca6ib5rakesh,se2L;or;i1Sy;a4EchFdal0Zi47;mo;id;aDeAi8o6u5vSy2;anMckn0Odhia3;n5s angel26;d2g bea1N;brev2Be3Lma5nz,sb2verpo28;!ss27; ma39i5;c5pzig;est16; p6g5ho2Wn0Cusan24;os;az,la33;aHharFiClaipeBo9rak0Du7y5;iv,o5;to;ala lump4n5;mi1sh0;hi0Hlka2Xpavog4si5wlo2;ce;da;ev,n5rkuk;gst2sha5;sa;k5toum;iv;bHdu3llakuric0Qmpa3Fn6ohsiu1ra5un1Iwaguc0Q;c0Pj;d5o,p4;ah1Ty;a7e6i5ohannesV;l1Vn0;dd36rusalem;ip4k5;ar2H;bad0mph1OnArkutUs7taXz5;mir,tapala5;pa;fah0l6tanb5;ul;am2Zi2H;che2d5;ianap2Mo20;aAe7o5yder2W; chi mi5ms,nolulu;nh;f6lsin5rakli2;ki;ei;ifa,lifax,mCn5rb1Dva3;g8nov01oi;aFdanEenDhCiPlasgBo9raz,u5;a5jr23;dal6ng5yaquil;zh1J;aja2Oupe;ld coa1Bthen5;bu2S;ow;ent;e0Uoa;sk;lw7n5za;dhi5gt1E;nag0U;ay;aisal29es,o8r6ukuya5;ma;ankfu5esno;rt;rt5sh0; wor6ale5;za;th;d5indhov0Pl paso;in5mont2;bur5;gh;aBe8ha0Xisp4o7resd0Lu5;b5esseldorf,nkirk,rb0shanbe;ai,l0I;ha,nggu0rtmu13;hradSl6nv5troit;er;hi;donghIe6k09l5masc1Zr es sala1KugavpiY;i0lU;gu,je2;aJebu,hAleve0Vo5raio02uriti1Q;lo7n6penhag0Ar5;do1Ok;akKst0V;gUm5;bo;aBen8i6ongqi1ristchur5;ch;ang m7ca5ttago1;go;g6n5;ai;du,zho1;ng5ttogr14;ch8sha,zh07;gliari,i9lga8mayenJn6pe town,r5tanO;acCdiff;ber1Ac5;un;ry;ro;aWeNhKirmingh0WoJr9u5;chareTdapeTenos air7r5s0tu0;g5sa;as;es;a9is6usse5;ls;ba6t5;ol;ne;sil8tisla7zzav5;il5;le;va;ia;goZst2;op6ubaneshw5;ar;al;iCl9ng8r5;g6l5n;in;en;aluru,hazi;fa6grade,o horizon5;te;st;ji1rut;ghd0BkFn9ot8r7s6yan n4;ur;el,r07;celo3i,ranquil09;ou;du1g6ja lu5;ka;alo6k5;ok;re;ng;ers5u;field;a05b02cc01ddis aba00gartaZhmedXizawl,lSmPnHqa00rEsBt7uck5;la5;nd;he7l5;an5;ta;ns;h5unci2;dod,gab5;at;li5;ngt2;on;a8c5kaOtwerp;hora6o3;na;ge;h7p5;ol5;is;eim;aravati,m0s5;terd5;am; 7buquerq6eppo,giers,ma5;ty;ue;basrah al qadim5mawsil al jadid5;ah;ab5;ad;la;ba;ra;idj0u dha5;bi;an;lbo6rh5;us;rg",
		"Region": "true¦0:2O;1:2L;2:2U;3:2F;a2Sb2Fc21d1Wes1Vf1Tg1Oh1Ki1Fj1Bk16l13m0Sn09o07pYqVrSsJtEuBverAw6y4zacatec2W;akut0o0Fu4;cat1k09;a5est 4isconsin,yomi1O;bengal,virgin0;rwick3shington4;! dc;acruz,mont;dmurt0t4;ah,tar4; 2Pa12;a6e5laxca1Vripu21u4;scaEva;langa2nnessee,x2J;bas10m4smQtar29;aulip2Hil nadu;a9elang07i7o5taf16u4ylh1J;ff02rr09s1E;me1Gno1Uuth 4;cZdY;ber0c4kkim,naloa;hu1ily;n5rawak,skatchew1xo4;ny; luis potosi,ta catari2;a4hodeA;j4ngp0C;asth1shahi;ingh29u4;e4intana roo;bec,en6retaro;aAe6rince edward4unjab; i4;sl0G;i,n5r4;ak,nambu0F;a0Rnsylv4;an0;ha0Pra4;!na;axa0Zdisha,h4klaho21ntar4reg7ss0Dx0I;io;aLeEo6u4;evo le4nav0X;on;r4tt18va scot0;f9mandy,th4; 4ampton3;c6d5yo4;rk3;ako1O;aroli2;olk;bras1Nva0Dw4; 6foundland4;! and labrad4;or;brunswick,hamp3jers5mexiTyork4;! state;ey;galPyarit;aAeghala0Mi6o4;nta2r4;dov0elos;ch6dlanDn5ss4zor11;issippi,ouri;as geraPneso18;ig1oac1;dhy12harasht0Gine,lac07ni5r4ssachusetts;anhao,i el,ylG;p4toba;ur;anca3e4incoln3ouisI;e4iR;ds;a6e5h4omi;aka06ul2;dah,lant1ntucky,ra01;bardino,lmyk0ns0Qr4;achay,el0nata0X;alis6har4iangxi;kh4;and;co;daho,llino7n4owa;d5gush4;et0;ia2;is;a6ert5i4un1;dalFm0D;ford3;mp3rya2waii;ansu,eorg0lou7oa,u4;an4izhou,jarat;ajuato,gdo4;ng;cester3;lori4uji1;da;sex;ageUe7o5uran4;go;rs4;et;lawaMrby3;aFeaEh9o4rim08umbr0;ahui7l6nnectic5rsi4ventry;ca;ut;i03orado;la;e5hattisgarh,i4uvash0;apRhuahua;chn5rke4;ss0;ya;ra;lGm4;bridge3peche;a9ihar,r8u4;ck4ryat0;ingham3;shi4;re;emen,itish columb0;h0ja cal8lk7s4v7;hkorto4que;st1;an;ar0;iforn0;ia;dygHguascalientes,lBndhr9r5ss4;am;izo2kans5un4;achal 7;as;na;a 4;pradesh;a6ber5t4;ai;ta;ba5s4;ka;ma;ea",
		"Place": "true¦0:4T;1:4V;2:44;3:4B;4:3I;a4Eb3Gc2Td2Ge26f25g1Vh1Ji1Fk1Cl14m0Vn0No0Jp08r04sTtNuLvJw7y5;a5o0Syz;kut1Bngtze;aDeChitBi9o5upatki,ycom2P;ki26o5;d5l1B;b3Ps5;i4to3Y;c0SllowbroCn5;c2Qgh2;by,chur1P;ed0ntw3Gs22;ke6r3St5;erf1f1; is0Gf3V;auxha3Mirgin is0Jost5;ok;laanbaatar,pto5xb3E;n,wn;a9eotihuac43h7ive49o6ru2Nsarskoe selo,u5;l2Dzigo47;nto,rquay,tt2J;am3e 5orn3E;bronx,hamptons;hiti,j mah0Iu1N;aEcotts bluff,eCfo,herbroQoApring9t7u5yd2F;dbu1Wn5;der03set3B;aff1ock2Nr5;atf1oud;hi37w24;ho,uth5; 1Iam1Zwo3E;a5i2O;f2Tt0;int lawrence riv3Pkhal2D;ayleigh,ed7i5oc1Z;chmo1Eo gran4ver5;be1Dfr09si4; s39cliffe,hi2Y;aCe9h8i5ompeii,utn2;c6ne5tcai2T; 2Pc0G;keri13t0;l,x;k,lh2mbr6n5r2J;n1Hzance;oke;cif38pahanaumokuak30r5;k5then0;si4w1K;ak7r6x5;f1l2X;ange county,d,f1inoco;mTw1G;e8i1Uo5;r5tt2N;th5wi0E; 0Sam19;uschwanste1Pw5; eng6a5h2market,po36;rk;la0P;a8co,e6i5uc;dt1Yll0Z;adow5ko0H;lands;chu picchu,gad2Ridsto1Ql8n7ple6r5;kh2; g1Cw11;hatt2Osf2B;ibu,t0ve1Z;a8e7gw,hr,in5owlOynd02;coln memori5dl2C;al;asi4w3;kefr7mbe1On5s,x;ca2Ig5si05;f1l27t0;ont;azan kreml14e6itchen2Gosrae,rasnoyar5ul;sk;ns0Hs1U;ax,cn,lf1n6ps5st;wiN;d5glew0Lverness;ian27ochina;aDeBi6kg,nd,ov5unti2H;d,enweep;gh6llc5;reL;bu03l5;and5;!s;r5yw0C;ef1tf1;libu24mp6r5stings;f1lem,row;stead,t0;aDodavari,r5uelph;avenAe5imsS;at 8en5; 6f1Fwi5;ch;acr3vall1H;brita0Flak3;hur5;st;ng3y villa0W;airhavHco,ra;aAgli9nf17ppi8u7ver6x5;et1Lf1;glad3t0;rope,st0;ng;nt0;rls1Ls5;t 5;e5si4;nd;aCe9fw,ig8o7ryd6u5xb;mfri3nstab00rh2tt0;en;nca18rcKv19wnt0B;by;n6r5vonpo1D;ry;!h2;nu8r5;l6t5;f1moor;ingt0;be;aLdg,eIgk,hClBo5royd0;l6m5rnwa0B;pt0;c7lingw6osse5;um;ood;he0S;earwat0St;a8el6i5uuk;chen itza,mney ro07natSricahua;m0Zt5;enh2;mor5rlottetPth2;ro;dar 5ntervilA;breaks,faZg5;rove;ld9m8r5versh2;lis6rizo pla5;in;le;bLpbellf1;weQ;aZcn,eNingl01kk,lackLolt0r5uckV;aGiAo5;ckt0ok5wns cany0;lyn,s5;i4to5;ne;de;dge6gh5;am,t0;n6t5;own;or5;th;ceb6m5;lNpt0;rid5;ge;bu5pool,wa8;rn;aconsfEdf1lBr9verly7x5;hi5;ll; hi5;lls;wi5;ck; air,l5;ingh2;am;ie5;ld;ltimore,rnsl6tters5;ea;ey;bLct0driadic,frica,ginJlGmFn9rc8s7tl6yleOzor3;es;!ant8;hcroft,ia; de triomphe,t6;adyr,ca8dov9tarct5;ic5; oce5;an;st5;er;ericas,s;be6dersh5hambra,list0;ot;rt0;cou5;rt;bot7i5;ngd0;on;sf1;ord",
		"Country": "true¦0:38;1:2L;2:3B;a2Xb2Ec22d1Ye1Sf1Mg1Ch1Ai14j12k0Zl0Um0Gn05om2pZqat1KrXsKtCu7v5wal4yemTz3;a25imbabwe;es,lis and futu2Y;a3enezue32ietnam;nuatu,tican city;gTk6nited 4ruXs3zbeE; 2Ca,sr;arab emirat0Kkingdom,states3;! of am2Y;!raiV;a8haCimor les0Co7rinidad 5u3;nis0rk3valu;ey,me2Zs and caic1V;and t3t3;oba1L;go,kel10nga;iw2ji3nz2T;ki2V;aDcotl1eCi9lov8o6pa2Dri lanka,u5w3yr0;az3edAitzerl1;il1;d2riname;lomon1Xmal0uth 3;afr2KkMsud2;ak0en0;erra leoFn3;gapo1Yt maart3;en;negLrb0ychellZ;int 3moa,n marino,udi arab0;hele26luc0mart21;epublic of ir0Eom2Euss0w3;an27;a4eIhilippinUitcairn1Mo3uerto riN;l1rtugF;ki2Dl4nama,pua new0Vra3;gu7;au,esti3;ne;aBe9i7or3;folk1Ith4w3;ay; k3ern mariana1D;or0O;caragua,ger3ue;!ia;p3ther1Aw zeal1;al;mib0u3;ru;a7exi6icro0Bo3yanm06;ldova,n3roc5zambA;a4gol0t3;enegro,serrat;co;cAdagasc01l7r5urit4yot3;te;an0i16;shall0Xtin3;ique;a4div3i,ta;es;wi,ys0;ao,ed02;a6e5i3uxembourg;b3echtenste12thu1G;er0ya;ban0Isotho;os,tv0;azakh1Fe4iriba04o3uwait,yrgyz1F;rXsovo;eling0Knya;a3erG;ma16p2;c7nd6r4s3taly,vory coast;le of m2rael;a3el1;n,q;ia,oJ;el1;aiTon3ungary;dur0Ng kong;aBermany,ha0QibraltAre8u3;a6ern5inea3ya0P;! biss3;au;sey;deloupe,m,tema0Q;e3na0N;ce,nl1;ar;bUmb0;a7i6r3;ance,ench 3;guia0Epoly3;nes0;ji,nl1;lklandUroeU;ast tim7cu6gypt,l salv6ngl1quatorial4ritr5st3thiop0;on0; guin3;ea;ad3;or;enmark,jibou5ominica4r con3;go;!n C;ti;aBentral african Ah8o5roat0u4yprRzech3; 9ia;ba,racao;c4lo3morQngo brazzaville,okGsta r04te de ivoiL;mb0;osE;i3ristmasG;le,na;republic;m3naUpe verde,ymanA;bod0ero3;on;aGeDhut2o9r5u3;lgar0r3;kina faso,ma,undi;azil,itish 3unei;virgin3; is3;lands;liv0nai5snia and herzegoviHtswaHuvet3; isl1;and;re;l3n8rmuG;ar3gium,ize;us;h4ngladesh,rbad3;os;am4ra3;in;as;fghaGlDmBn6r4ustr3zerbaij2;al0ia;genti3men0uba;na;dorra,g5t3;arct7igua and barbu3;da;o3uil3;la;er3;ica;b3ger0;an0;ia;ni3;st2;an",
		"FirstName": "true¦aTblair,cQdOfrancoZgabMhinaLilya,jHkClBm6ni4quinn,re3s0;h0umit,yd;ay,e0iloh;a,lby;g9ne;co,ko0;!s;a1el0ina,org6;!okuhF;ds,naia,r1tt0xiB;i,y;ion,lo;ashawn,eif,uca;a3e1ir0rM;an;lsFn0rry;dall,yat5;i,sD;a0essIie,ude;i1m0;ie,mG;me;ta;rie0y;le;arcy,ev0;an,on;as1h0;arl8eyenne;ey,sidy;drien,kira,l4nd1ubr0vi;ey;i,r0;a,e0;a,y;ex2f1o0;is;ie;ei,is",
		"WeekDay": "true¦fri2mon2s1t0wednesd3;hurs1ues1;aturd1und1;!d0;ay0;!s",
		"Month": "true¦dec0february,july,nov0octo1sept0;em0;ber",
		"Date": "true¦ago,on4som4t1week0yesterd5; end,ends;mr1o0;d2morrow;!w;ed0;ay",
		"Duration": "true¦centurAd8h7m5q4se3w1y0;ear8r8;eek0k7;!end,s;ason,c5;tr,uarter;i0onth3;llisecond2nute2;our1r1;ay0ecade0;!s;ies,y",
		"FemaleName": "true¦0:J7;1:JB;2:IJ;3:IK;4:J1;5:IO;6:JS;7:JO;8:HB;9:JK;A:H4;B:I2;C:IT;D:JH;E:IX;F:BA;G:I4;aGTbFLcDRdD0eBMfB4gADh9Ti9Gj8Dk7Cl5Wm48n3Lo3Hp33qu32r29s15t0Eu0Cv02wVxiTyOzH;aLeIineb,oHsof3;e3Sf3la,ra;h2iKlIna,ynH;ab,ep;da,ma;da,h2iHra;nab;aKeJi0FolB7uIvH;et8onDP;i0na;le0sen3;el,gm3Hn,rGLs8W;aoHme0nyi;m5XyAD;aMendDZhiDGiH;dele9lJnH;if48niHo0;e,f47;a,helmi0lHma;a,ow;ka0nB;aNeKiHusa5;ck84kIl8oleAviH;anFenJ4;ky,toriBK;da,lA8rHs0;a,nHoniH9;a,iFR;leHnesH9;nILrH;i1y;g9rHs6xHA;su5te;aYeUhRiNoLrIuHy2;i,la;acJ3iHu0J;c3na,sH;hFta;nHr0F;iFya;aJffaEOnHs6;a,gtiH;ng;!nFSra;aIeHomasi0;a,l9Oo8Ares1;l3ndolwethu;g9Fo88rIssH;!a,ie;eHi,ri7;sa,za;bOlMmKnIrHs6tia0wa0;a60yn;iHya;a,ka,s6;arFe2iHm77ra;!ka;a,iH;a,t6;at6it6;a0Ecarlett,e0AhWiSkye,neza0oQri,tNuIyH;bIGlvi1;ha,mayIJniAsIzH;an3Net8ie,y;anHi7;!a,e,nH;aCe;aIeH;fan4l5Dphan6E;cI5r5;b3fiAAm0LnHphi1;d2ia,ja,ya;er2lJmon1nIobh8QtH;a,i;dy;lETv3;aMeIirHo0risFDy5;a,lDM;ba,e0i5lJrH;iHr6Jyl;!d8Ifa;ia,lDZ;hd,iMki2nJrIu0w0yH;la,ma,na;i,le9on,ron,yn;aIda,ia,nHon;a,on;!ya;k6mH;!aa;lJrItaye82vH;da,inj;e0ife;en1i0ma;anA9bLd5Oh1SiBkKlJmInd2rHs6vannaC;aCi0;ant6i2;lDOma,ome;ee0in8Tu2;in1ri0;a05eZhXiUoHuthDM;bScRghQl8LnPsJwIxH;anB3ie,y;an,e0;aIeHie,lD;ann7ll1marDGtA;!lHnn1;iHyn;e,nH;a,dF;da,i,na;ayy8G;hel67io;bDRerAyn;a,cIkHmas,nFta,ya;ki,o;h8Xki;ea,iannGMoH;da,n1P;an0bJemFgi0iInHta,y0;a8Bee;han86na;a,eH;cHkaC;a,ca;bi0chIe,i0mo0nHquETy0;di,ia;aERelHiB;!e,le;een4ia0;aPeOhMiLoJrHute6A;iHudenCV;scil3LyamvaB;lHrt3;i0ly;a,paluk;ilome0oebe,ylH;is,lis;ggy,nelope,r5t2;ige,m0VnKo5rvaDMtIulH;a,et8in1;ricHt4T;a,e,ia;do2i07;ctav3dIfD3is6ksa0lHphD3umC5yunbileg;a,ga,iv3;eHvAF;l3t8;aWeUiMoIurHy5;!ay,ul;a,eJor,rIuH;f,r;aCeEma;ll1mi;aNcLhariBQkKlaJna,sHta,vi;anHha;ur;!y;a,iDZki;hoGk9YolH;a,e4P;!mh;hir,lHna,risDEsreE;!a,iDDlBV;asuMdLh3i6Dl5nKomi7rgEVtH;aHhal4;lHs6;i1ya;cy,et8;e9iF0ya;nngu2X;a0Ackenz4e02iMoJrignayani,uriDJyH;a,rH;a,iOlNna,tG;bi0i2llBJnH;a,iH;ca,ka,qD9;a,cUdo4ZkaTlOmi,nMrItzi,yH;ar;aJiIlH;anET;am;!l,nB;dy,eHh,n4;nhGrva;aKdJe0iCUlH;iHy;cent,e;red;!gros;!e5;ae5hH;ae5el3Z;ag5DgNi,lKrH;edi7AiIjem,on,yH;em,l;em,sCG;an4iHliCF;nHsCJ;a,da;!an,han;b09cASd07e,g05ha,i04ja,l02n00rLsoum5YtKuIv84xBKyHz4;bell,ra,soBB;d7rH;a,eE;h8Gild1t4;a,cUgQiKjor4l7Un4s6tJwa,yH;!aHbe6Xja9lAE;m,nBL;a,ha,in1;!aJbCGeIja,lDna,sHt63;!a,ol,sa;!l1D;!h,mInH;!a,e,n1;!awit,i;arJeIie,oHr48ueri8;!t;!ry;et46i3B;el4Xi7Cy;dHon,ue5;akranAy;ak,en,iHlo3S;a,ka,nB;a,re,s4te;daHg4;!l3E;alDd4elHge,isDJon0;ei9in1yn;el,le;a0Ne0CiXoQuLyH;d3la,nH;!a,dIe2OnHsCT;!a,e2N;a,sCR;aD4cJel0Pis1lIna,pHz;e,iA;a,u,wa;iHy;a0Se,ja,l2NnB;is,l1UrItt1LuHvel4;el5is1;aKeIi7na,rH;aADi7;lHn1tA;ei;!in1;aTbb9HdSepa,lNnKsJvIzH;!a,be5Ret8z4;!ia;a,et8;!a,dH;a,sHy;ay,ey,i,y;a,iJja,lH;iHy;aA8e;!aH;!nF;ia,ya;!nH;!a,ne;aPda,e0iNjYla,nMoKsJtHx93y5;iHt4;c3t3;e2PlCO;la,nHra;a,ie,o2;a,or1;a,gh,laH;!ni;!h,nH;a,d2e,n5V;cOdon9DiNkes6mi9Gna,rMtJurIvHxmi,y5;ern1in3;a,e5Aie,yn;as6iIoH;nya,ya;fa,s6;a,isA9;a,la;ey,ie,y;a04eZhXiOlASoNrJyH;lHra;a,ee,ie;istHy6I;a,en,iIyH;!na;!e,n5F;nul,ri,urtnB8;aOerNlB7mJrHzzy;a,stH;en,in;!berlImernH;aq;eHi,y;e,y;a,stE;!na,ra;aHei2ongordzol;dij1w5;el7UiKjsi,lJnIrH;a,i,ri;d2na,za;ey,i,lBLs4y;ra,s6;biAcARdiat7MeBAiSlQmPnyakuma1DrNss6NtKviAyH;!e,lH;a,eH;e,i8T;!a6HeIhHi4TlDri0y;ar8Her8Hie,leErBAy;!lyn8Ori0;a,en,iHl5Xoli0yn;!ma,nFs95;a5il1;ei8Mi,lH;e,ie;a,tl6O;a0AeZiWoOuH;anMdLlHst88;es,iH;a8NeHs8X;!n9tH;!a,te;e5Mi3My;a,iA;!anNcelDdMelGhan7VleLni,sIva0yH;a,ce;eHie;fHlDph7Y;a,in1;en,n1;i7y;!a,e,n45;lHng;!i1DlH;!i1C;anNle0nKrJsH;i8JsH;!e,i8I;i,ri;!a,elGif2CnH;a,et8iHy;!e,f2A;a,eJiInH;a,eIiH;e,n1;!t8;cMda,mi,nIque4YsminFvie2y9zH;min7;a7eIiH;ce,e,n1s;!lHs82t0F;e,le;inIk6HlDquelH;in1yn;da,ta;da,lRmPnOo0rNsIvaHwo0zaro;!a0lu,na;aJiIlaHob89;!n9R;do2;belHdo2;!a,e,l3B;a7Ben1i0ma;di2es,gr72ji;a9elBogH;en1;a,e9iHo0se;a0na;aSeOiJoHus7Kyacin2C;da,ll4rten24snH;a,i9U;lImaH;ri;aIdHlaI;a,egard;ry;ath1BiJlInrietArmi9sH;sa,t1A;en2Uga,mi;di;bi2Fil8MlNnMrJsItHwa,yl8M;i5Tt4;n60ti;iHmo51ri53;etH;!te;aCnaC;a,ey,l4;a02eWiRlPoNrKunJwH;enHyne1R;!dolD;ay,el;acieIetHiselB;a,chE;!la;ld1CogooH;sh;adys,enHor3yn2K;a,da,na;aKgi,lIna,ov8EselHta;a,e,le;da,liH;an;!n0;mLnJorgIrH;ald5Si,m3Etrud7;et8i4X;a,eHna;s29vieve;ma;bIle,mHrnet,yG;al5Si5;iIrielH;a,l1;!ja;aTeQiPlorOoz3rH;anJeIiH;da,eB;da,ja;!cH;esIiHoi0P;n1s66;!ca;a,enc3;en,o0;lIn0rnH;anB;ec3ic3;jr,nArKtHy7;emIiHma,oumaA;ha,ma,n;eh;ah,iBrah,za0;cr4Rd0Re0Qi0Pk0Ol07mXn54rUsOtNuMvHwa;aKelIiH;!e,ta;inFyn;!a;!ngel4V;geni1ni47;h5Yien9ta;mLperanKtH;eIhHrel5;er;l31r7;za;a,eralB;iHma,ne4Lyn;cHka,n;a,ka;aPeNiKmH;aHe21ie,y;!li9nuH;elG;lHn1;e7iHy;a,e,ja;lHrald;da,y;!nue5;aWeUiNlMma,no2oKsJvH;a,iH;na,ra;a,ie;iHuiH;se;a,en,ie,y;a0c3da,e,f,nMsJzaH;!betHveA;e,h;aHe,ka;!beH;th;!a,or;anor,nH;!a,i;!in1na;ate1Rta;leEs6;vi;eIiHna,wi0;e,th;l,n;aYeMh3iLjeneKoH;lor5Vminiq4Ln3FrHtt4;a,eEis,la,othHthy;ea,y;ba;an09naCon9ya;anQbPde,eOiMlJmetr3nHsir5M;a,iH;ce,se;a,iIla,orHphi9;es,is;a,l6F;dHrdH;re;!d5Ena;!b2ForaCraC;a,d2nH;!a,e;hl3i0l0GmNnLphn1rIvi1WyH;le,na;a,by,cIia,lH;a,en1;ey,ie;a,et8iH;!ca,el1Aka,z;arHia;is;a0Re0Nh04i02lUoJristIynH;di,th3;al,i0;lPnMrIurH;tn1D;aJd2OiHn2Ori9;!nH;a,e,n1;!l4;cepci5Cn4sH;tanHuelo;ce,za;eHleE;en,t8;aJeoIotH;il54;!pat2;ir7rJudH;et8iH;a,ne;a,e,iH;ce,sZ;a2er2ndH;i,y;aReNloe,rH;isJyH;stH;al;sy,tH;a1Sen,iHy;an1e,n1;deJlseIrH;!i7yl;a,y;li9;nMrH;isKlImH;ai9;a,eHot8;n1t8;!sa;d2elGtH;al,elG;cIlH;es8i47;el3ilH;e,ia,y;itlYlXmilWndVrMsKtHy5;aIeIhHri0;er1IleErDy;ri0;a38sH;a37ie;a,iOlLmeJolIrH;ie,ol;!e,in1yn;lHn;!a,la;a,eIie,otHy;a,ta;ne,y;na,s1X;a0Ii0I;a,e,l1;isAl4;in,yn;a0Ke02iZlXoUrH;andi7eRiJoIyH;an0nn;nwDoke;an3HdgMgiLtH;n31tH;!aInH;ey,i,y;ny;d,t8;etH;!t7;an0e,nH;da,na;bbi7glarIlo07nH;iAn4;ka;ancHythe;a,he;an1Clja0nHsm3M;iAtH;ou;aWcVlinUniArPssOtJulaCvH;!erlH;ey,y;hJsy,tH;e,iHy7;e,na;!anH;ie,y;!ie;nItHyl;ha,ie;adIiH;ce;et8i9;ay,da;ca,ky;!triH;ce,z;rbJyaH;rmH;aa;a2o2ra;a2Ub2Od25g21i1Sj5l18m0Zn0Boi,r06sWtVuPvOwa,yIzH;ra,u0;aKes6gJlIn,seH;!l;in;un;!nH;a,na;a,i2K;drLguJrIsteH;ja;el3;stH;in1;a,ey,i,y;aahua,he0;hIi2Gja,miAs2DtrH;id;aMlIraqHt21;at;eIi7yH;!n;e,iHy;gh;!nH;ti;iJleIo6piA;ta;en,n1t8;aHelG;!n1J;a01dje5eZgViTjRnKohito,toHya;inet8nH;el5ia;te;!aKeIiHmJ;e,ka;!mHtt7;ar4;!belIliHmU;sa;!l1;a,eliH;ca;ka,sHta;a,sa;elHie;a,iH;a,ca,n1qH;ue;!tH;a,te;!bImHstasiMya;ar3;el;aLberKeliJiHy;e,l3naH;!ta;a,ja;!ly;hGiIl3nB;da;a,ra;le;aWba,ePiMlKthJyH;a,c3sH;a,on,sa;ea;iHys0N;e,s0M;a,cIn1sHza;a,e,ha,on,sa;e,ia,ja;c3is6jaKksaKna,sJxH;aHia;!nd2;ia,saH;nd2;ra;ia;i0nIyH;ah,na;a,is,naCoud;la;c6da,leEmNnLsH;haClH;inHyY;g,n;!h;a,o,slH;ey;ee;en;at6g4nIusH;ti0;es;ie;aWdiTelMrH;eJiH;anMenH;a,e,ne;an0;na;!aLeKiIyH;nn;a,n1;a,e;!ne;!iH;de;e,lDsH;on;yn;!lH;i9yn;ne;aKbIiHrL;!e,gaK;ey,i7y;!e;gaH;il;dKliyJradhIs6;ha;ya;ah;a,ya",
		"Honorific": "true¦director1field marsh2lieutenant1rear0sergeant major,vice0; admir1; gener0;al",
		"Adj|Gerund": "true¦0:3F;1:3H;2:31;3:2X;4:35;5:33;6:3C;7:2Z;8:36;9:29;a33b2Tc2Bd1Te1If19g12h0Zi0Rl0Nm0Gnu0Fo0Ap04rYsKtEuBvAw1Ayiel3;ar6e08;nBpA;l1Rs0B;fol3n1Zsett2;aEeDhrBi4ouc7rAwis0;e0Bif2oub2us0yi1;ea1SiA;l2vi1;l2mp0rr1J;nt1Vxi1;aMcreec7enten2NhLkyrocke0lo0Vmi2oJpHtDuBweA;e0Ul2;pp2ArA;gi1pri5roun3;aBea8iAri2Hun9;mula0r4;gge4rA;t2vi1;ark2eAraw2;e3llb2F;aAot7;ki1ri1;i9oc29;dYtisf6;aEeBive0oAus7;a4l2;assu4defi9fres7ig9juve07mai9s0vAwar3;ea2italiAol1G;si1zi1;gi1ll6mb2vi1;a6eDier23lun1VrAun2C;eBoA;mi5vo1Z;ce3s5vai2;n3rpleA;xi1;ffCpWutBverAwi1;arc7lap04p0Pri3whel8;goi1l6st1J;en3sA;et0;m2Jrtu4;aEeDiCoBuAyst0L;mb2;t1Jvi1;s5tiga0;an1Rl0n3smeri26;dAtu4;de9;aCeaBiAo0U;fesa0Tvi1;di1ni1;c1Fg19s0;llumiGmFnArri0R;cDfurHsCtBviA;go23ti1;e1Oimi21oxica0rig0V;pi4ul0;orpo20r0K;po5;na0;eaBorr02umilA;ia0;li1rtwar8;lFrA;atiDipCoBuelA;i1li1;undbrea10wi1;pi1;f6ng;a4ea8;a3etc7it0lEoCrBulfA;il2;ee1FighXust1L;rAun3;ebo3thco8;aCoA;a0wA;e4i1;mi1tte4;lectrJmHnExA;aCci0hBis0pA;an3lo3;aOila1B;c0spe1A;ab2coura0CdBergi13ga0Clive9ric7s02tA;hral2i0J;ea4u4;barras5er09pA;owe4;if6;aQeIiBrA;if0;sAzz6;aEgDhearCsen0tA;rAur11;ac0es5;te9;us0;ppoin0r8;biliGcDfi9gra3ligh0mBpres5sAvasG;erE;an3ea9orA;ali0L;a6eiBli9rA;ea5;vi1;ta0;maPri1s7un0zz2;aPhMlo5oAripp2ut0;mGnArrespon3;cer9fDspi4tA;inBrA;as0ibu0ol2;ui1;lic0u5;ni1;fDmCpA;eAromi5;l2ti1;an3;or0;aAil2;llenAnAr8;gi1;l8ptAri1;iva0;aff2eGin3lFoDrBuA;d3st2;eathtaAui5;ki1;gg2i2o8ri1unA;ci1;in3;co8wiA;lAtc7;de4;bsorVcOgonMlJmHnno6ppea2rFsA;pi4su4toA;nBun3;di1;is7;hi1;res0;li1;aFu5;si1;ar8lu4;ri1;mi1;iAzi1;zi1;cAhi1;eleDomA;moBpan6;yi1;da0;ra0;ti1;bi1;ng",
		"Comparable": "true¦0:3C;1:3Q;2:3F;a3Tb3Cc33d2Te2Mf2Ag1Wh1Li1Fj1Ek1Bl13m0Xn0So0Rp0Iqu0Gr07sHtCug0vAw4y3za0Q;el10ouN;ary,e6hi5i3ry;ck0Cde,l3n1ry,se;d,y;ny,te;a3i3R;k,ry;a3erda2ulgar;gue,in,st;a6en2Xhi5i4ouZr3;anqu2Cen1ue;dy,g36me0ny;ck,rs28;ll,me,rt,wd3I;aRcaPeOhMiLkin0BlImGoEpDt6u4w3;eet,ift;b3dd0Wperfi21rre28;sta26t21;a8e7iff,r4u3;pUr1;a4ict,o3;ng;ig2Vn0N;a1ep,rn;le,rk,te0;e1Si2Vright0;ci1Yft,l3on,re;emn,id;a3el0;ll,rt;e4i3y;g2Mm0Z;ek,nd2T;ck24l0mp1L;a3iRrill,y;dy,l01rp;ve0Jxy;n1Jr3;ce,y;d,fe,int0l1Hv0V;a8e6i5o3ude;mantic,o19sy,u3;gh;pe,t1P;a3d,mo0A;dy,l;gg4iFndom,p3re,w;id;ed;ai2i3;ck,et;hoAi1Fl9o8r5u3;ny,r3;e,p11;egna2ic4o3;fouSud;ey,k0;liXor;ain,easa2;ny;dd,i0ld,ranL;aive,e5i4o3u14;b0Sisy,rm0Ysy;bb0ce,mb0R;a3r1w;r,t;ad,e5ild,o4u3;nda12te;ist,o1;a4ek,l3;low;s0ty;a8e7i6o3ucky;f0Jn4o15u3ve0w10y0N;d,sy;e0g;ke0l,mp,tt0Eve0;e1Qwd;me,r3te;ge;e4i3;nd;en;ol0ui19;cy,ll,n3;secu6t3;e3ima4;llege2rmedia3;te;re;aAe7i6o5u3;ge,m3ng1C;bYid;me0t;gh,l0;a3fXsita2;dy,rWv3;en0y;nd13ppy,r3;d3sh;!y;aFenEhCiBlAoofy,r3;a8e6i5o3ue0Z;o3ss;vy;m,s0;at,e3y;dy,n;nd,y;ad,ib,ooD;a2d1;a3o3;st0;tDuiS;u1y;aCeebBi9l8o6r5u3;ll,n3r0N;!ny;aCesh,iend0;a3nd,rmD;my;at,ir7;erce,nan3;ci9;le;r,ul3;ty;a6erie,sse4v3xtre0B;il;nti3;al;r4s3;tern,y;ly,th0;appZe9i5ru4u3;mb;nk;r5vi4z3;zy;ne;e,ty;a3ep,n9;d3f,r;!ly;agey,h8l7o5r4u3;dd0r0te;isp,uel;ar3ld,mmon,st0ward0zy;se;evKou1;e3il0;ap,e3;sy;aHiFlCoAr5u3;ff,r0sy;ly;a6i3oad;g4llia2;nt;ht;sh,ve;ld,un3;cy;a4o3ue;nd,o1;ck,nd;g,tt3;er;d,ld,w1;dy;bsu6ng5we3;so3;me;ry;rd",
		"Adverb": "true¦a08b05d00eYfSheQinPjustOkinda,likewiZmMnJoEpCquite,r9s5t2u0very,well;ltima01p0; to,wards5;h1iny bit,o0wiO;o,t6;en,us;eldom,o0uch;!me1rt0; of;how,times,w0C;a1e0;alS;ndomRth05;ar excellenEer0oint blank; Lhaps;f3n0utright;ce0ly;! 0;ag05moX; courGten;ewJo0; longWt 0;onHwithstand9;aybe,eanwhiNore0;!ovT;! aboX;deed,steY;lla,n0;ce;or3u0;ck1l9rther0;!moK;ing; 0evK;exampCgood,suH;n mas0vI;se;e0irect2; 2fini0;te0;ly;juAtrop;ackward,y 0;far,no0; means,w; GbroFd nauseam,gEl7ny5part,s4t 2w0;ay,hi0;le;be7l0mo7wor7;arge,ea6; soon,i4;mo0way;re;l 3mo2ongsi1ready,so,togeth0ways;er;de;st;b1t0;hat;ut;ain;ad;lot,posteriori",
		"Conjunction": "true¦aXbTcReNhowMiEjust00noBo9p8supposing,t5wh0yet;e1il0o3;e,st;n1re0thN; if,by,vM;evL;h0il,o;erefOo0;!uU;lus,rovided th9;r0therwiM;! not; mattEr,w0;! 0;since,th4w7;f4n0; 0asmuch;as mIcaForder t0;h0o;at;! 0;only,t0w0;hen;!ev3;ith2ven0;! 0;if,tB;er;o0uz;s,z;e0ut,y the time;cau1f0;ore;se;lt3nd,s 0;far1if,m0soon1t2;uch0; as;hou0;gh",
		"Currency": "true¦$,aud,bQcOdJeurIfHgbp,hkd,iGjpy,kElDp8r7s3usd,x2y1z0¢,£,¥,ден,лв,руб,฿,₡,₨,€,₭,﷼;lotyQł;en,uanP;af,of;h0t5;e0il5;k0q0;elK;oubleJp,upeeJ;e2ound st0;er0;lingG;n0soF;ceEnies;empi7i7;n,r0wanzaCyatC;!onaBw;ls,nr;ori7ranc9;!os;en3i2kk,o0;b0ll2;ra5;me4n0rham4;ar3;e0ny;nt1;aht,itcoin0;!s",
		"Determiner": "true¦aBboth,d9e6few,le5mu8neiDplenty,s4th2various,wh0;at0ich0;evC;a0e4is,ose;!t;everal,ome;!ast,s;a1l0very;!se;ch;e0u;!s;!n0;!o0y;th0;er",
		"Adj|Present": "true¦a07b04cVdQeNfJhollIidRlEmCnarrIoBp9qua8r7s3t2uttFw0;aKet,ro0;ng,u08;endChin;e2hort,l1mooth,our,pa9tray,u0;re,speU;i2ow;cu6da02leSpaN;eplica01i02;ck;aHerfePr0;eseUime,omV;bscu1pen,wn;atu0e3odeH;re;a2e1ive,ow0;er;an;st,y;ow;a2i1oul,r0;ee,inge;rm;iIke,ncy,st;l1mpty,x0;emHpress;abo4ic7;amp,e2i1oub0ry,ull;le;ffu9re6;fu8libe0;raE;alm,l5o0;mpleCn3ol,rr1unterfe0;it;e0u7;ct;juga8sum7;ea1o0;se;n,r;ankru1lu0;nt;pt;li2pproxi0rticula1;ma0;te;ght",
		"Person|Adj": "true¦b3du2earnest,frank,mi2r0san1woo1;an0ich,u1;dy;sty;ella,rown",
		"Modal": "true¦c5lets,m4ought3sh1w0;ill,o5;a0o4;ll,nt;! to,a;ight,ust;an,o0;uld",
		"Verb": "true¦born,cannot,gonna,has,keep tabs,msg",
		"Person|Verb": "true¦b8ch7dr6foster,gra5ja9lan4ma2ni9ollie,p1rob,s0wade;kip,pike,t5ue;at,eg,ier2;ck,r0;k,shal;ce;ce,nt;ew;ase,u1;iff,l1ob,u0;ck;aze,ossom",
		"Person|Date": "true¦a2j0sep;an0une;!uary;p0ugust,v0;ril"
	};
	//#endregion
	//#region node_modules/.pnpm/efrt@2.7.0/node_modules/efrt/src/encoding.js
	var BASE = 36;
	var seq = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var cache = seq.split("").reduce(function(h, c, i) {
		h[c] = i;
		return h;
	}, {});
	var toAlphaCode = function(n) {
		if (seq[n] !== void 0) return seq[n];
		let places = 1;
		let range = BASE;
		let s = "";
		for (; n >= range; n -= range, places++, range *= BASE);
		while (places--) {
			const d = n % BASE;
			s = String.fromCharCode((d < 10 ? 48 : 55) + d) + s;
			n = (n - d) / BASE;
		}
		return s;
	};
	var fromAlphaCode = function(s) {
		if (cache[s] !== void 0) return cache[s];
		let n = 0;
		let places = 1;
		let range = BASE;
		let pow = 1;
		for (; places < s.length; n += range, places++, range *= BASE);
		for (let i = s.length - 1; i >= 0; i--, pow *= BASE) {
			let d = s.charCodeAt(i) - 48;
			if (d > 10) d -= 7;
			n += d * pow;
		}
		return n;
	};
	var encoding_default = {
		toAlphaCode,
		fromAlphaCode
	};
	//#endregion
	//#region node_modules/.pnpm/efrt@2.7.0/node_modules/efrt/src/unpack/symbols.js
	var symbols = function(t) {
		const reSymbol = /* @__PURE__ */ new RegExp("([0-9A-Z]+):([0-9A-Z]+)");
		for (let i = 0; i < t.nodes.length; i++) {
			const m = reSymbol.exec(t.nodes[i]);
			if (!m) {
				t.symCount = i;
				break;
			}
			t.syms[encoding_default.fromAlphaCode(m[1])] = encoding_default.fromAlphaCode(m[2]);
		}
		t.nodes = t.nodes.slice(t.symCount, t.nodes.length);
	};
	//#endregion
	//#region node_modules/.pnpm/efrt@2.7.0/node_modules/efrt/src/unpack/traverse.js
	var indexFromRef = function(trie, ref, index) {
		const dnode = encoding_default.fromAlphaCode(ref);
		if (dnode < trie.symCount) return trie.syms[dnode];
		return index + dnode + 1 - trie.symCount;
	};
	var toArray = function(trie) {
		const all = [];
		const crawl = (index, pref) => {
			let node = trie.nodes[index];
			if (node[0] === "!") {
				all.push(pref);
				node = node.slice(1);
			}
			const matches = node.split(/([A-Z0-9,]+)/g);
			for (let i = 0; i < matches.length; i += 2) {
				const str = matches[i];
				const ref = matches[i + 1];
				if (!str) continue;
				const have = pref + str;
				if (ref === "," || ref === void 0) {
					all.push(have);
					continue;
				}
				crawl(indexFromRef(trie, ref, index), have);
			}
		};
		crawl(0, "");
		return all;
	};
	var unpack$1 = function(str) {
		const trie = {
			nodes: str.split(";"),
			syms: [],
			symCount: 0
		};
		if (str.match(":")) symbols(trie);
		return toArray(trie);
	};
	//#endregion
	//#region node_modules/.pnpm/efrt@2.7.0/node_modules/efrt/src/unpack/index.js
	var unpack = function(str) {
		if (!str) return {};
		const obj = str.split("|").reduce((h, s) => {
			const arr = s.split("¦");
			h[arr[0]] = arr[1];
			return h;
		}, {});
		const all = {};
		Object.keys(obj).forEach(function(cat) {
			const arr = unpack$1(obj[cat]);
			if (cat === "true") cat = true;
			for (let i = 0; i < arr.length; i++) {
				const k = arr[i];
				if (all.hasOwnProperty(k) === true) if (Array.isArray(all[k]) === false) all[k] = [all[k], cat];
				else all[k].push(cat);
				else all[k] = cat;
			}
		});
		return all;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/lexicon/misc.js
	var prp = ["Possessive", "Pronoun"];
	var misc$2 = {
		"20th century fox": "Organization",
		"7 eleven": "Organization",
		"motel 6": "Organization",
		g8: "Organization",
		vh1: "Organization",
		"76ers": "SportsTeam",
		"49ers": "SportsTeam",
		q1: "Date",
		q2: "Date",
		q3: "Date",
		q4: "Date",
		km2: "Unit",
		m2: "Unit",
		dm2: "Unit",
		cm2: "Unit",
		mm2: "Unit",
		mile2: "Unit",
		in2: "Unit",
		yd2: "Unit",
		ft2: "Unit",
		m3: "Unit",
		dm3: "Unit",
		cm3: "Unit",
		in3: "Unit",
		ft3: "Unit",
		yd3: "Unit",
		"at&t": "Organization",
		"black & decker": "Organization",
		"h & m": "Organization",
		"johnson & johnson": "Organization",
		"procter & gamble": "Organization",
		"ben & jerry's": "Organization",
		"&": "Conjunction",
		i: ["Pronoun", "Singular"],
		he: ["Pronoun", "Singular"],
		she: ["Pronoun", "Singular"],
		it: ["Pronoun", "Singular"],
		they: ["Pronoun", "Plural"],
		we: ["Pronoun", "Plural"],
		was: ["Copula", "PastTense"],
		is: ["Copula", "PresentTense"],
		are: ["Copula", "PresentTense"],
		am: ["Copula", "PresentTense"],
		were: ["Copula", "PastTense"],
		her: prp,
		his: prp,
		hers: prp,
		their: prp,
		theirs: prp,
		themselves: prp,
		your: prp,
		our: prp,
		ours: prp,
		my: prp,
		its: prp,
		vs: ["Conjunction", "Abbreviation"],
		if: ["Condition", "Preposition"],
		closer: "Comparative",
		closest: "Superlative",
		much: "Adverb",
		may: "Modal",
		babysat: "PastTense",
		blew: "PastTense",
		drank: "PastTense",
		drove: "PastTense",
		forgave: "PastTense",
		skiied: "PastTense",
		spilt: "PastTense",
		stung: "PastTense",
		swam: "PastTense",
		swung: "PastTense",
		guaranteed: "PastTense",
		shrunk: "PastTense",
		nears: "PresentTense",
		nearing: "Gerund",
		neared: "PastTense",
		no: ["Negative", "Expression"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/lexicon/frozenLex.js
	var frozenLex_default = {
		"20th century fox": "Organization",
		"7 eleven": "Organization",
		"motel 6": "Organization",
		"excuse me": "Expression",
		"financial times": "Organization",
		"guns n roses": "Organization",
		"la z boy": "Organization",
		"labour party": "Organization",
		"new kids on the block": "Organization",
		"new york times": "Organization",
		"the guess who": "Organization",
		"thin lizzy": "Organization",
		"prime minister": "Actor",
		"free market": "Singular",
		"lay up": "Singular",
		"living room": "Singular",
		"living rooms": "Plural",
		"spin off": "Singular",
		"appeal court": "Uncountable",
		"cold war": "Uncountable",
		"gene pool": "Uncountable",
		"machine learning": "Uncountable",
		"nail polish": "Uncountable",
		"time off": "Uncountable",
		"take part": "Infinitive",
		"bill gates": "Person",
		"doctor who": "Person",
		"dr who": "Person",
		"he man": "Person",
		"iron man": "Person",
		"kid cudi": "Person",
		"run dmc": "Person",
		"rush limbaugh": "Person",
		"snow white": "Person",
		"tiger woods": "Person",
		"brand new": "Adjective",
		"en route": "Adjective",
		"left wing": "Adjective",
		"off guard": "Adjective",
		"on board": "Adjective",
		"part time": "Adjective",
		"right wing": "Adjective",
		"so called": "Adjective",
		"spot on": "Adjective",
		"straight forward": "Adjective",
		"super duper": "Adjective",
		"tip top": "Adjective",
		"top notch": "Adjective",
		"up to date": "Adjective",
		"win win": "Adjective",
		"brooklyn nets": "SportsTeam",
		"chicago bears": "SportsTeam",
		"houston astros": "SportsTeam",
		"houston dynamo": "SportsTeam",
		"houston rockets": "SportsTeam",
		"houston texans": "SportsTeam",
		"minnesota twins": "SportsTeam",
		"orlando magic": "SportsTeam",
		"san antonio spurs": "SportsTeam",
		"san diego chargers": "SportsTeam",
		"san diego padres": "SportsTeam",
		"iron maiden": "ProperNoun",
		"isle of man": "Country",
		"united states": "Country",
		"united states of america": "Country",
		"prince edward island": "Region",
		"cedar breaks": "Place",
		"cedar falls": "Place",
		"point blank": "Adverb",
		"tiny bit": "Adverb",
		"by the time": "Conjunction",
		"no matter": "Conjunction",
		"civil wars": "Plural",
		"credit cards": "Plural",
		"default rates": "Plural",
		"free markets": "Plural",
		"head starts": "Plural",
		"home runs": "Plural",
		"lay ups": "Plural",
		"phone calls": "Plural",
		"press releases": "Plural",
		"record labels": "Plural",
		"soft serves": "Plural",
		"student loans": "Plural",
		"tax returns": "Plural",
		"tv shows": "Plural",
		"video games": "Plural",
		"took part": "PastTense",
		"takes part": "PresentTense",
		"taking part": "Gerund",
		"taken part": "Participle",
		"light bulb": "Noun",
		"rush hour": "Noun",
		"fluid ounce": "Unit",
		"the rolling stones": "Organization"
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/lexicon/emoticons.js
	var emoticons_default = [
		":(",
		":)",
		":P",
		":p",
		":O",
		";(",
		";)",
		";P",
		";p",
		";O",
		":3",
		":|",
		":/",
		":\\",
		":$",
		":*",
		":@",
		":-(",
		":-)",
		":-P",
		":-p",
		":-O",
		":-3",
		":-|",
		":-/",
		":-\\",
		":-$",
		":-*",
		":-@",
		":^(",
		":^)",
		":^P",
		":^p",
		":^O",
		":^3",
		":^|",
		":^/",
		":^\\",
		":^$",
		":^*",
		":^@",
		"):",
		"(:",
		"$:",
		"*:",
		")-:",
		"(-:",
		"$-:",
		"*-:",
		")^:",
		"(^:",
		"$^:",
		"*^:",
		"<3",
		"</3",
		"<\\3",
		"=("
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/nouns/toPlural/_rules.js
	/** patterns for turning 'bus' to 'buses'*/
	var suffixes$2 = {
		a: [[/(antenn|formul|nebul|vertebr|vit)a$/i, "$1ae"], [/ia$/i, "ia"]],
		e: [
			[/(kn|l|w)ife$/i, "$1ives"],
			[/(hive)$/i, "$1s"],
			[/([m|l])ouse$/i, "$1ice"],
			[/([m|l])ice$/i, "$1ice"]
		],
		f: [[/^(dwar|handkerchie|hoo|scar|whar)f$/i, "$1ves"], [/^((?:ca|e|ha|(?:our|them|your)?se|she|wo)l|lea|loa|shea|thie)f$/i, "$1ves"]],
		i: [[/(octop|vir)i$/i, "$1i"]],
		m: [[/([ti])um$/i, "$1a"]],
		n: [[/^(oxen)$/i, "$1"]],
		o: [[/(al|ad|at|er|et|ed)o$/i, "$1oes"]],
		s: [
			[/(ax|test)is$/i, "$1es"],
			[/(alias|status)$/i, "$1es"],
			[/sis$/i, "ses"],
			[/(bu)s$/i, "$1ses"],
			[/(sis)$/i, "ses"],
			[/^(?!talis|.*hu)(.*)man$/i, "$1men"],
			[/(octop|vir|radi|nucle|fung|cact|stimul)us$/i, "$1i"]
		],
		x: [[/(matr|vert|ind|cort)(ix|ex)$/i, "$1ices"], [/^(ox)$/i, "$1en"]],
		y: [[/([^aeiouy]|qu)y$/i, "$1ies"]],
		z: [[/(quiz)$/i, "$1zes"]]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/nouns/toPlural/index.js
	var addE = /([xsz]|ch|sh)$/;
	var trySuffix = function(str) {
		const c = str[str.length - 1];
		if (suffixes$2.hasOwnProperty(c) === true) for (let i = 0; i < suffixes$2[c].length; i += 1) {
			const reg = suffixes$2[c][i][0];
			if (reg.test(str) === true) return str.replace(reg, suffixes$2[c][i][1]);
		}
		return null;
	};
	/** Turn a singular noun into a plural
	* assume the given string is singular
	*/
	var pluralize = function(str = "", model) {
		const { irregularPlurals, uncountable } = model.two;
		if (uncountable.hasOwnProperty(str)) return str;
		if (irregularPlurals.hasOwnProperty(str)) return irregularPlurals[str];
		const plural = trySuffix(str);
		if (plural !== null) return plural;
		if (addE.test(str)) return str + "es";
		return str + "s";
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/lexicon/index.js
	var hasSwitch = /\|/;
	var lexicon = misc$2;
	var switches = {};
	var tmpModel$1 = { two: {
		irregularPlurals: plurals_default,
		uncountable: {}
	} };
	Object.keys(_data_default$1).forEach((tag) => {
		const wordsObj = unpack(_data_default$1[tag]);
		if (!hasSwitch.test(tag)) {
			Object.keys(wordsObj).forEach((w) => {
				lexicon[w] = tag;
			});
			return;
		}
		Object.keys(wordsObj).forEach((w) => {
			switches[w] = tag;
			if (tag === "Noun|Verb") {
				const plural = pluralize(w, tmpModel$1);
				switches[plural] = "Plural|Verb";
			}
		});
	});
	emoticons_default.forEach((str) => lexicon[str] = "Emoticon");
	delete lexicon[""];
	delete lexicon[null];
	delete lexicon[" "];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/_noun.js
	var n = "Singular";
	var _noun_default = {
		beforeTags: {
			Determiner: n,
			Possessive: n,
			Acronym: n,
			Noun: n,
			Adjective: n,
			PresentTense: n,
			Gerund: n,
			PastTense: n,
			Infinitive: n,
			Date: n,
			Ordinal: n,
			Demonym: n
		},
		afterTags: {
			Value: n,
			Modal: n,
			Copula: n,
			PresentTense: n,
			PastTense: n,
			Demonym: n,
			Actor: n
		},
		beforeWords: {
			the: n,
			with: n,
			without: n,
			of: n,
			for: n,
			any: n,
			all: n,
			on: n,
			cut: n,
			cuts: n,
			increase: n,
			decrease: n,
			raise: n,
			drop: n,
			save: n,
			saved: n,
			saves: n,
			make: n,
			makes: n,
			made: n,
			minus: n,
			plus: n,
			than: n,
			another: n,
			versus: n,
			neither: n,
			about: n,
			favorite: n,
			best: n,
			daily: n,
			weekly: n,
			linear: n,
			binary: n,
			mobile: n,
			lexical: n,
			technical: n,
			computer: n,
			scientific: n,
			security: n,
			government: n,
			popular: n,
			formal: n,
			no: n,
			more: n,
			one: n,
			let: n,
			her: n,
			his: n,
			their: n,
			our: n,
			us: n,
			sheer: n,
			monthly: n,
			yearly: n,
			current: n,
			previous: n,
			upcoming: n,
			last: n,
			next: n,
			main: n,
			initial: n,
			final: n,
			beginning: n,
			end: n,
			top: n,
			bottom: n,
			future: n,
			past: n,
			major: n,
			minor: n,
			side: n,
			central: n,
			peripheral: n,
			public: n,
			private: n
		},
		afterWords: {
			of: n,
			system: n,
			aid: n,
			method: n,
			utility: n,
			tool: n,
			reform: n,
			therapy: n,
			philosophy: n,
			room: n,
			authority: n,
			says: n,
			said: n,
			wants: n,
			wanted: n,
			is: n,
			did: n,
			do: n,
			can: n,
			wise: n
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/_verb.js
	var v = "Infinitive";
	var _verb_default = {
		beforeTags: {
			Modal: v,
			Adverb: v,
			Negative: v,
			Plural: v
		},
		afterTags: {
			Determiner: v,
			Adverb: v,
			Possessive: v,
			Reflexive: v,
			Preposition: v,
			Cardinal: v,
			Comparative: v,
			Superlative: v
		},
		beforeWords: {
			i: v,
			we: v,
			you: v,
			they: v,
			to: v,
			please: v,
			will: v,
			have: v,
			had: v,
			would: v,
			could: v,
			should: v,
			do: v,
			did: v,
			does: v,
			can: v,
			must: v,
			us: v,
			me: v,
			let: v,
			even: v,
			when: v,
			help: v,
			he: v,
			she: v,
			it: v,
			being: v,
			bi: v,
			co: v,
			contra: v,
			de: v,
			inter: v,
			intra: v,
			mis: v,
			pre: v,
			out: v,
			counter: v,
			nobody: v,
			somebody: v,
			anybody: v,
			everybody: v
		},
		afterWords: {
			the: v,
			me: v,
			you: v,
			him: v,
			us: v,
			her: v,
			his: v,
			them: v,
			they: v,
			it: v,
			himself: v,
			herself: v,
			itself: v,
			myself: v,
			ourselves: v,
			themselves: v,
			something: v,
			anything: v,
			a: v,
			an: v,
			up: v,
			down: v,
			by: v,
			out: v,
			off: v,
			under: v,
			what: v,
			all: v,
			to: v,
			because: v,
			although: v,
			how: v,
			otherwise: v,
			together: v,
			though: v,
			into: v,
			yet: v,
			more: v,
			here: v,
			there: v,
			away: v
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/actor-verb.js
	var clue$7 = {
		beforeTags: Object.assign({}, _verb_default.beforeTags, _noun_default.beforeTags, {}),
		afterTags: Object.assign({}, _verb_default.afterTags, _noun_default.afterTags, {}),
		beforeWords: Object.assign({}, _verb_default.beforeWords, _noun_default.beforeWords, {}),
		afterWords: Object.assign({}, _verb_default.afterWords, _noun_default.afterWords, {})
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/_adj.js
	var jj$2 = "Adjective";
	var _adj_default = {
		beforeTags: {
			Determiner: jj$2,
			Possessive: jj$2,
			Hyphenated: jj$2
		},
		afterTags: { Adjective: jj$2 },
		beforeWords: {
			seem: jj$2,
			seemed: jj$2,
			seems: jj$2,
			feel: jj$2,
			feels: jj$2,
			felt: jj$2,
			stay: jj$2,
			appear: jj$2,
			appears: jj$2,
			appeared: jj$2,
			also: jj$2,
			over: jj$2,
			under: jj$2,
			too: jj$2,
			it: jj$2,
			but: jj$2,
			still: jj$2,
			really: jj$2,
			quite: jj$2,
			well: jj$2,
			very: jj$2,
			truly: jj$2,
			how: jj$2,
			deeply: jj$2,
			hella: jj$2,
			profoundly: jj$2,
			extremely: jj$2,
			so: jj$2,
			badly: jj$2,
			mostly: jj$2,
			totally: jj$2,
			awfully: jj$2,
			rather: jj$2,
			nothing: jj$2,
			something: jj$2,
			anything: jj$2,
			not: jj$2,
			me: jj$2,
			is: jj$2,
			face: jj$2,
			faces: jj$2,
			faced: jj$2,
			look: jj$2,
			looks: jj$2,
			looked: jj$2,
			reveal: jj$2,
			reveals: jj$2,
			revealed: jj$2,
			sound: jj$2,
			sounded: jj$2,
			sounds: jj$2,
			remains: jj$2,
			remained: jj$2,
			prove: jj$2,
			proves: jj$2,
			proved: jj$2,
			becomes: jj$2,
			stays: jj$2,
			tastes: jj$2,
			taste: jj$2,
			smells: jj$2,
			smell: jj$2,
			gets: jj$2,
			grows: jj$2,
			as: jj$2,
			rings: jj$2,
			radiates: jj$2,
			conveys: jj$2,
			convey: jj$2,
			conveyed: jj$2,
			of: jj$2
		},
		afterWords: {
			too: jj$2,
			also: jj$2,
			or: jj$2,
			enough: jj$2,
			as: jj$2
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/_gerund.js
	var g$1 = "Gerund";
	var _gerund_default = {
		beforeTags: {
			Adverb: g$1,
			Preposition: g$1,
			Conjunction: g$1
		},
		afterTags: {
			Adverb: g$1,
			Possessive: g$1,
			Person: g$1,
			Pronoun: g$1,
			Determiner: g$1,
			Copula: g$1,
			Preposition: g$1,
			Conjunction: g$1,
			Comparative: g$1
		},
		beforeWords: {
			been: g$1,
			keep: g$1,
			continue: g$1,
			stop: g$1,
			am: g$1,
			be: g$1,
			me: g$1,
			began: g$1,
			start: g$1,
			starts: g$1,
			started: g$1,
			stops: g$1,
			stopped: g$1,
			help: g$1,
			helps: g$1,
			avoid: g$1,
			avoids: g$1,
			love: g$1,
			loves: g$1,
			loved: g$1,
			hate: g$1,
			hates: g$1,
			hated: g$1
		},
		afterWords: {
			you: g$1,
			me: g$1,
			her: g$1,
			him: g$1,
			his: g$1,
			them: g$1,
			their: g$1,
			it: g$1,
			this: g$1,
			there: g$1,
			on: g$1,
			about: g$1,
			for: g$1,
			up: g$1,
			down: g$1
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/adj-gerund.js
	var g = "Gerund";
	var jj$1 = "Adjective";
	var clue$6 = {
		beforeTags: Object.assign({}, _adj_default.beforeTags, _gerund_default.beforeTags, {
			Imperative: g,
			Infinitive: jj$1,
			Plural: g
		}),
		afterTags: Object.assign({}, _adj_default.afterTags, _gerund_default.afterTags, { Noun: jj$1 }),
		beforeWords: Object.assign({}, _adj_default.beforeWords, _gerund_default.beforeWords, {
			is: jj$1,
			are: g,
			was: jj$1,
			of: jj$1,
			suggest: g,
			suggests: g,
			suggested: g,
			recommend: g,
			recommends: g,
			recommended: g,
			imagine: g,
			imagines: g,
			imagined: g,
			consider: g,
			considered: g,
			considering: g,
			resist: g,
			resists: g,
			resisted: g,
			avoid: g,
			avoided: g,
			avoiding: g,
			except: jj$1,
			accept: jj$1,
			assess: g,
			explore: g,
			fear: g,
			fears: g,
			appreciate: g,
			question: g,
			help: g,
			embrace: g,
			with: jj$1
		}),
		afterWords: Object.assign({}, _adj_default.afterWords, _gerund_default.afterWords, {
			to: g,
			not: g,
			the: g
		})
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/adj-noun.js
	var misc$1 = {
		beforeTags: {
			Determiner: void 0,
			Cardinal: "Noun",
			PhrasalVerb: "Adjective"
		},
		afterTags: {}
	};
	var clue$5 = {
		beforeTags: Object.assign({}, _adj_default.beforeTags, _noun_default.beforeTags, misc$1.beforeTags),
		afterTags: Object.assign({}, _adj_default.afterTags, _noun_default.afterTags, misc$1.afterTags),
		beforeWords: Object.assign({}, _adj_default.beforeWords, _noun_default.beforeWords, {
			are: "Adjective",
			is: "Adjective",
			was: "Adjective",
			be: "Adjective",
			off: "Adjective",
			out: "Adjective"
		}),
		afterWords: Object.assign({}, _adj_default.afterWords, _noun_default.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/adj-past.js
	var past = "PastTense";
	var jj = "Adjective";
	var adjPast = {
		beforeTags: {
			Adverb: past,
			Pronoun: past,
			ProperNoun: past,
			Auxiliary: past,
			Noun: past
		},
		afterTags: {
			Possessive: past,
			Pronoun: past,
			Determiner: past,
			Adverb: past,
			Comparative: past,
			Date: past,
			Gerund: past
		},
		beforeWords: {
			be: past,
			who: past,
			get: jj,
			had: past,
			has: past,
			have: past,
			been: past,
			it: past,
			as: past,
			for: jj,
			more: jj,
			always: jj
		},
		afterWords: {
			by: past,
			back: past,
			out: past,
			in: past,
			up: past,
			down: past,
			before: past,
			after: past,
			for: past,
			the: past,
			with: past,
			as: past,
			on: past,
			at: past,
			between: past,
			to: past,
			into: past,
			us: past,
			them: past,
			his: past,
			her: past,
			their: past,
			our: past,
			me: past,
			about: jj
		}
	};
	var adj_past_default = {
		beforeTags: Object.assign({}, _adj_default.beforeTags, adjPast.beforeTags),
		afterTags: Object.assign({}, _adj_default.afterTags, adjPast.afterTags),
		beforeWords: Object.assign({}, _adj_default.beforeWords, adjPast.beforeWords),
		afterWords: Object.assign({}, _adj_default.afterWords, adjPast.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/adj-present.js
	var clue$4 = {
		beforeTags: Object.assign({}, _adj_default.beforeTags, _verb_default.beforeTags, {
			Adverb: void 0,
			Negative: void 0
		}),
		afterTags: Object.assign({}, _adj_default.afterTags, _verb_default.afterTags, { afterTags: {
			Noun: "Adjective",
			Conjunction: void 0
		} }.afterTags),
		beforeWords: Object.assign({}, _adj_default.beforeWords, _verb_default.beforeWords, {
			have: void 0,
			had: void 0,
			not: void 0,
			went: "Adjective",
			goes: "Adjective",
			got: "Adjective",
			be: "Adjective"
		}),
		afterWords: Object.assign({}, _adj_default.afterWords, _verb_default.afterWords, {
			to: void 0,
			as: "Adjective"
		})
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/noun-gerund.js
	var misc = {
		beforeTags: {
			Copula: "Gerund",
			PastTense: "Gerund",
			PresentTense: "Gerund",
			Infinitive: "Gerund"
		},
		afterTags: { Value: "Gerund" },
		beforeWords: {
			are: "Gerund",
			were: "Gerund",
			be: "Gerund",
			no: "Gerund",
			without: "Gerund",
			you: "Gerund",
			we: "Gerund",
			they: "Gerund",
			he: "Gerund",
			she: "Gerund",
			us: "Gerund",
			them: "Gerund"
		},
		afterWords: {
			the: "Gerund",
			this: "Gerund",
			that: "Gerund",
			me: "Gerund",
			us: "Gerund",
			them: "Gerund"
		}
	};
	var clue$3 = {
		beforeTags: Object.assign({}, _gerund_default.beforeTags, _noun_default.beforeTags, misc.beforeTags),
		afterTags: Object.assign({}, _gerund_default.afterTags, _noun_default.afterTags, misc.afterTags),
		beforeWords: Object.assign({}, _gerund_default.beforeWords, _noun_default.beforeWords, misc.beforeWords),
		afterWords: Object.assign({}, _gerund_default.afterWords, _noun_default.afterWords, misc.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/noun-verb.js
	var nn$1 = "Singular";
	var vb$1 = "Infinitive";
	var clue$2 = {
		beforeTags: Object.assign({}, _verb_default.beforeTags, _noun_default.beforeTags, {
			Adjective: nn$1,
			Particle: nn$1
		}),
		afterTags: Object.assign({}, _verb_default.afterTags, _noun_default.afterTags, {
			ProperNoun: vb$1,
			Gerund: vb$1,
			Adjective: vb$1,
			Copula: nn$1
		}),
		beforeWords: Object.assign({}, _verb_default.beforeWords, _noun_default.beforeWords, {
			is: nn$1,
			was: nn$1,
			of: nn$1,
			have: null
		}),
		afterWords: Object.assign({}, _verb_default.afterWords, _noun_default.afterWords, {
			instead: vb$1,
			about: vb$1,
			his: vb$1,
			her: vb$1,
			to: null,
			by: null,
			in: null
		})
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/_person.js
	var p$1 = "Person";
	var _person_default = {
		beforeTags: {
			Honorific: p$1,
			Person: p$1
		},
		afterTags: {
			Person: p$1,
			ProperNoun: p$1,
			Verb: p$1
		},
		ownTags: { ProperNoun: p$1 },
		beforeWords: {
			hi: p$1,
			hey: p$1,
			yo: p$1,
			dear: p$1,
			hello: p$1
		},
		afterWords: {
			said: p$1,
			says: p$1,
			told: p$1,
			tells: p$1,
			feels: p$1,
			felt: p$1,
			seems: p$1,
			thinks: p$1,
			thought: p$1,
			spends: p$1,
			spendt: p$1,
			plays: p$1,
			played: p$1,
			sing: p$1,
			sang: p$1,
			learn: p$1,
			learned: p$1,
			wants: p$1,
			wanted: p$1
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/person-date.js
	var m = "Month";
	var month = {
		beforeTags: {
			Date: m,
			Value: m
		},
		afterTags: {
			Date: m,
			Value: m
		},
		beforeWords: {
			by: m,
			in: m,
			on: m,
			during: m,
			after: m,
			before: m,
			between: m,
			until: m,
			til: m,
			sometime: m,
			of: m,
			this: m,
			next: m,
			last: m,
			previous: m,
			following: m,
			with: "Person"
		},
		afterWords: {
			sometime: m,
			in: m,
			of: m,
			until: m,
			the: m
		}
	};
	var person_date_default = {
		beforeTags: Object.assign({}, _person_default.beforeTags, month.beforeTags),
		afterTags: Object.assign({}, _person_default.afterTags, month.afterTags),
		beforeWords: Object.assign({}, _person_default.beforeWords, month.beforeWords),
		afterWords: Object.assign({}, _person_default.afterWords, month.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/person-noun.js
	var clue$1 = {
		beforeTags: Object.assign({}, _noun_default.beforeTags, _person_default.beforeTags),
		afterTags: Object.assign({}, _noun_default.afterTags, _person_default.afterTags),
		beforeWords: Object.assign({}, _noun_default.beforeWords, _person_default.beforeWords, {
			i: "Infinitive",
			we: "Infinitive"
		}),
		afterWords: Object.assign({}, _noun_default.afterWords, _person_default.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/person-verb.js
	var clues$3 = {
		beforeTags: Object.assign({}, _noun_default.beforeTags, _person_default.beforeTags, _verb_default.beforeTags),
		afterTags: Object.assign({}, _noun_default.afterTags, _person_default.afterTags, _verb_default.afterTags),
		beforeWords: Object.assign({}, _noun_default.beforeWords, _person_default.beforeWords, _verb_default.beforeWords),
		afterWords: Object.assign({}, _noun_default.afterWords, _person_default.afterWords, _verb_default.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/person-place.js
	var p = "Place";
	var place = {
		beforeTags: { Place: p },
		afterTags: {
			Place: p,
			Abbreviation: p
		},
		beforeWords: {
			in: p,
			by: p,
			near: p,
			from: p,
			to: p
		},
		afterWords: {
			in: p,
			by: p,
			near: p,
			from: p,
			to: p,
			government: p,
			council: p,
			region: p,
			city: p
		}
	};
	var clue = {
		beforeTags: Object.assign({}, place.beforeTags, _person_default.beforeTags),
		afterTags: Object.assign({}, place.afterTags, _person_default.afterTags),
		beforeWords: Object.assign({}, place.beforeWords, _person_default.beforeWords),
		afterWords: Object.assign({}, place.afterWords, _person_default.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/person-adj.js
	var clues$2 = {
		beforeTags: Object.assign({}, _person_default.beforeTags, _adj_default.beforeTags),
		afterTags: Object.assign({}, _person_default.afterTags, _adj_default.afterTags),
		beforeWords: Object.assign({}, _person_default.beforeWords, _adj_default.beforeWords),
		afterWords: Object.assign({}, _person_default.afterWords, _adj_default.afterWords)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/unit-noun.js
	var un = "Unit";
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/clues/index.js
	var clues = {
		"Actor|Verb": clue$7,
		"Adj|Gerund": clue$6,
		"Adj|Noun": clue$5,
		"Adj|Past": adj_past_default,
		"Adj|Present": clue$4,
		"Noun|Verb": clue$2,
		"Noun|Gerund": clue$3,
		"Person|Noun": clue$1,
		"Person|Date": person_date_default,
		"Person|Verb": clues$3,
		"Person|Place": clue,
		"Person|Adj": clues$2,
		"Unit|Noun": {
			beforeTags: { Value: un },
			afterTags: {},
			beforeWords: {
				per: un,
				every: un,
				each: un,
				square: un,
				cubic: un,
				sq: un,
				metric: un
			},
			afterWords: {
				per: un,
				squared: un,
				cubed: un,
				long: un
			}
		}
	};
	var copy = (obj, more) => {
		const res = Object.keys(obj).reduce((h, k) => {
			h[k] = obj[k] === "Infinitive" ? "PresentTense" : "Plural";
			return h;
		}, {});
		return Object.assign(res, more);
	};
	clues["Plural|Verb"] = {
		beforeWords: copy(clues["Noun|Verb"].beforeWords, {
			had: "Plural",
			have: "Plural"
		}),
		afterWords: copy(clues["Noun|Verb"].afterWords, {
			his: "PresentTense",
			her: "PresentTense",
			its: "PresentTense",
			in: null,
			to: null,
			is: "PresentTense",
			by: "PresentTense"
		}),
		beforeTags: copy(clues["Noun|Verb"].beforeTags, {
			Conjunction: "PresentTense",
			Noun: void 0,
			ProperNoun: "PresentTense"
		}),
		afterTags: copy(clues["Noun|Verb"].afterTags, {
			Gerund: "Plural",
			Noun: "PresentTense",
			Value: "PresentTense"
		})
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/patterns/suffixes.js
	var Adj$2 = "Adjective";
	var Inf$1 = "Infinitive";
	var Pres$1 = "PresentTense";
	var Sing$1 = "Singular";
	var Past$1 = "PastTense";
	var Avb = "Adverb";
	var Plrl = "Plural";
	var Actor$1 = "Actor";
	var Vb = "Verb";
	var Noun$2 = "Noun";
	var Prop = "ProperNoun";
	var Last$1 = "LastName";
	var Modal = "Modal";
	var Place = "Place";
	var Prt = "Participle";
	var suffixes_default = [
		null,
		null,
		{
			ea: Sing$1,
			ia: Noun$2,
			ic: Adj$2,
			ly: Avb,
			"'n": Vb,
			"'t": Vb
		},
		{
			oed: Past$1,
			ued: Past$1,
			xed: Past$1,
			" so": Avb,
			"'ll": Modal,
			"'re": "Copula",
			azy: Adj$2,
			eer: Noun$2,
			end: Vb,
			ped: Past$1,
			ffy: Adj$2,
			ify: Inf$1,
			ing: "Gerund",
			ize: Inf$1,
			ibe: Inf$1,
			lar: Adj$2,
			mum: Adj$2,
			nes: Pres$1,
			nny: Adj$2,
			ous: Adj$2,
			que: Adj$2,
			ger: Noun$2,
			ber: Noun$2,
			rol: Sing$1,
			sis: Sing$1,
			ogy: Sing$1,
			oid: Sing$1,
			ian: Sing$1,
			zes: Pres$1,
			eld: Past$1,
			ken: Prt,
			ven: Prt,
			ten: Prt,
			ect: Inf$1,
			ict: Inf$1,
			ign: Inf$1,
			oze: Inf$1,
			ful: Adj$2,
			bal: Adj$2,
			ton: Noun$2,
			pur: Place
		},
		{
			amed: Past$1,
			aped: Past$1,
			ched: Past$1,
			lked: Past$1,
			rked: Past$1,
			reed: Past$1,
			nded: Past$1,
			mned: Adj$2,
			cted: Past$1,
			dged: Past$1,
			ield: Sing$1,
			akis: Last$1,
			cede: Inf$1,
			chuk: Last$1,
			czyk: Last$1,
			ects: Pres$1,
			iend: Sing$1,
			ends: Vb,
			enko: Last$1,
			ette: Sing$1,
			iary: Sing$1,
			wner: Sing$1,
			fies: Pres$1,
			fore: Avb,
			gate: Inf$1,
			gone: Adj$2,
			ices: Plrl,
			ints: Plrl,
			ruct: Inf$1,
			ines: Plrl,
			ions: Plrl,
			ners: Plrl,
			pers: Plrl,
			lers: Plrl,
			less: Adj$2,
			llen: Adj$2,
			made: Adj$2,
			nsen: Last$1,
			oses: Pres$1,
			ould: Modal,
			some: Adj$2,
			sson: Last$1,
			ians: Plrl,
			tion: Sing$1,
			tage: Noun$2,
			ique: Sing$1,
			tive: Adj$2,
			tors: Noun$2,
			vice: Sing$1,
			lier: Sing$1,
			fier: Sing$1,
			wned: Past$1,
			gent: Sing$1,
			tist: Actor$1,
			pist: Actor$1,
			rist: Actor$1,
			mist: Actor$1,
			yist: Actor$1,
			vist: Actor$1,
			ists: Actor$1,
			lite: Sing$1,
			site: Sing$1,
			rite: Sing$1,
			mite: Sing$1,
			bite: Sing$1,
			mate: Sing$1,
			date: Sing$1,
			ndal: Sing$1,
			vent: Sing$1,
			uist: Actor$1,
			gist: Actor$1,
			note: Sing$1,
			cide: Sing$1,
			ence: Sing$1,
			wide: Adj$2,
			vide: Inf$1,
			ract: Inf$1,
			duce: Inf$1,
			pose: Inf$1,
			eive: Inf$1,
			lyze: Inf$1,
			lyse: Inf$1,
			iant: Adj$2,
			nary: Adj$2,
			ghty: Adj$2,
			uent: Adj$2,
			erer: Actor$1,
			bury: Place,
			dorf: Noun$2,
			esty: Noun$2,
			wych: Place,
			dale: Place,
			folk: Place,
			vale: Place,
			abad: Place,
			sham: Place,
			wick: Place,
			view: Place
		},
		{
			elist: Actor$1,
			holic: Sing$1,
			phite: Sing$1,
			tized: Past$1,
			urned: Past$1,
			eased: Past$1,
			ances: Plrl,
			bound: Adj$2,
			ettes: Plrl,
			fully: Avb,
			ishes: Pres$1,
			ities: Plrl,
			marek: Last$1,
			nssen: Last$1,
			ology: Noun$2,
			osome: Sing$1,
			tment: Sing$1,
			ports: Plrl,
			rough: Adj$2,
			tches: Pres$1,
			tieth: "Ordinal",
			tures: Plrl,
			wards: Avb,
			where: Avb,
			archy: Noun$2,
			pathy: Noun$2,
			opoly: Noun$2,
			embly: Noun$2,
			phate: Noun$2,
			ndent: Sing$1,
			scent: Sing$1,
			onist: Actor$1,
			anist: Actor$1,
			alist: Actor$1,
			olist: Actor$1,
			icist: Actor$1,
			ounce: Inf$1,
			iable: Adj$2,
			borne: Adj$2,
			gnant: Adj$2,
			inant: Adj$2,
			igent: Adj$2,
			atory: Adj$2,
			rient: Sing$1,
			dient: Sing$1,
			maker: Actor$1,
			burgh: Place,
			mouth: Place,
			ceter: Place,
			ville: Place,
			hurst: Place,
			stead: Place,
			endon: Place,
			brook: Place,
			shire: Place,
			worth: Noun$2,
			field: Prop,
			ridge: Place
		},
		{
			auskas: Last$1,
			parent: Sing$1,
			cedent: Sing$1,
			ionary: Sing$1,
			cklist: Sing$1,
			brooke: Place,
			keeper: Actor$1,
			logist: Actor$1,
			teenth: "Value",
			worker: Actor$1,
			master: Actor$1,
			writer: Actor$1,
			brough: Place,
			cester: Place,
			ington: Place,
			cliffe: Place,
			ingham: Place
		},
		{
			chester: Place,
			logists: Actor$1,
			opoulos: Last$1,
			borough: Place,
			sdottir: Last$1
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/patterns/prefixes.js
	var Adj$1 = "Adjective";
	var Noun$1 = "Noun";
	var Verb$1 = "Verb";
	var prefixes_default = [
		null,
		null,
		{},
		{
			neo: Noun$1,
			bio: Noun$1,
			"de-": Verb$1,
			"re-": Verb$1,
			"un-": Verb$1,
			"ex-": Noun$1
		},
		{
			anti: Noun$1,
			auto: Noun$1,
			faux: Adj$1,
			hexa: Noun$1,
			kilo: Noun$1,
			mono: Noun$1,
			nano: Noun$1,
			octa: Noun$1,
			poly: Noun$1,
			semi: Adj$1,
			tele: Noun$1,
			"pro-": Adj$1,
			"mis-": Verb$1,
			"dis-": Verb$1,
			"pre-": Adj$1
		},
		{
			anglo: Noun$1,
			centi: Noun$1,
			ethno: Noun$1,
			ferro: Noun$1,
			grand: Noun$1,
			hepta: Noun$1,
			hydro: Noun$1,
			intro: Noun$1,
			macro: Noun$1,
			micro: Noun$1,
			milli: Noun$1,
			nitro: Noun$1,
			penta: Noun$1,
			quasi: Adj$1,
			radio: Noun$1,
			tetra: Noun$1,
			"omni-": Adj$1,
			"post-": Adj$1
		},
		{
			pseudo: Adj$1,
			"extra-": Adj$1,
			"hyper-": Adj$1,
			"inter-": Adj$1,
			"intra-": Adj$1,
			"deca-": Adj$1
		},
		{ electro: Noun$1 }
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/patterns/endsWith.js
	var Adj = "Adjective";
	var Inf = "Infinitive";
	var Pres = "PresentTense";
	var Sing = "Singular";
	var Past = "PastTense";
	var Adverb = "Adverb";
	var Exp = "Expression";
	var Actor = "Actor";
	var Verb = "Verb";
	var Noun = "Noun";
	var Last = "LastName";
	var endsWith_default = {
		a: [
			[
				/.[aeiou]na$/,
				Noun,
				"tuna"
			],
			[/.[oau][wvl]ska$/, Last],
			[
				/.[^aeiou]ica$/,
				Sing,
				"harmonica"
			],
			[
				/^([hyj]a+)+$/,
				Exp,
				"haha"
			]
		],
		c: [[/.[^aeiou]ic$/, Adj]],
		d: [
			[
				/[aeiou](pp|ll|ss|ff|gg|tt|rr|bb|nn|mm)ed$/,
				Past,
				"popped"
			],
			[
				/.[aeo]{2}[bdgmnprvz]ed$/,
				Past,
				"rammed"
			],
			[
				/.[aeiou][sg]hed$/,
				Past,
				"gushed"
			],
			[
				/.[aeiou]red$/,
				Past,
				"hired"
			],
			[
				/.[aeiou]r?ried$/,
				Past,
				"hurried"
			],
			[
				/[^aeiou]ard$/,
				Sing,
				"steward"
			],
			[
				/[aeiou][^aeiou]id$/,
				Adj,
				""
			],
			[
				/.[vrl]id$/,
				Adj,
				"livid"
			],
			[
				/..led$/,
				Past,
				"hurled"
			],
			[
				/.[iao]sed$/,
				Past,
				""
			],
			[
				/[aeiou]n?[cs]ed$/,
				Past,
				""
			],
			[
				/[aeiou][rl]?[mnf]ed$/,
				Past,
				""
			],
			[
				/[aeiou][ns]?c?ked$/,
				Past,
				"bunked"
			],
			[/[aeiou]gned$/, Past],
			[/[aeiou][nl]?ged$/, Past],
			[/.[tdbwxyz]ed$/, Past],
			[/[^aeiou][aeiou][tvx]ed$/, Past],
			[
				/.[cdflmnprstv]ied$/,
				Past,
				"emptied"
			]
		],
		e: [
			[
				/.[lnr]ize$/,
				Inf,
				"antagonize"
			],
			[
				/.[^aeiou]ise$/,
				Inf,
				"antagonise"
			],
			[
				/.[aeiou]te$/,
				Inf,
				"bite"
			],
			[
				/.[^aeiou][ai]ble$/,
				Adj,
				"fixable"
			],
			[
				/.[^aeiou]eable$/,
				Adj,
				"maleable"
			],
			[
				/.[ts]ive$/,
				Adj,
				"festive"
			],
			[
				/[a-z]-like$/,
				Adj,
				"woman-like"
			]
		],
		h: [
			[
				/.[^aeiouf]ish$/,
				Adj,
				"cornish"
			],
			[
				/.v[iy]ch$/,
				Last,
				"..ovich"
			],
			[
				/^ug?h+$/,
				Exp,
				"ughh"
			],
			[
				/^uh[ -]?oh$/,
				Exp,
				"uhoh"
			],
			[
				/[a-z]-ish$/,
				Adj,
				"cartoon-ish"
			]
		],
		i: [[
			/.[oau][wvl]ski$/,
			Last,
			"polish-male"
		]],
		k: [[
			/^(k){2}$/,
			Exp,
			"kkkk"
		]],
		l: [
			[
				/.[gl]ial$/,
				Adj,
				"familial"
			],
			[
				/.[^aeiou]ful$/,
				Adj,
				"fitful"
			],
			[
				/.[nrtumcd]al$/,
				Adj,
				"natal"
			],
			[
				/.[^aeiou][ei]al$/,
				Adj,
				"familial"
			]
		],
		m: [
			[
				/.[^aeiou]ium$/,
				Sing,
				"magnesium"
			],
			[
				/[^aeiou]ism$/,
				Sing,
				"schism"
			],
			[
				/^[hu]m+$/,
				Exp,
				"hmm"
			],
			[
				/^\d+ ?[ap]m$/,
				"Date",
				"3am"
			]
		],
		n: [
			[
				/.[lsrnpb]ian$/,
				Adj,
				"republican"
			],
			[
				/[^aeiou]ician$/,
				Actor,
				"musician"
			],
			[
				/[aeiou][ktrp]in'$/,
				"Gerund",
				"cookin'"
			]
		],
		o: [
			[
				/^no+$/,
				Exp,
				"noooo"
			],
			[
				/^(yo)+$/,
				Exp,
				"yoo"
			],
			[
				/^wo{2,}[pt]?$/,
				Exp,
				"woop"
			]
		],
		r: [
			[/.[bdfklmst]ler$/, "Noun"],
			[/[aeiou][pns]er$/, Sing],
			[/[^i]fer$/, Inf],
			[/.[^aeiou][ao]pher$/, Actor],
			[/.[lk]er$/, "Noun"],
			[/.ier$/, "Comparative"]
		],
		t: [
			[/.[di]est$/, "Superlative"],
			[/.[icldtgrv]ent$/, Adj],
			[/[aeiou].*ist$/, Adj],
			[/^[a-z]et$/, Verb]
		],
		s: [
			[/.[^aeiou]ises$/, Pres],
			[/.[rln]ates$/, Pres],
			[/.[^z]ens$/, Verb],
			[/.[lstrn]us$/, Sing],
			[/.[aeiou]sks$/, Pres],
			[/.[aeiou]kes$/, Pres],
			[/[aeiou][^aeiou]is$/, Sing],
			[/[a-z]'s$/, Noun],
			[/^yes+$/, Exp]
		],
		v: [[/.[^aeiou][ai][kln]ov$/, Last]],
		y: [
			[/.[cts]hy$/, Adj],
			[/.[st]ty$/, Adj],
			[/.[tnl]ary$/, Adj],
			[/.[oe]ry$/, Sing],
			[/[rdntkbhs]ly$/, Adverb],
			[/.(gg|bb|zz)ly$/, Adj],
			[/...lly$/, Adverb],
			[/.[gk]y$/, Adj],
			[/[bszmp]{2}y$/, Adj],
			[/.[ai]my$/, Adj],
			[/[ea]{2}zy$/, Adj],
			[/.[^aeiou]ity$/, Sing]
		]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/patterns/neighbours.js
	var vb = "Verb";
	var nn = "Noun";
	var neighbours_default = {
		leftTags: [
			["Adjective", nn],
			["Possessive", nn],
			["Determiner", nn],
			["Adverb", vb],
			["Pronoun", vb],
			["Value", nn],
			["Ordinal", nn],
			["Modal", vb],
			["Superlative", nn],
			["Demonym", nn],
			["Honorific", "Person"]
		],
		leftWords: [
			["i", vb],
			["first", nn],
			["it", vb],
			["there", vb],
			["not", vb],
			["because", nn],
			["if", nn],
			["but", nn],
			["who", vb],
			["this", nn],
			["his", nn],
			["when", nn],
			["you", vb],
			["very", "Adjective"],
			["old", nn],
			["never", vb],
			["before", nn],
			["a", nn],
			["the", nn],
			["been", vb]
		],
		rightTags: [
			["Copula", nn],
			["PastTense", nn],
			["Conjunction", nn],
			["Modal", nn]
		],
		rightWords: [
			["there", vb],
			["me", vb],
			["man", "Adjective"],
			["him", vb],
			["it", vb],
			["were", nn],
			["took", nn],
			["himself", vb],
			["went", nn],
			["who", nn],
			["jr", "Person"]
		]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/models/_data.js
	var _data_default = {
		"Comparative": {
			"fwd": "3:ser,ier¦1er:h,t,f,l,n¦1r:e¦2er:ss,or,om",
			"both": "3er:ver,ear,alm¦3ner:hin¦3ter:lat¦2mer:im¦2er:ng,rm,mb¦2ber:ib¦2ger:ig¦1er:w,p,k,d¦ier:y",
			"rev": "1:tter,yer¦2:uer,ver,ffer,oner,eler,ller,iler,ster,cer,uler,sher,ener,gher,aner,adder,nter,eter,rter,hter,rner,fter¦3:oser,ooler,eafer,user,airer,bler,maler,tler,eater,uger,rger,ainer,urer,ealer,icher,pler,emner,icter,nser,iser¦4:arser,viner,ucher,rosser,somer,ndomer,moter,oother,uarer,hiter¦5:nuiner,esser,emier¦ar:urther",
			"ex": "worse:bad¦better:good¦4er:fair,gray,poor¦1urther:far¦3ter:fat,hot,wet¦3der:mad,sad¦3er:shy,fun¦4der:glad¦:¦4r:cute,dire,fake,fine,free,lame,late,pale,rare,ripe,rude,safe,sore,tame,wide¦5r:eerie,stale"
		},
		"Gerund": {
			"fwd": "1:nning,tting,rring,pping,eing,mming,gging,dding,bbing,kking¦2:eking,oling,eling,eming¦3:velling,siting,uiting,fiting,loting,geting,ialing,celling¦4:graming",
			"both": "1:aing,iing,fing,xing,ying,oing,hing,wing¦2:tzing,rping,izzing,bting,mning,sping,wling,rling,wding,rbing,uping,lming,wning,mping,oning,lting,mbing,lking,fting,hting,sking,gning,pting,cking,ening,nking,iling,eping,ering,rting,rming,cting,lping,ssing,nting,nding,lding,sting,rning,rding,rking¦3:belling,siping,toming,yaking,uaking,oaning,auling,ooping,aiding,naping,euring,tolling,uzzing,ganing,haning,ualing,halling,iasing,auding,ieting,ceting,ouling,voring,ralling,garing,joring,oaming,oaking,roring,nelling,ooring,uelling,eaming,ooding,eaping,eeting,ooting,ooming,xiting,keting,ooking,ulling,airing,oaring,biting,outing,oiting,earing,naling,oading,eeding,ouring,eaking,aiming,illing,oining,eaning,onging,ealing,aining,eading¦4:thoming,melling,aboring,ivoting,weating,dfilling,onoring,eriting,imiting,tialling,rgining,otoring,linging,winging,lleting,louding,spelling,mpelling,heating,feating,opelling,choring,welling,ymaking,ctoring,calling,peating,iloring,laiting,utoring,uditing,mmaking,loating,iciting,waiting,mbating,voiding,otalling,nsoring,nselling,ocusing,itoring,eloping¦5:rselling,umpeting,atrolling,treating,tselling,rpreting,pringing,ummeting,ossoming,elmaking,eselling,rediting,totyping,onmaking,rfeiting,ntrolling¦5e:chmaking,dkeeping,severing,erouting,ecreting,ephoning,uthoring,ravening,reathing,pediting,erfering,eotyping,fringing,entoring,ombining,ompeting¦4e:emaking,eething,twining,rruling,chuting,xciting,rseding,scoping,edoring,pinging,lunging,agining,craping,pleting,eleting,nciting,nfining,ncoding,tponing,ecoding,writing,esaling,nvening,gnoring,evoting,mpeding,rvening,dhering,mpiling,storing,nviting,ploring¦3e:tining,nuring,saking,miring,haling,ceding,xuding,rining,nuting,laring,caring,miling,riding,hoking,piring,lading,curing,uading,noting,taping,futing,paring,hading,loding,siring,guring,vading,voking,during,niting,laning,caping,luting,muting,ruding,ciding,juring,laming,caling,hining,uoting,liding,ciling,duling,tuting,puting,cuting,coring,uiding,tiring,turing,siding,rading,enging,haping,buting,lining,taking,anging,haring,uiring,coming,mining,moting,suring,viding,luding¦2e:tring,zling,uging,oging,gling,iging,vring,fling,lging,obing,psing,pling,ubing,cling,dling,wsing,iking,rsing,dging,kling,ysing,tling,rging,eging,nsing,uning,osing,uming,using,ibing,bling,aging,ising,asing,ating¦2ie:rlying¦1e:zing,uing,cing,ving",
			"rev": "ying:ie¦1ing:se,ke,te,we,ne,re,de,pe,me,le,c,he¦2ing:ll,ng,dd,ee,ye,oe,rg,us¦2ning:un¦2ging:og,ag,ug,ig,eg¦2ming:um¦2bing:ub,ab,eb,ob¦3ning:lan,can,hin,pin,win¦3ring:cur,lur,tir,tar,pur,car¦3ing:ait,del,eel,fin,eat,oat,eem,lel,ool,ein,uin¦3ping:rop,rap,top,uip,wap,hip,hop,lap,rip,cap¦3ming:tem,wim,rim,kim,lim¦3ting:mat,cut,pot,lit,lot,hat,set,pit,put¦3ding:hed,bed,bid¦3king:rek¦3ling:cil,pel¦3bing:rib¦4ning:egin¦4ing:isit,ruit,ilot,nsit,dget,rkel,ival,rcel¦4ring:efer,nfer¦4ting:rmit,mmit,ysit,dmit,emit,bmit,tfit,gret¦4ling:evel,xcel,ivel¦4ding:hred¦5ing:arget,posit,rofit¦5ring:nsfer¦5ting:nsmit,orget,cquit¦5ling:ancel,istil",
			"ex": "3:adding,eating,aiming,aiding,airing,outing,gassing,setting,getting,putting,cutting,winning,sitting,betting,mapping,tapping,letting,bidding,hitting,tanning,netting,popping,fitting,capping,lapping,barring,banning,vetting,topping,rotting,tipping,potting,wetting,pitting,dipping,budding,hemming,pinning,jetting,kidding,padding,podding,sipping,wedding,bedding,donning,warring,penning,gutting,cueing,wadding,petting,ripping,napping,matting,tinning,binning,dimming,hopping,mopping,nodding,panning,rapping,ridding,sinning¦4:selling,falling,calling,waiting,editing,telling,rolling,heating,boating,hanging,beating,coating,singing,tolling,felling,polling,discing,seating,voiding,gelling,yelling,baiting,reining,ruining,seeking,spanning,stepping,knitting,emitting,slipping,quitting,dialing,omitting,clipping,shutting,skinning,abutting,flipping,trotting,cramming,fretting,suiting¦5:bringing,treating,spelling,stalling,trolling,expelling,rivaling,wringing,deterring,singeing,befitting,refitting¦6:enrolling,distilling,scrolling,strolling,caucusing,travelling¦7:installing,redefining,stencilling,recharging,overeating,benefiting,unraveling,programing¦9:reprogramming¦is:being¦2e:using,aging,owing¦3e:making,taking,coming,noting,hiring,filing,coding,citing,doping,baking,coping,hoping,lading,caring,naming,voting,riding,mining,curing,lining,ruling,typing,boring,dining,firing,hiding,piling,taping,waning,baling,boning,faring,honing,wiping,luring,timing,wading,piping,fading,biting,zoning,daring,waking,gaming,raking,ceding,tiring,coking,wining,joking,paring,gaping,poking,pining,coring,liming,toting,roping,wiring,aching¦4e:writing,storing,eroding,framing,smoking,tasting,wasting,phoning,shaking,abiding,braking,flaking,pasting,priming,shoring,sloping,withing,hinging¦5e:defining,refining,renaming,swathing,fringing,reciting¦1ie:dying,tying,lying,vying¦7e:sunbathing"
		},
		"Participle": {
			"fwd": "1:mt¦2:llen¦3:iven,aken¦:ne¦y:in",
			"both": "1:wn¦2:me,aten¦3:seen,bidden,isen¦4:roven,asten¦3l:pilt¦3d:uilt¦2e:itten¦1im:wum¦1eak:poken¦1ine:hone¦1ose:osen¦1in:gun¦1ake:woken¦ear:orn¦eal:olen¦eeze:ozen¦et:otten¦ink:unk¦ing:ung",
			"rev": "2:un¦oken:eak¦ought:eek¦oven:eave¦1ne:o¦1own:ly¦1den:de¦1in:ay¦2t:am¦2n:ee¦3en:all¦4n:rive,sake,take¦5n:rgive",
			"ex": "2:been¦3:seen,run¦4:given,taken¦5:shaken¦2eak:broken¦1ive:dove¦2y:flown¦3e:hidden,ridden¦1eek:sought¦1ake:woken¦1eave:woven"
		},
		"PastTense": {
			"fwd": "1:tted,wed,gged,nned,een,rred,pped,yed,bbed,oed,dded,rd,wn,mmed¦2:eed,nded,et,hted,st,oled,ut,emed,eled,lded,ken,rt,nked,apt,ant,eped,eked¦3:eared,eat,eaded,nelled,ealt,eeded,ooted,eaked,eaned,eeted,mited,bid,uit,ead,uited,ealed,geted,velled,ialed,belled¦4:ebuted,hined,comed¦y:ied¦ome:ame¦ear:ore¦ind:ound¦ing:ung,ang¦ep:pt¦ink:ank,unk¦ig:ug¦all:ell¦ee:aw¦ive:ave¦eeze:oze¦old:eld¦ave:ft¦ake:ook¦ell:old¦ite:ote¦ide:ode¦ine:one¦in:un,on¦eal:ole¦im:am¦ie:ay¦and:ood¦1ise:rose¦1eak:roke¦1ing:rought¦1ive:rove¦1el:elt¦1id:bade¦1et:got¦1y:aid¦1it:sat¦3e:lid¦3d:pent",
			"both": "1:aed,fed,xed,hed¦2:sged,xted,wled,rped,lked,kied,lmed,lped,uped,bted,rbed,rked,wned,rled,mped,fted,mned,mbed,zzed,omed,ened,cked,gned,lted,sked,ued,zed,nted,ered,rted,rmed,ced,sted,rned,ssed,rded,pted,ved,cted¦3:cled,eined,siped,ooned,uked,ymed,jored,ouded,ioted,oaned,lged,asped,iged,mured,oided,eiled,yped,taled,moned,yled,lit,kled,oaked,gled,naled,fled,uined,oared,valled,koned,soned,aided,obed,ibed,meted,nicked,rored,micked,keted,vred,ooped,oaded,rited,aired,auled,filled,ouled,ooded,ceted,tolled,oited,bited,aped,tled,vored,dled,eamed,nsed,rsed,sited,owded,pled,sored,rged,osed,pelled,oured,psed,oated,loned,aimed,illed,eured,tred,ioned,celled,bled,wsed,ooked,oiled,itzed,iked,iased,onged,ased,ailed,uned,umed,ained,auded,nulled,ysed,eged,ised,aged,oined,ated,used,dged,doned¦4:ntied,efited,uaked,caded,fired,roped,halled,roked,himed,culed,tared,lared,tuted,uared,routed,pited,naked,miled,houted,helled,hared,cored,caled,tired,peated,futed,ciled,called,tined,moted,filed,sided,poned,iloted,honed,lleted,huted,ruled,cured,named,preted,vaded,sured,talled,haled,peded,gined,nited,uided,ramed,feited,laked,gured,ctored,unged,pired,cuted,voked,eloped,ralled,rined,coded,icited,vided,uaded,voted,mined,sired,noted,lined,nselled,luted,jured,fided,puted,piled,pared,olored,cided,hoked,enged,tured,geoned,cotted,lamed,uiled,waited,udited,anged,luded,mired,uired,raded¦5:modelled,izzled,eleted,umpeted,ailored,rseded,treated,eduled,ecited,rammed,eceded,atrolled,nitored,basted,twined,itialled,ncited,gnored,ploded,xcited,nrolled,namelled,plored,efeated,redited,ntrolled,nfined,pleted,llided,lcined,eathed,ibuted,lloted,dhered,cceded¦3ad:sled¦2aw:drew¦2ot:hot¦2ke:made¦2ow:hrew,grew¦2ose:hose¦2d:ilt¦2in:egan¦1un:ran¦1ink:hought¦1ick:tuck¦1ike:ruck¦1eak:poke,nuck¦1it:pat¦1o:did¦1ow:new¦1ake:woke¦go:went",
			"rev": "3:rst,hed,hut,cut,set¦4:tbid¦5:dcast,eread,pread,erbid¦ought:uy,eek¦1ied:ny,ly,dy,ry,fy,py,vy,by,ty,cy¦1ung:ling,ting,wing¦1pt:eep¦1ank:rink¦1ore:bear,wear¦1ave:give¦1oze:reeze¦1ound:rind,wind¦1ook:take,hake¦1aw:see¦1old:sell¦1ote:rite¦1ole:teal¦1unk:tink¦1am:wim¦1ay:lie¦1ood:tand¦1eld:hold¦2d:he,ge,re,le,leed,ne,reed,be,ye,lee,pe,we¦2ed:dd,oy,or,ey,gg,rr,us,ew,to¦2ame:ecome,rcome¦2ped:ap¦2ged:ag,og,ug,eg¦2bed:ub,ab,ib,ob¦2lt:neel¦2id:pay¦2ang:pring¦2ove:trive¦2med:um¦2ode:rride¦2at:ysit¦3ted:mit,hat,mat,lat,pot,rot,bat¦3ed:low,end,tow,und,ond,eem,lay,cho,dow,xit,eld,ald,uld,law,lel,eat,oll,ray,ank,fin,oam,out,how,iek,tay,haw,ait,vet,say,cay,bow¦3d:ste,ede,ode,ete,ree,ude,ame,oke,ote,ime,ute,ade¦3red:lur,cur,pur,car¦3ped:hop,rop,uip,rip,lip,tep,top¦3ded:bed,rod,kid¦3ade:orbid¦3led:uel¦3ned:lan,can,kin,pan,tun¦3med:rim,lim¦4ted:quit,llot¦4ed:pear,rrow,rand,lean,mand,anel,pand,reet,link,abel,evel,imit,ceed,ruit,mind,peal,veal,hool,head,pell,well,mell,uell,band,hear,weak¦4led:nnel,qual,ebel,ivel¦4red:nfer,efer,sfer¦4n:sake,trew¦4d:ntee¦4ded:hred¦4ned:rpin¦5ed:light,nceal,right,ndear,arget,hread,eight,rtial,eboot¦5d:edite,nvite¦5ted:egret¦5led:ravel",
			"ex": "2:been,upped¦3:added,aged,aided,aimed,aired,bid,died,dyed,egged,erred,eyed,fit,gassed,hit,lied,owed,pent,pied,tied,used,vied,oiled,outed,banned,barred,bet,canned,cut,dipped,donned,ended,feed,inked,jarred,let,manned,mowed,netted,padded,panned,pitted,popped,potted,put,set,sewn,sowed,tanned,tipped,topped,vowed,weed,bowed,jammed,binned,dimmed,hopped,mopped,nodded,pinned,rigged,sinned,towed,vetted¦4:ached,baked,baled,boned,bored,called,caned,cared,ceded,cited,coded,cored,cubed,cured,dared,dined,edited,exited,faked,fared,filed,fined,fired,fuelled,gamed,gelled,hired,hoped,joked,lined,mined,named,noted,piled,poked,polled,pored,pulled,reaped,roamed,rolled,ruled,seated,shed,sided,timed,tolled,toned,voted,waited,walled,waned,winged,wiped,wired,zoned,yelled,tamed,lubed,roped,faded,mired,caked,honed,banged,culled,heated,raked,welled,banded,beat,cast,cooled,cost,dealt,feared,folded,footed,handed,headed,heard,hurt,knitted,landed,leaked,leapt,linked,meant,minded,molded,neared,needed,peaked,plodded,plotted,pooled,quit,read,rooted,sealed,seeded,seeped,shipped,shunned,skimmed,slammed,sparred,stemmed,stirred,suited,thinned,twinned,swayed,winked,dialed,abutted,blotted,fretted,healed,heeded,peeled,reeled¦5:basted,cheated,equalled,eroded,exiled,focused,opined,pleated,primed,quoted,scouted,shored,sloped,smoked,sniped,spelled,spouted,routed,staked,stored,swelled,tasted,treated,wasted,smelled,dwelled,honored,prided,quelled,eloped,scared,coveted,sweated,breaded,cleared,debuted,deterred,freaked,modeled,pleaded,rebutted,speeded¦6:anchored,defined,endured,impaled,invited,refined,revered,strolled,cringed,recast,thrust,unfolded¦7:authored,combined,competed,conceded,convened,excreted,extruded,redefined,restored,secreted,rescinded,welcomed¦8:expedited,infringed¦9:interfered,intervened,persevered¦10:contravened¦eat:ate¦is:was¦go:went¦are:were¦3d:bent,lent,rent,sent¦3e:bit,fled,hid,lost¦3ed:bled,bred¦2ow:blew,grew¦1uy:bought¦2tch:caught¦1o:did¦1ive:dove,gave¦2aw:drew¦2ed:fed¦2y:flew,laid,paid,said¦1ight:fought¦1et:got¦2ve:had¦1ang:hung¦2ad:led¦2ght:lit¦2ke:made¦2et:met¦1un:ran¦1ise:rose¦1it:sat¦1eek:sought¦1each:taught¦1ake:woke,took¦1eave:wove¦2ise:arose¦1ear:bore,tore,wore¦1ind:bound,found,wound¦2eak:broke¦2ing:brought,wrung¦1ome:came¦2ive:drove¦1ig:dug¦1all:fell¦2el:felt¦4et:forgot¦1old:held¦2ave:left¦1ing:rang,sang¦1ide:rode¦1ink:sank¦1ee:saw¦2ine:shone¦4e:slid¦1ell:sold,told¦4d:spent¦2in:spun¦1in:won"
		},
		"PresentTense": {
			"fwd": "1:oes¦1ve:as",
			"both": "1:xes¦2:zzes,ches,shes,sses¦3:iases¦2y:llies,plies¦1y:cies,bies,ties,vies,nies,pies,dies,ries,fies¦:s",
			"rev": "1ies:ly¦2es:us,go,do¦3es:cho,eto",
			"ex": "2:does,goes¦3:gasses¦5:focuses¦is:are¦3y:relies¦2y:flies¦2ve:has"
		},
		"Superlative": {
			"fwd": "1st:e¦1est:l,m,f,s¦1iest:cey¦2est:or,ir¦3est:ver",
			"both": "4:east¦5:hwest¦5lest:erful¦4est:weet,lgar,tter,oung¦4most:uter¦3est:ger,der,rey,iet,ong,ear¦3test:lat¦3most:ner¦2est:pt,ft,nt,ct,rt,ht¦2test:it¦2gest:ig¦1est:b,k,n,p,h,d,w¦iest:y",
			"rev": "1:ttest,nnest,yest¦2:sest,stest,rmest,cest,vest,lmest,olest,ilest,ulest,ssest,imest,uest¦3:rgest,eatest,oorest,plest,allest,urest,iefest,uelest,blest,ugest,amest,yalest,ealest,illest,tlest,itest¦4:cerest,eriest,somest,rmalest,ndomest,motest,uarest,tiffest¦5:leverest,rangest¦ar:urthest¦3ey:riciest",
			"ex": "best:good¦worst:bad¦5est:great¦4est:fast,full,fair,dull¦3test:hot,wet,fat¦4nest:thin¦1urthest:far¦3est:gay,shy,ill¦4test:neat¦4st:late,wide,fine,safe,cute,fake,pale,rare,rude,sore,ripe,dire¦6st:severe"
		},
		"AdjToNoun": {
			"fwd": "1:tistic,eable,lful,sful,ting,tty¦2:onate,rtable,geous,ced,seful,ctful¦3:ortive,ented¦arity:ear¦y:etic¦fulness:begone¦1ity:re¦1y:tiful,gic¦2ity:ile,imous,ilous,ime¦2ion:ated¦2eness:iving¦2y:trious¦2ation:iring¦2tion:vant¦3ion:ect¦3ce:mant,mantic¦3tion:irable¦3y:est,estic¦3m:mistic,listic¦3ess:ning¦4n:utious¦4on:rative,native,vative,ective¦4ce:erant",
			"both": "1:king,wing¦2:alous,ltuous,oyful,rdous¦3:gorous,ectable,werful,amatic¦4:oised,usical,agical,raceful,ocused,lined,ightful¦5ness:stful,lding,itous,nuous,ulous,otous,nable,gious,ayful,rvous,ntous,lsive,peful,entle,ciful,osive,leful,isive,ncise,reful,mious¦5ty:ivacious¦5ties:ubtle¦5ce:ilient,adiant,atient¦5cy:icient¦5sm:gmatic¦5on:sessive,dictive¦5ity:pular,sonal,eative,entic¦5sity:uminous¦5ism:conic¦5nce:mperate¦5ility:mitable¦5ment:xcited¦5n:bitious¦4cy:brant,etent,curate¦4ility:erable,acable,icable,ptable¦4ty:nacious,aive,oyal,dacious¦4n:icious¦4ce:vient,erent,stent,ndent,dient,quent,ident¦4ness:adic,ound,hing,pant,sant,oing,oist,tute¦4icity:imple¦4ment:fined,mused¦4ism:otic¦4ry:dantic¦4ity:tund,eral¦4edness:hand¦4on:uitive¦4lity:pitable¦4sm:eroic,namic¦4sity:nerous¦3th:arm¦3ility:pable,bable,dable,iable¦3cy:hant,nant,icate¦3ness:red,hin,nse,ict,iet,ite,oud,ind,ied,rce¦3ion:lute¦3ity:ual,gal,volous,ial¦3ce:sent,fensive,lant,gant,gent,lent,dant¦3on:asive¦3m:fist,sistic,iastic¦3y:terious,xurious,ronic,tastic¦3ur:amorous¦3e:tunate¦3ation:mined¦3sy:rteous¦3ty:ain¦3ry:ave¦3ment:azed¦2ness:de,on,ue,rn,ur,ft,rp,pe,om,ge,rd,od,ay,ss,er,ll,oy,ap,ht,ld,ad,rt¦2inousness:umous¦2ity:neous,ene,id,ane¦2cy:bate,late¦2ation:ized¦2ility:oble,ible¦2y:odic¦2e:oving,aring¦2s:ost¦2itude:pt¦2dom:ee¦2ance:uring¦2tion:reet¦2ion:oted¦2sion:ending¦2liness:an¦2or:rdent¦1th:ung¦1e:uable¦1ness:w,h,k,f¦1ility:mble¦1or:vent¦1ement:ging¦1tiquity:ncient¦1ment:hed¦verty:or¦ength:ong¦eat:ot¦pth:ep¦iness:y",
			"rev": "",
			"ex": "5:forceful,humorous¦8:charismatic¦13:understanding¦5ity:active¦11ness:adventurous,inquisitive,resourceful¦8on:aggressive,automatic,perceptive¦7ness:amorous,fatuous,furtive,ominous,serious¦5ness:ample,sweet¦12ness:apprehensive,cantankerous,contemptuous,ostentatious¦13ness:argumentative,conscientious¦9ness:assertive,facetious,imperious,inventive,oblivious,rapacious,receptive,seditious,whimsical¦10ness:attractive,expressive,impressive,loquacious,salubrious,thoughtful¦3edom:boring¦4ness:calm,fast,keen,tame¦8ness:cheerful,gracious,specious,spurious,timorous,unctuous¦5sity:curious¦9ion:deliberate¦8ion:desperate¦6e:expensive¦7ce:fragrant¦3y:furious¦9ility:ineluctable¦6ism:mystical¦8ity:physical,proactive,sensitive,vertical¦5cy:pliant¦7ity:positive¦9ity:practical¦12ism:professional¦6ce:prudent¦3ness:red¦6cy:vagrant¦3dom:wise"
		}
	};
	//#endregion
	//#region node_modules/.pnpm/suffix-thumb@5.0.2/node_modules/suffix-thumb/src/convert/index.js
	var checkEx = function(str, ex = {}) {
		if (ex.hasOwnProperty(str)) return ex[str];
		return null;
	};
	var checkSame = function(str, same = []) {
		for (let i = 0; i < same.length; i += 1) if (str.endsWith(same[i])) return str;
		return null;
	};
	var checkRules = function(str, fwd, both = {}) {
		fwd = fwd || {};
		let max = str.length - 1;
		for (let i = max; i >= 1; i -= 1) {
			let size = str.length - i;
			let suff = str.substring(size, str.length);
			if (fwd.hasOwnProperty(suff) === true) return str.slice(0, size) + fwd[suff];
			if (both.hasOwnProperty(suff) === true) return str.slice(0, size) + both[suff];
		}
		if (fwd.hasOwnProperty("")) return str += fwd[""];
		if (both.hasOwnProperty("")) return str += both[""];
		return null;
	};
	var convert = function(str = "", model = {}) {
		let out = checkEx(str, model.ex);
		out = out || checkSame(str, model.same);
		out = out || checkRules(str, model.fwd, model.both);
		out = out || str;
		return out;
	};
	//#endregion
	//#region node_modules/.pnpm/suffix-thumb@5.0.2/node_modules/suffix-thumb/src/reverse/index.js
	var flipObj = function(obj) {
		return Object.entries(obj).reduce((h, a) => {
			h[a[1]] = a[0];
			return h;
		}, {});
	};
	var reverse = function(model = {}) {
		return {
			reversed: true,
			both: flipObj(model.both),
			ex: flipObj(model.ex),
			fwd: model.rev || {}
		};
	};
	//#endregion
	//#region node_modules/.pnpm/suffix-thumb@5.0.2/node_modules/suffix-thumb/src/compress/unpack.js
	var prefix$2 = /^([0-9]+)/;
	var toObject = function(txt) {
		let obj = {};
		txt.split("¦").forEach((str) => {
			let [key, vals] = str.split(":");
			vals = (vals || "").split(",");
			vals.forEach((val) => {
				obj[val] = key;
			});
		});
		return obj;
	};
	var growObject = function(key = "", val = "") {
		val = String(val);
		let m = val.match(prefix$2);
		if (m === null) return val;
		let num = Number(m[1]) || 0;
		return key.substring(0, num) + val.replace(prefix$2, "");
	};
	var unpackOne = function(str) {
		let obj = toObject(str);
		return Object.keys(obj).reduce((h, k) => {
			h[k] = growObject(k, obj[k]);
			return h;
		}, {});
	};
	var uncompress = function(model = {}) {
		if (typeof model === "string") model = JSON.parse(model);
		model.fwd = unpackOne(model.fwd || "");
		model.both = unpackOne(model.both || "");
		model.rev = unpackOne(model.rev || "");
		model.ex = unpackOne(model.ex || "");
		return model;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/models/index.js
	var fromPast = uncompress(_data_default.PastTense);
	var fromPresent = uncompress(_data_default.PresentTense);
	var fromGerund = uncompress(_data_default.Gerund);
	var fromParticiple = uncompress(_data_default.Participle);
	var toPast = reverse(fromPast);
	var toPresent = reverse(fromPresent);
	var toGerund = reverse(fromGerund);
	var toParticiple = reverse(fromParticiple);
	var toComparative$1 = uncompress(_data_default.Comparative);
	var toSuperlative$1 = uncompress(_data_default.Superlative);
	var models_default = {
		fromPast,
		fromPresent,
		fromGerund,
		fromParticiple,
		toPast,
		toPresent,
		toGerund,
		toParticiple,
		toComparative: toComparative$1,
		toSuperlative: toSuperlative$1,
		fromComparative: reverse(toComparative$1),
		fromSuperlative: reverse(toSuperlative$1),
		adjToNoun: uncompress(_data_default.AdjToNoun)
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/regex/regex-normal.js
	var regex_normal_default = [
		[/^[\w.]+@[\w.]+\.[a-z]{2,3}$/, "Email"],
		[
			/^(https?:\/\/|www\.)+\w+\.[a-z]{2,3}/,
			"Url",
			"http.."
		],
		[
			/^[a-z0-9./].+\.(com|net|gov|org|ly|edu|info|biz|dev|ru|jp|de|in|uk|br|io|ai)/,
			"Url",
			".com"
		],
		[
			/^[PMCE]ST$/,
			"Timezone",
			"EST"
		],
		[
			/^ma?c'[a-z]{3}/,
			"LastName",
			"mc'neil"
		],
		[
			/^o'[a-z]{3}/,
			"LastName",
			"o'connor"
		],
		[
			/^ma?cd[aeiou][a-z]{3}/,
			"LastName",
			"mcdonald"
		],
		[
			/^(lol)+[sz]$/,
			"Expression",
			"lol"
		],
		[
			/^wo{2,}a*h?$/,
			"Expression",
			"wooah"
		],
		[
			/^(hee?){2,}h?$/,
			"Expression",
			"hehe"
		],
		[
			/^(un|de|re)\\-[a-z\u00C0-\u00FF]{2}/,
			"Verb",
			"un-vite"
		],
		[
			/^(m|k|cm|km)\/(s|h|hr)$/,
			"Unit",
			"5 k/m"
		],
		[
			/^(ug|ng|mg)\/(l|m3|ft3)$/,
			"Unit",
			"ug/L"
		],
		[
			/[^:/]\/\p{Letter}/u,
			"SlashedTerm",
			"love/hate"
		]
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/regex/regex-text.js
	var regex_text_default = [
		[/^#[\p{Number}_]*\p{Letter}/u, "HashTag"],
		[/^@\w{2,}$/, "AtMention"],
		[
			/^([A-Z]\.){2}[A-Z]?/i,
			["Acronym", "Noun"],
			"F.B.I"
		],
		[
			/.{3}[lkmnp]in['‘’‛‵′`´]$/,
			"Gerund",
			"chillin'"
		],
		[
			/.{4}s['‘’‛‵′`´]$/,
			"Possessive",
			"flanders'"
		],
		[
			/^[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u,
			"Emoji",
			"emoji-class"
		]
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/regex/regex-numbers.js
	var regex_numbers_default = [
		[
			/^@1?[0-9](am|pm)$/i,
			"Time",
			"3pm"
		],
		[
			/^@1?[0-9]:[0-9]{2}(am|pm)?$/i,
			"Time",
			"3:30pm"
		],
		[/^'[0-9]{2}$/, "Year"],
		[
			/^[012]?[0-9](:[0-5][0-9])(:[0-5][0-9])$/,
			"Time",
			"3:12:31"
		],
		[
			/^[012]?[0-9](:[0-5][0-9])?(:[0-5][0-9])? ?(am|pm)$/i,
			"Time",
			"1:12pm"
		],
		[
			/^[012]?[0-9](:[0-5][0-9])(:[0-5][0-9])? ?(am|pm)?$/i,
			"Time",
			"1:12:31pm"
		],
		[
			/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}/i,
			"Date",
			"iso-date"
		],
		[
			/^[0-9]{1,4}-[0-9]{1,2}-[0-9]{1,4}$/,
			"Date",
			"iso-dash"
		],
		[
			/^[0-9]{1,4}\/[0-9]{1,2}\/([0-9]{4}|[0-9]{2})$/,
			"Date",
			"iso-slash"
		],
		[
			/^[0-9]{1,4}\.[0-9]{1,2}\.[0-9]{1,4}$/,
			"Date",
			"iso-dot"
		],
		[
			/^[0-9]{1,4}-[a-z]{2,9}-[0-9]{1,4}$/i,
			"Date",
			"12-dec-2019"
		],
		[
			/^utc ?[+-]?[0-9]+$/,
			"Timezone",
			"utc-9"
		],
		[
			/^(gmt|utc)[+-][0-9]{1,2}$/i,
			"Timezone",
			"gmt-3"
		],
		[
			/^[0-9]{3}-[0-9]{4}$/,
			"PhoneNumber",
			"421-0029"
		],
		[
			/^(\+?[0-9][ -])?[0-9]{3}[ -]?[0-9]{3}-[0-9]{4}$/,
			"PhoneNumber",
			"1-800-"
		],
		[
			/^[-+]?\p{Currency_Symbol}[-+]?[0-9]+(,[0-9]{3})*(\.[0-9]+)?([kmb]|bn)?\+?$/u,
			["Money", "Value"],
			"$5.30"
		],
		[
			/^[-+]?[0-9]+(,[0-9]{3})*(\.[0-9]+)?\p{Currency_Symbol}\+?$/u,
			["Money", "Value"],
			"5.30£"
		],
		[
			/^[-+]?[$£]?[0-9]([0-9,.])+(usd|eur|jpy|gbp|cad|aud|chf|cny|hkd|nzd|kr|rub)$/i,
			["Money", "Value"],
			"$400usd"
		],
		[
			/^[-+]?[0-9]+(,[0-9]{3})*(\.[0-9]+)?\+?$/,
			["Cardinal", "NumericValue"],
			"5,999"
		],
		[
			/^[-+]?[0-9]+(,[0-9]{3})*(\.[0-9]+)?(st|nd|rd|r?th)$/,
			["Ordinal", "NumericValue"],
			"53rd"
		],
		[
			/^\.[0-9]+\+?$/,
			["Cardinal", "NumericValue"],
			".73th"
		],
		[
			/^[-+]?[0-9]+(,[0-9]{3})*(\.[0-9]+)?%\+?$/,
			[
				"Percent",
				"Cardinal",
				"NumericValue"
			],
			"-4%"
		],
		[
			/^\.[0-9]+%$/,
			[
				"Percent",
				"Cardinal",
				"NumericValue"
			],
			".3%"
		],
		[
			/^[0-9]{1,4}\/[0-9]{1,4}(st|nd|rd|th)?s?$/,
			["Fraction", "NumericValue"],
			"2/3rds"
		],
		[
			/^[0-9.]{1,3}[a-z]{0,2}[-–—][0-9]{1,3}[a-z]{0,2}$/,
			["Value", "NumberRange"],
			"3-4"
		],
		[
			/^[0-9]{1,2}(:[0-9][0-9])?(am|pm)? ?[-–—] ?[0-9]{1,2}(:[0-9][0-9])?(am|pm)$/,
			["Time", "NumberRange"],
			"3-4pm"
		],
		[
			/^[0-9.]+([a-z°]{1,4})$/,
			"NumericValue",
			"9km"
		]
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/orgWords.js
	var orgWords_default = [
		"academy",
		"administration",
		"agence",
		"agences",
		"agencies",
		"agency",
		"airlines",
		"airways",
		"army",
		"assoc",
		"associates",
		"association",
		"assurance",
		"authority",
		"autorite",
		"aviation",
		"bank",
		"banque",
		"board",
		"boys",
		"brands",
		"brewery",
		"brotherhood",
		"brothers",
		"bureau",
		"cafe",
		"co",
		"caisse",
		"capital",
		"care",
		"cathedral",
		"center",
		"centre",
		"chemicals",
		"choir",
		"chronicle",
		"church",
		"circus",
		"clinic",
		"clinique",
		"club",
		"co",
		"coalition",
		"coffee",
		"collective",
		"college",
		"commission",
		"committee",
		"communications",
		"community",
		"company",
		"comprehensive",
		"computers",
		"confederation",
		"conference",
		"conseil",
		"consulting",
		"containers",
		"corporation",
		"corps",
		"corp",
		"council",
		"crew",
		"data",
		"departement",
		"department",
		"departments",
		"design",
		"development",
		"directorate",
		"division",
		"drilling",
		"education",
		"eglise",
		"electric",
		"electricity",
		"energy",
		"ensemble",
		"enterprise",
		"enterprises",
		"entertainment",
		"estate",
		"etat",
		"faculty",
		"faction",
		"federation",
		"financial",
		"fm",
		"foundation",
		"fund",
		"gas",
		"gazette",
		"girls",
		"government",
		"group",
		"guild",
		"herald",
		"holdings",
		"hospital",
		"hotel",
		"hotels",
		"inc",
		"industries",
		"institut",
		"institute",
		"institutes",
		"insurance",
		"international",
		"interstate",
		"investment",
		"investments",
		"investors",
		"journal",
		"laboratory",
		"labs",
		"llc",
		"ltd",
		"limited",
		"machines",
		"magazine",
		"management",
		"marine",
		"marketing",
		"markets",
		"media",
		"memorial",
		"ministere",
		"ministry",
		"military",
		"mobile",
		"motor",
		"motors",
		"musee",
		"museum",
		"news",
		"observatory",
		"office",
		"oil",
		"optical",
		"orchestra",
		"organization",
		"partners",
		"partnership",
		"petrol",
		"petroleum",
		"pharmacare",
		"pharmaceutical",
		"pharmaceuticals",
		"pizza",
		"plc",
		"police",
		"politburo",
		"polytechnic",
		"post",
		"power",
		"press",
		"productions",
		"quartet",
		"radio",
		"reserve",
		"resources",
		"restaurant",
		"restaurants",
		"savings",
		"school",
		"securities",
		"service",
		"services",
		"societe",
		"subsidiary",
		"society",
		"sons",
		"subcommittee",
		"syndicat",
		"systems",
		"telecommunications",
		"telegraph",
		"television",
		"times",
		"tribunal",
		"tv",
		"union",
		"university",
		"utilities",
		"workers"
	].reduce((h, str) => {
		h[str] = true;
		return h;
	}, {});
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/placeWords.js
	var placeWords_default = [
		"atoll",
		"basin",
		"bay",
		"beach",
		"bluff",
		"bog",
		"camp",
		"canyon",
		"canyons",
		"cape",
		"cave",
		"caves",
		"cliffs",
		"coast",
		"cove",
		"coves",
		"crater",
		"crossing",
		"creek",
		"desert",
		"dune",
		"dunes",
		"downs",
		"estates",
		"escarpment",
		"estuary",
		"falls",
		"fjord",
		"fjords",
		"forest",
		"forests",
		"glacier",
		"gorge",
		"gorges",
		"grove",
		"gulf",
		"gully",
		"highland",
		"heights",
		"hollow",
		"hill",
		"hills",
		"inlet",
		"island",
		"islands",
		"isthmus",
		"junction",
		"knoll",
		"lagoon",
		"lake",
		"lakeshore",
		"marsh",
		"marshes",
		"mount",
		"mountain",
		"mountains",
		"narrows",
		"peninsula",
		"plains",
		"plateau",
		"pond",
		"rapids",
		"ravine",
		"reef",
		"reefs",
		"ridge",
		"river",
		"rivers",
		"sandhill",
		"shoal",
		"shore",
		"shoreline",
		"shores",
		"strait",
		"straits",
		"springs",
		"stream",
		"swamp",
		"tombolo",
		"trail",
		"trails",
		"trench",
		"valley",
		"vallies",
		"village",
		"volcano",
		"waterfall",
		"watershed",
		"wetland",
		"woods",
		"acres",
		"burough",
		"county",
		"district",
		"municipality",
		"prefecture",
		"province",
		"region",
		"reservation",
		"state",
		"territory",
		"borough",
		"metropolis",
		"downtown",
		"uptown",
		"midtown",
		"city",
		"town",
		"township",
		"hamlet",
		"country",
		"kingdom",
		"enclave",
		"neighbourhood",
		"neighborhood",
		"kingdom",
		"ward",
		"zone",
		"airport",
		"amphitheater",
		"arch",
		"arena",
		"auditorium",
		"bar",
		"barn",
		"basilica",
		"battlefield",
		"bridge",
		"building",
		"castle",
		"centre",
		"coliseum",
		"cineplex",
		"complex",
		"dam",
		"farm",
		"field",
		"fort",
		"garden",
		"gardens",
		"gymnasium",
		"hall",
		"house",
		"levee",
		"library",
		"manor",
		"memorial",
		"monument",
		"museum",
		"gallery",
		"palace",
		"pillar",
		"pits",
		"plantation",
		"playhouse",
		"quarry",
		"sportsfield",
		"sportsplex",
		"stadium",
		"terrace",
		"terraces",
		"theater",
		"tower",
		"park",
		"parks",
		"site",
		"ranch",
		"raceway",
		"sportsplex",
		"ave",
		"st",
		"street",
		"rd",
		"road",
		"lane",
		"landing",
		"crescent",
		"cr",
		"way",
		"tr",
		"terrace",
		"avenue"
	].reduce((h, str) => {
		h[str] = true;
		return h;
	}, {});
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/nouns/toSingular/_rules.js
	var _rules_default = [
		[/([^v])ies$/i, "$1y"],
		[/(ise)s$/i, "$1"],
		[/(kn|[^o]l|w)ives$/i, "$1ife"],
		[/^((?:ca|e|ha|(?:our|them|your)?se|she|wo)l|lea|loa|shea|thie)ves$/i, "$1f"],
		[/^(dwar|handkerchie|hoo|scar|whar)ves$/i, "$1f"],
		[/(antenn|formul|nebul|vertebr|vit)ae$/i, "$1a"],
		[/(octop|vir|radi|nucle|fung|cact|stimul)(i)$/i, "$1us"],
		[/(buffal|tomat|tornad)(oes)$/i, "$1o"],
		[/(ause)s$/i, "$1"],
		[/(ease)s$/i, "$1"],
		[/(ious)es$/i, "$1"],
		[/(ouse)s$/i, "$1"],
		[/(ose)s$/i, "$1"],
		[/(..ase)s$/i, "$1"],
		[/(..[aeiu]s)es$/i, "$1"],
		[/(vert|ind|cort)(ices)$/i, "$1ex"],
		[/(matr|append)(ices)$/i, "$1ix"],
		[/([xo]|ch|ss|sh)es$/i, "$1"],
		[/men$/i, "man"],
		[/(n)ews$/i, "$1ews"],
		[/([ti])a$/i, "$1um"],
		[/([^aeiouy]|qu)ies$/i, "$1y"],
		[/(s)eries$/i, "$1eries"],
		[/(m)ovies$/i, "$1ovie"],
		[/(cris|ax|test)es$/i, "$1is"],
		[/(alias|status)es$/i, "$1"],
		[/(ss)$/i, "$1"],
		[/(ic)s$/i, "$1"],
		[/s$/i, ""]
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/nouns/toSingular/index.js
	var invertObj = function(obj) {
		return Object.keys(obj).reduce((h, k) => {
			h[obj[k]] = k;
			return h;
		}, {});
	};
	var toSingular = function(str, model) {
		const { irregularPlurals } = model.two;
		const invert = invertObj(irregularPlurals);
		if (invert.hasOwnProperty(str)) return invert[str];
		for (let i = 0; i < _rules_default.length; i++) if (_rules_default[i][0].test(str) === true) {
			str = str.replace(_rules_default[i][0], _rules_default[i][1]);
			return str;
		}
		return str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/nouns/index.js
	var all$2 = function(str, model) {
		const arr = [str];
		const p = pluralize(str, model);
		if (p !== str) arr.push(p);
		const s = toSingular(str, model);
		if (s !== str) arr.push(s);
		return arr;
	};
	var nouns_default$2 = {
		toPlural: pluralize,
		toSingular,
		all: all$2
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/verbs/getTense/_guess.js
	var guessVerb = {
		Gerund: ["ing"],
		Actor: ["erer"],
		Infinitive: [
			"ate",
			"ize",
			"tion",
			"rify",
			"then",
			"ress",
			"ify",
			"age",
			"nce",
			"ect",
			"ise",
			"ine",
			"ish",
			"ace",
			"ash",
			"ure",
			"tch",
			"end",
			"ack",
			"and",
			"ute",
			"ade",
			"ock",
			"ite",
			"ase",
			"ose",
			"use",
			"ive",
			"int",
			"nge",
			"lay",
			"est",
			"ain",
			"ant",
			"ent",
			"eed",
			"er",
			"le",
			"unk",
			"ung",
			"upt",
			"en"
		],
		PastTense: [
			"ept",
			"ed",
			"lt",
			"nt",
			"ew",
			"ld"
		],
		PresentTense: [
			"rks",
			"cks",
			"nks",
			"ngs",
			"mps",
			"tes",
			"zes",
			"ers",
			"les",
			"acks",
			"ends",
			"ands",
			"ocks",
			"lays",
			"eads",
			"lls",
			"els",
			"ils",
			"ows",
			"nds",
			"ays",
			"ams",
			"ars",
			"ops",
			"ffs",
			"als",
			"urs",
			"lds",
			"ews",
			"ips",
			"es",
			"ts",
			"ns"
		],
		Participle: ["ken", "wn"]
	};
	guessVerb = Object.keys(guessVerb).reduce((h, k) => {
		guessVerb[k].forEach((a) => h[a] = k);
		return h;
	}, {});
	var _guess_default = guessVerb;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/verbs/getTense/index.js
	/** it helps to know what we're conjugating from */
	var getTense = function(str) {
		const three = str.substring(str.length - 3);
		if (_guess_default.hasOwnProperty(three) === true) return _guess_default[three];
		const two = str.substring(str.length - 2);
		if (_guess_default.hasOwnProperty(two) === true) return _guess_default[two];
		if (str.substring(str.length - 1) === "s") return "PresentTense";
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/verbs/toInfinitive/index.js
	var toParts = function(str, model) {
		let prefix = "";
		let prefixes = {};
		if (model.one && model.one.prefixes) prefixes = model.one.prefixes;
		let [verb, particle] = str.split(/ /);
		if (particle && prefixes[verb] === true) {
			prefix = verb;
			verb = particle;
			particle = "";
		}
		return {
			prefix,
			verb,
			particle
		};
	};
	var copulaMap = {
		are: "be",
		were: "be",
		been: "be",
		is: "be",
		am: "be",
		was: "be",
		be: "be",
		being: "be"
	};
	var toInfinitive = function(str, model, tense) {
		const { fromPast, fromPresent, fromGerund, fromParticiple } = model.two.models;
		const { prefix, verb, particle } = toParts(str, model);
		let inf = "";
		if (!tense) tense = getTense(str);
		if (copulaMap.hasOwnProperty(str)) inf = copulaMap[str];
		else if (tense === "Participle") inf = convert(verb, fromParticiple);
		else if (tense === "PastTense") inf = convert(verb, fromPast);
		else if (tense === "PresentTense") inf = convert(verb, fromPresent);
		else if (tense === "Gerund") inf = convert(verb, fromGerund);
		else return str;
		if (particle) inf += " " + particle;
		if (prefix) inf = prefix + " " + inf;
		return inf;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/verbs/conjugate/index.js
	var parse = (inf) => {
		if (/ /.test(inf)) return inf.split(/ /);
		return [inf, ""];
	};
	var conjugate = function(inf, model) {
		const { toPast, toPresent, toGerund, toParticiple } = model.two.models;
		if (inf === "be") return {
			Infinitive: inf,
			Gerund: "being",
			PastTense: "was",
			PresentTense: "is"
		};
		const [str, particle] = parse(inf);
		const found = {
			Infinitive: str,
			PastTense: convert(str, toPast),
			PresentTense: convert(str, toPresent),
			Gerund: convert(str, toGerund),
			FutureTense: "will " + str
		};
		let pastPrt = convert(str, toParticiple);
		if (pastPrt !== inf && pastPrt !== found.PastTense) {
			const lex = model.one.lexicon || {};
			if (lex[pastPrt] === "Participle" || lex[pastPrt] === "Adjective") {
				if (inf === "play") pastPrt = "played";
				found.Participle = pastPrt;
			}
		}
		if (particle) Object.keys(found).forEach((k) => {
			found[k] += " " + particle;
		});
		return found;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/verbs/index.js
	var all$1 = function(str, model) {
		const res = conjugate(str, model);
		delete res.FutureTense;
		return Object.values(res).filter((s) => s);
	};
	var verbs_default$2 = {
		toInfinitive,
		conjugate,
		all: all$1
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/adjectives/inflect.js
	var toSuperlative = function(adj, model) {
		const mod = model.two.models.toSuperlative;
		return convert(adj, mod);
	};
	var toComparative = function(adj, model) {
		const mod = model.two.models.toComparative;
		return convert(adj, mod);
	};
	var fromComparative = function(adj, model) {
		const mod = model.two.models.fromComparative;
		return convert(adj, mod);
	};
	var fromSuperlative = function(adj, model) {
		const mod = model.two.models.fromSuperlative;
		return convert(adj, mod);
	};
	var toNoun = function(adj, model) {
		const mod = model.two.models.adjToNoun;
		return convert(adj, mod);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/adjectives/conjugate/lib.js
	var suffixLoop$1 = function(str = "", suffixes = []) {
		const len = str.length;
		const max = len <= 6 ? len - 1 : 6;
		for (let i = max; i >= 1; i -= 1) {
			const suffix = str.substring(len - i, str.length);
			if (suffixes[suffix.length].hasOwnProperty(suffix) === true) return str.slice(0, len - i) + suffixes[suffix.length][suffix];
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/adjectives/conjugate/fromAdverb.js
	var s = "ically";
	var ical = new Set([
		"analyt" + s,
		"chem" + s,
		"class" + s,
		"clin" + s,
		"crit" + s,
		"ecolog" + s,
		"electr" + s,
		"empir" + s,
		"frant" + s,
		"grammat" + s,
		"ident" + s,
		"ideolog" + s,
		"log" + s,
		"mag" + s,
		"mathemat" + s,
		"mechan" + s,
		"med" + s,
		"method" + s,
		"method" + s,
		"mus" + s,
		"phys" + s,
		"phys" + s,
		"polit" + s,
		"pract" + s,
		"rad" + s,
		"satir" + s,
		"statist" + s,
		"techn" + s,
		"technolog" + s,
		"theoret" + s,
		"typ" + s,
		"vert" + s,
		"whims" + s
	]);
	var suffixes$1 = [
		null,
		{},
		{ "ly": "" },
		{
			"ily": "y",
			"bly": "ble",
			"ply": "ple"
		},
		{
			"ally": "al",
			"rply": "rp"
		},
		{
			"ually": "ual",
			"ially": "ial",
			"cally": "cal",
			"eally": "eal",
			"rally": "ral",
			"nally": "nal",
			"mally": "mal",
			"eeply": "eep",
			"eaply": "eap"
		},
		{ ically: "ic" }
	];
	var noAdj = new Set([
		"early",
		"only",
		"hourly",
		"daily",
		"weekly",
		"monthly",
		"yearly",
		"mostly",
		"duly",
		"unduly",
		"especially",
		"undoubtedly",
		"conversely",
		"namely",
		"exceedingly",
		"presumably",
		"accordingly",
		"overly",
		"best",
		"latter",
		"little",
		"long",
		"low"
	]);
	var exceptions$2 = {
		wholly: "whole",
		fully: "full",
		truly: "true",
		gently: "gentle",
		singly: "single",
		customarily: "customary",
		idly: "idle",
		publically: "public",
		quickly: "quick",
		superbly: "superb",
		cynically: "cynical",
		well: "good"
	};
	var toAdjective = function(str) {
		if (!str.endsWith("ly")) return null;
		if (ical.has(str)) return str.replace(/ically/, "ical");
		if (noAdj.has(str)) return null;
		if (exceptions$2.hasOwnProperty(str)) return exceptions$2[str];
		return suffixLoop$1(str, suffixes$1) || str;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/adjectives/conjugate/toAdverb.js
	var suffixes = [
		null,
		{ y: "ily" },
		{
			ly: "ly",
			ic: "ically"
		},
		{
			ial: "ially",
			ual: "ually",
			tle: "tly",
			ble: "bly",
			ple: "ply",
			ary: "arily"
		},
		{},
		{},
		{}
	];
	var exceptions$1 = {
		cool: "cooly",
		whole: "wholly",
		full: "fully",
		good: "well",
		idle: "idly",
		public: "publicly",
		single: "singly",
		special: "especially"
	};
	var toAdverb = function(str) {
		if (exceptions$1.hasOwnProperty(str)) return exceptions$1[str];
		let adv = suffixLoop$1(str, suffixes);
		if (!adv) adv = str + "ly";
		return adv;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/adjectives/index.js
	var all = function(str, model) {
		let arr = [str];
		arr.push(toSuperlative(str, model));
		arr.push(toComparative(str, model));
		arr.push(toAdverb(str));
		arr = arr.filter((s) => s);
		arr = new Set(arr);
		return Array.from(arr);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/transform/index.js
	var transform_default = {
		noun: nouns_default$2,
		verb: verbs_default$2,
		adjective: {
			toSuperlative,
			toComparative,
			toAdverb,
			toNoun,
			fromAdverb: toAdjective,
			fromSuperlative,
			fromComparative,
			all
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/expand/byTag.js
	var byTag_default = {
		Singular: (word, lex, methods, model) => {
			const already = model.one.lexicon;
			const plural = methods.two.transform.noun.toPlural(word, model);
			if (!already[plural]) lex[plural] = lex[plural] || "Plural";
		},
		Actor: (word, lex, methods, model) => {
			const already = model.one.lexicon;
			const plural = methods.two.transform.noun.toPlural(word, model);
			if (!already[plural]) lex[plural] = lex[plural] || ["Plural", "Actor"];
		},
		Comparable: (word, lex, methods, model) => {
			const already = model.one.lexicon;
			const { toSuperlative, toComparative } = methods.two.transform.adjective;
			const sup = toSuperlative(word, model);
			if (!already[sup]) lex[sup] = lex[sup] || "Superlative";
			const comp = toComparative(word, model);
			if (!already[comp]) lex[comp] = lex[comp] || "Comparative";
			lex[word] = "Adjective";
		},
		Demonym: (word, lex, methods, model) => {
			const plural = methods.two.transform.noun.toPlural(word, model);
			lex[plural] = lex[plural] || ["Demonym", "Plural"];
		},
		Infinitive: (word, lex, methods, model) => {
			const already = model.one.lexicon;
			const all = methods.two.transform.verb.conjugate(word, model);
			Object.entries(all).forEach((a) => {
				if (!already[a[1]] && !lex[a[1]] && a[0] !== "FutureTense") lex[a[1]] = a[0];
			});
		},
		PhrasalVerb: (word, lex, methods, model) => {
			const already = model.one.lexicon;
			lex[word] = ["PhrasalVerb", "Infinitive"];
			const _multi = model.one._multiCache;
			const [inf, rest] = word.split(" ");
			if (!already[inf]) lex[inf] = lex[inf] || "Infinitive";
			const all = methods.two.transform.verb.conjugate(inf, model);
			delete all.FutureTense;
			Object.entries(all).forEach((a) => {
				if (a[0] === "Actor" || a[1] === "") return;
				if (!lex[a[1]] && !already[a[1]]) lex[a[1]] = a[0];
				_multi[a[1]] = 2;
				const str = a[1] + " " + rest;
				lex[str] = lex[str] || [a[0], "PhrasalVerb"];
			});
		},
		Multiple: (word, lex) => {
			lex[word] = ["Multiple", "Cardinal"];
			lex[word + "th"] = ["Multiple", "Ordinal"];
			lex[word + "ths"] = ["Multiple", "Fraction"];
		},
		Cardinal: (word, lex) => {
			lex[word] = ["TextValue", "Cardinal"];
		},
		Ordinal: (word, lex) => {
			lex[word] = ["TextValue", "Ordinal"];
			lex[word + "s"] = ["TextValue", "Fraction"];
		},
		Place: (word, lex) => {
			lex[word] = ["Place", "ProperNoun"];
		},
		Region: (word, lex) => {
			lex[word] = ["Region", "ProperNoun"];
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/expand/index.js
	var expand$1 = function(words, world) {
		const { methods, model } = world;
		const lex = {};
		const _multi = {};
		Object.keys(words).forEach((word) => {
			const tag = words[word];
			word = word.toLowerCase().trim();
			word = word.replace(/'s\b/, "");
			const split = word.split(/ /);
			if (split.length > 1) {
				if (_multi[split[0]] === void 0 || split.length > _multi[split[0]]) _multi[split[0]] = split.length;
			}
			if (byTag_default.hasOwnProperty(tag) === true) byTag_default[tag](word, lex, methods, model);
			lex[word] = lex[word] || tag;
		});
		delete lex[""];
		delete lex[null];
		delete lex[" "];
		return {
			lex,
			_multi
		};
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/quickSplit.js
	var splitOn = function(terms, i) {
		const isNum = /^[0-9]+$/;
		const term = terms[i];
		if (!term) return false;
		const maybeDate = new Set([
			"may",
			"april",
			"august",
			"jan"
		]);
		if (term.normal === "like" || maybeDate.has(term.normal)) return false;
		if (term.tags.has("Place") || term.tags.has("Date")) return false;
		if (terms[i - 1]) {
			const lastTerm = terms[i - 1];
			if (lastTerm.tags.has("Date") || maybeDate.has(lastTerm.normal)) return false;
			if (lastTerm.tags.has("Adjective") || term.tags.has("Adjective")) return false;
		}
		const str = term.normal;
		if (str.length === 1 || str.length === 2 || str.length === 4) {
			if (isNum.test(str)) return false;
		}
		return true;
	};
	var quickSplit = function(document) {
		const splitHere = /[,:;]/;
		const arr = [];
		document.forEach((terms) => {
			let start = 0;
			terms.forEach((term, i) => {
				if (splitHere.test(term.post) && splitOn(terms, i + 1)) {
					arr.push(terms.slice(start, i + 1));
					start = i + 1;
				}
			});
			if (start < terms.length) arr.push(terms.slice(start, terms.length));
		});
		return arr;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/looksPlural.js
	var isPlural = {
		e: [
			"mice",
			"louse",
			"antennae",
			"formulae",
			"nebulae",
			"vertebrae",
			"vitae"
		],
		i: [
			"tia",
			"octopi",
			"viri",
			"radii",
			"nuclei",
			"fungi",
			"cacti",
			"stimuli"
		],
		n: ["men"],
		t: ["feet"]
	};
	var exceptions = new Set([
		"israelis",
		"menus",
		"logos"
	]);
	var notPlural = [
		"bus",
		"mas",
		"was",
		"ias",
		"xas",
		"vas",
		"cis",
		"lis",
		"nis",
		"ois",
		"ris",
		"sis",
		"tis",
		"xis",
		"aus",
		"cus",
		"eus",
		"fus",
		"gus",
		"ius",
		"lus",
		"nus",
		"das",
		"ous",
		"pus",
		"rus",
		"sus",
		"tus",
		"xus",
		"aos",
		"igos",
		"ados",
		"ogos",
		"'s",
		"ss"
	];
	var looksPlural = function(str) {
		if (!str || str.length <= 3) return false;
		if (exceptions.has(str)) return true;
		const end = str[str.length - 1];
		if (isPlural.hasOwnProperty(end)) return isPlural[end].find((suff) => str.endsWith(suff));
		if (end !== "s") return false;
		if (notPlural.find((suff) => str.endsWith(suff))) return false;
		return true;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/methods/index.js
	var methods_default = { two: {
		quickSplit,
		expandLexicon: expand$1,
		transform: transform_default,
		looksPlural
	} };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/_expand/irregulars.js
	var expandIrregulars = function(model) {
		const { irregularPlurals } = model.two;
		const { lexicon } = model.one;
		Object.entries(irregularPlurals).forEach((a) => {
			lexicon[a[0]] = lexicon[a[0]] || "Singular";
			lexicon[a[1]] = lexicon[a[1]] || "Plural";
		});
		return model;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/_expand/index.js
	var tmpModel = {
		one: { lexicon: {} },
		two: { models: models_default }
	};
	var switchDefaults = {
		"Actor|Verb": "Actor",
		"Adj|Gerund": "Adjective",
		"Adj|Noun": "Adjective",
		"Adj|Past": "Adjective",
		"Adj|Present": "Adjective",
		"Noun|Verb": "Singular",
		"Noun|Gerund": "Gerund",
		"Person|Noun": "Noun",
		"Person|Date": "Month",
		"Person|Verb": "FirstName",
		"Person|Place": "Person",
		"Person|Adj": "Comparative",
		"Plural|Verb": "Plural",
		"Unit|Noun": "Noun"
	};
	var expandLexicon = function(words, model) {
		const world = {
			model,
			methods: methods_default
		};
		const { lex, _multi } = methods_default.two.expandLexicon(words, world);
		Object.assign(model.one.lexicon, lex);
		Object.assign(model.one._multiCache, _multi);
		return model;
	};
	var addUncountables = function(words, model) {
		Object.keys(words).forEach((k) => {
			if (words[k] === "Uncountable") {
				model.two.uncountable[k] = true;
				words[k] = "Uncountable";
			}
		});
		return model;
	};
	var expandVerb = function(str, words, doPresent) {
		const obj = conjugate(str, tmpModel);
		words[obj.PastTense] = words[obj.PastTense] || "PastTense";
		words[obj.Gerund] = words[obj.Gerund] || "Gerund";
		if (doPresent === true) words[obj.PresentTense] = words[obj.PresentTense] || "PresentTense";
	};
	var expandAdjective = function(str, words, model) {
		const sup = toSuperlative(str, model);
		words[sup] = words[sup] || "Superlative";
		const comp = toComparative(str, model);
		words[comp] = words[comp] || "Comparative";
	};
	var expandNoun = function(str, words, model) {
		const plur = pluralize(str, model);
		words[plur] = words[plur] || "Plural";
	};
	var expandVariable = function(switchWords, model) {
		const words = {};
		const lex = model.one.lexicon;
		Object.keys(switchWords).forEach((w) => {
			const name = switchWords[w];
			words[w] = switchDefaults[name];
			if (name === "Noun|Verb" || name === "Person|Verb" || name === "Actor|Verb") expandVerb(w, lex, false);
			if (name === "Adj|Present") {
				expandVerb(w, lex, true);
				expandAdjective(w, lex, model);
			}
			if (name === "Person|Adj") expandAdjective(w, lex, model);
			if (name === "Adj|Gerund" || name === "Noun|Gerund") {
				const inf = toInfinitive(w, tmpModel, "Gerund");
				if (!lex[inf]) words[inf] = "Infinitive";
			}
			if (name === "Noun|Gerund" || name === "Adj|Noun" || name === "Person|Noun") expandNoun(w, lex, model);
			if (name === "Adj|Past") {
				const inf = toInfinitive(w, tmpModel, "PastTense");
				if (!lex[inf]) words[inf] = "Infinitive";
			}
		});
		model = expandLexicon(words, model);
		return model;
	};
	var expand = function(model) {
		model = expandLexicon(model.one.lexicon, model);
		model = addUncountables(model.one.lexicon, model);
		model = expandVariable(model.two.switches, model);
		model = expandIrregulars(model);
		return model;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/model/index.js
	var model = {
		one: {
			_multiCache: {},
			lexicon,
			frozenLex: frozenLex_default
		},
		two: {
			irregularPlurals: plurals_default,
			models: models_default,
			suffixPatterns: suffixes_default,
			prefixPatterns: prefixes_default,
			endsWith: endsWith_default,
			neighbours: neighbours_default,
			regexNormal: regex_normal_default,
			regexText: regex_text_default,
			regexNumbers: regex_numbers_default,
			switches,
			clues,
			uncountable: {},
			orgWords: orgWords_default,
			placeWords: placeWords_default
		}
	};
	model = expand(model);
	var model_default$1 = model;
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/1st-pass/01-colons.js
	var byPunctuation = function(terms, i, model, world) {
		const setTag = world.methods.one.setTag;
		if (i === 0 && terms.length >= 3) {
			if (terms[0].post.match(/:/)) {
				const nextTerm = terms[1];
				if (nextTerm.tags.has("Value") || nextTerm.tags.has("Email") || nextTerm.tags.has("PhoneNumber")) return;
				setTag([terms[0]], "Expression", world, null, `2-punct-colon''`);
			}
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/1st-pass/02-hyphens.js
	var byHyphen = function(terms, i, model, world) {
		const setTag = world.methods.one.setTag;
		if (terms[i].post === "-" && terms[i + 1]) setTag([terms[i], terms[i + 1]], "Hyphenated", world, null, `1-punct-hyphen''`);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/00-tagSwitch.js
	var prefix$1 = /^(under|over|mis|re|un|dis|semi)-?/;
	var tagSwitch = function(terms, i, model) {
		const switches = model.two.switches;
		const term = terms[i];
		if (switches.hasOwnProperty(term.normal)) {
			term.switch = switches[term.normal];
			return;
		}
		if (prefix$1.test(term.normal)) {
			const stem = term.normal.replace(prefix$1, "");
			if (stem.length > 3 && switches.hasOwnProperty(stem)) term.switch = switches[stem];
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/_fastTag.js
	var log = (term, tag, reason = "") => {
		const yellow = (str) => "\x1B[33m\x1B[3m" + str + "\x1B[0m";
		const i = (str) => "\x1B[3m" + str + "\x1B[0m";
		const word = term.text || "[" + term.implicit + "]";
		if (typeof tag !== "string" && tag.length > 2) tag = tag.slice(0, 2).join(", #") + " +";
		tag = typeof tag !== "string" ? tag.join(", #") : tag;
		console.log(` ${yellow(word).padEnd(24)} \x1b[32m→\x1b[0m #${tag.padEnd(22)}  ${i(reason)}`);
	};
	var fastTag = function(term, tag, reason) {
		if (!tag || tag.length === 0) return;
		if (term.frozen === true) return;
		const env = typeof process === "undefined" || !process.env ? self.env || {} : process.env;
		if (env && env.DEBUG_TAGS) log(term, tag, reason);
		term.tags = term.tags || /* @__PURE__ */ new Set();
		if (typeof tag === "string") term.tags.add(tag);
		else tag.forEach((tg) => term.tags.add(tg));
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/_fillTags.js
	var uncountable = [
		"Acronym",
		"Abbreviation",
		"ProperNoun",
		"Uncountable",
		"Possessive",
		"Pronoun",
		"Activity",
		"Honorific",
		"Month"
	];
	var setPluralSingular = function(term) {
		if (!term.tags.has("Noun") || term.tags.has("Plural") || term.tags.has("Singular")) return;
		if (uncountable.find((tag) => term.tags.has(tag))) return;
		if (looksPlural(term.normal)) fastTag(term, "Plural", "3-plural-guess");
		else fastTag(term, "Singular", "3-singular-guess");
	};
	var setTense = function(term) {
		const tags = term.tags;
		if (tags.has("Verb") && tags.size === 1) {
			const guess = getTense(term.normal);
			if (guess) fastTag(term, guess, "3-verb-tense-guess");
		}
	};
	var fillTags = function(terms, i, model) {
		const term = terms[i];
		const tags = Array.from(term.tags);
		for (let k = 0; k < tags.length; k += 1) if (model.one.tagSet[tags[k]]) {
			const toAdd = model.one.tagSet[tags[k]].parents;
			fastTag(term, toAdd, ` -inferred by #${tags[k]}`);
		}
		setPluralSingular(term);
		setTense(term, model);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/01-case.js
	var titleCase$1 = /^\p{Lu}[\p{Ll}'’]/u;
	var hasNumber = /[0-9]/;
	var notProper = [
		"Date",
		"Month",
		"WeekDay",
		"Unit",
		"Expression"
	];
	var hasIVX = /[IVX]/;
	var romanNumeral = /^[IVXLCDM]{2,}$/;
	var romanNumValid = /^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$/;
	var nope = {
		li: true,
		dc: true,
		md: true,
		dm: true,
		ml: true
	};
	var checkCase = function(terms, i, model) {
		const term = terms[i];
		term.index = term.index || [0, 0];
		const index = term.index[1];
		const str = term.text || "";
		if (index !== 0 && titleCase$1.test(str) === true && hasNumber.test(str) === false) {
			if (notProper.find((tag) => term.tags.has(tag))) return null;
			if (term.pre.match(/["']$/)) return null;
			if (term.normal === "the") return null;
			fillTags(terms, i, model);
			if (!term.tags.has("Noun") && !term.frozen) term.tags.clear();
			fastTag(term, "ProperNoun", "2-titlecase");
			return true;
		}
		if (str.length >= 2 && romanNumeral.test(str) && hasIVX.test(str) && romanNumValid.test(str) && !nope[term.normal]) {
			fastTag(term, "RomanNumeral", "2-xvii");
			return true;
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/02-suffix.js
	var suffixLoop = function(str = "", suffixes = []) {
		const len = str.length;
		let max = 7;
		if (len <= max) max = len - 1;
		for (let i = max; i > 1; i -= 1) {
			const suffix = str.substring(len - i, len);
			if (suffixes[suffix.length].hasOwnProperty(suffix) === true) return suffixes[suffix.length][suffix];
		}
		return null;
	};
	var tagBySuffix = function(terms, i, model) {
		const term = terms[i];
		if (term.tags.size === 0) {
			let tag = suffixLoop(term.normal, model.two.suffixPatterns);
			if (tag !== null) {
				fastTag(term, tag, "2-suffix");
				term.confidence = .7;
				return true;
			}
			if (term.implicit) {
				tag = suffixLoop(term.implicit, model.two.suffixPatterns);
				if (tag !== null) {
					fastTag(term, tag, "2-implicit-suffix");
					term.confidence = .7;
					return true;
				}
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/03-regex.js
	var hasApostrophe = /['‘’‛‵′`´]/;
	var doRegs = function(str, regs) {
		for (let i = 0; i < regs.length; i += 1) if (regs[i][0].test(str) === true) return regs[i];
		return null;
	};
	var doEndsWith = function(str = "", byEnd) {
		const char = str[str.length - 1];
		if (byEnd.hasOwnProperty(char) === true) {
			const regs = byEnd[char] || [];
			for (let r = 0; r < regs.length; r += 1) if (regs[r][0].test(str) === true) return regs[r];
		}
		return null;
	};
	var checkRegex = function(terms, i, model, world) {
		const setTag = world.methods.one.setTag;
		const { regexText, regexNormal, regexNumbers, endsWith } = model.two;
		const term = terms[i];
		const normal = term.machine || term.normal;
		let text = term.text;
		if (hasApostrophe.test(term.post) && !hasApostrophe.test(term.pre)) text += term.post.trim();
		let arr = doRegs(text, regexText) || doRegs(normal, regexNormal);
		if (!arr && /[0-9]/.test(normal)) arr = doRegs(normal, regexNumbers);
		if (!arr && term.tags.size === 0) arr = doEndsWith(normal, endsWith);
		if (arr) {
			setTag([term], arr[1], world, null, `2-regex-'${arr[2] || arr[0]}'`);
			term.confidence = .6;
			return true;
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/04-prefix.js
	var prefixLoop = function(str = "", prefixes = []) {
		const len = str.length;
		let max = 7;
		if (max > len - 3) max = len - 3;
		for (let i = max; i > 2; i -= 1) {
			const prefix = str.substring(0, i);
			if (prefixes[prefix.length].hasOwnProperty(prefix) === true) return prefixes[prefix.length][prefix];
		}
		return null;
	};
	var checkPrefix = function(terms, i, model) {
		const term = terms[i];
		if (term.tags.size === 0) {
			const tag = prefixLoop(term.normal, model.two.prefixPatterns);
			if (tag !== null) {
				fastTag(term, tag, "2-prefix");
				term.confidence = .5;
				return true;
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/2nd-pass/05-year.js
	var min = 1400;
	var max = 2100;
	var dateWords = new Set([
		"in",
		"on",
		"by",
		"until",
		"for",
		"to",
		"during",
		"throughout",
		"through",
		"within",
		"before",
		"after",
		"of",
		"this",
		"next",
		"last",
		"circa",
		"around",
		"post",
		"pre",
		"budget",
		"classic",
		"plan",
		"may"
	]);
	var seemsGood = function(term) {
		if (!term) return false;
		const str = term.normal || term.implicit;
		if (dateWords.has(str)) return true;
		if (term.tags.has("Date") || term.tags.has("Month") || term.tags.has("WeekDay") || term.tags.has("Year")) return true;
		if (term.tags.has("ProperNoun")) return true;
		return false;
	};
	var seemsOkay = function(term) {
		if (!term) return false;
		if (term.tags.has("Ordinal")) return true;
		if (term.tags.has("Cardinal") && term.normal.length < 3) return true;
		if (term.normal === "is" || term.normal === "was") return true;
		return false;
	};
	var seemsFine = function(term) {
		return term && (term.tags.has("Date") || term.tags.has("Month") || term.tags.has("WeekDay") || term.tags.has("Year"));
	};
	var tagYear = function(terms, i) {
		const term = terms[i];
		if (term.tags.has("NumericValue") && term.tags.has("Cardinal") && term.normal.length === 4) {
			const num = Number(term.normal);
			if (num && !isNaN(num)) {
				if (num > min && num < max) {
					const lastTerm = terms[i - 1];
					const nextTerm = terms[i + 1];
					if (seemsGood(lastTerm) || seemsGood(nextTerm)) return fastTag(term, "Year", "2-tagYear");
					if (num >= 1920 && num < 2025) {
						if (seemsOkay(lastTerm) || seemsOkay(nextTerm)) return fastTag(term, "Year", "2-tagYear-close");
						if (seemsFine(terms[i - 2]) || seemsFine(terms[i + 2])) return fastTag(term, "Year", "2-tagYear-far");
						if (lastTerm && (lastTerm.tags.has("Determiner") || lastTerm.tags.has("Possessive"))) {
							if (nextTerm && nextTerm.tags.has("Noun") && !nextTerm.tags.has("Plural")) return fastTag(term, "Year", "2-tagYear-noun");
						}
					}
				}
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/07-verb-type.js
	var verbType = function(terms, i, model, world) {
		const setTag = world.methods.one.setTag;
		const term = terms[i];
		const types = [
			"PastTense",
			"PresentTense",
			"Auxiliary",
			"Modal",
			"Particle"
		];
		if (term.tags.has("Verb")) {
			if (!types.find((typ) => term.tags.has(typ))) setTag([term], "Infinitive", world, null, `2-verb-type''`);
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/01-acronym.js
	var oneLetterAcronym = /^[A-Z]('s|,)?$/;
	var isUpperCase = /^[A-Z-]+$/;
	var upperThenS = /^[A-Z]+s$/;
	var periodAcronym = /([A-Z]\.)+[A-Z]?,?$/;
	var noPeriodAcronym = /[A-Z]{2,}('s|,)?$/;
	var lowerCaseAcronym = /([a-z]\.)+[a-z]\.?$/;
	var oneLetterWord = {
		I: true,
		A: true
	};
	var places = {
		la: true,
		ny: true,
		us: true,
		dc: true,
		gb: true
	};
	var isNoPeriodAcronym = function(term, model) {
		let str = term.text;
		if (isUpperCase.test(str) === false) if (str.length > 3 && upperThenS.test(str) === true) str = str.replace(/s$/, "");
		else return false;
		if (str.length > 5) return false;
		if (oneLetterWord.hasOwnProperty(str)) return false;
		if (model.one.lexicon.hasOwnProperty(term.normal)) return false;
		if (periodAcronym.test(str) === true) return true;
		if (lowerCaseAcronym.test(str) === true) return true;
		if (oneLetterAcronym.test(str) === true) return true;
		if (noPeriodAcronym.test(str) === true) return true;
		return false;
	};
	var isAcronym = function(terms, i, model) {
		const term = terms[i];
		if (term.tags.has("RomanNumeral") || term.tags.has("Acronym") || term.frozen) return null;
		if (isNoPeriodAcronym(term, model)) {
			term.tags.clear();
			fastTag(term, ["Acronym", "Noun"], "3-no-period-acronym");
			if (places[term.normal] === true) fastTag(term, "Place", "3-place-acronym");
			if (upperThenS.test(term.text) === true) fastTag(term, "Plural", "3-plural-acronym");
			return true;
		}
		if (!oneLetterWord.hasOwnProperty(term.text) && oneLetterAcronym.test(term.text)) {
			term.tags.clear();
			fastTag(term, ["Acronym", "Noun"], "3-one-letter-acronym");
			return true;
		}
		if (term.tags.has("Organization") && term.text.length <= 3) {
			fastTag(term, "Acronym", "3-org-acronym");
			return true;
		}
		if (term.tags.has("Organization") && isUpperCase.test(term.text) && term.text.length <= 6) {
			fastTag(term, "Acronym", "3-titlecase-acronym");
			return true;
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/02-neighbours.js
	var lookAtWord = function(term, words) {
		if (!term) return null;
		const found = words.find((a) => term.normal === a[0]);
		if (found) return found[1];
		return null;
	};
	var lookAtTag = function(term, tags) {
		if (!term) return null;
		const found = tags.find((a) => term.tags.has(a[0]));
		if (found) return found[1];
		return null;
	};
	var neighbours = function(terms, i, model) {
		const { leftTags, leftWords, rightWords, rightTags } = model.two.neighbours;
		const term = terms[i];
		if (term.tags.size === 0) {
			let tag = null;
			tag = tag || lookAtWord(terms[i - 1], leftWords);
			tag = tag || lookAtWord(terms[i + 1], rightWords);
			tag = tag || lookAtTag(terms[i - 1], leftTags);
			tag = tag || lookAtTag(terms[i + 1], rightTags);
			if (tag) {
				fastTag(term, tag, "3-[neighbour]");
				fillTags(terms, i, model);
				terms[i].confidence = .2;
				return true;
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/03-orgWords.js
	var isTitleCase$2 = (str) => /^\p{Lu}[\p{Ll}'’]/u.test(str);
	var isOrg = function(term, i, yelling) {
		if (!term) return false;
		if (term.tags.has("FirstName") || term.tags.has("Place")) return false;
		if (term.tags.has("ProperNoun") || term.tags.has("Organization") || term.tags.has("Acronym")) return true;
		if (!yelling && isTitleCase$2(term.text)) {
			if (i === 0) return term.tags.has("Singular");
			return true;
		}
		return false;
	};
	var tagOrgs$1 = function(terms, i, world, yelling) {
		const orgWords = world.model.two.orgWords;
		const setTag = world.methods.one.setTag;
		const term = terms[i];
		if (orgWords[term.machine || term.normal] === true && isOrg(terms[i - 1], i - 1, yelling)) {
			setTag([terms[i]], "Organization", world, null, "3-[org-word]");
			for (let t = i; t >= 0; t -= 1) if (isOrg(terms[t], t, yelling)) setTag([terms[t]], "Organization", world, null, "3-[org-word]");
			else break;
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/04-placeWords.js
	var isTitleCase$1 = (str) => /^\p{Lu}[\p{Ll}'’]/u.test(str);
	var isPossessive$1 = /'s$/;
	var placeCont = new Set([
		"athletic",
		"city",
		"community",
		"eastern",
		"federal",
		"financial",
		"great",
		"historic",
		"historical",
		"local",
		"memorial",
		"municipal",
		"national",
		"northern",
		"provincial",
		"southern",
		"state",
		"western",
		"spring",
		"pine",
		"sunset",
		"view",
		"oak",
		"maple",
		"spruce",
		"cedar",
		"willow"
	]);
	var noBefore = new Set([
		"center",
		"centre",
		"way",
		"range",
		"bar",
		"bridge",
		"field",
		"pit"
	]);
	var isPlace = function(term, i, yelling) {
		if (!term) return false;
		const tags = term.tags;
		if (tags.has("Organization") || tags.has("Possessive") || isPossessive$1.test(term.normal)) return false;
		if (tags.has("ProperNoun") || tags.has("Place")) return true;
		if (!yelling && isTitleCase$1(term.text)) {
			if (i === 0) return tags.has("Singular");
			return true;
		}
		return false;
	};
	var tagOrgs = function(terms, i, world, yelling) {
		const placeWords = world.model.two.placeWords;
		const setTag = world.methods.one.setTag;
		const term = terms[i];
		const str = term.machine || term.normal;
		if (placeWords[str] === true) {
			for (let n = i - 1; n >= 0; n -= 1) {
				if (placeCont.has(terms[n].normal)) continue;
				if (isPlace(terms[n], n, yelling)) {
					setTag(terms.slice(n, i + 1), "Place", world, null, "3-[place-of-foo]");
					continue;
				}
				break;
			}
			if (noBefore.has(str)) return false;
			for (let n = i + 1; n < terms.length; n += 1) {
				if (isPlace(terms[n], n, yelling)) {
					setTag(terms.slice(i, n + 1), "Place", world, null, "3-[foo-place]");
					return true;
				}
				if (terms[n].normal === "of" || placeCont.has(terms[n].normal)) continue;
				break;
			}
		}
		return null;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/05-fallback.js
	var nounFallback = function(terms, i, model) {
		let isEmpty = false;
		const tags = terms[i].tags;
		if (tags.size === 0) isEmpty = true;
		else if (tags.size === 1) {
			if (tags.has("Hyphenated") || tags.has("HashTag") || tags.has("Prefix") || tags.has("SlashedTerm")) isEmpty = true;
		}
		if (isEmpty) {
			fastTag(terms[i], "Noun", "3-[fallback]");
			fillTags(terms, i, model);
			terms[i].confidence = .1;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/_adhoc.js
	var isTitleCase = /^[A-Z][a-z]/;
	var isCapital = (terms, i) => {
		if (terms[i].tags.has("ProperNoun") && isTitleCase.test(terms[i].text)) return "Noun";
		return null;
	};
	var isAlone = (terms, i, tag) => {
		if (i === 0 && !terms[1]) return tag;
		return null;
	};
	var isEndNoun = function(terms, i) {
		if (!terms[i + 1] && terms[i - 1] && terms[i - 1].tags.has("Determiner")) return "Noun";
		return null;
	};
	var isStart = function(terms, i, tag) {
		if (i === 0 && terms.length > 3) return tag;
		return null;
	};
	var adhoc = {
		"Adj|Gerund": (terms, i) => {
			return isCapital(terms, i);
		},
		"Adj|Noun": (terms, i) => {
			return isCapital(terms, i) || isEndNoun(terms, i);
		},
		"Actor|Verb": (terms, i) => {
			return isCapital(terms, i);
		},
		"Adj|Past": (terms, i) => {
			return isCapital(terms, i);
		},
		"Adj|Present": (terms, i) => {
			return isCapital(terms, i);
		},
		"Noun|Gerund": (terms, i) => {
			return isCapital(terms, i);
		},
		"Noun|Verb": (terms, i) => {
			return i > 0 && isCapital(terms, i) || isAlone(terms, i, "Infinitive");
		},
		"Plural|Verb": (terms, i) => {
			return isCapital(terms, i) || isAlone(terms, i, "PresentTense") || isStart(terms, i, "Plural");
		},
		"Person|Noun": (terms, i) => {
			return isCapital(terms, i);
		},
		"Person|Verb": (terms, i) => {
			if (i !== 0) return isCapital(terms, i);
			return null;
		},
		"Person|Adj": (terms, i) => {
			if (i === 0 && terms.length > 1) return "Person";
			return isCapital(terms, i) ? "Person" : null;
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/06-switches.js
	var env = typeof process === "undefined" || !process.env ? self.env || {} : process.env;
	var prefix = /^(under|over|mis|re|un|dis|semi)-?/;
	var checkWord = (term, obj) => {
		if (!term || !obj) return null;
		const str = term.normal || term.implicit;
		let found = null;
		if (obj.hasOwnProperty(str)) found = obj[str];
		if (found && env.DEBUG_TAGS) console.log(`\n  \x1b[2m\x1b[3m     ↓ - '${str}' \x1b[0m`);
		return found;
	};
	var checkTag = (term, obj = {}, tagSet) => {
		if (!term || !obj) return null;
		let found = Array.from(term.tags).sort((a, b) => {
			return (tagSet[a] ? tagSet[a].parents.length : 0) > (tagSet[b] ? tagSet[b].parents.length : 0) ? -1 : 1;
		}).find((tag) => obj[tag]);
		if (found && env.DEBUG_TAGS) console.log(`  \x1b[2m\x1b[3m      ↓ - '${term.normal || term.implicit}' (#${found})  \x1b[0m`);
		found = obj[found];
		return found;
	};
	var pickTag = function(terms, i, clues, model) {
		if (!clues) return null;
		const beforeIndex = terms[i - 1]?.text !== "also" ? i - 1 : Math.max(0, i - 2);
		const tagSet = model.one.tagSet;
		let tag = checkWord(terms[i + 1], clues.afterWords);
		tag = tag || checkWord(terms[beforeIndex], clues.beforeWords);
		tag = tag || checkTag(terms[beforeIndex], clues.beforeTags, tagSet);
		tag = tag || checkTag(terms[i + 1], clues.afterTags, tagSet);
		return tag;
	};
	var doSwitches = function(terms, i, world) {
		const model = world.model;
		const setTag = world.methods.one.setTag;
		const { switches, clues } = model.two;
		const term = terms[i];
		let str = term.normal || term.implicit || "";
		if (prefix.test(str) && !switches[str]) str = str.replace(prefix, "");
		if (term.switch) {
			const form = term.switch;
			if (term.tags.has("Acronym") || term.tags.has("PhrasalVerb")) return;
			let tag = pickTag(terms, i, clues[form], model);
			if (adhoc[form]) tag = adhoc[form](terms, i) || tag;
			if (tag) {
				setTag([term], tag, world, null, `3-[switch] (${form})`);
				fillTags(terms, i, model);
			} else if (env.DEBUG_TAGS) console.log(`\n -> X  - '${str}'  : (${form})  `);
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/3rd-pass/08-imperative.js
	var beside = {
		there: true,
		this: true,
		it: true,
		him: true,
		her: true,
		us: true
	};
	var imperative = function(terms, world) {
		const setTag = world.methods.one.setTag;
		const multiWords = world.model.one._multiCache || {};
		const t = terms[0];
		if ((t.switch === "Noun|Verb" || t.tags.has("Infinitive")) && terms.length >= 2) {
			if (terms.length < 4 && !beside[terms[1].normal]) return;
			if (!t.tags.has("PhrasalVerb") && multiWords.hasOwnProperty(t.normal)) return;
			if (terms[1].tags.has("Noun") || terms[1].tags.has("Determiner")) {
				if (!terms.slice(1, 3).some((term) => term.tags.has("Verb")) || t.tags.has("#PhrasalVerb")) setTag([t], "Imperative", world, null, "3-[imperative]");
			}
		}
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/tagger/index.js
	var ignoreCase = function(terms) {
		if (terms.filter((t) => !t.tags.has("ProperNoun")).length <= 3) return false;
		const lowerCase = /^[a-z]/;
		return terms.every((t) => !lowerCase.test(t.text));
	};
	var firstPass = function(docs, model, world) {
		docs.forEach((terms) => {
			byPunctuation(terms, 0, model, world);
		});
	};
	var secondPass = function(terms, model, world, isYelling) {
		for (let i = 0; i < terms.length; i += 1) {
			if (terms[i].frozen === true) continue;
			tagSwitch(terms, i, model);
			if (isYelling === false) checkCase(terms, i, model);
			tagBySuffix(terms, i, model);
			checkRegex(terms, i, model, world);
			checkPrefix(terms, i, model);
			tagYear(terms, i, model);
		}
	};
	var thirdPass = function(terms, model, world, isYelling) {
		for (let i = 0; i < terms.length; i += 1) {
			let found = isAcronym(terms, i, model);
			fillTags(terms, i, model);
			found = found || neighbours(terms, i, model);
			found = found || nounFallback(terms, i, model);
		}
		for (let i = 0; i < terms.length; i += 1) {
			if (terms[i].frozen === true) continue;
			tagOrgs$1(terms, i, world, isYelling);
			tagOrgs(terms, i, world, isYelling);
			doSwitches(terms, i, world);
			verbType(terms, i, model, world);
			byHyphen(terms, i, model, world);
		}
		imperative(terms, world);
	};
	var preTagger = function(view) {
		const { methods, model, world } = view;
		const docs = view.docs;
		firstPass(docs, model, world);
		const document = methods.two.quickSplit(docs);
		for (let n = 0; n < document.length; n += 1) {
			const terms = document[n];
			const isYelling = ignoreCase(terms);
			secondPass(terms, model, world, isYelling);
			thirdPass(terms, model, world, isYelling);
		}
		return document;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/root.js
	var toRoot = {
		"Possessive": (term) => {
			let str = term.machine || term.normal || term.text;
			str = str.replace(/'s$/, "");
			return str;
		},
		"Plural": (term, world) => {
			const str = term.machine || term.normal || term.text;
			return world.methods.two.transform.noun.toSingular(str, world.model);
		},
		"Copula": () => {
			return "is";
		},
		"PastTense": (term, world) => {
			const str = term.machine || term.normal || term.text;
			return world.methods.two.transform.verb.toInfinitive(str, world.model, "PastTense");
		},
		"Gerund": (term, world) => {
			const str = term.machine || term.normal || term.text;
			return world.methods.two.transform.verb.toInfinitive(str, world.model, "Gerund");
		},
		"PresentTense": (term, world) => {
			const str = term.machine || term.normal || term.text;
			if (term.tags.has("Infinitive")) return str;
			return world.methods.two.transform.verb.toInfinitive(str, world.model, "PresentTense");
		},
		"Comparative": (term, world) => {
			const str = term.machine || term.normal || term.text;
			return world.methods.two.transform.adjective.fromComparative(str, world.model);
		},
		"Superlative": (term, world) => {
			const str = term.machine || term.normal || term.text;
			return world.methods.two.transform.adjective.fromSuperlative(str, world.model);
		},
		"Adverb": (term, world) => {
			const { fromAdverb } = world.methods.two.transform.adjective;
			return fromAdverb(term.machine || term.normal || term.text);
		}
	};
	var getRoot = function(view) {
		const world = view.world;
		const keys = Object.keys(toRoot);
		view.docs.forEach((terms) => {
			for (let i = 0; i < terms.length; i += 1) {
				const term = terms[i];
				for (let k = 0; k < keys.length; k += 1) if (term.tags.has(keys[k])) {
					const fn = toRoot[keys[k]];
					const root = fn(term, world);
					if (term.normal !== root) term.root = root;
					break;
				}
			}
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/penn.js
	var mapping = {
		Adverb: "RB",
		Comparative: "JJR",
		Superlative: "JJS",
		Adjective: "JJ",
		TO: "Conjunction",
		Modal: "MD",
		Auxiliary: "MD",
		Gerund: "VBG",
		PastTense: "VBD",
		Participle: "VBN",
		PresentTense: "VBZ",
		Infinitive: "VB",
		Particle: "RP",
		Verb: "VB",
		Pronoun: "PRP",
		Cardinal: "CD",
		Conjunction: "CC",
		Determiner: "DT",
		Preposition: "IN",
		QuestionWord: "WP",
		Expression: "UH",
		Possessive: "POS",
		ProperNoun: "NNP",
		Person: "NNP",
		Place: "NNP",
		Organization: "NNP",
		Singular: "NN",
		Plural: "NNS",
		Noun: "NN",
		There: "EX"
	};
	var toPenn = function(term) {
		if (term.tags.has("ProperNoun") && term.tags.has("Plural")) return "NNPS";
		if (term.tags.has("Possessive") && term.tags.has("Pronoun")) return "PRP$";
		if (term.normal === "there") return "EX";
		if (term.normal === "to") return "TO";
		const arr = term.tagRank || [];
		for (let i = 0; i < arr.length; i += 1) if (mapping.hasOwnProperty(arr[i])) return mapping[arr[i]];
		return null;
	};
	var pennTag = function(view) {
		view.compute("tagRank");
		view.docs.forEach((terms) => {
			terms.forEach((term) => {
				term.penn = toPenn(term);
			});
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/compute/index.js
	var compute_default$2 = {
		preTagger,
		root: getRoot,
		penn: pennTag
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/tagSet/nouns.js
	var entity = [
		"Person",
		"Place",
		"Organization"
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/preTagger/plugin.js
	var plugin_default$3 = {
		compute: compute_default$2,
		methods: methods_default,
		model: model_default$1,
		tags: Object.assign({}, {
			Noun: { not: [
				"Verb",
				"Adjective",
				"Adverb",
				"Value",
				"Determiner"
			] },
			Singular: {
				is: "Noun",
				not: ["Plural", "Uncountable"]
			},
			ProperNoun: { is: "Noun" },
			Person: {
				is: "Singular",
				also: ["ProperNoun"],
				not: [
					"Place",
					"Organization",
					"Date"
				]
			},
			FirstName: { is: "Person" },
			MaleName: {
				is: "FirstName",
				not: ["FemaleName", "LastName"]
			},
			FemaleName: {
				is: "FirstName",
				not: ["MaleName", "LastName"]
			},
			LastName: {
				is: "Person",
				not: ["FirstName"]
			},
			Honorific: {
				is: "Person",
				not: [
					"FirstName",
					"LastName",
					"Value"
				]
			},
			Place: {
				is: "Singular",
				not: ["Person", "Organization"]
			},
			Country: {
				is: "Place",
				also: ["ProperNoun"],
				not: ["City"]
			},
			City: {
				is: "Place",
				also: ["ProperNoun"],
				not: ["Country"]
			},
			Region: {
				is: "Place",
				also: ["ProperNoun"]
			},
			Address: {},
			Organization: {
				is: "ProperNoun",
				not: ["Person", "Place"]
			},
			SportsTeam: { is: "Organization" },
			School: { is: "Organization" },
			Company: { is: "Organization" },
			Plural: {
				is: "Noun",
				not: ["Singular", "Uncountable"]
			},
			Uncountable: { is: "Noun" },
			Pronoun: {
				is: "Noun",
				not: entity
			},
			Actor: {
				is: "Noun",
				not: ["Place", "Organization"]
			},
			Activity: {
				is: "Noun",
				not: ["Person", "Place"]
			},
			Unit: {
				is: "Noun",
				not: entity
			},
			Demonym: {
				is: "Noun",
				also: ["ProperNoun"],
				not: entity
			},
			Possessive: { is: "Noun" },
			Reflexive: { is: "Pronoun" }
		}, {
			Verb: { not: [
				"Noun",
				"Adjective",
				"Adverb",
				"Value",
				"Expression"
			] },
			PresentTense: {
				is: "Verb",
				not: ["PastTense", "FutureTense"]
			},
			Infinitive: {
				is: "PresentTense",
				not: ["Gerund"]
			},
			Imperative: {
				is: "Verb",
				not: [
					"PastTense",
					"Gerund",
					"Copula"
				]
			},
			Gerund: {
				is: "PresentTense",
				not: ["Copula"]
			},
			PastTense: {
				is: "Verb",
				not: [
					"PresentTense",
					"Gerund",
					"FutureTense"
				]
			},
			FutureTense: {
				is: "Verb",
				not: ["PresentTense", "PastTense"]
			},
			Copula: { is: "Verb" },
			Modal: {
				is: "Verb",
				not: ["Infinitive"]
			},
			Participle: { is: "PastTense" },
			Auxiliary: {
				is: "Verb",
				not: [
					"PastTense",
					"PresentTense",
					"Gerund",
					"Conjunction"
				]
			},
			PhrasalVerb: { is: "Verb" },
			Particle: {
				is: "PhrasalVerb",
				not: [
					"PastTense",
					"PresentTense",
					"Copula",
					"Gerund"
				]
			},
			Passive: { is: "Verb" }
		}, {
			Value: { not: [
				"Verb",
				"Adjective",
				"Adverb"
			] },
			Ordinal: {
				is: "Value",
				not: ["Cardinal"]
			},
			Cardinal: {
				is: "Value",
				not: ["Ordinal"]
			},
			Fraction: {
				is: "Value",
				not: ["Noun"]
			},
			Multiple: { is: "TextValue" },
			RomanNumeral: {
				is: "Cardinal",
				not: ["TextValue"]
			},
			TextValue: {
				is: "Value",
				not: ["NumericValue"]
			},
			NumericValue: {
				is: "Value",
				not: ["TextValue"]
			},
			Money: { is: "Cardinal" },
			Percent: { is: "Value" }
		}, {
			Date: { not: [
				"Verb",
				"Adverb",
				"Adjective"
			] },
			Month: {
				is: "Date",
				also: ["Noun"],
				not: [
					"Year",
					"WeekDay",
					"Time"
				]
			},
			WeekDay: {
				is: "Date",
				also: ["Noun"]
			},
			Year: {
				is: "Date",
				not: ["RomanNumeral"]
			},
			FinancialQuarter: {
				is: "Date",
				not: "Fraction"
			},
			Holiday: {
				is: "Date",
				also: ["Noun"]
			},
			Season: { is: "Date" },
			Timezone: {
				is: "Date",
				also: ["Noun"],
				not: ["ProperNoun"]
			},
			Time: {
				is: "Date",
				not: ["AtMention"]
			},
			Duration: {
				is: "Date",
				also: ["Noun"]
			}
		}, {
			Adjective: { not: [
				"Noun",
				"Verb",
				"Adverb",
				"Value"
			] },
			Comparable: { is: "Adjective" },
			Comparative: { is: "Adjective" },
			Superlative: {
				is: "Adjective",
				not: ["Comparative"]
			},
			NumberRange: {},
			Adverb: { not: [
				"Noun",
				"Verb",
				"Adjective",
				"Value"
			] },
			Determiner: { not: [
				"Noun",
				"Verb",
				"Adjective",
				"Adverb",
				"QuestionWord",
				"Conjunction"
			] },
			Conjunction: { not: [
				"Noun",
				"Verb",
				"Adjective",
				"Adverb",
				"Value",
				"QuestionWord"
			] },
			Preposition: { not: [
				"Noun",
				"Verb",
				"Adjective",
				"Adverb",
				"QuestionWord",
				"Determiner"
			] },
			QuestionWord: { not: ["Determiner"] },
			Currency: { is: "Noun" },
			Expression: { not: [
				"Noun",
				"Adjective",
				"Verb",
				"Adverb"
			] },
			Abbreviation: {},
			Url: { not: [
				"HashTag",
				"PhoneNumber",
				"Verb",
				"Adjective",
				"Value",
				"AtMention",
				"Email",
				"SlashedTerm"
			] },
			PhoneNumber: { not: [
				"HashTag",
				"Verb",
				"Adjective",
				"Value",
				"AtMention",
				"Email"
			] },
			HashTag: {},
			AtMention: {
				is: "Noun",
				not: ["HashTag", "Email"]
			},
			Emoji: { not: [
				"HashTag",
				"Verb",
				"Adjective",
				"Value",
				"AtMention"
			] },
			Emoticon: { not: [
				"HashTag",
				"Verb",
				"Adjective",
				"Value",
				"AtMention",
				"SlashedTerm"
			] },
			SlashedTerm: { not: [
				"Emoticon",
				"Url",
				"Value"
			] },
			Email: { not: [
				"HashTag",
				"Verb",
				"Adjective",
				"Value",
				"AtMention"
			] },
			Acronym: { not: [
				"Plural",
				"RomanNumeral",
				"Pronoun",
				"Date"
			] },
			Negative: { not: [
				"Noun",
				"Adjective",
				"Value",
				"Expression"
			] },
			Condition: { not: [
				"Verb",
				"Adjective",
				"Noun",
				"Value"
			] },
			There: { not: [
				"Verb",
				"Adjective",
				"Noun",
				"Value",
				"Conjunction",
				"Preposition"
			] },
			Prefix: { not: [
				"Abbreviation",
				"Acronym",
				"ProperNoun"
			] },
			Hyphenated: {}
		}),
		hooks: ["preTagger"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/api/contract.js
	var postPunct = /[,)"';:\-–—.…]/;
	var setContraction = function(m, suffix) {
		if (!m.found) return;
		const terms = m.termList();
		for (let i = 0; i < terms.length - 1; i++) {
			const t = terms[i];
			if (postPunct.test(t.post)) return;
		}
		terms[0].implicit = terms[0].normal;
		terms[0].text += suffix;
		terms[0].normal += suffix;
		terms.slice(1).forEach((t) => {
			t.implicit = t.normal;
			t.text = "";
			t.normal = "";
		});
		for (let i = 0; i < terms.length - 1; i++) terms[i].post = terms[i].post.replace(/ /, "");
	};
	/** turn 'i am' into i'm */
	var contract = function() {
		const doc = this.not("@hasContraction");
		let m = doc.match("(we|they|you) are");
		setContraction(m, `'re`);
		m = doc.match("(he|she|they|it|we|you) will");
		setContraction(m, `'ll`);
		m = doc.match("(he|she|they|it|we) is");
		setContraction(m, `'s`);
		m = doc.match("#Person is");
		setContraction(m, `'s`);
		m = doc.match("#Person would");
		setContraction(m, `'d`);
		m = doc.match("(is|was|had|would|should|could|do|does|have|has|can) not");
		setContraction(m, `n't`);
		m = doc.match("(i|we|they) have");
		setContraction(m, `'ve`);
		m = doc.match("(would|should|could) have");
		setContraction(m, `'ve`);
		m = doc.match("i am");
		setContraction(m, `'m`);
		m = doc.match("going to");
		return this;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/api/index.js
	var titleCase = /^\p{Lu}[\p{Ll}'’]/u;
	var toTitleCase = function(str = "") {
		str = str.replace(/^ *[a-z\u00C0-\u00FF]/, (x) => x.toUpperCase());
		return str;
	};
	var api$1 = function(View) {
		/** */
		class Contractions extends View {
			constructor(document, pointer, groups) {
				super(document, pointer, groups);
				this.viewType = "Contraction";
			}
			/** i've -> 'i have' */
			expand() {
				this.docs.forEach((terms) => {
					const isTitleCase = titleCase.test(terms[0].text);
					terms.forEach((t, i) => {
						t.text = t.implicit || "";
						delete t.implicit;
						if (i < terms.length - 1 && t.post === "") t.post += " ";
						t.dirty = true;
					});
					if (isTitleCase) terms[0].text = toTitleCase(terms[0].text);
				});
				this.compute("normal");
				return this;
			}
		}
		View.prototype.contractions = function() {
			const m = this.match("@hasContraction+");
			return new Contractions(this.document, m.pointer);
		};
		View.prototype.contract = contract;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/_splice.js
	var insertContraction = function(document, point, words) {
		const [n, w] = point;
		if (!words || words.length === 0) return;
		words = words.map((word, i) => {
			word.implicit = word.text;
			word.machine = word.text;
			word.pre = "";
			word.post = "";
			word.text = "";
			word.normal = "";
			word.index = [n, w + i];
			return word;
		});
		if (words[0]) {
			words[0].pre = document[n][w].pre;
			words[words.length - 1].post = document[n][w].post;
			words[0].text = document[n][w].text;
			words[0].normal = document[n][w].normal;
		}
		document[n].splice(w, 1, ...words);
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/apostrophe-s.js
	var hasContraction$1 = /'/;
	var hasWords = new Set(["been", "become"]);
	var isWords = new Set([
		"what",
		"how",
		"when",
		"if",
		"too"
	]);
	var adjLike$1 = new Set([
		"too",
		"also",
		"enough"
	]);
	var isOrHas = (terms, i) => {
		for (let o = i + 1; o < terms.length; o += 1) {
			const t = terms[o];
			if (hasWords.has(t.normal)) return "has";
			if (isWords.has(t.normal)) return "is";
			if (t.tags.has("Gerund")) return "is";
			if (t.tags.has("Determiner")) return "is";
			if (t.tags.has("Adjective")) return "is";
			if (t.switch === "Adj|Past") {
				if (terms[o + 1]) {
					if (adjLike$1.has(terms[o + 1].normal)) return "is";
					if (terms[o + 1].tags.has("Preposition")) return "is";
				}
			}
			if (t.tags.has("PastTense")) {
				if (terms[o + 1] && terms[o + 1].normal === "for") return "is";
				return "has";
			}
		}
		return "is";
	};
	var apostropheS = function(terms, i) {
		const before = terms[i].normal.split(hasContraction$1)[0];
		if (before === "let") return [before, "us"];
		if (before === "there") {
			const t = terms[i + 1];
			if (t && t.tags.has("Plural")) return [before, "are"];
		}
		if (isOrHas(terms, i) === "has") return [before, "has"];
		return [before, "is"];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/apostrophe-d.js
	var hasContraction = /'/;
	var hadWords = new Set([
		"better",
		"done",
		"before",
		"it",
		"had"
	]);
	var wouldWords = new Set(["have", "be"]);
	var hadOrWould = (terms, i) => {
		for (let o = i + 1; o < terms.length; o += 1) {
			const t = terms[o];
			if (hadWords.has(t.normal)) return "had";
			if (wouldWords.has(t.normal)) return "would";
			if (t.tags.has("PastTense") || t.switch === "Adj|Past") return "had";
			if (t.tags.has("PresentTense") || t.tags.has("Infinitive")) return "would";
			if (t.tags.has("#Determiner")) return "had";
			if (t.tags.has("Adjective")) return "would";
		}
		return false;
	};
	var _apostropheD = function(terms, i) {
		const before = terms[i].normal.split(hasContraction)[0];
		if (before === "how" || before === "what") return [before, "did"];
		if (hadOrWould(terms, i) === "had") return [before, "had"];
		return [before, "would"];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/apostrophe-t.js
	var lastNoun = function(terms, i) {
		for (let n = i - 1; n >= 0; n -= 1) if (terms[n].tags.has("Noun") || terms[n].tags.has("Pronoun") || terms[n].tags.has("Plural") || terms[n].tags.has("Singular")) return terms[n];
		return null;
	};
	var apostropheT = function(terms, i) {
		if (terms[i].normal === "ain't" || terms[i].normal === "aint") {
			if (terms[i + 1] && terms[i + 1].normal === "never") return ["have"];
			const noun = lastNoun(terms, i);
			if (noun) {
				if (noun.normal === "we" || noun.normal === "they") return ["are", "not"];
				if (noun.normal === "i") return ["am", "not"];
				if (noun.tags && noun.tags.has("Plural")) return ["are", "not"];
			}
			return ["is", "not"];
		}
		return [terms[i].normal.replace(/n't/, ""), "not"];
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/isPossessive.js
	var banList = {
		that: true,
		there: true,
		let: true,
		here: true,
		everywhere: true
	};
	var beforePossessive = {
		in: true,
		by: true,
		for: true
	};
	var adjLike = new Set([
		"too",
		"also",
		"enough",
		"about"
	]);
	var nounLike = new Set([
		"is",
		"are",
		"did",
		"were",
		"could",
		"should",
		"must",
		"had",
		"have"
	]);
	var isPossessive = (terms, i) => {
		const term = terms[i];
		if (banList.hasOwnProperty(term.machine || term.normal)) return false;
		if (term.tags.has("Possessive")) return true;
		if (term.tags.has("QuestionWord")) return false;
		if (term.normal === `he's` || term.normal === `she's`) return false;
		const nextTerm = terms[i + 1];
		if (!nextTerm) return true;
		if (term.normal === `it's`) {
			if (nextTerm.tags.has("#Noun")) return true;
			return false;
		}
		if (nextTerm.switch == "Noun|Gerund") {
			const next2 = terms[i + 2];
			if (!next2) {
				if (term.tags.has("Actor") || term.tags.has("ProperNoun")) return true;
				return false;
			}
			if (next2.tags.has("Copula")) return true;
			if (next2.normal === "on" || next2.normal === "in") return false;
			return false;
		}
		if (nextTerm.tags.has("Verb")) {
			if (nextTerm.tags.has("Infinitive")) return true;
			if (nextTerm.tags.has("Gerund")) return false;
			if (nextTerm.tags.has("PresentTense")) return true;
			return false;
		}
		if (nextTerm.switch === "Adj|Noun") {
			const twoTerm = terms[i + 2];
			if (!twoTerm) return false;
			if (nounLike.has(twoTerm.normal)) return true;
			if (adjLike.has(twoTerm.normal)) return false;
		}
		if (nextTerm.tags.has("Noun")) {
			const nextStr = nextTerm.machine || nextTerm.normal;
			if (nextStr === "here" || nextStr === "there" || nextStr === "everywhere") return false;
			if (nextTerm.tags.has("Possessive")) return false;
			if (nextTerm.tags.has("ProperNoun") && !term.tags.has("ProperNoun")) return false;
			return true;
		}
		if (terms[i - 1] && beforePossessive[terms[i - 1].normal] === true) return true;
		if (nextTerm.tags.has("Adjective")) {
			const twoTerm = terms[i + 2];
			if (!twoTerm) return false;
			if (twoTerm.tags.has("Noun") && !twoTerm.tags.has("Pronoun")) {
				const str = nextTerm.normal;
				if (str === "above" || str === "below" || str === "behind") return false;
				return true;
			}
			if (twoTerm.switch === "Noun|Verb") return true;
			return false;
		}
		if (nextTerm.tags.has("Value")) return true;
		return false;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/compute/index.js
	var byApostrophe = /'/;
	var reIndex = function(terms) {
		terms.forEach((t, i) => {
			if (t.index) t.index[1] = i;
		});
	};
	var reTag = function(terms, view, start, len) {
		const tmp = view.update();
		tmp.document = [terms];
		let end = start + len;
		if (start > 0) start -= 1;
		if (terms[end]) end += 1;
		tmp.ptrs = [[
			0,
			start,
			end
		]];
		tmp.compute([
			"freeze",
			"lexicon",
			"preTagger",
			"unfreeze"
		]);
		reIndex(terms);
	};
	var byEnd = {
		d: (terms, i) => _apostropheD(terms, i),
		t: (terms, i) => apostropheT(terms, i),
		s: (terms, i, world) => {
			if (isPossessive(terms, i)) return world.methods.one.setTag([terms[i]], "Possessive", world, null, "2-contraction");
			return apostropheS(terms, i);
		}
	};
	var toDocs = function(words, view) {
		const doc = view.fromText(words.join(" "));
		doc.compute("id");
		return doc.docs[0];
	};
	var contractionTwo = (view) => {
		const { world, document } = view;
		document.forEach((terms, n) => {
			for (let i = terms.length - 1; i >= 0; i -= 1) {
				if (terms[i].implicit) continue;
				let after = null;
				if (byApostrophe.test(terms[i].normal) === true) after = terms[i].normal.split(byApostrophe)[1];
				let words = null;
				if (byEnd.hasOwnProperty(after)) words = byEnd[after](terms, i, world);
				if (words) {
					words = toDocs(words, view);
					insertContraction(document, [n, i], words);
					reTag(document[n], view, i, words.length);
					continue;
				}
			}
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/contraction-two/plugin.js
	var plugin_default$2 = {
		compute: { contractionTwo },
		api: api$1,
		hooks: ["contractionTwo"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adjective/adjective.js
	var adjective_default = [
		{
			match: "[(all|both)] #Determiner #Noun",
			group: 0,
			tag: "Noun",
			reason: "all-noun"
		},
		{
			match: "#Copula [(just|alone)]$",
			group: 0,
			tag: "Adjective",
			reason: "not-adverb"
		},
		{
			match: "#Singular is #Adverb? [#PastTense$]",
			group: 0,
			tag: "Adjective",
			reason: "is-filled"
		},
		{
			match: "[#PastTense] #Singular is",
			group: 0,
			tag: "Adjective",
			reason: "smoked-poutine"
		},
		{
			match: "[#PastTense] #Plural are",
			group: 0,
			tag: "Adjective",
			reason: "baked-onions"
		},
		{
			match: "well [#PastTense]",
			group: 0,
			tag: "Adjective",
			reason: "well-made"
		},
		{
			match: "#Copula [fucked up?]",
			group: 0,
			tag: "Adjective",
			reason: "swears-adjective"
		},
		{
			match: "#Singular (seems|appears) #Adverb? [#PastTense$]",
			group: 0,
			tag: "Adjective",
			reason: "seems-filled"
		},
		{
			match: "#Copula #Adjective? [(out|in|through)]$",
			group: 0,
			tag: "Adjective",
			reason: "still-out"
		},
		{
			match: "^[#Adjective] (the|your) #Noun",
			group: 0,
			notIf: "(all|even)",
			tag: "Infinitive",
			reason: "shut-the"
		},
		{
			match: "the [said] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "the-said-card"
		},
		{
			match: "[#Hyphenated (#Hyphenated && #PastTense)] (#Noun|#Conjunction)",
			group: 0,
			tag: "Adjective",
			notIf: "#Adverb",
			reason: "faith-based"
		},
		{
			match: "[#Hyphenated (#Hyphenated && #Gerund)] (#Noun|#Conjunction)",
			group: 0,
			tag: "Adjective",
			notIf: "#Adverb",
			reason: "self-driving"
		},
		{
			match: "[#PastTense (#Hyphenated && #PhrasalVerb)] (#Noun|#Conjunction)",
			group: 0,
			tag: "Adjective",
			reason: "dammed-up"
		},
		{
			match: "(#Hyphenated && #Value) fold",
			tag: "Adjective",
			reason: "two-fold"
		},
		{
			match: "must (#Hyphenated && #Infinitive)",
			tag: "Adjective",
			reason: "must-win"
		},
		{
			match: `(#Hyphenated && #Infinitive) #Hyphenated`,
			tag: "Adjective",
			notIf: "#PhrasalVerb",
			reason: "vacuum-sealed"
		},
		{
			match: "too much",
			tag: "Adverb Adjective",
			reason: "bit-4"
		},
		{
			match: "a bit much",
			tag: "Determiner Adverb Adjective",
			reason: "bit-3"
		},
		{
			match: "[(un|contra|extra|inter|intra|macro|micro|mid|mis|mono|multi|pre|sub|tri|ex)] #Adjective",
			group: 0,
			tag: ["Adjective", "Prefix"],
			reason: "un-skilled"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adjective/adj-adverb.js
	var adverbAdj = `(dark|bright|flat|light|soft|pale|dead|dim|faux|little|wee|sheer|most|near|good|extra|all)`;
	var noLy = "(hard|fast|late|early|high|right|deep|close|direct)";
	var adj_adverb_default = [
		{
			match: `#Adverb [#Adverb] (and|or|then)`,
			group: 0,
			tag: "Adjective",
			reason: "kinda-sparkly-and"
		},
		{
			match: `[${adverbAdj}] #Adjective`,
			group: 0,
			tag: "Adverb",
			reason: "dark-green"
		},
		{
			match: `#Copula [far too] #Adjective`,
			group: 0,
			tag: "Adverb",
			reason: "far-too"
		},
		{
			match: `#Copula [still] (in|#Gerund|#Adjective)`,
			group: 0,
			tag: "Adverb",
			reason: "was-still-walking"
		},
		{
			match: `#Plural ${noLy}`,
			tag: "#PresentTense #Adverb",
			reason: "studies-hard"
		},
		{
			match: `#Verb [${noLy}] !#Noun?`,
			group: 0,
			notIf: "(#Copula|get|got|getting|become|became|becoming|feel|feels|feeling|#Determiner|#Preposition)",
			tag: "Adverb",
			reason: "shops-direct"
		},
		{
			match: `[#Plural] a lot`,
			tag: "PresentTense",
			reason: "studies-a-lot"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adjective/adj-gerund.js
	var adj_gerund_default$1 = [
		{
			match: "as [#Gerund] as",
			group: 0,
			tag: "Adjective",
			reason: "as-gerund-as"
		},
		{
			match: "more [#Gerund] than",
			group: 0,
			tag: "Adjective",
			reason: "more-gerund-than"
		},
		{
			match: "(so|very|extremely) [#Gerund]",
			group: 0,
			tag: "Adjective",
			reason: "so-gerund"
		},
		{
			match: "(found|found) it #Adverb? [#Gerund]",
			group: 0,
			tag: "Adjective",
			reason: "found-it-gerund"
		},
		{
			match: "a (little|bit|wee) bit? [#Gerund]",
			group: 0,
			tag: "Adjective",
			reason: "a-bit-gerund"
		},
		{
			match: "#Gerund [#Gerund]",
			group: 0,
			tag: "Adjective",
			notIf: "(impersonating|practicing|considering|assuming)",
			reason: "looking-annoying"
		},
		{
			match: "(looked|look|looks) #Adverb? [%Adj|Gerund%]",
			group: 0,
			tag: "Adjective",
			notIf: "(impersonating|practicing|considering|assuming)",
			reason: "looked-amazing"
		},
		{
			match: "[%Adj|Gerund%] #Determiner",
			group: 0,
			tag: "Gerund",
			reason: "developing-a"
		},
		{
			match: "#Possessive [%Adj|Gerund%] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "leading-manufacturer"
		},
		{
			match: "%Noun|Gerund% %Adj|Gerund%",
			tag: "Gerund #Adjective",
			reason: "meaning-alluring"
		},
		{
			match: "(face|embrace|reveal|stop|start|resume) %Adj|Gerund%",
			tag: "#PresentTense #Adjective",
			reason: "face-shocking"
		},
		{
			match: "(are|were) [%Adj|Gerund%] #Plural",
			group: 0,
			tag: "Adjective",
			reason: "are-enduring-symbols"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adjective/adj-noun.js
	var adj_noun_default = [
		{
			match: "#Determiner [#Adjective] #Copula",
			group: 0,
			tag: "Noun",
			reason: "the-adj-is"
		},
		{
			match: "#Adjective [#Adjective] #Copula",
			group: 0,
			tag: "Noun",
			reason: "adj-adj-is"
		},
		{
			match: "(his|its) [%Adj|Noun%]",
			group: 0,
			tag: "Noun",
			notIf: "#Hyphenated",
			reason: "his-fine"
		},
		{
			match: "#Copula #Adverb? [all]",
			group: 0,
			tag: "Noun",
			reason: "is-all"
		},
		{
			match: `(have|had) [#Adjective] #Preposition .`,
			group: 0,
			tag: "Noun",
			reason: "have-fun"
		},
		{
			match: `#Gerund (giant|capital|center|zone|application)`,
			tag: "Noun",
			reason: "brewing-giant"
		},
		{
			match: `#Preposition (a|an) [#Adjective]$`,
			group: 0,
			tag: "Noun",
			reason: "an-instant"
		},
		{
			match: `no [#Adjective] #Modal`,
			group: 0,
			tag: "Noun",
			reason: "no-golden"
		},
		{
			match: `[brand #Gerund?] new`,
			group: 0,
			tag: "Adverb",
			reason: "brand-new"
		},
		{
			match: `(#Determiner|#Comparative|new|different) [kind]`,
			group: 0,
			tag: "Noun",
			reason: "some-kind"
		},
		{
			match: `#Possessive [%Adj|Noun%] #Noun`,
			group: 0,
			tag: "Adjective",
			reason: "her-favourite"
		},
		{
			match: `must && #Hyphenated .`,
			tag: "Adjective",
			reason: "must-win"
		},
		{
			match: `#Determiner [#Adjective]$`,
			tag: "Noun",
			notIf: "(this|that|#Comparative|#Superlative)",
			reason: "the-south"
		},
		{
			match: `(#Noun && #Hyphenated) (#Adjective && #Hyphenated)`,
			tag: "Adjective",
			notIf: "(this|that|#Comparative|#Superlative)",
			reason: "company-wide"
		},
		{
			match: `#Determiner [#Adjective] (#Copula|#Determiner)`,
			notIf: "(#Comparative|#Superlative)",
			group: 0,
			tag: "Noun",
			reason: "the-poor"
		},
		{
			match: `[%Adj|Noun%] #Noun`,
			notIf: "(#Pronoun|#ProperNoun)",
			group: 0,
			tag: "Adjective",
			reason: "stable-foundations"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adjective/adj-verb.js
	var adj_verb_default = [
		{
			match: "(slowly|quickly) [#Adjective]",
			group: 0,
			tag: "Verb",
			reason: "slowly-adj"
		},
		{
			match: "does (#Adverb|not)? [#Adjective]",
			group: 0,
			tag: "PresentTense",
			reason: "does-mean"
		},
		{
			match: "[(fine|okay|cool|ok)] by me",
			group: 0,
			tag: "Adjective",
			reason: "okay-by-me"
		},
		{
			match: "i (#Adverb|do)? not? [mean]",
			group: 0,
			tag: "PresentTense",
			reason: "i-mean"
		},
		{
			match: "will #Adjective",
			tag: "Auxiliary Infinitive",
			reason: "will-adj"
		},
		{
			match: "#Pronoun [#Adjective] #Determiner #Adjective? #Noun",
			group: 0,
			tag: "Verb",
			reason: "he-adj-the"
		},
		{
			match: "#Copula [%Adj|Present%] to #Verb",
			group: 0,
			tag: "Verb",
			reason: "adj-to"
		},
		{
			match: "#Copula [#Adjective] (well|badly|quickly|slowly)",
			group: 0,
			tag: "Verb",
			reason: "done-well"
		},
		{
			match: "#Adjective and [#Gerund] !#Preposition?",
			group: 0,
			tag: "Adjective",
			reason: "rude-and-x"
		},
		{
			match: "#Copula #Adverb? (over|under) [#PastTense]",
			group: 0,
			tag: "Adjective",
			reason: "over-cooked"
		},
		{
			match: "#Copula #Adjective+ (and|or) [#PastTense]$",
			group: 0,
			tag: "Adjective",
			reason: "bland-and-overcooked"
		},
		{
			match: "got #Adverb? [#PastTense] of",
			group: 0,
			tag: "Adjective",
			reason: "got-tired-of"
		},
		{
			match: "(seem|seems|seemed|appear|appeared|appears|feel|feels|felt|sound|sounds|sounded) (#Adverb|#Adjective)? [#PastTense]",
			group: 0,
			tag: "Adjective",
			reason: "felt-loved"
		},
		{
			match: "(seem|feel|seemed|felt) [#PastTense #Particle?]",
			group: 0,
			tag: "Adjective",
			reason: "seem-confused"
		},
		{
			match: "a (bit|little|tad) [#PastTense #Particle?]",
			group: 0,
			tag: "Adjective",
			reason: "a-bit-confused"
		},
		{
			match: "not be [%Adj|Past% #Particle?]",
			group: 0,
			tag: "Adjective",
			reason: "do-not-be-confused"
		},
		{
			match: "#Copula just [%Adj|Past% #Particle?]",
			group: 0,
			tag: "Adjective",
			reason: "is-just-right"
		},
		{
			match: "as [#Infinitive] as",
			group: 0,
			tag: "Adjective",
			reason: "as-pale-as"
		},
		{
			match: "[%Adj|Past%] and #Adjective",
			group: 0,
			tag: "Adjective",
			reason: "faled-and-oppressive"
		},
		{
			match: "or [#PastTense] #Noun",
			group: 0,
			tag: "Adjective",
			notIf: "(#Copula|#Pronoun)",
			reason: "or-heightened-emotion"
		},
		{
			match: "(become|became|becoming|becomes) [#Verb]",
			group: 0,
			tag: "Adjective",
			reason: "become-verb"
		},
		{
			match: "#Possessive [#PastTense] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "declared-intentions"
		},
		{
			match: "#Copula #Pronoun [%Adj|Present%]",
			group: 0,
			tag: "Adjective",
			reason: "is-he-cool"
		},
		{
			match: "#Copula [%Adj|Past%] with",
			group: 0,
			tag: "Adjective",
			notIf: "(associated|worn|baked|aged|armed|bound|fried|loaded|mixed|packed|pumped|filled|sealed)",
			reason: "is-crowded-with"
		},
		{
			match: "#Copula #Adverb? [%Adj|Present%]$",
			group: 0,
			tag: "Adjective",
			reason: "was-empty$"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/adverb.js
	var adverb_default = [
		{
			match: "[still] #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "still-advb"
		},
		{
			match: "[still] #Verb",
			group: 0,
			tag: "Adverb",
			reason: "still-verb"
		},
		{
			match: "[so] #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "so-adv"
		},
		{
			match: "[way] #Comparative",
			group: 0,
			tag: "Adverb",
			reason: "way-adj"
		},
		{
			match: "[way] #Adverb #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "way-too-adj"
		},
		{
			match: "[all] #Verb",
			group: 0,
			tag: "Adverb",
			reason: "all-verb"
		},
		{
			match: "#Verb  [like]",
			group: 0,
			notIf: "(#Modal|#PhrasalVerb)",
			tag: "Adverb",
			reason: "verb-like"
		},
		{
			match: "(barely|hardly) even",
			tag: "Adverb",
			reason: "barely-even"
		},
		{
			match: "[even] #Verb",
			group: 0,
			tag: "Adverb",
			reason: "even-walk"
		},
		{
			match: "[even] #Comparative",
			group: 0,
			tag: "Adverb",
			reason: "even-worse"
		},
		{
			match: "[even] (#Determiner|#Possessive)",
			group: 0,
			tag: "#Adverb",
			reason: "even-the"
		},
		{
			match: "even left",
			tag: "#Adverb #Verb",
			reason: "even-left"
		},
		{
			match: "[way] #Adjective",
			group: 0,
			tag: "#Adverb",
			reason: "way-over"
		},
		{
			match: "#PresentTense [(hard|quick|bright|slow|fast|backwards|forwards)]",
			notIf: "#Copula",
			group: 0,
			tag: "Adverb",
			reason: "lazy-ly"
		},
		{
			match: "[much] #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "bit-1"
		},
		{
			match: "#Copula [#Adverb]$",
			group: 0,
			tag: "Adjective",
			reason: "is-well"
		},
		{
			match: "a [(little|bit|wee) bit?] #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "a-bit-cold"
		},
		{
			match: `[(super|pretty)] #Adjective`,
			group: 0,
			tag: "Adverb",
			reason: "super-strong"
		},
		{
			match: "(become|fall|grow) #Adverb? [#PastTense]",
			group: 0,
			tag: "Adjective",
			reason: "overly-weakened"
		},
		{
			match: "(a|an) #Adverb [#Participle] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "completely-beaten"
		},
		{
			match: "#Determiner #Adverb? [close]",
			group: 0,
			tag: "Adjective",
			reason: "a-close"
		},
		{
			match: "#Gerund #Adverb? [close]",
			group: 0,
			tag: "Adverb",
			notIf: "(getting|becoming|feeling)",
			reason: "being-close"
		},
		{
			match: "(the|those|these|a|an) [#Participle] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "blown-motor"
		},
		{
			match: "(#PresentTense|#PastTense) [back]",
			group: 0,
			tag: "Adverb",
			notIf: "(#PhrasalVerb|#Copula)",
			reason: "charge-back"
		},
		{
			match: "#Verb [around]",
			group: 0,
			tag: "Adverb",
			notIf: "#PhrasalVerb",
			reason: "send-around"
		},
		{
			match: "[later] #PresentTense",
			group: 0,
			tag: "Adverb",
			reason: "later-say"
		},
		{
			match: "#Determiner [well] !#PastTense?",
			group: 0,
			tag: "Noun",
			reason: "the-well"
		},
		{
			match: "#Adjective [enough]",
			group: 0,
			tag: "Adverb",
			reason: "high-enough"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/dates/date-phrase.js
	var date_phrase_default = [
		{
			match: "#Holiday (day|eve)",
			tag: "Holiday",
			reason: "holiday-day"
		},
		{
			match: "#Value of #Month",
			tag: "Date",
			reason: "value-of-month"
		},
		{
			match: "#Cardinal #Month",
			tag: "Date",
			reason: "cardinal-month"
		},
		{
			match: "#Month #Value to #Value",
			tag: "Date",
			reason: "value-to-value"
		},
		{
			match: "#Month the #Value",
			tag: "Date",
			reason: "month-the-value"
		},
		{
			match: "(#WeekDay|#Month) #Value",
			tag: "Date",
			reason: "date-value"
		},
		{
			match: "#Value (#WeekDay|#Month)",
			tag: "Date",
			reason: "value-date"
		},
		{
			match: "(#TextValue && #Date) #TextValue",
			tag: "Date",
			reason: "textvalue-date"
		},
		{
			match: `#Month #NumberRange`,
			tag: "Date",
			reason: "aug 20-21"
		},
		{
			match: `#WeekDay #Month #Ordinal`,
			tag: "Date",
			reason: "week mm-dd"
		},
		{
			match: `#Month #Ordinal #Cardinal`,
			tag: "Date",
			reason: "mm-dd-yyy"
		},
		{
			match: `(#Place|#Demonmym|#Time) (standard|daylight|central|mountain)? time`,
			tag: "Timezone",
			reason: "std-time"
		},
		{
			match: `(eastern|mountain|pacific|central|atlantic) (standard|daylight|summer)? time`,
			tag: "Timezone",
			reason: "eastern-time"
		},
		{
			match: `#Time [(eastern|mountain|pacific|central|est|pst|gmt)]`,
			group: 0,
			tag: "Timezone",
			reason: "5pm-central"
		},
		{
			match: `(central|western|eastern) european time`,
			tag: "Timezone",
			reason: "cet"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/dates/date.js
	var date_default = [
		{
			match: "[sun] the #Ordinal",
			tag: "WeekDay",
			reason: "sun-the-5th"
		},
		{
			match: "[sun] #Date",
			group: 0,
			tag: "WeekDay",
			reason: "sun-feb"
		},
		{
			match: "#Date (on|this|next|last|during)? [sun]",
			group: 0,
			tag: "WeekDay",
			reason: "1pm-sun"
		},
		{
			match: `(in|by|before|during|on|until|after|of|within|all) [sat]`,
			group: 0,
			tag: "WeekDay",
			reason: "sat"
		},
		{
			match: `(in|by|before|during|on|until|after|of|within|all) [wed]`,
			group: 0,
			tag: "WeekDay",
			reason: "wed"
		},
		{
			match: `(in|by|before|during|on|until|after|of|within|all) [march]`,
			group: 0,
			tag: "Month",
			reason: "march"
		},
		{
			match: "[sat] #Date",
			group: 0,
			tag: "WeekDay",
			reason: "sat-feb"
		},
		{
			match: `#Preposition [(march|may)]`,
			group: 0,
			tag: "Month",
			reason: "in-month"
		},
		{
			match: `(this|next|last) (march|may) !#Infinitive?`,
			tag: "#Date #Month",
			reason: "this-month"
		},
		{
			match: `(march|may) the? #Value`,
			tag: "#Month #Date #Date",
			reason: "march-5th"
		},
		{
			match: `#Value of? (march|may)`,
			tag: "#Date #Date #Month",
			reason: "5th-of-march"
		},
		{
			match: `[(march|may)] .? #Date`,
			group: 0,
			tag: "Month",
			reason: "march-and-feb"
		},
		{
			match: `#Date .? [(march|may)]`,
			group: 0,
			tag: "Month",
			reason: "feb-and-march"
		},
		{
			match: `#Adverb [(march|may)]`,
			group: 0,
			tag: "Verb",
			reason: "quickly-march"
		},
		{
			match: `[(march|may)] #Adverb`,
			group: 0,
			tag: "Verb",
			reason: "march-quickly"
		},
		{
			match: `#Value (am|pm)`,
			tag: "Time",
			reason: "2-am"
		}
	];
	var nouns_default = [
		{
			match: "(the|any) [more]",
			group: 0,
			tag: "Singular",
			reason: "more-noun"
		},
		{
			match: "[more] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "more-noun"
		},
		{
			match: "(right|rights) of .",
			tag: "Noun",
			reason: "right-of"
		},
		{
			match: "a [bit]",
			group: 0,
			tag: "Singular",
			reason: "bit-2"
		},
		{
			match: "a [must]",
			group: 0,
			tag: "Singular",
			reason: "must-2"
		},
		{
			match: "(we|us) [all]",
			group: 0,
			tag: "Noun",
			reason: "we all"
		},
		{
			match: "due to [#Verb]",
			group: 0,
			tag: "Noun",
			reason: "due-to"
		},
		{
			match: "some [#Verb] #Plural",
			group: 0,
			tag: "Noun",
			reason: "determiner6"
		},
		{
			match: "#Possessive #Ordinal [#PastTense]",
			group: 0,
			tag: "Noun",
			reason: "first-thought"
		},
		{
			match: "(the|this|those|these) #Adjective [%Verb|Noun%]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "the-adj-verb"
		},
		{
			match: "(the|this|those|these) #Adverb #Adjective [#Verb]",
			group: 0,
			tag: "Noun",
			reason: "determiner4"
		},
		{
			match: "the [#Verb] #Preposition .",
			group: 0,
			tag: "Noun",
			reason: "determiner1"
		},
		{
			match: "(a|an|the) [#Verb] of",
			group: 0,
			tag: "Noun",
			reason: "the-verb-of"
		},
		{
			match: "#Determiner #Noun of [#Verb]",
			group: 0,
			tag: "Noun",
			notIf: "#Gerund",
			reason: "noun-of-noun"
		},
		{
			match: "#PastTense #Preposition [#PresentTense]",
			group: 0,
			notIf: "#Gerund",
			tag: "Noun",
			reason: "ended-in-ruins"
		},
		{
			match: "#Conjunction [u]",
			group: 0,
			tag: "Pronoun",
			reason: "u-pronoun-2"
		},
		{
			match: "[u] #Verb",
			group: 0,
			tag: "Pronoun",
			reason: "u-pronoun-1"
		},
		{
			match: "#Determiner [(western|eastern|northern|southern|central)] #Noun",
			group: 0,
			tag: "Noun",
			reason: "western-line"
		},
		{
			match: "(#Singular && @hasHyphen) #PresentTense",
			tag: "Noun",
			reason: "hyphen-verb"
		},
		{
			match: "is no [#Verb]",
			group: 0,
			tag: "Noun",
			reason: "is-no-verb"
		},
		{
			match: "do [so]",
			group: 0,
			tag: "Noun",
			reason: "so-noun"
		},
		{
			match: "#Determiner [(shit|damn|hell)]",
			group: 0,
			tag: "Noun",
			reason: "swears-noun"
		},
		{
			match: "to [(shit|hell)]",
			group: 0,
			tag: "Noun",
			reason: "to-swears"
		},
		{
			match: "(the|these) [#Singular] (were|are)",
			group: 0,
			tag: "Plural",
			reason: "singular-were"
		},
		{
			match: `a #Noun+ or #Adverb+? [#Verb]`,
			group: 0,
			tag: "Noun",
			reason: "noun-or-noun"
		},
		{
			match: "(the|those|these|a|an) #Adjective? [#PresentTense #Particle?]",
			group: 0,
			tag: "Noun",
			notIf: "(seem|appear|include|#Gerund|#Copula)",
			reason: "det-inf"
		},
		{
			match: "#Noun #Actor",
			tag: "Actor",
			notIf: "(#Person|#Pronoun)",
			reason: "thing-doer"
		},
		{
			match: "#Gerund #Actor",
			tag: "Actor",
			reason: "gerund-doer"
		},
		{
			match: `co #Singular`,
			tag: "Actor",
			reason: "co-noun"
		},
		{
			match: `[#Noun+] #Actor`,
			group: 0,
			tag: "Actor",
			notIf: "(#Honorific|#Pronoun|#Possessive)",
			reason: "air-traffic-controller"
		},
		{
			match: `(urban|cardiac|cardiovascular|respiratory|medical|clinical|visual|graphic|creative|dental|exotic|fine|certified|registered|technical|virtual|professional|amateur|junior|senior|special|pharmaceutical|theoretical)+ #Noun? #Actor`,
			tag: "Actor",
			reason: "fine-artist"
		},
		{
			match: `#Noun+ (coach|chef|king|engineer|fellow|personality|boy|girl|man|woman|master)`,
			tag: "Actor",
			reason: "dance-coach"
		},
		{
			match: `chief . officer`,
			tag: "Actor",
			reason: "chief-x-officer"
		},
		{
			match: `chief of #Noun+`,
			tag: "Actor",
			reason: "chief-of-police"
		},
		{
			match: `senior? vice? president of #Noun+`,
			tag: "Actor",
			reason: "president-of"
		},
		{
			match: "#Determiner [sun]",
			group: 0,
			tag: "Singular",
			reason: "the-sun"
		},
		{
			match: "#Verb (a|an) [#Value]$",
			group: 0,
			tag: "Singular",
			reason: "did-a-value"
		},
		{
			match: "the [(can|will|may)]",
			group: 0,
			tag: "Singular",
			reason: "the can"
		},
		{
			match: "#FirstName #Acronym? (#Possessive && #LastName)",
			tag: "Possessive",
			reason: "name-poss"
		},
		{
			match: "#Organization+ #Possessive",
			tag: "Possessive",
			reason: "org-possessive"
		},
		{
			match: "#Place+ #Possessive",
			tag: "Possessive",
			reason: "place-possessive"
		},
		{
			match: "#Possessive #PresentTense #Particle?",
			notIf: "(#Gerund|her)",
			tag: "Noun",
			reason: "possessive-verb"
		},
		{
			match: "(my|our|their|her|his|its) [(#Plural && #Actor)] #Noun",
			tag: "Possessive",
			reason: "my-dads"
		},
		{
			match: "#Value of a [second]",
			group: 0,
			unTag: "Value",
			tag: "Singular",
			reason: "10th-of-a-second"
		},
		{
			match: "#Value [seconds]",
			group: 0,
			unTag: "Value",
			tag: "Plural",
			reason: "10-seconds"
		},
		{
			match: "in [#Infinitive]",
			group: 0,
			tag: "Singular",
			reason: "in-age"
		},
		{
			match: "a [#Adjective] #Preposition",
			group: 0,
			tag: "Noun",
			reason: "a-minor-in"
		},
		{
			match: "#Determiner [#Singular] said",
			group: 0,
			tag: "Actor",
			reason: "the-actor-said"
		},
		{
			match: `#Determiner #Noun [(feel|sense|process|rush|side|bomb|bully|challenge|cover|crush|dump|exchange|flow|function|issue|lecture|limit|march|process)] !(#Preposition|to|#Adverb)?`,
			group: 0,
			tag: "Noun",
			reason: "the-noun-sense"
		},
		{
			match: "[#PresentTense] (of|by|for) (a|an|the) #Noun #Copula",
			group: 0,
			tag: "Plural",
			reason: "photographs-of"
		},
		{
			match: "#Infinitive and [%Noun|Verb%]",
			group: 0,
			tag: "Infinitive",
			reason: "fight and win"
		},
		{
			match: "#Noun and [#Verb] and #Noun",
			group: 0,
			tag: "Noun",
			reason: "peace-and-flowers"
		},
		{
			match: "the #Cardinal [%Adj|Noun%]",
			group: 0,
			tag: "Noun",
			reason: "the-1992-classic"
		},
		{
			match: "#Copula the [%Adj|Noun%] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "the-premier-university"
		},
		{
			match: "i #Verb [me] #Noun",
			group: 0,
			tag: "Possessive",
			reason: "scottish-me"
		},
		{
			match: "[#PresentTense] (music|class|lesson|night|party|festival|league|ceremony)",
			group: 0,
			tag: "Noun",
			reason: "dance-music"
		},
		{
			match: "[wit] (me|it)",
			group: 0,
			tag: "Presposition",
			reason: "wit-me"
		},
		{
			match: "#PastTense #Possessive [#Verb]",
			group: 0,
			tag: "Noun",
			notIf: "(saw|made)",
			reason: "left-her-boots"
		},
		{
			match: "#Value [%Plural|Verb%]",
			group: 0,
			tag: "Plural",
			notIf: "(one|1|a|an)",
			reason: "35-signs"
		},
		{
			match: "had [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "(#Gerund|come|become)",
			reason: "had-time"
		},
		{
			match: "%Adj|Noun% %Noun|Verb%",
			tag: "#Adjective #Noun",
			notIf: "#ProperNoun #Noun",
			reason: "instant-access"
		},
		{
			match: "#Determiner [%Adj|Noun%] #Conjunction",
			group: 0,
			tag: "Noun",
			reason: "a-rep-to"
		},
		{
			match: "#Adjective #Noun [%Plural|Verb%]$",
			group: 0,
			tag: "Plural",
			notIf: "#Pronoun",
			reason: "near-death-experiences"
		},
		{
			match: "#Possessive #Noun [%Plural|Verb%]$",
			group: 0,
			tag: "Plural",
			reason: "your-guild-colors"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/noun-gerund.js
	var noun_gerund_default = [
		{
			match: "(this|that|the|a|an) [#Gerund #Infinitive]",
			group: 0,
			tag: "Singular",
			reason: "the-planning-process"
		},
		{
			match: "(that|the) [#Gerund #PresentTense]",
			group: 0,
			ifNo: "#Copula",
			tag: "Plural",
			reason: "the-paving-stones"
		},
		{
			match: "#Determiner [#Gerund] #Noun",
			group: 0,
			tag: "Adjective",
			reason: "the-gerund-noun"
		},
		{
			match: `#Pronoun #Infinitive [#Gerund] #PresentTense`,
			group: 0,
			tag: "Noun",
			reason: "tipping-sucks"
		},
		{
			match: "#Adjective [#Gerund]",
			group: 0,
			tag: "Noun",
			notIf: "(still|even|just)",
			reason: "early-warning"
		},
		{
			match: "[#Gerund] #Adverb? not? #Copula",
			group: 0,
			tag: "Activity",
			reason: "gerund-copula"
		},
		{
			match: "#Copula [(#Gerund|#Activity)] #Copula",
			group: 0,
			tag: "Gerund",
			reason: "are-doing-is"
		},
		{
			match: "[#Gerund] #Modal",
			group: 0,
			tag: "Activity",
			reason: "gerund-modal"
		},
		{
			match: "#Singular for [%Noun|Gerund%]",
			group: 0,
			tag: "Gerund",
			reason: "noun-for-gerund"
		},
		{
			match: "#Comparative (for|at) [%Noun|Gerund%]",
			group: 0,
			tag: "Gerund",
			reason: "better-for-gerund"
		},
		{
			match: "#PresentTense the [#Gerund]",
			group: 0,
			tag: "Noun",
			reason: "keep-the-touching"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/verb-noun.js
	var verb_noun_default = [
		{
			match: "#Infinitive (this|that|the) [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "do-this-dance"
		},
		{
			match: "#Gerund #Determiner [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "running-a-show"
		},
		{
			match: "#Determiner (only|further|just|more|backward) [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "the-only-reason"
		},
		{
			match: "(the|this|a|an) [#Infinitive] #Adverb? #Verb",
			group: 0,
			tag: "Noun",
			reason: "determiner5"
		},
		{
			match: "#Determiner #Adjective #Adjective? [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "a-nice-inf"
		},
		{
			match: "#Determiner #Demonym [#PresentTense]",
			group: 0,
			tag: "Noun",
			reason: "mexican-train"
		},
		{
			match: "#Adjective #Noun+ [#Infinitive] #Copula",
			group: 0,
			tag: "Noun",
			reason: "career-move"
		},
		{
			match: "at some [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "at-some-inf"
		},
		{
			match: "(go|goes|went) to [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "goes-to-verb"
		},
		{
			match: "(a|an) #Adjective? #Noun [#Infinitive] (#Preposition|#Noun)",
			group: 0,
			notIf: "from",
			tag: "Noun",
			reason: "a-noun-inf"
		},
		{
			match: "(a|an) #Noun [#Infinitive]$",
			group: 0,
			tag: "Noun",
			reason: "a-noun-inf2"
		},
		{
			match: "#Gerund #Adjective? for [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "running-for"
		},
		{
			match: "about [#Infinitive]",
			group: 0,
			tag: "Singular",
			reason: "about-love"
		},
		{
			match: "#Plural on [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "on-stage"
		},
		{
			match: "any [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "any-charge"
		},
		{
			match: "no [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "no-doubt"
		},
		{
			match: "number of [#PresentTense]",
			group: 0,
			tag: "Noun",
			reason: "number-of-x"
		},
		{
			match: "(taught|teaches|learns|learned) [#PresentTense]",
			group: 0,
			tag: "Noun",
			reason: "teaches-x"
		},
		{
			match: "(try|use|attempt|build|make) [#Verb #Particle?]",
			notIf: "(#Copula|#Noun|sure|fun|up)",
			group: 0,
			tag: "Noun",
			reason: "do-verb"
		},
		{
			match: "^[#Infinitive] (is|was)",
			group: 0,
			tag: "Noun",
			reason: "checkmate-is"
		},
		{
			match: "#Infinitive much [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "get-much"
		},
		{
			match: "[cause] #Pronoun #Verb",
			group: 0,
			tag: "Conjunction",
			reason: "cause-cuz"
		},
		{
			match: "the #Singular [#Infinitive] #Noun",
			group: 0,
			tag: "Noun",
			notIf: "#Pronoun",
			reason: "cardio-dance"
		},
		{
			match: "#Determiner #Modal [#Noun]",
			group: 0,
			tag: "PresentTense",
			reason: "should-smoke"
		},
		{
			match: "this [#Plural]",
			group: 0,
			tag: "PresentTense",
			notIf: "(#Preposition|#Date)",
			reason: "this-verbs"
		},
		{
			match: "#Noun that [#Plural]",
			group: 0,
			tag: "PresentTense",
			notIf: "(#Preposition|#Pronoun|way)",
			reason: "voice-that-rocks"
		},
		{
			match: "that [#Plural] to",
			group: 0,
			tag: "PresentTense",
			notIf: "#Preposition",
			reason: "that-leads-to"
		},
		{
			match: "(let|make|made) (him|her|it|#Person|#Place|#Organization)+ [#Singular] (a|an|the|it)",
			group: 0,
			tag: "Infinitive",
			reason: "let-him-glue"
		},
		{
			match: "#Verb (all|every|each|most|some|no) [#PresentTense]",
			notIf: "#Modal",
			group: 0,
			tag: "Noun",
			reason: "all-presentTense"
		},
		{
			match: "(had|have|#PastTense) #Adjective [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "better",
			reason: "adj-presentTense"
		},
		{
			match: "#Value #Adjective [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "one-big-reason"
		},
		{
			match: "#PastTense #Adjective+ [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "(#Copula|better)",
			reason: "won-wide-support"
		},
		{
			match: "(many|few|several|couple) [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "many-poses"
		},
		{
			match: "#Determiner #Adverb #Adjective [%Noun|Verb%]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "very-big-dream"
		},
		{
			match: "from #Noun to [%Noun|Verb%]",
			group: 0,
			tag: "Noun",
			reason: "start-to-finish"
		},
		{
			match: "(for|with|of) #Noun (and|or|not) [%Noun|Verb%]",
			group: 0,
			tag: "Noun",
			notIf: "#Pronoun",
			reason: "for-food-and-gas"
		},
		{
			match: "#Adjective #Adjective [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "adorable-little-store"
		},
		{
			match: "#Gerund #Adverb? #Comparative [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "higher-costs"
		},
		{
			match: "(#Noun && @hasComma) #Noun (and|or) [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "noun-list"
		},
		{
			match: "(many|any|some|several) [#PresentTense] for",
			group: 0,
			tag: "Noun",
			reason: "any-verbs-for"
		},
		{
			match: `to #PresentTense #Noun [#PresentTense] #Preposition`,
			group: 0,
			tag: "Noun",
			reason: "gas-exchange"
		},
		{
			match: `#PastTense (until|as|through|without) [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "waited-until-release"
		},
		{
			match: `#Gerund like #Adjective? [#PresentTense]`,
			group: 0,
			tag: "Plural",
			reason: "like-hot-cakes"
		},
		{
			match: `some #Adjective [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "some-reason"
		},
		{
			match: `for some [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "for-some-reason"
		},
		{
			match: `(same|some|the|that|a) kind of [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "some-kind-of"
		},
		{
			match: `(same|some|the|that|a) type of [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "some-type-of"
		},
		{
			match: `#Gerund #Adjective #Preposition [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "doing-better-for-x"
		},
		{
			match: `(get|got|have) #Comparative [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "got-better-aim"
		},
		{
			match: "whose [#PresentTense] #Copula",
			group: 0,
			tag: "Noun",
			reason: "whos-name-was"
		},
		{
			match: `#PhrasalVerb #Particle #Preposition [#PresentTense]`,
			group: 0,
			tag: "Noun",
			reason: "given-up-on-x"
		},
		{
			match: "there (are|were) #Adjective? [#PresentTense]",
			group: 0,
			tag: "Plural",
			reason: "there-are"
		},
		{
			match: "#Value [#PresentTense] of",
			group: 0,
			notIf: "(one|1|#Copula|#Infinitive)",
			tag: "Plural",
			reason: "2-trains"
		},
		{
			match: "[#PresentTense] (are|were) #Adjective",
			group: 0,
			tag: "Plural",
			reason: "compromises-are-possible"
		},
		{
			match: "^[(hope|guess|thought|think)] #Pronoun #Verb",
			group: 0,
			tag: "Infinitive",
			reason: "suppose-i"
		},
		{
			match: "#Possessive #Adjective [#Verb]",
			group: 0,
			tag: "Noun",
			notIf: "#Copula",
			reason: "our-full-support"
		},
		{
			match: "[(tastes|smells)] #Adverb? #Adjective",
			group: 0,
			tag: "PresentTense",
			reason: "tastes-good"
		},
		{
			match: "#Copula #Gerund [#PresentTense] !by?",
			group: 0,
			tag: "Noun",
			notIf: "going",
			reason: "ignoring-commute"
		},
		{
			match: "#Determiner #Adjective? [(shed|thought|rose|bid|saw|spelt)]",
			group: 0,
			tag: "Noun",
			reason: "noun-past"
		},
		{
			match: "how to [%Noun|Verb%]",
			group: 0,
			tag: "Infinitive",
			reason: "how-to-noun"
		},
		{
			match: "which [%Noun|Verb%] #Noun",
			group: 0,
			tag: "Infinitive",
			reason: "which-boost-it"
		},
		{
			match: "#Gerund [%Plural|Verb%]",
			group: 0,
			tag: "Plural",
			reason: "asking-questions"
		},
		{
			match: "(ready|available|difficult|hard|easy|made|attempt|try) to [%Noun|Verb%]",
			group: 0,
			tag: "Infinitive",
			reason: "ready-to-noun"
		},
		{
			match: "(bring|went|go|drive|run|bike) to [%Noun|Verb%]",
			group: 0,
			tag: "Noun",
			reason: "bring-to-noun"
		},
		{
			match: "#Modal #Noun [%Noun|Verb%]",
			group: 0,
			tag: "Infinitive",
			reason: "would-you-look"
		},
		{
			match: "#Copula just [#Infinitive]",
			group: 0,
			tag: "Noun",
			reason: "is-just-spam"
		},
		{
			match: "^%Noun|Verb% %Plural|Verb%",
			tag: "Imperative #Plural",
			reason: "request-copies"
		},
		{
			match: "#Adjective #Plural and [%Plural|Verb%]",
			group: 0,
			tag: "#Plural",
			reason: "pickles-and-drinks"
		},
		{
			match: "#Determiner #Year [#Verb]",
			group: 0,
			tag: "Noun",
			reason: "the-1968-film"
		},
		{
			match: "#Determiner [#PhrasalVerb #Particle]",
			group: 0,
			tag: "Noun",
			reason: "the-break-up"
		},
		{
			match: "#Determiner [%Adj|Noun%] #Noun",
			group: 0,
			tag: "Adjective",
			notIf: "(#Pronoun|#Possessive|#ProperNoun)",
			reason: "the-individual-goals"
		},
		{
			match: "[%Noun|Verb%] or #Infinitive",
			group: 0,
			tag: "Infinitive",
			reason: "work-or-prepare"
		},
		{
			match: "to #Infinitive [#PresentTense]",
			group: 0,
			tag: "Noun",
			notIf: "(#Gerund|#Copula|help)",
			reason: "to-give-thanks"
		},
		{
			match: "[#Noun] me",
			group: 0,
			tag: "Verb",
			reason: "kills-me"
		},
		{
			match: "%Plural|Verb% %Plural|Verb%",
			tag: "#PresentTense #Plural",
			reason: "removes-wrinkles"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/numbers/money.js
	var money_default = [
		{
			match: "#Money and #Money #Currency?",
			tag: "Money",
			reason: "money-and-money"
		},
		{
			match: "#Value #Currency [and] #Value (cents|ore|centavos|sens)",
			group: 0,
			tag: "money",
			reason: "and-5-cents"
		},
		{
			match: "#Value (mark|rand|won|rub|ore)",
			tag: "#Money #Currency",
			reason: "4-mark"
		},
		{
			match: "a pound",
			tag: "#Money #Unit",
			reason: "a-pound"
		},
		{
			match: "#Value (pound|pounds)",
			tag: "#Money #Unit",
			reason: "4-pounds"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/numbers/fractions.js
	var fractions_default = [
		{
			match: "[(half|quarter)] of? (a|an)",
			group: 0,
			tag: "Fraction",
			reason: "millionth"
		},
		{
			match: "#Adverb [half]",
			group: 0,
			tag: "Fraction",
			reason: "nearly-half"
		},
		{
			match: "[half] the",
			group: 0,
			tag: "Fraction",
			reason: "half-the"
		},
		{
			match: "#Cardinal and a half",
			tag: "Fraction",
			reason: "and-a-half"
		},
		{
			match: "#Value (halves|halfs|quarters)",
			tag: "Fraction",
			reason: "two-halves"
		},
		{
			match: "a #Ordinal",
			tag: "Fraction",
			reason: "a-quarter"
		},
		{
			match: "[#Cardinal+] (#Fraction && /s$/)",
			tag: "Fraction",
			reason: "seven-fifths"
		},
		{
			match: "[#Cardinal+ #Ordinal] of .",
			group: 0,
			tag: "Fraction",
			reason: "ordinal-of"
		},
		{
			match: "[(#NumericValue && #Ordinal)] of .",
			group: 0,
			tag: "Fraction",
			reason: "num-ordinal-of"
		},
		{
			match: "(a|one) #Cardinal?+ #Ordinal",
			tag: "Fraction",
			reason: "a-ordinal"
		},
		{
			match: "#Cardinal+ out? of every? #Cardinal",
			tag: "Fraction",
			reason: "out-of"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/numbers/numbers.js
	var numbers_default = [
		{
			match: `#Cardinal [second]`,
			tag: "Unit",
			reason: "one-second"
		},
		{
			match: "!once? [(a|an)] (#Duration|hundred|thousand|million|billion|trillion)",
			group: 0,
			tag: "Value",
			reason: "a-is-one"
		},
		{
			match: "1 #Value #PhoneNumber",
			tag: "PhoneNumber",
			reason: "1-800-Value"
		},
		{
			match: "#NumericValue #PhoneNumber",
			tag: "PhoneNumber",
			reason: "(800) PhoneNumber"
		},
		{
			match: "#Demonym #Currency",
			tag: "Currency",
			reason: "demonym-currency"
		},
		{
			match: "#Value [(buck|bucks|grand)]",
			group: 0,
			tag: "Currency",
			reason: "value-bucks"
		},
		{
			match: "[#Value+] #Currency",
			group: 0,
			tag: "Money",
			reason: "15 usd"
		},
		{
			match: "[second] #Noun",
			group: 0,
			tag: "Ordinal",
			reason: "second-noun"
		},
		{
			match: "#Value+ [#Currency]",
			group: 0,
			tag: "Unit",
			reason: "5-yan"
		},
		{
			match: "#Value [(foot|feet)]",
			group: 0,
			tag: "Unit",
			reason: "foot-unit"
		},
		{
			match: "#Value [#Abbreviation]",
			group: 0,
			tag: "Unit",
			reason: "value-abbr"
		},
		{
			match: "#Value [k]",
			group: 0,
			tag: "Unit",
			reason: "value-k"
		},
		{
			match: "#Unit an hour",
			tag: "Unit",
			reason: "unit-an-hour"
		},
		{
			match: "(minus|negative) #Value",
			tag: "Value",
			reason: "minus-value"
		},
		{
			match: "#Value (point|decimal) #Value",
			tag: "Value",
			reason: "value-point-value"
		},
		{
			match: "#Determiner [(half|quarter)] #Ordinal",
			group: 0,
			tag: "Value",
			reason: "half-ordinal"
		},
		{
			match: `#Multiple+ and #Value`,
			tag: "Value",
			reason: "magnitude-and-value"
		},
		{
			match: "#Value #Unit [(per|an) (hr|hour|sec|second|min|minute)]",
			group: 0,
			tag: "Unit",
			reason: "12-miles-per-second"
		},
		{
			match: "#Value [(square|cubic)] #Unit",
			group: 0,
			tag: "Unit",
			reason: "square-miles"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/person/person-phrase.js
	var person_phrase_default = [
		{
			match: "#Copula [(#Noun|#PresentTense)] #LastName",
			group: 0,
			tag: "FirstName",
			reason: "copula-noun-lastname"
		},
		{
			match: "(sister|pope|brother|father|aunt|uncle|grandpa|grandfather|grandma) #ProperNoun",
			tag: "Person",
			reason: "lady-titlecase",
			safe: true
		},
		{
			match: "#FirstName [#Determiner #Noun] #LastName",
			group: 0,
			tag: "Person",
			reason: "first-noun-last"
		},
		{
			match: "#ProperNoun (b|c|d|e|f|g|h|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z) #ProperNoun",
			tag: "Person",
			reason: "titlecase-acronym-titlecase",
			safe: true
		},
		{
			match: "#Acronym #LastName",
			tag: "Person",
			reason: "acronym-lastname",
			safe: true
		},
		{
			match: "#Person (jr|sr|md)",
			tag: "Person",
			reason: "person-honorific"
		},
		{
			match: "#Honorific #Acronym",
			tag: "Person",
			reason: "Honorific-TitleCase"
		},
		{
			match: "#Person #Person the? #RomanNumeral",
			tag: "Person",
			reason: "roman-numeral"
		},
		{
			match: "#FirstName [/^[^aiurck]$/]",
			group: 0,
			tag: ["Acronym", "Person"],
			reason: "john-e"
		},
		{
			match: "#Noun van der? #Noun",
			tag: "Person",
			reason: "van der noun",
			safe: true
		},
		{
			match: "(king|queen|prince|saint|lady) of #Noun",
			tag: "Person",
			reason: "king-of-noun",
			safe: true
		},
		{
			match: "(prince|lady) #Place",
			tag: "Person",
			reason: "lady-place"
		},
		{
			match: "(king|queen|prince|saint) #ProperNoun",
			tag: "Person",
			notIf: "#Place",
			reason: "saint-foo"
		},
		{
			match: "al (#Person|#ProperNoun)",
			tag: "Person",
			reason: "al-borlen",
			safe: true
		},
		{
			match: "#FirstName de #Noun",
			tag: "Person",
			reason: "bill-de-noun"
		},
		{
			match: "#FirstName (bin|al) #Noun",
			tag: "Person",
			reason: "bill-al-noun"
		},
		{
			match: "#FirstName #Acronym #ProperNoun",
			tag: "Person",
			reason: "bill-acronym-title"
		},
		{
			match: "#FirstName #FirstName #ProperNoun",
			tag: "Person",
			reason: "bill-firstname-title"
		},
		{
			match: "#Honorific #FirstName? #ProperNoun",
			tag: "Person",
			reason: "dr-john-Title"
		},
		{
			match: "#FirstName the #Adjective",
			tag: "Person",
			reason: "name-the-great"
		},
		{
			match: "#ProperNoun (van|al|bin) #ProperNoun",
			tag: "Person",
			reason: "title-van-title",
			safe: true
		},
		{
			match: "#ProperNoun (de|du) la? #ProperNoun",
			tag: "Person",
			notIf: "#Place",
			reason: "title-de-title"
		},
		{
			match: "#Singular #Acronym #LastName",
			tag: "#FirstName #Person .",
			reason: "title-acro-noun",
			safe: true
		},
		{
			match: "[#ProperNoun] #Person",
			group: 0,
			tag: "Person",
			reason: "proper-person",
			safe: true
		},
		{
			match: "#Person [#ProperNoun #ProperNoun]",
			group: 0,
			tag: "Person",
			notIf: "#Possessive",
			reason: "three-name-person",
			safe: true
		},
		{
			match: "#FirstName #Acronym? [#ProperNoun]",
			group: 0,
			tag: "LastName",
			notIf: "#Possessive",
			reason: "firstname-titlecase"
		},
		{
			match: "#FirstName [#FirstName]",
			group: 0,
			tag: "LastName",
			reason: "firstname-firstname"
		},
		{
			match: "#FirstName #Acronym #Noun",
			tag: "Person",
			reason: "n-acro-noun",
			safe: true
		},
		{
			match: "#FirstName [(de|di|du|van|von)] #Person",
			group: 0,
			tag: "LastName",
			reason: "de-firstname"
		},
		{
			match: "[(lieutenant|corporal|sergeant|captain|qeen|king|admiral|major|colonel|marshal|president|queen|king)+] #ProperNoun",
			group: 0,
			tag: "Honorific",
			reason: "seargeant-john"
		},
		{
			match: "[(private|general|major|rear|prime|field|count|miss)] #Honorific? #Person",
			group: 0,
			tag: ["Honorific", "Person"],
			reason: "ambg-honorifics"
		},
		{
			match: "#Honorific #FirstName [#Singular]",
			group: 0,
			tag: "LastName",
			notIf: "#Possessive",
			reason: "dr-john-foo",
			safe: true
		},
		{
			match: "[(his|her) (majesty|honour|worship|excellency|honorable)] #Person",
			group: 0,
			tag: "Honorific",
			reason: "his-excellency"
		},
		{
			match: "#Honorific #Actor",
			tag: "Honorific",
			reason: "Lieutenant colonel"
		},
		{
			match: "(first|second|third|1st|2nd|3rd) #Actor",
			tag: "Honorific",
			reason: "first lady"
		},
		{
			match: "#Person #RomanNumeral",
			tag: "Person",
			reason: "louis-IV"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/person/ambig-name.js
	var ambig_name_default = [
		{
			match: "#FirstName #Noun$",
			tag: ". #LastName",
			notIf: "(#Possessive|#Organization|#Place|#Pronoun|@hasTitleCase)",
			reason: "firstname-noun"
		},
		{
			match: "%Person|Date% #Acronym? #ProperNoun",
			tag: "Person",
			reason: "jan-thierson"
		},
		{
			match: "%Person|Noun% #Acronym? #ProperNoun",
			tag: "Person",
			reason: "switch-person",
			safe: true
		},
		{
			match: "%Person|Noun% #Organization",
			tag: "Organization",
			reason: "olive-garden"
		},
		{
			match: "%Person|Verb% #Acronym? #ProperNoun",
			tag: "Person",
			reason: "verb-propernoun",
			ifNo: "#Actor"
		},
		{
			match: `[%Person|Verb%] (will|had|has|said|says|told|did|learned|wants|wanted)`,
			group: 0,
			tag: "Person",
			reason: "person-said"
		},
		{
			match: `[%Person|Place%] (harbor|harbour|pier|town|city|place|dump|landfill)`,
			group: 0,
			tag: "Place",
			reason: "sydney-harbour"
		},
		{
			match: `(west|east|north|south) [%Person|Place%]`,
			group: 0,
			tag: "Place",
			reason: "east-sydney"
		},
		{
			match: `#Modal [%Person|Verb%]`,
			group: 0,
			tag: "Verb",
			reason: "would-mark"
		},
		{
			match: `#Adverb [%Person|Verb%]`,
			group: 0,
			tag: "Verb",
			reason: "really-mark"
		},
		{
			match: `[%Person|Verb%] (#Adverb|#Comparative)`,
			group: 0,
			tag: "Verb",
			reason: "drew-closer"
		},
		{
			match: `%Person|Verb% #Person`,
			tag: "Person",
			reason: "rob-smith"
		},
		{
			match: `%Person|Verb% #Acronym #ProperNoun`,
			tag: "Person",
			reason: "rob-a-smith"
		},
		{
			match: "[will] #Verb",
			group: 0,
			tag: "Modal",
			reason: "will-verb"
		},
		{
			match: "(will && @isTitleCase) #ProperNoun",
			tag: "Person",
			reason: "will-name"
		},
		{
			match: "(#FirstName && !#Possessive) [#Singular] #Verb",
			group: 0,
			safe: true,
			tag: "LastName",
			reason: "jack-layton"
		},
		{
			match: "^[#Singular] #Person #Verb",
			group: 0,
			safe: true,
			tag: "Person",
			reason: "sherwood-anderson"
		},
		{
			match: "(a|an) [#Person]$",
			group: 0,
			unTag: "Person",
			reason: "a-warhol"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/verbs.js
	var verbs_default = [
		{
			match: "#Copula (pretty|dead|full|well|sure) (#Adjective|#Noun)",
			tag: "#Copula #Adverb #Adjective",
			reason: "sometimes-adverb"
		},
		{
			match: "(#Pronoun|#Person) (had|#Adverb)? [better] #PresentTense",
			group: 0,
			tag: "Modal",
			reason: "i-better"
		},
		{
			match: "(#Modal|i|they|we|do) not? [like]",
			group: 0,
			tag: "PresentTense",
			reason: "modal-like"
		},
		{
			match: "#Noun #Adverb? [left]",
			group: 0,
			tag: "PastTense",
			reason: "left-verb"
		},
		{
			match: "will #Adverb? not? #Adverb? [be] #Gerund",
			group: 0,
			tag: "Copula",
			reason: "will-be-copula"
		},
		{
			match: "will #Adverb? not? #Adverb? [be] #Adjective",
			group: 0,
			tag: "Copula",
			reason: "be-copula"
		},
		{
			match: "[march] (up|down|back|toward)",
			notIf: "#Date",
			group: 0,
			tag: "Infinitive",
			reason: "march-to"
		},
		{
			match: "#Modal [march]",
			group: 0,
			tag: "Infinitive",
			reason: "must-march"
		},
		{
			match: `[may] be`,
			group: 0,
			tag: "Verb",
			reason: "may-be"
		},
		{
			match: `[(subject|subjects|subjected)] to`,
			group: 0,
			tag: "Verb",
			reason: "subject to"
		},
		{
			match: `[home] to`,
			group: 0,
			tag: "PresentTense",
			reason: "home to"
		},
		{
			match: "[open] #Determiner",
			group: 0,
			tag: "Infinitive",
			reason: "open-the"
		},
		{
			match: `(were|was) being [#PresentTense]`,
			group: 0,
			tag: "PastTense",
			reason: "was-being"
		},
		{
			match: `(had|has|have) [been /en$/]`,
			group: 0,
			tag: "Auxiliary Participle",
			reason: "had-been-broken"
		},
		{
			match: `(had|has|have) [been /ed$/]`,
			group: 0,
			tag: "Auxiliary PastTense",
			reason: "had-been-smoked"
		},
		{
			match: `(had|has) #Adverb? [been] #Adverb? #PastTense`,
			group: 0,
			tag: "Auxiliary",
			reason: "had-been-adj"
		},
		{
			match: `(had|has) to [#Noun] (#Determiner|#Possessive)`,
			group: 0,
			tag: "Infinitive",
			reason: "had-to-noun"
		},
		{
			match: `have [#PresentTense]`,
			group: 0,
			tag: "PastTense",
			notIf: "(come|gotten)",
			reason: "have-read"
		},
		{
			match: `(does|will|#Modal) that [work]`,
			group: 0,
			tag: "PastTense",
			reason: "does-that-work"
		},
		{
			match: `[(sound|sounds)] #Adjective`,
			group: 0,
			tag: "PresentTense",
			reason: "sounds-fun"
		},
		{
			match: `[(look|looks)] #Adjective`,
			group: 0,
			tag: "PresentTense",
			reason: "looks-good"
		},
		{
			match: `[(start|starts|stop|stops|begin|begins)] #Gerund`,
			group: 0,
			tag: "Verb",
			reason: "starts-thinking"
		},
		{
			match: `(have|had) read`,
			tag: "Modal #PastTense",
			reason: "read-read"
		},
		{
			match: `(is|was|were) [(under|over) #PastTense]`,
			group: 0,
			tag: "Adverb Adjective",
			reason: "was-under-cooked"
		},
		{
			match: "[shit] (#Determiner|#Possessive|them)",
			group: 0,
			tag: "Verb",
			reason: "swear1-verb"
		},
		{
			match: "[damn] (#Determiner|#Possessive|them)",
			group: 0,
			tag: "Verb",
			reason: "swear2-verb"
		},
		{
			match: "[fuck] (#Determiner|#Possessive|them)",
			group: 0,
			tag: "Verb",
			reason: "swear3-verb"
		},
		{
			match: "#Plural that %Noun|Verb%",
			tag: ". #Preposition #Infinitive",
			reason: "jobs-that-work"
		},
		{
			match: "[works] for me",
			group: 0,
			tag: "PresentTense",
			reason: "works-for-me"
		},
		{
			match: "as #Pronoun [please]",
			group: 0,
			tag: "Infinitive",
			reason: "as-we-please"
		},
		{
			match: "[(co|mis|de|inter|intra|pre|re|un|out|under|over|counter)] #Verb",
			group: 0,
			tag: ["Verb", "Prefix"],
			notIf: "(#Copula|#PhrasalVerb)",
			reason: "co-write"
		},
		{
			match: "#PastTense and [%Adj|Past%]",
			group: 0,
			tag: "PastTense",
			reason: "dressed-and-left"
		},
		{
			match: "[%Adj|Past%] and #PastTense",
			group: 0,
			tag: "PastTense",
			reason: "dressed-and-left"
		},
		{
			match: "#Copula #Pronoun [%Adj|Past%]",
			group: 0,
			tag: "Adjective",
			reason: "is-he-stoked"
		},
		{
			match: "to [%Noun|Verb%] #Preposition",
			group: 0,
			tag: "Infinitive",
			reason: "to-dream-of"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/auxiliary.js
	var auxiliary_default = [
		{
			match: `will (#Adverb|not)+? [have] (#Adverb|not)+? #Verb`,
			group: 0,
			tag: "Auxiliary",
			reason: "will-have-vb"
		},
		{
			match: `[#Copula] (#Adverb|not)+? (#Gerund|#PastTense)`,
			group: 0,
			tag: "Auxiliary",
			reason: "copula-walking"
		},
		{
			match: `[(#Modal|did)+] (#Adverb|not)+? #Verb`,
			group: 0,
			tag: "Auxiliary",
			reason: "modal-verb"
		},
		{
			match: `#Modal (#Adverb|not)+? [have] (#Adverb|not)+? [had] (#Adverb|not)+? #Verb`,
			group: 0,
			tag: "Auxiliary",
			reason: "would-have"
		},
		{
			match: `[(has|had)] (#Adverb|not)+? #PastTense`,
			group: 0,
			tag: "Auxiliary",
			reason: "had-walked"
		},
		{
			match: "[(do|does|did|will|have|had|has|got)] (not|#Adverb)+? #Verb",
			group: 0,
			tag: "Auxiliary",
			reason: "have-had"
		},
		{
			match: "[about to] #Adverb? #Verb",
			group: 0,
			tag: ["Auxiliary", "Verb"],
			reason: "about-to"
		},
		{
			match: `#Modal (#Adverb|not)+? [be] (#Adverb|not)+? #Verb`,
			group: 0,
			tag: "Auxiliary",
			reason: "would-be"
		},
		{
			match: `[(#Modal|had|has)] (#Adverb|not)+? [been] (#Adverb|not)+? #Verb`,
			group: 0,
			tag: "Auxiliary",
			reason: "had-been"
		},
		{
			match: "[(be|being|been)] #Participle",
			group: 0,
			tag: "Auxiliary",
			reason: "being-driven"
		},
		{
			match: "[may] #Adverb? #Infinitive",
			group: 0,
			tag: "Auxiliary",
			reason: "may-want"
		},
		{
			match: "#Copula (#Adverb|not)+? [(be|being|been)] #Adverb+? #PastTense",
			group: 0,
			tag: "Auxiliary",
			reason: "being-walked"
		},
		{
			match: "will [be] #PastTense",
			group: 0,
			tag: "Auxiliary",
			reason: "will-be-x"
		},
		{
			match: "[(be|been)] (#Adverb|not)+? #Gerund",
			group: 0,
			tag: "Auxiliary",
			reason: "been-walking"
		},
		{
			match: "[used to] #PresentTense",
			group: 0,
			tag: "Auxiliary",
			reason: "used-to-walk"
		},
		{
			match: "#Copula (#Adverb|not)+? [going to] #Adverb+? #PresentTense",
			group: 0,
			tag: "Auxiliary",
			reason: "going-to-walk"
		},
		{
			match: "#Imperative [(me|him|her)]",
			group: 0,
			tag: "Reflexive",
			reason: "tell-him"
		},
		{
			match: "(is|was) #Adverb? [no]",
			group: 0,
			tag: "Negative",
			reason: "is-no"
		},
		{
			match: "[(been|had|became|came)] #PastTense",
			group: 0,
			notIf: "#PhrasalVerb",
			tag: "Auxiliary",
			reason: "been-told"
		},
		{
			match: "[(being|having|getting)] #Verb",
			group: 0,
			tag: "Auxiliary",
			reason: "being-born"
		},
		{
			match: "[be] #Gerund",
			group: 0,
			tag: "Auxiliary",
			reason: "be-walking"
		},
		{
			match: "[better] #PresentTense",
			group: 0,
			tag: "Modal",
			notIf: "(#Copula|#Gerund)",
			reason: "better-go"
		},
		{
			match: "even better",
			tag: "Adverb #Comparative",
			reason: "even-better"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/phrasal.js
	var phrasal_default = [
		{
			match: "(#Verb && @hasHyphen) up",
			tag: "PhrasalVerb",
			reason: "foo-up"
		},
		{
			match: "(#Verb && @hasHyphen) off",
			tag: "PhrasalVerb",
			reason: "foo-off"
		},
		{
			match: "(#Verb && @hasHyphen) over",
			tag: "PhrasalVerb",
			reason: "foo-over"
		},
		{
			match: "(#Verb && @hasHyphen) out",
			tag: "PhrasalVerb",
			reason: "foo-out"
		},
		{
			match: "[#Verb (in|out|up|down|off|back)] (on|in)",
			notIf: "#Copula",
			tag: "PhrasalVerb Particle",
			reason: "walk-in-on"
		},
		{
			match: "(lived|went|crept|go) [on] for",
			group: 0,
			tag: "PhrasalVerb",
			reason: "went-on"
		},
		{
			match: "#Verb (up|down|in|on|for)$",
			tag: "PhrasalVerb #Particle",
			notIf: "#PhrasalVerb",
			reason: "come-down$"
		},
		{
			match: "help [(stop|end|make|start)]",
			group: 0,
			tag: "Infinitive",
			reason: "help-stop"
		},
		{
			match: "#PhrasalVerb (in && #Particle) #Determiner",
			tag: "#Verb #Preposition #Determiner",
			unTag: "PhrasalVerb",
			reason: "work-in-the"
		},
		{
			match: "[(stop|start|finish|help)] #Gerund",
			group: 0,
			tag: "Infinitive",
			reason: "start-listening"
		},
		{
			match: "#Verb (him|her|it|us|himself|herself|itself|everything|something) [(up|down)]",
			group: 0,
			tag: "Adverb",
			reason: "phrasal-pronoun-advb"
		}
	];
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/model/verbs/imperative.js
	var notIf = "(i|we|they)";
	var imperative_default = [
		{
			match: "^do not? [#Infinitive #Particle?]",
			notIf,
			group: 0,
			tag: "Imperative",
			reason: "do-eat"
		},
		{
			match: "^please do? not? [#Infinitive #Particle?]",
			group: 0,
			tag: "Imperative",
			reason: "please-go"
		},
		{
			match: "^just do? not? [#Infinitive #Particle?]",
			group: 0,
			tag: "Imperative",
			reason: "just-go"
		},
		{
			match: "^[#Infinitive] it #Comparative",
			notIf,
			group: 0,
			tag: "Imperative",
			reason: "do-it-better"
		},
		{
			match: "^[#Infinitive] it (please|now|again|plz)",
			notIf,
			group: 0,
			tag: "Imperative",
			reason: "do-it-please"
		},
		{
			match: "^[#Infinitive] (#Adjective|#Adverb)$",
			group: 0,
			tag: "Imperative",
			notIf: "(so|such|rather|enough)",
			reason: "go-quickly"
		},
		{
			match: "^[#Infinitive] (up|down|over) #Determiner",
			group: 0,
			tag: "Imperative",
			reason: "turn-down"
		},
		{
			match: "^[#Infinitive] (your|my|the|a|an|any|each|every|some|more|with|on)",
			group: 0,
			notIf: "like",
			tag: "Imperative",
			reason: "eat-my-shorts"
		},
		{
			match: "^[#Infinitive] (him|her|it|us|me|there)",
			group: 0,
			tag: "Imperative",
			reason: "tell-him"
		},
		{
			match: "^[#Infinitive] #Adjective #Noun$",
			group: 0,
			tag: "Imperative",
			reason: "avoid-loud-noises"
		},
		{
			match: "^[#Infinitive] (#Adjective|#Adverb)? and #Infinitive",
			group: 0,
			tag: "Imperative",
			reason: "call-and-reserve"
		},
		{
			match: "^(go|stop|wait|hurry) please?$",
			tag: "Imperative",
			reason: "go"
		},
		{
			match: "^(somebody|everybody) [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "somebody-call"
		},
		{
			match: "^let (us|me) [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "lets-leave"
		},
		{
			match: "^[(shut|close|open|start|stop|end|keep)] #Determiner #Noun",
			group: 0,
			tag: "Imperative",
			reason: "shut-the-door"
		},
		{
			match: "^[#PhrasalVerb #Particle] #Determiner #Noun",
			group: 0,
			tag: "Imperative",
			reason: "turn-off-the-light"
		},
		{
			match: "^[go] to .",
			group: 0,
			tag: "Imperative",
			reason: "go-to-toronto"
		},
		{
			match: "^#Modal you [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "would-you-"
		},
		{
			match: "^never [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "never-stop"
		},
		{
			match: "^come #Infinitive",
			tag: "Imperative",
			notIf: "on",
			reason: "come-have"
		},
		{
			match: "^come and? #Infinitive",
			tag: "Imperative . Imperative",
			notIf: "#PhrasalVerb",
			reason: "come-and-have"
		},
		{
			match: "^stay (out|away|back)",
			tag: "Imperative",
			reason: "stay-away"
		},
		{
			match: "^[(stay|be|keep)] #Adjective",
			group: 0,
			tag: "Imperative",
			reason: "stay-cool"
		},
		{
			match: "^[keep it] #Adjective",
			group: 0,
			tag: "Imperative",
			reason: "keep-it-cool"
		},
		{
			match: "^do not [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "do-not-be"
		},
		{
			match: "[#Infinitive] (yourself|yourselves)",
			group: 0,
			tag: "Imperative",
			reason: "allow-yourself"
		},
		{
			match: "[#Infinitive] what .",
			group: 0,
			tag: "Imperative",
			reason: "look-what"
		},
		{
			match: "^[#Infinitive] #Gerund",
			group: 0,
			tag: "Imperative",
			reason: "keep-playing"
		},
		{
			match: "^[#Infinitive] (to|for|into|toward|here|there)",
			group: 0,
			tag: "Imperative",
			reason: "go-to"
		},
		{
			match: "^[#Infinitive] (and|or) #Infinitive",
			group: 0,
			tag: "Imperative",
			reason: "inf-and-inf"
		},
		{
			match: "^[%Noun|Verb%] to",
			group: 0,
			tag: "Imperative",
			reason: "commit-to"
		},
		{
			match: "^[#Infinitive] #Adjective? #Singular #Singular",
			group: 0,
			tag: "Imperative",
			reason: "maintain-eye-contact"
		},
		{
			match: "do not (forget|omit|neglect) to [#Infinitive]",
			group: 0,
			tag: "Imperative",
			reason: "do-not-forget"
		},
		{
			match: "^[(ask|wear|pay|look|help|show|watch|act|fix|kill|stop|start|turn|try|win)] #Noun",
			group: 0,
			tag: "Imperative",
			reason: "pay-attention"
		}
	];
	var model_default = { two: { matches: [].concat([
		{
			match: "(got|were|was|is|are|am) (#PastTense|#Participle)",
			tag: "Passive",
			reason: "got-walked"
		},
		{
			match: "(was|were|is|are|am) being (#PastTense|#Participle)",
			tag: "Passive",
			reason: "was-being"
		},
		{
			match: "(had|have|has) been (#PastTense|#Participle)",
			tag: "Passive",
			reason: "had-been"
		},
		{
			match: "will be being? (#PastTense|#Participle)",
			tag: "Passive",
			reason: "will-be-cleaned"
		},
		{
			match: "#Noun [(#PastTense|#Participle)] by (the|a) #Noun",
			group: 0,
			tag: "Passive",
			reason: "suffered-by"
		}
	], adjective_default, adj_adverb_default, adj_gerund_default$1, adj_noun_default, adverb_default, date_default, date_phrase_default, nouns_default, noun_gerund_default, verb_noun_default, money_default, fractions_default, numbers_default, person_phrase_default, ambig_name_default, verbs_default, adj_verb_default, auxiliary_default, phrasal_default, imperative_default, [{
		match: "(that|which) were [%Adj|Gerund%]",
		group: 0,
		tag: "Gerund",
		reason: "that-were-growing"
	}, {
		match: "#Gerund [#Gerund] #Plural",
		group: 0,
		tag: "Adjective",
		reason: "hard-working-fam"
	}], [
		{
			match: "u r",
			tag: "#Pronoun #Copula",
			reason: "u r"
		},
		{
			match: "#Noun [(who|whom)]",
			group: 0,
			tag: "Determiner",
			reason: "captain-who"
		},
		{
			match: "[had] #Noun+ #PastTense",
			group: 0,
			tag: "Condition",
			reason: "had-he"
		},
		{
			match: "[were] #Noun+ to #Infinitive",
			group: 0,
			tag: "Condition",
			reason: "were-he"
		},
		{
			match: "some sort of",
			tag: "Adjective Noun Conjunction",
			reason: "some-sort-of"
		},
		{
			match: "of some sort",
			tag: "Conjunction Adjective Noun",
			reason: "of-some-sort"
		},
		{
			match: "[such] (a|an|is)? #Noun",
			group: 0,
			tag: "Determiner",
			reason: "such-skill"
		},
		{
			match: "[right] (before|after|in|into|to|toward)",
			group: 0,
			tag: "#Adverb",
			reason: "right-into"
		},
		{
			match: "#Preposition [about]",
			group: 0,
			tag: "Adjective",
			reason: "at-about"
		},
		{
			match: "(are|#Modal|see|do|for) [ya]",
			group: 0,
			tag: "Pronoun",
			reason: "are-ya"
		},
		{
			match: "[long live] .",
			group: 0,
			tag: "#Adjective #Infinitive",
			reason: "long-live"
		},
		{
			match: "[plenty] of",
			group: 0,
			tag: "#Uncountable",
			reason: "plenty-of"
		},
		{
			match: "(always|nearly|barely|practically) [there]",
			group: 0,
			tag: "Adjective",
			reason: "always-there"
		},
		{
			match: "[there] (#Adverb|#Pronoun)? #Copula",
			group: 0,
			tag: "There",
			reason: "there-is"
		},
		{
			match: "#Copula [there] .",
			group: 0,
			tag: "There",
			reason: "is-there"
		},
		{
			match: "#Modal #Adverb? [there]",
			group: 0,
			tag: "There",
			reason: "should-there"
		},
		{
			match: "^[do] (you|we|they)",
			group: 0,
			tag: "QuestionWord",
			reason: "do-you"
		},
		{
			match: "^[does] (he|she|it|#ProperNoun)",
			group: 0,
			tag: "QuestionWord",
			reason: "does-he"
		},
		{
			match: "#Determiner #Noun+ [who] #Verb",
			group: 0,
			tag: "Preposition",
			reason: "the-x-who"
		},
		{
			match: "#Determiner #Noun+ [which] #Verb",
			group: 0,
			tag: "Preposition",
			reason: "the-x-which"
		},
		{
			match: "a [while]",
			group: 0,
			tag: "Noun",
			reason: "a-while"
		},
		{
			match: "guess who",
			tag: "#Infinitive #QuestionWord",
			reason: "guess-who"
		},
		{
			match: "[fucking] !#Verb",
			group: 0,
			tag: "#Gerund",
			reason: "f-as-gerund"
		}
	], [
		{
			match: "university of #Place",
			tag: "Organization",
			reason: "university-of-Foo"
		},
		{
			match: "#Noun (&|n) #Noun",
			tag: "Organization",
			reason: "Noun-&-Noun"
		},
		{
			match: "#Organization of the? #ProperNoun",
			tag: "Organization",
			reason: "org-of-place",
			safe: true
		},
		{
			match: "#Organization #Country",
			tag: "Organization",
			reason: "org-country"
		},
		{
			match: "#ProperNoun #Organization",
			tag: "Organization",
			notIf: "#FirstName",
			reason: "titlecase-org"
		},
		{
			match: "#ProperNoun (ltd|co|inc|dept|assn|bros)",
			tag: "Organization",
			reason: "org-abbrv"
		},
		{
			match: "the [#Acronym]",
			group: 0,
			tag: "Organization",
			reason: "the-acronym",
			safe: true
		},
		{
			match: "government of the? [#Place+]",
			tag: "Organization",
			reason: "government-of-x"
		},
		{
			match: "(health|school|commerce) board",
			tag: "Organization",
			reason: "school-board"
		},
		{
			match: "(nominating|special|conference|executive|steering|central|congressional) committee",
			tag: "Organization",
			reason: "special-comittee"
		},
		{
			match: "(world|global|international|national|#Demonym) #Organization",
			tag: "Organization",
			reason: "global-org"
		},
		{
			match: "#Noun+ (public|private) school",
			tag: "School",
			reason: "noun-public-school"
		},
		{
			match: "#Place+ #SportsTeam",
			tag: "SportsTeam",
			reason: "place-sportsteam"
		},
		{
			match: "(dc|atlanta|minnesota|manchester|newcastle|sheffield) united",
			tag: "SportsTeam",
			reason: "united-sportsteam"
		},
		{
			match: "#Place+ fc",
			tag: "SportsTeam",
			reason: "fc-sportsteam"
		},
		{
			match: "#Place+ #Noun{0,2} (club|society|group|team|committee|commission|association|guild|crew)",
			tag: "Organization",
			reason: "place-noun-society"
		}
	], [
		{
			match: "(west|north|south|east|western|northern|southern|eastern)+ #Place",
			tag: "Region",
			reason: "west-norfolk"
		},
		{
			match: "#City [(al|ak|az|ar|ca|ct|dc|fl|ga|id|il|nv|nh|nj|ny|oh|pa|sc|tn|tx|ut|vt|pr)]",
			group: 0,
			tag: "Region",
			reason: "us-state"
		},
		{
			match: "portland [or]",
			group: 0,
			tag: "Region",
			reason: "portland-or"
		},
		{
			match: "#ProperNoun+ (cliff|place|range|pit|place|point|room|grounds|ruins)",
			tag: "Place",
			reason: "foo-point"
		},
		{
			match: "in [#ProperNoun] #Place",
			group: 0,
			tag: "Place",
			reason: "propernoun-place"
		},
		{
			match: "#Value #Noun (st|street|rd|road|crescent|cr|way|tr|terrace|avenue|ave)",
			tag: "Address",
			reason: "address-st"
		},
		{
			match: "(port|mount|mt) #ProperName",
			tag: "Place",
			reason: "port-name"
		}
	], [
		{
			match: "[so] #Noun",
			group: 0,
			tag: "Conjunction",
			reason: "so-conj"
		},
		{
			match: "[(who|what|where|why|how|when)] #Noun #Copula #Adverb? (#Verb|#Adjective)",
			group: 0,
			tag: "Conjunction",
			reason: "how-he-is-x"
		},
		{
			match: "#Copula [(who|what|where|why|how|when)] #Noun",
			group: 0,
			tag: "Conjunction",
			reason: "when-he"
		},
		{
			match: "#Verb [that] #Pronoun",
			group: 0,
			tag: "Conjunction",
			reason: "said-that-he"
		},
		{
			match: "#Noun [that] #Copula",
			group: 0,
			tag: "Conjunction",
			reason: "that-are"
		},
		{
			match: "#Noun [that] #Verb #Adjective",
			group: 0,
			tag: "Conjunction",
			reason: "that-seem"
		},
		{
			match: "#Noun #Copula not? [that] #Adjective",
			group: 0,
			tag: "Adverb",
			reason: "that-adj"
		},
		{
			match: "#Verb #Adverb? #Noun [(that|which)]",
			group: 0,
			tag: "Preposition",
			reason: "that-prep"
		},
		{
			match: "@hasComma [which] (#Pronoun|#Verb)",
			group: 0,
			tag: "Preposition",
			reason: "which-copula"
		},
		{
			match: "#Noun [like] #Noun",
			group: 0,
			tag: "Preposition",
			reason: "noun-like"
		},
		{
			match: "^[like] #Determiner",
			group: 0,
			tag: "Preposition",
			reason: "like-the"
		},
		{
			match: "a #Noun [like] (#Noun|#Determiner)",
			group: 0,
			tag: "Preposition",
			reason: "a-noun-like"
		},
		{
			match: "#Adverb [like]",
			group: 0,
			tag: "Verb",
			reason: "really-like"
		},
		{
			match: "(not|nothing|never) [like]",
			group: 0,
			tag: "Preposition",
			reason: "nothing-like"
		},
		{
			match: "#Infinitive #Pronoun [like]",
			group: 0,
			tag: "Preposition",
			reason: "treat-them-like"
		},
		{
			match: "[#QuestionWord] (#Pronoun|#Determiner)",
			group: 0,
			tag: "Preposition",
			reason: "how-he"
		},
		{
			match: "[#QuestionWord] #Participle",
			group: 0,
			tag: "Preposition",
			reason: "when-stolen"
		},
		{
			match: "[how] (#Determiner|#Copula|#Modal|#PastTense)",
			group: 0,
			tag: "QuestionWord",
			reason: "how-is"
		},
		{
			match: "#Plural [(who|which|when)] .",
			group: 0,
			tag: "Preposition",
			reason: "people-who"
		}
	], [
		{
			match: "holy (shit|fuck|hell)",
			tag: "Expression",
			reason: "swears-expression"
		},
		{
			match: "^[(well|so|okay|now)] !#Adjective?",
			group: 0,
			tag: "Expression",
			reason: "well-"
		},
		{
			match: "^come on",
			tag: "Expression",
			reason: "come-on"
		},
		{
			match: "(say|says|said) [sorry]",
			group: 0,
			tag: "Expression",
			reason: "say-sorry"
		},
		{
			match: "^(ok|alright|shoot|hell|anyways)",
			tag: "Expression",
			reason: "ok-"
		},
		{
			match: "^(say && @hasComma)",
			tag: "Expression",
			reason: "say-"
		},
		{
			match: "^(like && @hasComma)",
			tag: "Expression",
			reason: "like-"
		},
		{
			match: "^[(dude|man|girl)] #Pronoun",
			group: 0,
			tag: "Expression",
			reason: "dude-i"
		}
	]) } };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/compute/index.js
	var net = null;
	var postTagger = function(view) {
		const { world } = view;
		const { model, methods } = world;
		net = net || methods.one.buildNet(model.two.matches, world);
		const ptrs = methods.two.quickSplit(view.document).map((terms) => {
			const t = terms[0];
			return [
				t.index[0],
				t.index[1],
				t.index[1] + terms.length
			];
		});
		const m = view.update(ptrs);
		m.cache();
		m.sweep(net);
		view.uncache();
		view.unfreeze();
		return view;
	};
	var tagger = (view) => view.compute([
		"freeze",
		"lexicon",
		"preTagger",
		"postTagger",
		"unfreeze"
	]);
	var compute_default = {
		postTagger,
		tagger
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/api.js
	var round = (n) => Math.round(n * 100) / 100;
	function api_default(View) {
		View.prototype.confidence = function() {
			let sum = 0;
			let count = 0;
			this.docs.forEach((terms) => {
				terms.forEach((term) => {
					count += 1;
					sum += term.confidence || 1;
				});
			});
			if (count === 0) return 1;
			return round(sum / count);
		};
		View.prototype.tagger = function() {
			return this.compute(["tagger"]);
		};
	}
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/postTagger/plugin.js
	var plugin = {
		api: api_default,
		compute: compute_default,
		model: model_default,
		hooks: ["postTagger"]
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/lazy/maybeMatch.js
	var getWords = function(net) {
		return Object.keys(net.hooks).filter((w) => !w.startsWith("#") && !w.startsWith("%"));
	};
	var maybeMatch = function(doc, net) {
		const words = getWords(net);
		if (words.length === 0) return doc;
		if (!doc._cache) doc.cache();
		const cache = doc._cache;
		return doc.filter((_m, i) => {
			return words.some((str) => cache[i].has(str));
		});
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/lazy/lazyParse.js
	var lazyParse = function(input, reg) {
		let net = reg;
		if (typeof reg === "string") net = this.buildNet([{ match: reg }]);
		const doc = this.tokenize(input);
		const m = maybeMatch(doc, net);
		if (m.found) {
			m.compute(["index", "tagger"]);
			return m.match(reg);
		}
		return doc.none();
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/lazy/plugin.js
	var plugin_default$1 = { lib: { lazy: lazyParse } };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/swap/api/swap-verb.js
	var matchVerb = function(m, lemma) {
		const conjugate = m.methods.two.transform.verb.conjugate;
		const all = conjugate(lemma, m.model);
		if (m.has("#Gerund")) return all.Gerund;
		if (m.has("#PastTense")) return all.PastTense;
		if (m.has("#PresentTense")) return all.PresentTense;
		if (m.has("#Gerund")) return all.Gerund;
		return lemma;
	};
	var swapVerb = function(vb, lemma) {
		let str = lemma;
		vb.forEach((m) => {
			if (!m.has("#Infinitive")) str = matchVerb(m, lemma);
			m.replaceWith(str);
		});
		return vb;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/swap/api/swap.js
	var swapNoun = function(m, lemma) {
		let str = lemma;
		if (m.has("#Plural")) {
			const toPlural = m.methods.two.transform.noun.toPlural;
			str = toPlural(lemma, m.model);
		}
		m.replaceWith(str, { possessives: true });
	};
	var swapAdverb = function(m, lemma) {
		const { toAdverb } = m.methods.two.transform.adjective;
		const adv = toAdverb(lemma);
		if (adv) m.replaceWith(adv);
	};
	var swapAdjective = function(m, lemma) {
		const { toComparative, toSuperlative } = m.methods.two.transform.adjective;
		let str = lemma;
		if (m.has("#Comparative")) str = toComparative(str, m.model);
		else if (m.has("#Superlative")) str = toSuperlative(str, m.model);
		if (str) m.replaceWith(str);
	};
	var swap = function(from, to, tag) {
		let reg = from.split(/ /g).map((str) => str.toLowerCase().trim());
		reg = reg.filter((str) => str);
		reg = reg.map((str) => `{${str}}`).join(" ");
		let m = this.match(reg);
		if (tag) m = m.if(tag);
		if (m.has("#Verb")) return swapVerb(m, to);
		if (m.has("#Noun")) return swapNoun(m, to);
		if (m.has("#Adverb")) return swapAdverb(m, to);
		if (m.has("#Adjective")) return swapAdjective(m, to);
		return this;
	};
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/2-two/swap/plugin.js
	var api = function(View) {
		View.prototype.swap = swap;
	};
	var plugin_default = { api };
	//#endregion
	//#region node_modules/.pnpm/compromise@14.15.1/node_modules/compromise/src/two.js
	one_default.plugin(plugin_default$3);
	one_default.plugin(plugin_default$2);
	one_default.plugin(plugin);
	one_default.plugin(plugin_default$1);
	one_default.plugin(plugin_default);
	var two_default = one_default;
	var tech_products_default = {
		_comment: "小写或全小写技术产品/工具名 — 出现一次即入 glossary. 维护注意: 这些都是 brand 性质, 翻译时应保持原文不译. 加新词时考虑: 1) 是否知名到读者一看便知 2) 是否容易和普通英文词混淆.",
		products: [
			"dbt",
			"redis",
			"nginx",
			"postgres",
			"POSTGRESQL",
			"mongodb",
			"mysql",
			"sqlite",
			"mariadb",
			"git",
			"vim",
			"curl",
			"tmux",
			"grpcurl",
			"ollama",
			"langgraph",
			"langchain",
			"kubernetes",
			"docker",
			"webpack",
			"rollup",
			"vite",
			"esbuild",
			"babel",
			"hadoop",
			"elasticsearch",
			"kibana",
			"logstash",
			"rabbitmq",
			"kafka",
			"flink",
			"spark",
			"airflow",
			"superset",
			"metabase",
			"grafana",
			"prometheus",
			"loki",
			"terraform",
			"ansible",
			"puppet",
			"chef",
			"vault",
			"consul",
			"nomad"
		],
		_publications_comment: "媒体名 — 用于消歧, 防止 'Stack'/'Review' 等被误抽成单字产品. 出现即抽出完整名称.",
		publications: [
			"The New Stack",
			"InfoQ",
			"TechCrunch",
			"Wired",
			"The Register",
			"Hacker News",
			"The Verge",
			"Ars Technica",
			"ZDNet",
			"VentureBeat"
		]
	};
	//#endregion
	//#region src/entrypoints/utils/glossaryExtractor.ts
	var TECH_PRODUCTS = new Set(tech_products_default.products);
	var CANONICAL_PRODUCTS = new Map([...TECH_PRODUCTS].map((p) => [p.toLowerCase(), p]));
	var KNOWN_PUBLICATIONS = new Set(tech_products_default.publications.flatMap((p) => p.toLowerCase().split(/\s+/)));
	var FULL_PUBLICATIONS = tech_products_default.publications;
	var TECH_ANCHORS = new Set([
		"AI",
		"ML",
		"LLM",
		"RAG",
		"NLP",
		"GPU",
		"CPU",
		"TPU",
		"NPU",
		"API",
		"GraphQL",
		"gRPC",
		"SQL",
		"NoSQL",
		"MCP",
		"RBAC",
		"PII",
		"TLS",
		"SSL",
		"SDK",
		"IDE",
		"CDN",
		"DDoS",
		"SaaS",
		"PaaS",
		"IaaS",
		"FaaS",
		"ETL",
		"ELT",
		"JVM",
		"WASM",
		"K8s",
		"Kafka",
		"Flink",
		"Spark",
		"Airflow",
		"Postgres",
		"Redis",
		"MongoDB",
		"Elasticsearch",
		"ClickHouse",
		"Docker",
		"Kubernetes",
		"PyTorch",
		"TensorFlow",
		"LangChain",
		"LangGraph",
		"Ollama",
		"Anthropic"
	]);
	var TECH_ANCHORS_LOWER = new Set([...TECH_ANCHORS].map((w) => w.toLowerCase()));
	var BLOCKED_TAIL_NOUNS = new Set([
		"apps",
		"services",
		"tools",
		"users",
		"systems",
		"solutions",
		"platforms",
		"products",
		"projects",
		"features",
		"components",
		"modules",
		"issues",
		"questions",
		"topics",
		"items",
		"things",
		"stuff",
		"aspects",
		"elements",
		"factors",
		"areas",
		"parts",
		"pieces"
	]);
	var STOPWORDS = new Set([
		"the",
		"a",
		"an",
		"and",
		"or",
		"but",
		"not",
		"nor",
		"yet",
		"so",
		"for",
		"in",
		"on",
		"at",
		"to",
		"of",
		"by",
		"with",
		"from",
		"as",
		"is",
		"are",
		"was",
		"were",
		"be",
		"been",
		"being",
		"have",
		"has",
		"had",
		"do",
		"does",
		"did",
		"will",
		"would",
		"could",
		"should",
		"shall",
		"may",
		"might",
		"must",
		"can",
		"need",
		"dare",
		"ought",
		"used",
		"it",
		"its",
		"he",
		"him",
		"his",
		"she",
		"her",
		"we",
		"us",
		"our",
		"they",
		"them",
		"their",
		"you",
		"your",
		"my",
		"me",
		"mine",
		"yours",
		"this",
		"that",
		"these",
		"those",
		"who",
		"whom",
		"whose",
		"which",
		"what",
		"where",
		"when",
		"why",
		"how",
		"all",
		"each",
		"every",
		"both",
		"few",
		"more",
		"most",
		"some",
		"any",
		"no",
		"none",
		"much",
		"many",
		"other",
		"another",
		"such",
		"same",
		"own",
		"than",
		"then",
		"too",
		"very",
		"also",
		"just",
		"only",
		"even",
		"still",
		"already",
		"never",
		"always",
		"here",
		"there",
		"now",
		"well",
		"about",
		"above",
		"below",
		"under",
		"over",
		"after",
		"before",
		"between",
		"through",
		"during",
		"without",
		"within",
		"along",
		"across",
		"against",
		"into",
		"onto",
		"upon",
		"out",
		"off",
		"up",
		"down",
		"if",
		"while",
		"although",
		"though",
		"because",
		"since",
		"until",
		"unless",
		"whether",
		"rather",
		"instead",
		"however",
		"therefore",
		"thus",
		"hence",
		"else",
		"ever",
		"once",
		"again",
		"further",
		"back",
		"i",
		"am",
		"been",
		"get",
		"got",
		"let",
		"make",
		"go",
		"come",
		"take",
		"give",
		"see",
		"know",
		"think",
		"say",
		"tell",
		"ask",
		"use",
		"find",
		"want",
		"look",
		"try",
		"help",
		"show",
		"hear",
		"play",
		"run",
		"move",
		"live",
		"put",
		"set",
		"add",
		"keep",
		"start",
		"stop",
		"turn",
		"call",
		"work",
		"seem",
		"feel",
		"leave",
		"bring",
		"begin",
		"one",
		"two",
		"three",
		"four",
		"five",
		"six",
		"seven",
		"eight",
		"nine",
		"ten",
		"great",
		"small",
		"large",
		"big",
		"long",
		"short",
		"high",
		"low",
		"right",
		"left",
		"early",
		"late",
		"hard",
		"easy",
		"best",
		"worst",
		"true",
		"false",
		"real",
		"sure",
		"able",
		"free",
		"full",
		"empty",
		"different",
		"important",
		"possible",
		"public",
		"private",
		"certain",
		"general",
		"local",
		"social",
		"national",
		"natural",
		"political",
		"point",
		"way",
		"day",
		"time",
		"year",
		"people",
		"man",
		"woman",
		"child",
		"world",
		"life",
		"hand",
		"part",
		"place",
		"case",
		"week",
		"company",
		"system",
		"program",
		"question",
		"home",
		"water",
		"room",
		"area",
		"money",
		"story",
		"fact",
		"month",
		"lot",
		"right",
		"study",
		"book",
		"eye",
		"job",
		"word",
		"business",
		"issue",
		"side",
		"kind",
		"head",
		"house",
		"service",
		"friend",
		"father",
		"mother",
		"power",
		"hour",
		"game",
		"line",
		"end",
		"member",
		"law",
		"car",
		"city",
		"community",
		"name",
		"president",
		"team",
		"minute",
		"idea",
		"body",
		"information",
		"back",
		"parent",
		"face",
		"level",
		"office",
		"door",
		"health",
		"person",
		"art",
		"war",
		"history",
		"party",
		"result",
		"customer",
		"server",
		"database",
		"network",
		"process",
		"model",
		"tool",
		"feature",
		"platform",
		"product",
		"project",
		"team",
		"user",
		"ive",
		"dont",
		"youre",
		"were",
		"theyre",
		"im",
		"id",
		"ill",
		"hes",
		"shes",
		"morning",
		"reason",
		"research",
		"girl",
		"guy",
		"moment",
		"air",
		"teacher",
		"force",
		"education",
		"foot",
		"boy",
		"age",
		"policy",
		"music",
		"market",
		"sense",
		"thing",
		"things",
		"love",
		"class",
		"state",
		"don",
		"doesn",
		"didn",
		"won",
		"wasn",
		"weren",
		"isn",
		"aren",
		"hasn",
		"haven",
		"hadn",
		"wouldn",
		"couldn",
		"shouldn",
		"mustn",
		"ve",
		"ll",
		"re",
		"shan"
	]);
	var ACRONYM_EXCLUSIONS = new Set([
		"THE",
		"AND",
		"FOR",
		"NOT",
		"ARE",
		"BUT",
		"ALL",
		"CAN",
		"HAS",
		"HER",
		"WAS",
		"ONE",
		"OUR",
		"OUT",
		"USE",
		"VIA",
		"WHO",
		"ITS",
		"MAY",
		"NOR",
		"SINCE",
		"INTO",
		"FROM",
		"THIS",
		"THAT",
		"WITH",
		"SUCH",
		"EACH",
		"WHEN",
		"WHERE",
		"WHICH",
		"WHILE",
		"OVER",
		"BOTH",
		"THEN",
		"THAN",
		"THEY",
		"THEM",
		"THEIR",
		"THESE",
		"THOSE",
		"BEEN",
		"BEING",
		"HAVE",
		"WILL",
		"WOULD",
		"COULD",
		"SHOULD",
		"ABOUT",
		"OTHER",
		"ALSO",
		"SOME",
		"VERY",
		"JUST",
		"MUST",
		"DOER",
		"VS",
		"GET",
		"SET",
		"PUT",
		"LET",
		"SEE",
		"SAY",
		"DAY",
		"WAY",
		"OWN",
		"TOO",
		"ANY",
		"TRY",
		"RUN",
		"ADD",
		"END",
		"TOP",
		"BIG",
		"BAD",
		"RED",
		"MAN",
		"OLD",
		"NEW",
		"HOT",
		"FAR",
		"OFF",
		"LOT",
		"AGE",
		"AGO",
		"DUE",
		"YET",
		"NON",
		"PER",
		"SUB",
		"PRE",
		"PRO",
		"POST",
		"SELF",
		"TRUE",
		"NULL",
		"VOID",
		"TYPE",
		"LIKE",
		"EVEN",
		"WELL",
		"BACK",
		"NEXT",
		"LAST",
		"BEST",
		"DONE",
		"MADE",
		"GONE",
		"TOLD",
		"CAME",
		"WENT",
		"TOOK",
		"SAID",
		"KNEW",
		"GOT",
		"NEED",
		"MAKE",
		"HELP",
		"WORK",
		"PART",
		"GOOD",
		"LOOK",
		"COME",
		"CALL",
		"KEEP",
		"GIVE",
		"TURN",
		"MOVE",
		"LIVE",
		"SHOW",
		"FIND",
		"HAND",
		"HEAD",
		"SIDE",
		"LINE",
		"CASE",
		"POINT",
		"MEAN",
		"USED",
		"SEEM",
		"WANT",
		"FACT",
		"FORM",
		"SURE",
		"ABLE",
		"ELSE",
		"EVER",
		"STILL",
		"ISBN",
		"HTML",
		"JSON",
		"ACM",
		"BETA",
		"MATH"
	]);
	var ACRONYM_PATTERN = /\b(?:[A-Z]{2,}|[a-z]+[A-Z]{2,}[A-Za-z0-9]*|[A-Z][a-z]+[A-Z][A-Za-z0-9]*)\b/g;
	function cleanTerm(term) {
		return term.replace(/^[,;:.!?'"“”‘’()\[\]{}\-–—#*_/\\|<>~`\s]+/, "").replace(/[,;:.!?'"“”‘’()\[\]{}\-–—#*_/\\|<>~`\s]+$/, "").replace(/['’]s$/i, "").split(/\.[A-Z]/)[0].replace(/['’]/g, "").trim();
	}
	function extractAcronyms(text) {
		const found = /* @__PURE__ */ new Map();
		for (const match of text.matchAll(ACRONYM_PATTERN)) {
			const word = match[0];
			if (!ACRONYM_EXCLUSIONS.has(word)) found.set(word, (found.get(word) || 0) + 1);
		}
		const result = [];
		for (const [word, count] of found) {
			if (/^[A-Z]{5,}$/.test(word) && !/\d/.test(word) && count < 2) continue;
			result.push(word);
		}
		return result;
	}
	var AI_VENDOR_PREFIXES = [
		"Claude",
		"GPT",
		"Gemini",
		"Llama",
		"Qwen",
		"Mistral",
		"DeepSeek",
		"Grok",
		"Nova",
		"Command",
		"Phi"
	];
	var compiledProductRe = null;
	function getProductRe() {
		if (compiledProductRe) return compiledProductRe;
		const escaped = AI_VENDOR_PREFIXES.map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).sort((a, b) => b.length - a.length);
		compiledProductRe = new RegExp(`\\b(?:${escaped.join("|")})(?:[0-9]+(?:\\.[0-9]+)?[A-Za-z]*|[\\s\\-]+(?:[A-Z][A-Za-z]*|[0-9]+(?:\\.[0-9]+)?[A-Za-z]*)){0,3}`, "g");
		return compiledProductRe;
	}
	/**
	* 从文本中提取 AI 产品名（上下文感知）。
	* 只匹配以 vendor prefix 开头的完整产品名，不会误伤普通英文词。
	*/
	function extractProductNames(text) {
		const re = getProductRe();
		const results = /* @__PURE__ */ new Set();
		for (const m of text.matchAll(re)) {
			const name = m[0].replace(/[\s\-]+$/, "").trim();
			if (name.length >= 3) results.add(name);
		}
		return [...results];
	}
	function extractNamedEntities(doc) {
		const entities = /* @__PURE__ */ new Set();
		const fullText = doc.text();
		const possessiveRanges = [];
		{
			let searchFrom = 0;
			for (const t of doc.match("#Possessive+").out("array")) {
				const idx = fullText.indexOf(t, searchFrom);
				if (idx >= 0) {
					possessiveRanges.push([idx, idx + t.length]);
					searchFrom = idx + t.length;
				}
			}
		}
		const isPossessive = (word) => {
			const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
			const regex = new RegExp(`(?<=^|[^a-zA-Z0-9_])${escaped}(?=[^a-zA-Z0-9_]|$)`, "g");
			let allPossessive = true;
			let hasMatch = false;
			for (const match of fullText.matchAll(regex)) {
				hasMatch = true;
				const idx = match.index;
				if (idx === void 0) continue;
				if (!possessiveRanges.some(([s, e]) => idx >= s && idx < e)) {
					allPossessive = false;
					break;
				}
			}
			return hasMatch ? allPossessive : false;
		};
		if (typeof doc.acronyms === "function") for (const ac of doc.acronyms().out("array")) {
			const cleaned = cleanTerm(ac);
			if (cleaned.length < 2 || cleaned.length >= 20) continue;
			if (cleaned.includes(" ")) continue;
			if (ACRONYM_EXCLUSIONS.has(cleaned.toUpperCase())) continue;
			if (isCommonNoun(cleaned)) continue;
			if (/^[A-Z]{5,}$/.test(cleaned) && !/\d/.test(cleaned)) {
				if ((fullText.match(new RegExp(`(?<=^|[^a-zA-Z0-9_])${cleaned}(?=[^a-zA-Z0-9_]|$)`, "g")) || []).length < 2) continue;
			}
			entities.add(cleaned);
		}
		if (typeof doc.people === "function") for (const person of doc.people().out("array")) {
			const cleaned = cleanTerm(person);
			if (cleaned.length < 2) continue;
			if (cleaned.includes(" ")) {
				for (const tok of cleaned.split(/\s+/)) if (tok.length >= 2 && !isCommonNoun(tok) && !isStopword(tok)) entities.add(tok);
			} else if (!isCommonNoun(cleaned) && !isStopword(cleaned)) entities.add(cleaned);
		}
		for (const m of fullText.matchAll(/(?:^|[^a-zA-Z0-9])([A-Z][a-z]+[A-Z][A-Za-z0-9]*)\b/g)) {
			const word = m[1];
			if (isCommonNoun(word)) continue;
			if (isPossessive(word)) continue;
			entities.add(word);
		}
		for (const m of fullText.matchAll(/(?<=[a-z,;:] )([A-Z][a-z]{2,})\b/g)) {
			const word = m[1];
			if (isCommonNoun(word)) continue;
			if (STOPWORDS.has(word.toLowerCase())) continue;
			if (isPossessive(word)) continue;
			if (KNOWN_PUBLICATIONS.has(word.toLowerCase())) continue;
			entities.add(word);
		}
		const sentenceStartWords = [...fullText.matchAll(/(?:^|[.!?]\s+|\n\s*)([A-Z][a-z]{2,})\b/g)].map((m) => m[1]);
		if (sentenceStartWords.length > 0) {
			const totalCounts = /* @__PURE__ */ new Map();
			for (const m of fullText.matchAll(/(?<![A-Za-z0-9_])([A-Z][a-z]{2,})\b/g)) {
				const w = m[1];
				totalCounts.set(w, (totalCounts.get(w) || 0) + 1);
			}
			for (const word of sentenceStartWords) {
				if (entities.has(word)) continue;
				if (isCommonNoun(word)) continue;
				if (STOPWORDS.has(word.toLowerCase())) continue;
				if (isPossessive(word)) continue;
				if (KNOWN_PUBLICATIONS.has(word.toLowerCase())) continue;
				if ((totalCounts.get(word) || 0) < 3 && !TECH_ANCHORS.has(word)) continue;
				entities.add(word);
			}
		}
		for (const pub of FULL_PUBLICATIONS) if (fullText.toLowerCase().includes(pub.toLowerCase())) entities.add(pub);
		const sentenceStartCounts = /* @__PURE__ */ new Map();
		for (const m of fullText.matchAll(/(?:^|[.!?]\s+|\n)([A-Z][A-Za-z]+)/g)) {
			const w = m[1].toLowerCase();
			sentenceStartCounts.set(w, (sentenceStartCounts.get(w) || 0) + 1);
		}
		const properNounCounts = /* @__PURE__ */ new Map();
		for (const pn of doc.match("#ProperNoun+").not("(#Pronoun|#Conjunction|#Preposition|#Determiner|#Adverb)").out("array")) {
			const cleaned = cleanTerm(pn);
			if (cleaned.includes(" ")) continue;
			if (cleaned.length < 3) continue;
			if (isStopword(cleaned)) continue;
			if (isCommonNoun(cleaned)) continue;
			if (isPossessive(cleaned)) continue;
			if (KNOWN_PUBLICATIONS.has(cleaned.toLowerCase())) continue;
			properNounCounts.set(cleaned, (properNounCounts.get(cleaned) || 0) + 1);
		}
		for (const [word, count] of properNounCounts) {
			const startCount = sentenceStartCounts.get(word.toLowerCase()) || 0;
			if (count > 1 && startCount >= count) continue;
			entities.add(word);
		}
		return [...entities];
	}
	var COMMON_NOUN_FALSE_POSITIVES = new Set([
		"Actually",
		"Coding",
		"Flash",
		"How",
		"Pro",
		"Scout",
		"Setup",
		"Studio",
		"Why",
		"When",
		"Where",
		"What",
		"Which",
		"Who",
		"Today",
		"Tomorrow",
		"Yesterday",
		"Nothing",
		"Everything",
		"Something",
		"Anything",
		"Everyone",
		"Anyone",
		"Someone",
		"Nobody",
		"Everybody",
		"Each",
		"Every",
		"Other",
		"Another",
		"Either",
		"Neither",
		"Most",
		"Some",
		"Many",
		"Several",
		"Few",
		"All",
		"Both",
		"None",
		"Future",
		"Past",
		"Present",
		"Now",
		"Then",
		"Here",
		"There",
		"Above",
		"Below",
		"Inside",
		"Outside",
		"Before",
		"After",
		"During",
		"Until",
		"Since",
		"While",
		"Because",
		"Although",
		"However",
		"Moreover",
		"Furthermore",
		"Therefore",
		"Otherwise",
		"Instead",
		"Besides",
		"Anyway",
		"Somewhere",
		"Nowhere",
		"Everywhere",
		"People",
		"Year",
		"Day",
		"Week",
		"Month",
		"Time",
		"Real",
		"End",
		"Beginning",
		"Start",
		"Middle",
		"Top",
		"Bottom",
		"Left",
		"Right",
		"Front",
		"Back",
		"Up",
		"Down",
		"Side",
		"Part",
		"Section",
		"Chapter",
		"Page",
		"Figure",
		"Table",
		"Section",
		"Appendix",
		"Section",
		"Note",
		"Warning",
		"Caution",
		"Tip",
		"Example",
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday",
		"Sunday",
		"Microservices",
		"Microservice",
		"Services",
		"Service",
		"Topology",
		"Connector",
		"Architecture",
		"Pipeline",
		"Aggregator",
		"Stream",
		"Streams",
		"Consumer",
		"Producer",
		"Broker",
		"Cluster",
		"Node",
		"Nodes",
		"Worker",
		"Workers",
		"Shard",
		"Shards",
		"Layer",
		"Layers",
		"Gateway",
		"Gateways",
		"Balancer",
		"Balancers",
		"Database",
		"Databases",
		"Query",
		"Queries",
		"Index",
		"Snapshot",
		"Snapshots",
		"Cache",
		"Bucket",
		"Endpoint",
		"Endpoints",
		"Protocol",
		"Protocols",
		"Metric",
		"Metrics",
		"Trace",
		"Tracer",
		"Spans",
		"Span",
		"Log",
		"Logs",
		"Filter",
		"Filters",
		"Graph",
		"Graphs",
		"Node",
		"Nodes",
		"Edge",
		"Edges",
		"Vertex",
		"Vertices",
		"Table",
		"Tables",
		"Column",
		"Columns",
		"Row",
		"Rows",
		"Field",
		"Fields",
		"View",
		"Views",
		"Model",
		"Models",
		"Schema",
		"Index",
		"Constraint",
		"Tier",
		"Tiers",
		"Region",
		"Regions",
		"Zone",
		"Zones",
		"Domain",
		"Domains",
		"Flow",
		"Logs",
		"Path",
		"Paths",
		"Edge",
		"Edges",
		"Source",
		"Sources",
		"Request",
		"Response",
		"Status",
		"Payload",
		"Header",
		"Headers",
		"Service",
		"Services",
		"Process",
		"Process",
		"Thread",
		"Threads",
		"Context",
		"Scope",
		"Token",
		"Tokens",
		"Session",
		"Sessions",
		"Pipeline",
		"Pipelines",
		"Job",
		"Jobs",
		"Task",
		"Tasks",
		"Batch",
		"Batches",
		"Customer",
		"Server",
		"Database",
		"Network",
		"Process",
		"Model",
		"Tool",
		"Feature",
		"Platform",
		"Product",
		"Project",
		"User",
		"Customer",
		"Stakes",
		"Controls",
		"Tooling",
		"Industries",
		"Agencies",
		"Vendors",
		"Practices",
		"Patterns",
		"Concerns",
		"Requirements",
		"Constraints",
		"Security",
		"Privacy",
		"Latency",
		"Throughput",
		"Compliance",
		"Developer",
		"Engineer",
		"Operator",
		"Admin",
		"Architect"
	]);
	function isCommonNoun(word) {
		if (COMMON_NOUN_FALSE_POSITIVES.has(word)) return true;
		return COMMON_NOUN_FALSE_POSITIVES.has(word.charAt(0).toUpperCase() + word.slice(1).toLowerCase());
	}
	function isStopword(word) {
		return STOPWORDS.has(word.toLowerCase());
	}
	function hasSubstantiveWord(words) {
		return words.some((w) => !isStopword(w));
	}
	var NOUN_CHAIN_BREAKERS = new Set([
		"targets",
		"offers",
		"provides",
		"builds",
		"uses",
		"runs",
		"manages",
		"handles",
		"supports",
		"creates",
		"includes",
		"helps",
		"makes",
		"allows",
		"enables",
		"gives",
		"takes",
		"shows",
		"works",
		"ships",
		"brings",
		"sets",
		"gets",
		"needs",
		"wants",
		"starts",
		"stops",
		"finds",
		"holds",
		"sends",
		"leaves",
		"follows",
		"removes",
		"applies",
		"produces",
		"contains",
		"represents",
		"generates",
		"delivers",
		"executes",
		"processes",
		"publishes",
		"schedules",
		"configures",
		"validates",
		"transforms",
		"converts",
		"maps",
		"tracks",
		"monitors",
		"alerts",
		"fetches",
		"queries",
		"returns",
		"retrieves",
		"cancels",
		"lists",
		"searches",
		"marks",
		"hosts",
		"serves",
		"stores",
		"loads",
		"caches",
		"syncs",
		"routes",
		"migrates",
		"streams",
		"batches",
		"commits",
		"merges",
		"deploys",
		"refactors",
		"installs",
		"updates",
		"upgrades",
		"logs",
		"trains",
		"predicts",
		"classifies",
		"embeds",
		"encodes",
		"decodes",
		"normalizes",
		"aggregates",
		"indexes",
		"replicates",
		"evaluates",
		"estimates",
		"performs",
		"implements",
		"integrates",
		"optimizes",
		"simplifies",
		"automates",
		"analyzes",
		"compiles",
		"initializes",
		"responds",
		"notifies",
		"subscribes",
		"broadcasts"
	]);
	var STRONG_VERBS = new Set([
		"feels",
		"seems",
		"looks",
		"sounds",
		"helps",
		"lets",
		"allows",
		"enables",
		"appears",
		"becomes",
		"remains",
		"involves",
		"requires",
		"ensures",
		"prevents",
		"specifies",
		"defines",
		"describes",
		"indicates",
		"suggests",
		"demonstrates",
		"recommends",
		"mentions",
		"expects"
	]);
	function extractFrequentTerms(doc) {
		const phraseCounts = /* @__PURE__ */ new Map();
		const phraseOriginals = /* @__PURE__ */ new Map();
		for (const pattern of [
			"#Noun+",
			"#Noun #Gerund",
			"#Noun #Noun #Gerund"
		]) for (const phrase of doc.match(pattern).not("(#Pronoun|#Preposition|#Conjunction)").out("array")) {
			const cleaned = cleanTerm(phrase);
			if (cleaned.length < 3 || cleaned.length > 60) continue;
			if (/[,;:—–]/.test(cleaned)) continue;
			const words = cleaned.split(/\s+/);
			if (!hasSubstantiveWord(words)) continue;
			const breakIndex = words.findIndex((word, index) => {
				if (index === 0) return false;
				const wLower = word.toLowerCase();
				return NOUN_CHAIN_BREAKERS.has(wLower) || STRONG_VERBS.has(wLower);
			});
			let finalWords = words;
			if (breakIndex !== -1) {
				finalWords = words.slice(0, breakIndex);
				if (finalWords.length === 0 || !hasSubstantiveWord(finalWords)) continue;
			}
			const finalCleaned = finalWords.join(" ");
			if (isStopword(finalWords[0])) continue;
			if (finalWords.length === 1 && isCommonNoun(finalWords[0])) continue;
			if (finalWords.length === 1) {
				const w = finalWords[0];
				if (/^[A-Z][a-z]+(?:er|est|ing)$/.test(w) && !/^[A-Z]{2,}$/.test(w)) continue;
			}
			if (/['']s\b/.test(finalCleaned)) continue;
			if (finalWords.every((w) => isCommonNoun(w))) continue;
			if (finalWords.length >= 2 && BLOCKED_TAIL_NOUNS.has(finalWords[finalWords.length - 1].toLowerCase())) continue;
			if (finalWords.length === 1 && finalCleaned.length < 4 && !/[A-Z]/.test(finalCleaned)) continue;
			const key = finalCleaned.toLowerCase();
			phraseCounts.set(key, (phraseCounts.get(key) || 0) + 1);
			if (!phraseOriginals.has(key)) phraseOriginals.set(key, finalCleaned);
		}
		const merged = /* @__PURE__ */ new Map();
		const mergedOriginals = /* @__PURE__ */ new Map();
		const processed = /* @__PURE__ */ new Set();
		const tokenWordCount = /* @__PURE__ */ new Map();
		for (const phrase of phraseCounts.keys()) {
			const ws = phrase.split(/\s+/);
			if (ws.length === 1) tokenWordCount.set(ws[0], (tokenWordCount.get(ws[0]) || 0) + 1);
		}
		for (const [key, count] of phraseCounts.entries()) {
			if (processed.has(key)) continue;
			let totalCount = count;
			if (key.split(/\s+/).length === 1 && key.length >= 4 && !/^\d+$/.test(key)) {
				const singular = key.replace(/s$/, "");
				if (singular !== key && phraseCounts.has(singular) && (tokenWordCount.get(singular) || 0) > 0) {
					totalCount += phraseCounts.get(singular);
					processed.add(singular);
				}
			}
			const plural = key + "s";
			if (plural !== key && !processed.has(plural) && phraseCounts.has(plural)) {
				totalCount += phraseCounts.get(plural);
				processed.add(plural);
			}
			processed.add(key);
			merged.set(key, totalCount);
			mergedOriginals.set(key, phraseOriginals.get(key) || key);
		}
		const result = [];
		const seen = /* @__PURE__ */ new Set();
		const sorted = [...merged.entries()].sort((a, b) => b[1] - a[1]);
		for (const [key, count] of sorted) {
			const isSingleWord = !key.includes(" ");
			const hasAnchor = key.split(/\s+/).some((w) => TECH_ANCHORS_LOWER.has(w));
			if (isSingleWord && count < 3 && !hasAnchor) continue;
			if (!isSingleWord && count < 2 && !hasAnchor) continue;
			const term = mergedOriginals.get(key) || key;
			if (seen.has(term.toLowerCase())) continue;
			seen.add(term.toLowerCase());
			result.push(term);
		}
		return result;
	}
	function extractGlossaryLocal(fullText, emphasizedTerms = []) {
		if (!fullText) return { document_terms: [] };
		const termSet = /* @__PURE__ */ new Set();
		const safeText = fullText.replace(/```[\s\S]*?```/g, (m) => " ".repeat(m.length)).replace(/`[^`]+`/g, (m) => " ".repeat(m.length)).replace(/https?:\/\/[^\s]+/g, (m) => " ".repeat(m.length));
		const acronyms = extractAcronyms(safeText);
		for (const acronym of acronyms) termSet.add(acronym);
		const productNames = extractProductNames(safeText);
		for (const name of productNames) termSet.add(name);
		{
			const validProducts = [...TECH_PRODUCTS].filter((p) => p.length >= 2);
			if (validProducts.length > 0) {
				const escaped = validProducts.map((p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).sort((a, b) => b.length - a.length);
				const productRe = new RegExp(`(?<=^|[^A-Za-z0-9_])(?:${escaped.join("|")})(?=[^A-Za-z0-9_]|$)`, "gi");
				for (const m of safeText.matchAll(productRe)) {
					const product = m[0];
					if (![...termSet].some((k) => k.toLowerCase() === product.toLowerCase())) termSet.add(product);
				}
			}
		}
		const doc = two_default(safeText);
		doc.match("(feels|seems|looks|sounds|helps|lets|allows|enables)").tag("Verb").unTag("Noun");
		doc.match("[#Noun] (the|a|an|to|with|for|by|its|their|our|us|them)").tag("Verb").unTag("Noun");
		doc.match("^(#Adverb|#Conjunction|#Pronoun|#Preposition|#Determiner)").unTag("ProperNoun");
		const namedEntities = extractNamedEntities(doc);
		for (const entity of namedEntities) termSet.add(entity);
		const frequentTerms = extractFrequentTerms(doc);
		for (const term of frequentTerms) if (!termSet.has(term)) termSet.add(term);
		for (const term of emphasizedTerms) {
			const trimmed = term.trim();
			if (trimmed.length > 1 && trimmed.length < 80) termSet.add(trimmed);
		}
		const allTerms = [...termSet];
		const uniqueTerms = /* @__PURE__ */ new Map();
		for (const term of allTerms) {
			const lower = term.toLowerCase();
			if (CANONICAL_PRODUCTS.has(lower)) {
				uniqueTerms.set(lower, CANONICAL_PRODUCTS.get(lower));
				continue;
			}
			if (!uniqueTerms.has(lower)) uniqueTerms.set(lower, term);
			else if (term !== term.toUpperCase() && /[a-z]/.test(term) && /^[A-Z]/.test(term)) uniqueTerms.set(lower, term);
		}
		const merged = /* @__PURE__ */ new Map();
		for (const [key, term] of uniqueTerms) {
			if (merged.has(key)) continue;
			const singular = key.replace(/s$/, "");
			const plural = key + "s";
			const twinKey = singular !== key && uniqueTerms.has(singular) ? singular : plural !== key && uniqueTerms.has(plural) ? plural : null;
			if (twinKey) {
				const twinTerm = uniqueTerms.get(twinKey);
				const preferTitleCase = (a, b) => {
					const aTitle = /^[A-Z]/.test(a) && a !== a.toUpperCase();
					const bTitle = /^[A-Z]/.test(b) && b !== b.toUpperCase();
					if (aTitle && !bTitle) return a;
					if (bTitle && !aTitle) return b;
					return a;
				};
				const winner = preferTitleCase(term, twinTerm);
				const canonicalKey = key.length <= twinKey.length ? key : twinKey;
				merged.set(canonicalKey, winner);
			} else merged.set(key, term);
		}
		return { document_terms: [...merged.values()].map((term) => ({
			term,
			score: scoreTerm(term, fullText)
		})).filter((s) => !isGenericNoise(s.term)).filter((s) => !isSentenceStartMisident(s.term, fullText)).sort((a, b) => b.score - a.score).slice(0, MAX_GLOSSARY_TERMS).map((s) => s.term) };
	}
	var GENERIC_NOISE = new Set([
		"services",
		"service",
		"systems",
		"system",
		"traces",
		"trace",
		"tools",
		"tool",
		"logs",
		"log",
		"metrics",
		"metric",
		"data",
		"engineers",
		"engineer",
		"teams",
		"team",
		"users",
		"user",
		"context",
		"details",
		"support",
		"requests",
		"request",
		"queries",
		"query",
		"edges",
		"edge",
		"paths",
		"path",
		"sources",
		"source",
		"levels",
		"level",
		"environments",
		"environment",
		"solutions",
		"solution",
		"attempts",
		"attempt",
		"patterns",
		"pattern",
		"questions",
		"question",
		"failures",
		"failure",
		"changes",
		"change",
		"views",
		"view",
		"layers",
		"layer",
		"snapshots",
		"snapshot",
		"workloads",
		"workload",
		"hops",
		"hop",
		"gateways",
		"gateway",
		"balancers",
		"balancer",
		"events",
		"event",
		"pipelines",
		"pipeline",
		"connections",
		"connection",
		"storage",
		"costs",
		"cost",
		"incidents",
		"incident",
		"limitations",
		"limitation",
		"processors",
		"processor",
		"consumers",
		"consumer",
		"protocols",
		"protocol",
		"endpoints",
		"endpoint",
		"dependencies",
		"dependency",
		"graphs",
		"graph",
		"response",
		"requirement",
		"requirements",
		"multi-region",
		"real-time",
		"sub-second"
	]);
	function isGenericNoise(term) {
		const normalized = term.toLowerCase().trim();
		if (GENERIC_NOISE.has(normalized)) return true;
		if (!term.includes(" ") && /^[a-z]+s$/.test(term) && term.length <= 10 && !TECH_PRODUCTS.has(normalized)) return true;
		return false;
	}
	/**
	* Compromise 经常把"句首大写"的普通词识别为 proper noun：
	* "Boost the cash flow" → "Boost" 进入 candidates
	* "Forecast says ..." → "Forecast" 进入 candidates
	* "Soars in 2026" → "Soars" 进入 candidates
	* "Tech companies ..." → "Tech" 进入 candidates
	*
	* 这些词应该被翻译成中文（"提升"/"预测"/"飙升"/"科技"），但被
	* compromise 当成命名实体，污染了 glossary，最终导致模型把它们所在
	* 的整段回传为 no-op 翻译。
	*
	* 修复策略：单 capitalized 普通词（Boost/Forecast/Soars/Cash/Tech）
	* 出现在句首 + 不在白名单 + 出现次数 ≤ 1 → 当句首误识丢弃。
	*
	* 已知品牌（Anthropic/Microsoft/Google/Apple/...）即使在句首也保留。
	* 它们的 frequency 一般 ≥ 2 或命中下面白名单。
	*
	* 多词短语（"Goldman Sachs Research"）不受影响 — `term.includes(' ')`
	* 直接 return false 走绿色通道。
	*/
	var KNOWN_BRANDS_AT_SENTENCE_START = new Set([
		"Anthropic",
		"Microsoft",
		"Google",
		"Apple",
		"Amazon",
		"Meta",
		"Tesla",
		"Nvidia",
		"Intel",
		"Oracle",
		"IBM",
		"Adobe",
		"Salesforce",
		"Netflix",
		"Spotify",
		"Uber",
		"Airbnb",
		"Twitter",
		"Facebook",
		"Linkedin",
		"Openai",
		"Deepseek",
		"Claude",
		"Gemini",
		"Copilot",
		"Cursor",
		"React",
		"Vue",
		"Angular",
		"Svelte",
		"Django",
		"Flask",
		"Rails",
		"Laravel",
		"Symfony",
		"Fastapi",
		"Express",
		"Koa",
		"Nestjs",
		"Spring",
		"Hibernate",
		"Tomcat",
		"Webpack",
		"Vite",
		"Rollup",
		"Babel",
		"Eslint",
		"Prettier",
		"Jest",
		"Mocha",
		"Cypress",
		"Playwright",
		"Puppeteer",
		"Selenium",
		"Docker",
		"Kubernetes",
		"Postgres",
		"Postgresql",
		"Mysql",
		"Redis",
		"Mongodb",
		"Elasticsearch",
		"Kafka",
		"Rabbitmq",
		"Nginx",
		"Apache",
		"Terraform",
		"Pulumi",
		"Ansible",
		"Puppet",
		"Chef",
		"Vagrant",
		"Github",
		"Gitlab",
		"Bitbucket",
		"Jenkins",
		"Circleci",
		"Travis",
		"Datadog",
		"Splunk",
		"Pagerduty",
		"Opsgenie",
		"Goldman",
		"Sachs",
		"Morgan",
		"Stanley",
		"Jpmorgan",
		"Citigroup",
		"Schneider",
		"Schroeder",
		"Pichai",
		"Nadella",
		"Altman",
		"Asml",
		"Tsmc",
		"Samsung",
		"Huawei",
		"Tencent",
		"Alibaba",
		"Bytedance",
		"Baidu",
		"Xiaomi",
		"S&P",
		"Nasdaq",
		"Nyse"
	]);
	function isSentenceStartMisident(term, fullText) {
		if (term.includes(" ")) return false;
		if (!/^[A-Z][a-z]+$/.test(term)) return false;
		if (KNOWN_BRANDS_AT_SENTENCE_START.has(term)) return false;
		if (KNOWN_BRANDS_AT_SENTENCE_START.has(term.toLowerCase())) return false;
		if (TECH_ANCHORS_LOWER.has(term.toLowerCase())) return false;
		if (TECH_PRODUCTS.has(term)) return false;
		if (TECH_PRODUCTS.has(term.toLowerCase())) return false;
		if (KNOWN_PUBLICATIONS.has(term.toLowerCase())) return false;
		const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		const matchRe = new RegExp(`\\b${escaped}\\b`, "g");
		if ((fullText.match(matchRe) || []).length >= 2) return false;
		return new RegExp(`(^|[.!?\\n]\\s*|\\A\\s*)${escaped}(?=\\s|$|[,;:])`).test(fullText);
	}
	var ACRONYM_BONUS = 1e3;
	var PROPER_NOUN_BONUS = 500;
	var LENGTH_WEIGHT = 10;
	var FREQUENCY_WEIGHT = 1;
	var MAX_GLOSSARY_TERMS = 50;
	function scoreTerm(term, fullText) {
		if (/^[A-Z]{2,6}$/.test(term)) return ACRONYM_BONUS + term.length * LENGTH_WEIGHT;
		const hasUpper = /[A-Z]/.test(term);
		const startsUpper = /^[A-Z]/.test(term);
		if (hasUpper && (startsUpper || /[a-z]/.test(term))) return PROPER_NOUN_BONUS + term.length * LENGTH_WEIGHT;
		const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		const regex = new RegExp(`(?<=^|[^a-zA-Z0-9_])${escaped}(?=[^a-zA-Z0-9_]|$)`, "gi");
		return (fullText.match(regex) || []).length * FREQUENCY_WEIGHT + term.length * LENGTH_WEIGHT * .1;
	}
	//#endregion
	//#region src/entrypoints/utils/translationQueue.ts
	var TranslationQueue = class {
		queue = [];
		running = 0;
		concurrency;
		maxRetries;
		retryDelay;
		constructor(concurrency = 4, maxRetries = 2, retryDelay = 1e3) {
			this.concurrency = concurrency;
			this.maxRetries = maxRetries;
			this.retryDelay = retryDelay;
		}
		async add(task) {
			return new Promise((resolve, reject) => {
				this.queue.push({
					task,
					resolve,
					reject,
					retries: 0
				});
				this.process();
			});
		}
		async process() {
			while (this.running < this.concurrency && this.queue.length > 0) {
				const item = this.queue.shift();
				if (!item) break;
				this.running++;
				try {
					const result = await item.task();
					item.resolve(result);
				} catch (error) {
					if (item.retries < this.maxRetries) {
						item.retries++;
						await this.delay(this.retryDelay * item.retries);
						this.queue.unshift(item);
					} else item.reject(error instanceof Error ? error : new Error(String(error)));
				} finally {
					this.running--;
					this.process();
				}
			}
		}
		delay(ms) {
			return new Promise((resolve) => setTimeout(resolve, ms));
		}
		setConcurrency(n) {
			this.concurrency = n;
			if (n > 0) this.process();
		}
		async addAllWithWarmup(tasks, warmupCount, maxConcurrency) {
			if (tasks.length === 0) return [];
			const results = [];
			for (let i = 0; i < Math.min(warmupCount, tasks.length); i++) results.push(await this.add(tasks[i]));
			if (tasks.length > warmupCount) {
				this.setConcurrency(maxConcurrency);
				const remaining = tasks.slice(warmupCount).map((t) => this.add(t));
				results.push(...await Promise.all(remaining));
			}
			return results;
		}
		get pendingCount() {
			return this.queue.length;
		}
		get runningCount() {
			return this.running;
		}
	};
	new TranslationQueue(1, 2, 1e3);
	//#endregion
	//#region src/entrypoints/utils/chunkRetry.ts
	/**
	* Decide whether a chunk translation should be retried.
	*
	* Used by translateChunksViaBackground (content.ts) to gate per-chunk
	* retry. Pure function — extracted here so it's testable in isolation
	* and the policy is documented in one place.
	*
	* Policy (revised after seeing 100% missing failures in the wild):
	*  - this isn't already a retry (cap recursion at 1)
	*  - there is something missing (missingCount > 0)
	*
	* That's it. We used to also reject when missing >= 50% (rationale:
	* "API is probably broken, retry is wasted budget"), but that heuristic
	* is wrong for the most common failure mode: API returns success with
	* an empty result (model refusal, JSON parse failure, transient network
	* glitch). In that case 100% of the chunk is missing — exactly the case
	* where we want a fresh API call rather than giving up. The retry chunk
	* is a smaller subset, so the cost is bounded; even if retry fails the
	* same way, the only damage is one extra round-trip logged.
	*
	* @param opts.missingCount how many blocks from this chunk were not
	*                          present in the API response
	* @param opts.totalCount   total blocks the chunk originally contained
	*                          (kept for API compatibility / future heuristics;
	*                          not used by the current policy)
	* @param opts.isRetry      true if this is already a retry attempt
	*/
	function shouldRetryMissing(opts) {
		const { missingCount, isRetry } = opts;
		if (isRetry) return false;
		if (missingCount <= 0) return false;
		return true;
	}
	/**
	* Pick the blocks that need to be re-translated, preserving the order
	* they appeared in the original chunk (so cache key + retries stay
	* deterministic).
	*/
	function pickMissingBlocks(blocks, missingIds) {
		const missingSet = new Set(missingIds);
		return blocks.filter((b) => missingSet.has(b.id));
	}
	/**
	* Build a fresh chunk containing only the blocks that were missing
	* from the parent's response. The retry chunk has:
	*  - id: `${parentChunk.id}_retry` so logs are easy to scan
	*  - blocks: subset in original order
	*  - jsonContent: re-serialized (DIFFERENT from parent's jsonContent,
	*    even if the block ids are the same) → bypasses translation cache
	*    and triggers a fresh API call
	*  - estimatedTokens: sum of block text length / 4 (consistent with
	*    chunkBuilder.estimateTokens)
	*/
	function buildRetryChunk(parentChunk, missingIds) {
		const retryBlocks = pickMissingBlocks(parentChunk.blocks, missingIds);
		const estimatedTokens = retryBlocks.reduce((sum, b) => sum + Math.ceil(b.text.length / 4), 0);
		return {
			id: `${parentChunk.id}_retry`,
			blocks: retryBlocks,
			jsonContent: JSON.stringify(retryBlocks.map((b) => ({
				id: b.id,
				text: b.text
			}))),
			estimatedTokens
		};
	}
	/**
	* Compute which block ids from the input were not present in the
	* response. Used right after parsing the API response to feed into
	* buildRetryChunk / shouldRetryMissing.
	*/
	function diffMissingIds(inputIds, outputIds) {
		const outputSet = new Set(outputIds);
		return inputIds.filter((id) => !outputSet.has(id));
	}
	//#endregion
	//#region src/entrypoints/utils/translationDisplay.ts
	/**
	* Wrap translation around an element without destroying its existing children.
	*
	* Why this matters: the previous implementation used `node.textContent = ''`
	* or `node.textContent = translatedText`, which destroyed any nested links,
	* images, inline formatting, etc. — making the original content unclickable.
	*
	* Now we move the existing child nodes into a `.fanyi-original` span, and
	* append a `.fanyi-translation` span alongside. The original DOM tree is
	* preserved untouched and can be restored by moving the children back in
	* `restoreBlock`.
	*
	* 始终使用双语对照模式 (original + translation 并排显示)。
	*/
	function applyBlockTranslation(node, translatedText) {
		if (node.classList.contains("fanyi-translated")) return;
		const originalText = node.textContent || "";
		node.classList.add("fanyi-translated");
		node.dataset.originalText = originalText;
		const originalSpan = document.createElement("span");
		originalSpan.className = "fanyi-original";
		while (node.firstChild) originalSpan.appendChild(node.firstChild);
		const translationSpan = document.createElement("span");
		translationSpan.className = "fanyi-translation";
		translationSpan.textContent = translatedText;
		node.appendChild(originalSpan);
		node.appendChild(translationSpan);
	}
	function restoreBlock(node) {
		const originalText = node.dataset.originalText;
		const originalSpan = node.querySelector(".fanyi-original");
		if (originalSpan) {
			while (originalSpan.firstChild) node.insertBefore(originalSpan.firstChild, originalSpan);
			originalSpan.remove();
		}
		const translationSpan = node.querySelector(".fanyi-translation");
		if (translationSpan) translationSpan.remove();
		if (originalText !== void 0 && !node.textContent) node.textContent = originalText;
		node.classList.remove("fanyi-translated");
		node.classList.remove("fanyi-missing");
		node.removeAttribute("title");
		delete node.dataset.originalText;
	}
	function toggleBlockTranslation(node) {
		const translationSpan = node.querySelector(".fanyi-translation");
		if (translationSpan) {
			const el = translationSpan;
			el.style.display = el.style.display === "none" ? "" : "none";
		}
	}
	//#endregion
	//#region src/entrypoints/content/chunkTranslation.ts
	/**
	* 把失败错误消息归入短分类标签，用于 [SessionSummary] 的
	* hardFailed 分桶统计。
	*/
	function categorizeError(msg) {
		if (!msg) return "other";
		if (msg.includes("HTTP 401")) return "401-auth";
		if (msg.includes("HTTP 403")) return "403-billing";
		if (msg.includes("HTTP 429")) return "429-rate-limit";
		if (msg.includes("HTTP 5")) return "5xx-server";
		if (msg.includes("HTTP 400")) return "400-bad-req";
		if (/HTTP 4\d\d/.test(msg)) return "4xx-other";
		if (msg.includes("网络请求失败") || msg.includes("fetch")) return "network";
		if (msg.includes("请求超时") || msg.includes("timeout")) return "timeout";
		if (msg.includes("Unexpected token") || msg.includes("JSON")) return "json-parse";
		if (msg.includes("缺少 choices[0].message.content")) return "invalid-resp";
		if (msg.includes("response body is null")) return "null-body";
		return "other";
	}
	/**
	* 批量发送 chunk 到 background，采用 warmup-then-parallel 策略：
	* 前 2 个串行（帮助 KV cache 构建），后续并行（桌面 4 / 移动 2）。
	*/
	async function translateChunksViaBackground(chunks, sourceLang, targetLang, nodeMap, glossary, onProgress, isMobile = false, state) {
		console.log("[ContentScript] translateChunksViaBackground called, chunks:", chunks.length);
		const maxConcurrency = isMobile ? 2 : 4;
		console.log(`[ContentScript] Warmup serial, then parallel=${maxConcurrency} (isMobile=${isMobile})`);
		const pool = new TranslationQueue(1, 0, 0);
		let completedCount = 0;
		let hasFailure = false;
		const applyPromises = [];
		const translatedIds = /* @__PURE__ */ new Set();
		const stats = {
			fullyOk: 0,
			neededRetry: 0,
			neededRetryRecovered: 0,
			neededRetryStillMissing: 0,
			hardFailed: 0,
			firstErrorMsg: "",
			errorsByCategory: {}
		};
		const tasks = chunks.map((chunk) => async () => {
			await translateChunkPayload(chunk, false, {
				nodeMap,
				sourceLang,
				targetLang,
				glossary,
				onFailure: () => {
					hasFailure = true;
				},
				onApply: (chunkMap) => applyPromises.push(applyTranslationsWithRAF(chunkMap, nodeMap, state)),
				onChunkComplete: (outcome, recovered, stillMissing, errMsg) => {
					if (outcome === "fully-ok") stats.fullyOk++;
					else if (outcome === "needed-retry") {
						stats.neededRetry++;
						stats.neededRetryRecovered += recovered;
						stats.neededRetryStillMissing += stillMissing;
					} else if (outcome === "hard-failed") {
						stats.hardFailed++;
						if (!stats.firstErrorMsg && errMsg) stats.firstErrorMsg = errMsg;
						const cat = categorizeError(errMsg || "");
						stats.errorsByCategory[cat] = (stats.errorsByCategory[cat] || 0) + 1;
					}
				},
				translatedIds
			});
			completedCount++;
			onProgress?.(completedCount, chunks.length);
		});
		await pool.addAllWithWarmup(tasks, 2, maxConcurrency);
		await Promise.all(applyPromises);
		const errorCatStr = Object.keys(stats.errorsByCategory).length > 0 ? " " + Object.entries(stats.errorsByCategory).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(",") : "";
		console.log(`[ContentScript][SessionSummary] total=${chunks.length} fullyOk=${stats.fullyOk} neededRetry=${stats.neededRetry}(recovered=${stats.neededRetryRecovered},stillMissing=${stats.neededRetryStillMissing}) hardFailed=${stats.hardFailed}${errorCatStr}` + (stats.firstErrorMsg ? ` firstError="${stats.firstErrorMsg.substring(0, 100)}"` : ""));
		return {
			allSucceeded: !hasFailure,
			translatedIds
		};
	}
	async function translateChunkPayload(chunk, isRetry, ctx) {
		const chunkMap = /* @__PURE__ */ new Map();
		const inputIds = chunk.blocks.map((b) => b.id);
		const label = isRetry ? `${chunk.id}(retry)` : chunk.id;
		let outerMissingCount = 0;
		let recoveredIds = [];
		try {
			const response = await import_browser_polyfill.default.runtime.sendMessage({
				action: "translateChunk",
				jsonContent: chunk.jsonContent,
				sourceLang: ctx.sourceLang,
				targetLang: ctx.targetLang,
				pageUrl: window.location.href,
				glossary: ctx.glossary
			});
			if (!response.success) {
				ctx.onFailure();
				console.error(`[ContentScript] ${label} translation FAILED — full response:`, {
					success: response.success,
					error: response.error,
					debugInfo: response.debugInfo ?? null,
					resultKeys: response.result ? Object.keys(response.result) : null,
					rawResponse: response
				});
				if (!isRetry) ctx.onChunkComplete("hard-failed", 0, 0, response.error || "unknown");
				return chunkMap;
			}
			const outputIds = [];
			for (const entry of response.result) {
				if (!Array.isArray(entry) || entry.length !== 2) {
					console.warn("[ContentScript]   Skipping malformed entry:", entry);
					continue;
				}
				const [id, text] = entry;
				if (typeof text !== "string") {
					console.warn(`[ContentScript]   Skipping block ${id}: translated_text is not a string (${typeof text})`);
					continue;
				}
				chunkMap.set(id, text);
				outputIds.push(id);
				ctx.translatedIds.add(id);
			}
			const chunkMissing = diffMissingIds(inputIds, outputIds);
			if (!isRetry) outerMissingCount = chunkMissing.length;
			const missingHint = chunkMissing.length > 0 ? ` (e.g. ${chunkMissing.slice(0, 3).join(",")}${chunkMissing.length > 3 ? `,+${chunkMissing.length - 3}` : ""})` : "";
			console.log(`[ContentScript][ChunkTrace] chunk=${label}`, `inputIds=[${inputIds.join(",")}]`, `outputIds=[${outputIds.join(",")}]`, `missing=${chunkMissing.length}${missingHint}`);
			if (chunkMissing.length > 0) {
				console.warn(`[ContentScript][ChunkTrace] chunk=${label} model returned ${outputIds.length}/${inputIds.length} entries — root cause in [Background][ChunkTrace] OUTPUT/MISSING`);
				if (response.trace) console.warn(`[ContentScript][ChunkTrace] chunk=${label} trace from background:\n` + JSON.stringify(response.trace, null, 2));
			}
			ctx.onApply(chunkMap);
			if (shouldRetryMissing({
				missingCount: chunkMissing.length,
				totalCount: chunk.blocks.length,
				isRetry
			})) {
				const retryChunk = buildRetryChunk(chunk, chunkMissing);
				console.log(`[ContentScript] ${label} missing ${chunkMissing.length} block(s), retrying as ${retryChunk.id}`);
				const retryMap = await translateChunkPayload(retryChunk, true, ctx);
				for (const id of retryMap.keys()) if (!ctx.translatedIds.has(id)) {
					ctx.translatedIds.add(id);
					recoveredIds.push(id);
				}
				console.log(`[ContentScript] ${label} retry recovered ${recoveredIds.length}/${chunkMissing.length} block(s)`);
			}
			if (!isRetry) if (outerMissingCount === 0) ctx.onChunkComplete("fully-ok", 0, 0);
			else {
				const stillMissing = Math.max(0, outerMissingCount - recoveredIds.length);
				ctx.onChunkComplete("needed-retry", recoveredIds.length, stillMissing);
			}
		} catch (error) {
			ctx.onFailure();
			console.error(`[ContentScript] ${label} threw — runtime/network error (no response):`, {
				name: error instanceof Error ? error.name : "unknown",
				message: error instanceof Error ? error.message : String(error),
				stack: error instanceof Error ? error.stack?.substring(0, 500) : null
			});
			if (!isRetry) {
				const msg = error instanceof Error ? error.message : String(error);
				ctx.onChunkComplete("hard-failed", 0, 0, msg);
			}
		}
		return chunkMap;
	}
	function applyTranslations(translationMap, nodeMap, state) {
		for (const [blockId, translatedText] of translationMap) {
			const node = nodeMap.get(blockId);
			if (!node || !(node instanceof HTMLElement)) continue;
			applyBlockTranslation(node, translatedText);
			if (state && state.translatedTexts) state.translatedTexts.set(blockId, translatedText);
		}
	}
	/**
	* 把译文写回 DOM：用 requestAnimationFrame 等下一帧批量应用，
	* 避免一次性 reflow 阻塞主线程。5s fallback 防止 hidden tab 时 rAF 不触发。
	*/
	function applyTranslationsWithRAF(translationMap, nodeMap, state) {
		return new Promise((resolve) => {
			let applied = false;
			const frameId = requestAnimationFrame(() => {
				applied = true;
				applyTranslations(translationMap, nodeMap, state);
				resolve();
			});
			setTimeout(() => {
				if (applied) return;
				cancelAnimationFrame(frameId);
				applyTranslations(translationMap, nodeMap, state);
				resolve();
			}, 5e3);
		});
	}
	//#endregion
	//#region src/entrypoints/content/serverTranslation.ts
	var MAX_FULL_HTML_CHARS = 9e5;
	/** 扩展端注入到 DOM 的 UI 选择器，发送 HTML 前需要移除。 */
	var EXTENSION_UI_SELECTORS = [
		".fanyi-status-overlay",
		".fanyi-floating-btn",
		".fanyi-config-panel",
		".selection-translator"
	];
	/**
	* 准备发送给服务端的 HTML：
	* 1. clone 当前 DOM，不影响用户正在看到的页面。
	* 2. 清理已有的双语译文结构（.fanyi-original / .fanyi-translation）。
	* 3. 清理扩展端 UI（状态提示、浮动按钮、配置面板等）。
	* 4. 保留 data-fanyi-block-id，让服务端能直接定位 block。
	*/
	function prepareHtmlForServer() {
		const clone = document.documentElement.cloneNode(true);
		for (const node of Array.from(clone.querySelectorAll(".fanyi-translated"))) {
			const el = node;
			const originalSpan = el.querySelector(".fanyi-original");
			if (originalSpan) {
				while (originalSpan.firstChild) el.insertBefore(originalSpan.firstChild, originalSpan);
				originalSpan.remove();
			}
			el.querySelector(".fanyi-translation")?.remove();
			el.classList.remove("fanyi-translated");
			delete el.dataset.originalText;
		}
		for (const node of Array.from(clone.querySelectorAll(".fanyi-missing"))) {
			const el = node;
			el.classList.remove("fanyi-missing");
			el.removeAttribute("title");
		}
		for (const selector of EXTENSION_UI_SELECTORS) for (const node of Array.from(clone.querySelectorAll(selector))) node.remove();
		const fullHtml = clone.outerHTML;
		const bodyHtml = clone.querySelector("body")?.outerHTML ?? fullHtml;
		return fullHtml.length > MAX_FULL_HTML_CHARS ? bodyHtml : fullHtml;
	}
	function getDefaultServerUrl(config) {
		return config.serverUrl?.trim() || "https://s.sunxiunan.com/fanyi/page";
	}
	/**
	* 查询服务端是否已有当前 URL 的翻译缓存。
	* @returns 命中的翻译后 HTML；未命中返回 null。
	*/
	async function checkServerCache(config) {
		const serverUrl = getDefaultServerUrl(config);
		const checkUrl = new URL(serverUrl);
		checkUrl.pathname = checkUrl.pathname.replace(/\/$/, "") + "/check";
		checkUrl.searchParams.set("url", window.location.href);
		checkUrl.searchParams.set("source", config.sourceLang || "en");
		checkUrl.searchParams.set("target", config.targetLang || "zh");
		const response = await fetch(checkUrl.toString(), { method: "GET" });
		if (!response.ok) throw new Error(`服务端缓存检查失败: ${response.status} ${response.statusText}`);
		if (response.status === 204) return null;
		return response.text();
	}
	/**
	* 解析服务端返回的双语对照 HTML，按 block id 回填到当前 DOM。
	*/
	function applyServerTranslatedHtml(translatedHtml, blocks, nodeMap) {
		const translatedDoc = new DOMParser().parseFromString(translatedHtml, "text/html");
		const translatedIds = /* @__PURE__ */ new Set();
		for (const block of blocks) {
			const el = translatedDoc.querySelector(`[data-fanyi-block-id="${block.id}"]`);
			if (!el) continue;
			const translatedText = el.querySelector(".fanyi-translation")?.textContent?.trim();
			if (!translatedText || translatedText === block.text) continue;
			const node = nodeMap.get(block.id);
			if (node instanceof HTMLElement) {
				applyBlockTranslation(node, translatedText);
				translatedIds.add(block.id);
			}
		}
		return translatedIds;
	}
	/**
	* 通过服务端翻译页面。
	* 发送包含 data-fanyi-block-id 的 HTML 到 /fanyi/page，
	* 解析返回的双语对照 HTML，提取 .fanyi-translation 文本并回填到当前 DOM。
	*/
	async function translateViaServer(config, blocks, nodeMap) {
		const serverUrl = getDefaultServerUrl(config);
		const url = window.location.href;
		const provider = config.provider || "deepseek";
		const apiKey = config.deepseekApiKey?.trim();
		if (provider === "deepseek" && !apiKey) throw new Error("DeepSeek API Key 未配置，服务端翻译（DeepSeek）需要 API Key");
		const html = prepareHtmlForServer();
		console.log(`[ServerTranslation] url=${url} provider=${provider} sentHtml=${html.length} bytes (bodyFallback=${html.startsWith("<body")})`);
		const body = {
			html,
			url,
			source: config.sourceLang,
			target: config.targetLang,
			mode: "bilingual",
			provider,
			promptStyle: config.promptStyle
		};
		if (provider === "deepseek" && apiKey) body.apiKey = apiKey;
		const response = await fetch(serverUrl, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body)
		});
		if (!response.ok) {
			const errorBody = await response.text().catch(() => "");
			console.error("[ServerTranslation] server error body:", errorBody);
			throw new Error(`服务端翻译失败: ${response.status} ${response.statusText}` + (errorBody ? ` — ${errorBody.substring(0, 500)}` : ""));
		}
		return applyServerTranslatedHtml(await response.text(), blocks, nodeMap);
	}
	//#endregion
	//#region src/entrypoints/utils/domObserver.ts
	var DOMObserverManager = class {
		mutationObserver = null;
		intersectionObserver = null;
		observedNodes = /* @__PURE__ */ new WeakMap();
		onNewContent;
		onNodeVisible;
		debounceTimer = null;
		debounceDelay;
		constructor(onNewContent, onNodeVisible, debounceDelay = 500) {
			this.onNewContent = onNewContent;
			this.onNodeVisible = onNodeVisible;
			this.debounceDelay = debounceDelay;
		}
		startMutationObserver(root = document) {
			this.stopMutationObserver();
			this.mutationObserver = new MutationObserver((mutations) => {
				this.handleMutations(mutations);
			});
			this.mutationObserver.observe(root, {
				childList: true,
				subtree: true,
				characterData: true
			});
		}
		stopMutationObserver() {
			if (this.mutationObserver) {
				this.mutationObserver.disconnect();
				this.mutationObserver = null;
			}
			if (this.debounceTimer) {
				clearTimeout(this.debounceTimer);
				this.debounceTimer = null;
			}
		}
		handleMutations(mutations) {
			if (this.debounceTimer) clearTimeout(this.debounceTimer);
			this.debounceTimer = window.setTimeout(() => {
				const newBlocks = [];
				for (const mutation of mutations) if (mutation.type === "childList") mutation.addedNodes.forEach((node) => {
					if (node.nodeType === Node.ELEMENT_NODE) {
						const blocks = this.extractBlocksFromNode(node);
						newBlocks.push(...blocks);
					}
				});
				else if (mutation.type === "characterData") {
					const target = mutation.target.parentElement;
					if (target && this.shouldProcessElement(target)) newBlocks.push({
						id: `dynamic_${Date.now()}`,
						xpath: "",
						tag: target.tagName.toLowerCase(),
						text: target.textContent?.trim() || ""
					});
				}
				if (newBlocks.length > 0) this.onNewContent(newBlocks);
			}, this.debounceDelay);
		}
		startIntersectionObserver(blocks, nodeMap, root = document) {
			this.stopIntersectionObserver();
			this.intersectionObserver = new IntersectionObserver((entries) => {
				for (const entry of entries) if (entry.isIntersecting) {
					const blockId = this.observedNodes.get(entry.target);
					if (blockId) {
						this.onNodeVisible(blockId, entry.target);
						this.intersectionObserver?.unobserve(entry.target);
						this.observedNodes.delete(entry.target);
					}
				}
			}, {
				root: null,
				rootMargin: "100px",
				threshold: .1
			});
			for (const block of blocks) {
				const node = nodeMap.get(block.id);
				if (node && node instanceof Element) {
					this.observedNodes.set(node, block.id);
					this.intersectionObserver.observe(node);
				}
			}
		}
		stopIntersectionObserver() {
			if (this.intersectionObserver) {
				this.intersectionObserver.disconnect();
				this.intersectionObserver = null;
			}
			this.observedNodes = /* @__PURE__ */ new WeakMap();
		}
		extractBlocksFromNode(element) {
			const blocks = [];
			const PROCESSABLE_TAGS = new Set([
				"P",
				"LI",
				"BLOCKQUOTE",
				"H1",
				"H2",
				"H3",
				"H4",
				"H5",
				"H6",
				"TD",
				"TH",
				"CAPTION",
				"FIGCAPTION",
				"LABEL",
				"LEGEND",
				"SPAN",
				"DIV",
				"SECTION",
				"ARTICLE",
				"MAIN"
			]);
			const IGNORE_TAGS = new Set([
				"SCRIPT",
				"STYLE",
				"NOSCRIPT",
				"CODE",
				"PRE",
				"SVG",
				"BUTTON",
				"NAV",
				"TEXTAREA",
				"INPUT",
				"SELECT",
				"HEADER",
				"FOOTER",
				"MENU",
				"DIALOG"
			]);
			function traverse(node) {
				if (node.nodeType !== Node.ELEMENT_NODE) return;
				const el = node;
				if (IGNORE_TAGS.has(el.tagName)) return;
				if (PROCESSABLE_TAGS.has(el.tagName)) {
					const text = el.textContent?.trim();
					const isGeneric = new Set([
						"DIV",
						"SPAN",
						"SECTION",
						"ARTICLE",
						"MAIN"
					]).has(el.tagName);
					if (text && text.length > (isGeneric ? 50 : 0)) blocks.push({
						id: `dynamic_${Date.now()}_${blocks.length}`,
						xpath: "",
						tag: el.tagName.toLowerCase(),
						text
					});
				}
				for (const child of Array.from(el.children)) traverse(child);
			}
			traverse(element);
			return blocks;
		}
		shouldProcessElement(element) {
			return new Set([
				"P",
				"LI",
				"BLOCKQUOTE",
				"H1",
				"H2",
				"H3",
				"H4",
				"H5",
				"H6",
				"TD",
				"TH",
				"CAPTION",
				"FIGCAPTION",
				"LABEL",
				"LEGEND",
				"SPAN",
				"DIV",
				"SECTION",
				"ARTICLE",
				"MAIN"
			]).has(element.tagName);
		}
		destroy() {
			this.stopMutationObserver();
			this.stopIntersectionObserver();
		}
	};
	//#endregion
	//#region src/entrypoints/content/translationUtils.ts
	async function retryGlobalMissing(blocks, nodeMap, translatedIds, config, isMobile) {
		const stillMissingIds = [];
		for (const [id] of nodeMap) if (!translatedIds.has(id)) stillMissingIds.push(id);
		if (stillMissingIds.length === 0) return;
		console.log(`[ContentScript] Global retry: ${stillMissingIds.length}/${nodeMap.size} blocks still missing`);
		showStatus(`补译 ${stillMissingIds.length} 段...`, "loading");
		const missingSet = new Set(stillMissingIds);
		const { translatedIds: retryTranslatedIds } = await translateChunksViaBackground(buildChunks(blocks.filter((b) => missingSet.has(b.id))), config.sourceLang, config.targetLang, nodeMap, {}, void 0, isMobile);
		let recoveredCount = 0;
		for (const id of retryTranslatedIds) if (!translatedIds.has(id)) {
			translatedIds.add(id);
			recoveredCount++;
		}
		console.log(`[ContentScript] Retry recovered ${recoveredCount}/${stillMissingIds.length} block(s)`);
	}
	function markMissingBlocks(nodeMap, translatedIds) {
		const missingIds = [];
		for (const [id, node] of nodeMap) {
			if (translatedIds.has(id)) continue;
			missingIds.push(id);
			if (node instanceof HTMLElement) {
				node.classList.add("fanyi-missing");
				node.title = "翻译响应中缺少该段落，点击扩展图标重新翻译";
			}
		}
		return missingIds;
	}
	function isPageTranslated() {
		return document.body?.dataset.fanyiTranslated === "true" || document.querySelector(".fanyi-translated") !== null || document.querySelector("[data-original-text]") !== null;
	}
	function warnOnNodeMapMismatch(blocks, nodeMap) {
		if (nodeMap.size === blocks.length) return;
		console.warn(`[ContentScript] NodeMap mismatch: ${nodeMap.size}/${blocks.length} blocks mapped to DOM. This usually means some blocks share an xpath and were collapsed — see extractors.`);
	}
	function saveOriginalTexts(blocks, nodeMap, state) {
		for (const block of blocks) {
			const node = nodeMap.get(block.id);
			if (node && node instanceof HTMLElement) state.originalTexts.set(block.id, node.textContent || "");
		}
	}
	function cleanupTempAttrs$1() {
		const tempAttrNodes = document.querySelectorAll("[data-fanyi-block-id]");
		for (const node of Array.from(tempAttrNodes)) {
			const el = node;
			delete el.dataset.fanyiBlockId;
		}
	}
	function restoreOriginal(state) {
		for (const node of Array.from(document.querySelectorAll(".fanyi-translated"))) restoreBlock(node);
		for (const node of Array.from(document.querySelectorAll(".fanyi-missing"))) {
			const el = node;
			el.classList.remove("fanyi-missing");
			el.removeAttribute("title");
		}
		cleanupTempAttrs$1();
		if (document.body) delete document.body.dataset.fanyiTranslated;
		if (state) {
			state.originalTexts.clear();
			state.translatedBlocks.clear();
			state.translatedTexts.clear();
		}
		updateButtonState(false);
		showStatus("已恢复原文", "success");
		setTimeout(hideStatus, 4e3);
	}
	function toggleTranslation() {
		for (const node of Array.from(document.querySelectorAll(".fanyi-translated"))) toggleBlockTranslation(node);
	}
	function setupDynamicContentObserver(state) {
		const observer = new DOMObserverManager(async (newBlocks) => {
			const config = await getConfig();
			for (const block of newBlocks) {
				if (!block.text || block.text.length <= 10) continue;
				try {
					const response = await import_browser_polyfill.default.runtime.sendMessage({
						action: "translateChunk",
						jsonContent: JSON.stringify([{
							id: block.id,
							text: block.text
						}]),
						sourceLang: config.sourceLang,
						targetLang: config.targetLang,
						pageUrl: window.location.href
					});
					if (response.success && response.result?.length > 0) {
						const node = findNodeByText(block.text);
						if (node) {
							applyBlockTranslation(node, response.result[0][1]);
							state.translatedBlocks.add(block.id);
						}
					}
				} catch (error) {
					console.error("Dynamic content translation failed:", error);
				}
			}
			reapplyLostTranslations(state);
		}, () => {}, 1500);
		observer.startMutationObserver();
		let scrollTimer = null;
		const onScroll = () => {
			if (scrollTimer) window.clearTimeout(scrollTimer);
			scrollTimer = window.setTimeout(() => {
				reapplyLostTranslations(state);
			}, 500);
		};
		window.addEventListener("scroll", onScroll, { passive: true });
		const originalStop = observer.stopMutationObserver.bind(observer);
		const originalDestroy = observer.destroy.bind(observer);
		observer.stopMutationObserver = () => {
			window.removeEventListener("scroll", onScroll);
			if (scrollTimer) window.clearTimeout(scrollTimer);
			originalStop();
		};
		observer.destroy = () => {
			window.removeEventListener("scroll", onScroll);
			if (scrollTimer) window.clearTimeout(scrollTimer);
			originalDestroy();
		};
		return observer;
	}
	/**
	* 恢复被 React/Next.js 重新渲染覆盖的翻译。
	*
	* 某些前端框架（如 Next.js App Router）会在滚动或交互后重新渲染 DOM，
	* 把我们插入的 .fanyi-translation / .fanyi-original 等节点清除掉。
	* 这里根据保存的 originalTexts + translatedTexts 映射，重新把译文应用回去。
	*/
	function reapplyLostTranslations(state) {
		if (state.originalTexts.size === 0 || state.translatedTexts.size === 0) return;
		const textToIds = /* @__PURE__ */ new Map();
		for (const [blockId, originalText] of state.originalTexts) {
			const list = textToIds.get(originalText);
			if (list) list.push(blockId);
			else textToIds.set(originalText, [blockId]);
		}
		const REAPPLYABLE_TAGS = new Set([
			"P",
			"LI",
			"DD",
			"BLOCKQUOTE",
			"FIGCAPTION",
			"H1",
			"H2",
			"H3",
			"H4",
			"H5",
			"H6"
		]);
		const candidates = document.querySelectorAll(Array.from(REAPPLYABLE_TAGS).join(","));
		let reapplied = 0;
		for (const el of Array.from(candidates)) {
			if (!(el instanceof HTMLElement)) continue;
			if (el.classList.contains("fanyi-translated")) continue;
			const text = (el.textContent || "").trim();
			if (!text) continue;
			const ids = textToIds.get(text);
			if (!ids || ids.length === 0) continue;
			for (const blockId of ids) {
				const translated = state.translatedTexts.get(blockId);
				if (translated) {
					applyBlockTranslation(el, translated);
					reapplied++;
					break;
				}
			}
		}
		if (reapplied > 0) console.log(`[ContentScript] Reapplied ${reapplied} lost translation(s)`);
	}
	function findNodeByText(text) {
		const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, { acceptNode: (node) => {
			const el = node;
			if (el.classList.contains("fanyi-translated")) return NodeFilter.FILTER_REJECT;
			if (el.textContent?.trim() === text) return NodeFilter.FILTER_ACCEPT;
			return NodeFilter.FILTER_SKIP;
		} });
		let current;
		while (current = walker.nextNode()) if (current.textContent?.trim() === text) return current;
		return null;
	}
	//#endregion
	//#region src/entrypoints/content/translation.ts
	function createTranslationController(isMobile, state) {
		let isTranslating = false;
		let isTranslatedState = false;
		const ctx = { isMobile };
		return {
			async start() {
				if (isTranslating) return;
				if (isTranslatedState || isPageTranslated()) {
					showStatus("页面已翻译", "success");
					setTimeout(hideStatus, 4e3);
					return;
				}
				const config = await getConfig();
				if ((!config.useServerTranslation || config.provider === "deepseek") && !config.deepseekApiKey) {
					showStatus("API Key 没有配置", "error");
					setTimeout(hideStatus, 5e3);
					return;
				}
				isTranslating = true;
				showStatus("正在提取文本...", "loading");
				try {
					const result = await handleFullTranslation(config, ctx.isMobile, state, (observer) => {});
					isTranslatedState = result.translated;
					if (result.observer) result.observer;
				} catch (error) {
					console.error("Translation failed:", error);
					showStatus(error instanceof Error ? error.message : "翻译失败", "error");
				} finally {
					isTranslating = false;
				}
			},
			restore() {
				isTranslatedState = false;
				restoreOriginal(state);
			},
			toggle() {
				toggleTranslation();
			},
			isTranslated() {
				return isTranslatedState || isPageTranslated();
			}
		};
	}
	async function handleFullTranslation(config, isMobile, state, setObserver) {
		if (isPageTranslated()) {
			console.log("[ContentScript] Page already translated, skip sending request.");
			return {
				translated: true,
				observer: null
			};
		}
		const siteRule = matchSiteRule(window.location.href)?.siteRule;
		const forceDirect = siteRule?.forceDirectTranslation === true;
		const skipGlossary = siteRule?.skipGlossary === true;
		const useServer = config.useServerTranslation && !forceDirect;
		let cachedHtml = null;
		if (useServer) {
			showStatus("正在检查服务端缓存...", "loading");
			try {
				cachedHtml = await checkServerCache(config);
				if (cachedHtml) console.log("[ContentScript] Server cache hit, skip heavy HTML preparation.");
			} catch (e) {
				console.error("[ContentScript] Server cache check failed:", e);
			}
		}
		const { blocks, chunks, fullText } = prepareDocument(document);
		if (blocks.length === 0) throw new Error("没有找到可翻译的内容");
		showStatus(`共 ${blocks.length} 个文本块`, "loading");
		const nodeMap = buildNodeMap(blocks, document);
		warnOnNodeMapMismatch(blocks, nodeMap);
		saveOriginalTexts(blocks, nodeMap, state);
		if (useServer) {
			let translatedIds;
			if (cachedHtml) {
				showStatus("正在应用服务端缓存...", "loading");
				translatedIds = applyServerTranslatedHtml(cachedHtml, blocks, nodeMap);
			} else {
				showStatus("正在发送到服务端翻译...", "loading");
				translatedIds = await translateViaServer(config, blocks, nodeMap);
			}
			const missingIds = markMissingBlocks(nodeMap, translatedIds);
			updateButtonState(true);
			cleanupTempAttrs();
			console.log(`[ContentScript] Server translation end: ${nodeMap.size} blocks total, ${translatedIds.size} translated, ${missingIds.length} missing`);
			showStatus(missingIds.length > 0 ? `翻译完成（${missingIds.length} 段未返回）` : "翻译完成", "success");
			setTimeout(hideStatus, 5e3);
			if (document.body) document.body.dataset.fanyiTranslated = "true";
			return {
				translated: true,
				observer: null
			};
		}
		const glossary = skipGlossary ? {} : await extractGlossary(fullText);
		showStatus(`翻译进度: 0/${chunks.length}`, "loading");
		const { translatedIds } = await translateChunksViaBackground(chunks, config.sourceLang, config.targetLang, nodeMap, glossary, (current, total) => showStatus(`翻译进度: ${current}/${total}`, "loading"), isMobile, state);
		await retryGlobalMissing(blocks, nodeMap, translatedIds, config, isMobile);
		const missingIds = markMissingBlocks(nodeMap, translatedIds);
		updateButtonState(true);
		const observer = setupDynamicContentObserver(state);
		setObserver(observer);
		cleanupTempAttrs();
		console.log(`[ContentScript] Session end: ${nodeMap.size} blocks total, ${translatedIds.size} translated, ${missingIds.length} missing`);
		showStatus(missingIds.length > 0 ? `翻译完成（${missingIds.length} 段未返回，可重试）` : "翻译完成", "success");
		setTimeout(hideStatus, 5e3);
		if (document.body) document.body.dataset.fanyiTranslated = "true";
		return {
			translated: true,
			observer
		};
	}
	async function extractGlossary(fullText) {
		if (fullText.length < 50) return {};
		showStatus("正在提取术语表...", "loading");
		try {
			const emphasizedTerms = [];
			for (const tag of [
				"em",
				"strong",
				"code"
			]) for (const el of document.querySelectorAll(tag)) {
				const text = el.textContent?.trim();
				if (text && text.length > 1 && text.length < 80) emphasizedTerms.push(text);
			}
			return extractGlossaryLocal(fullText.substring(0, 4e3), emphasizedTerms);
		} catch {
			return {};
		}
	}
	function cleanupTempAttrs() {
		const tempAttrNodes = document.querySelectorAll("[data-fanyi-block-id]");
		for (const node of Array.from(tempAttrNodes)) {
			const el = node;
			delete el.dataset.fanyiBlockId;
		}
	}
	//#endregion
	//#region src/entrypoints/content/youtube/provider.ts
	var PLAYER_DATA_REQUEST_TYPE = "FANYI_YT_PLAYER_DATA_REQUEST";
	var PLAYER_DATA_RESPONSE_TYPE = "FANYI_YT_PLAYER_DATA_RESPONSE";
	var WAIT_TIMEDTEXT_REQUEST_TYPE = "FANYI_YT_WAIT_TIMEDTEXT_REQUEST";
	var WAIT_TIMEDTEXT_RESPONSE_TYPE = "FANYI_YT_WAIT_TIMEDTEXT_RESPONSE";
	var ENSURE_SUBTITLES_REQUEST_TYPE = "FANYI_YT_ENSURE_SUBTITLES_REQUEST";
	var ENSURE_SUBTITLES_RESPONSE_TYPE = "FANYI_YT_ENSURE_SUBTITLES_RESPONSE";
	var DISABLE_NATIVE_CAPTIONS_REQUEST_TYPE = "FANYI_YT_DISABLE_NATIVE_CAPTIONS_REQUEST";
	var DISABLE_NATIVE_CAPTIONS_RESPONSE_TYPE = "FANYI_YT_DISABLE_NATIVE_CAPTIONS_RESPONSE";
	var POST_MESSAGE_TIMEOUT_MS = 5e3;
	var MAX_FETCH_RETRIES = 3;
	var FETCH_RETRY_DELAY_MS = 500;
	var MAX_POT_WAIT_ATTEMPTS = 10;
	var POT_WAIT_INTERVAL_MS = 500;
	var MAX_STATE_WAIT_ATTEMPTS = 20;
	var STATE_WAIT_INTERVAL_MS = 250;
	/**
	* 从 URL 提取 YouTube videoId。
	*
	* YouTube watch URL 格式：`https://www.youtube.com/watch?v=VIDEO_ID`
	* 用于 SPA 导航检测。
	*
	* @param url 可选 URL，默认用 window.location.href
	* @returns videoId 或 null（非 watch 页或无 v 参数）
	*/
	function extractVideoId(url = typeof window !== "undefined" ? window.location.href : "") {
		try {
			const parsed = new URL(url);
			if (parsed.hostname !== "www.youtube.com") return null;
			return parsed.searchParams.get("v");
		} catch {
			return null;
		}
	}
	/**
	* 抓取当前 YouTube 视频的字幕事件列表。
	*
	* 流程：
	*   1. 向 MAIN world 请求 player data
	*   2. 选择最佳字幕轨道
	*   3. 尝试快速抓取（已有 POT）
	*   4. 必要时开启 CC 并等待 timedtext URL
	*   5. 解析为 CaptionEvent[]
	*
	* @param videoId YouTube videoId
	* @returns 按时间排序的字幕事件数组
	*/
	async function fetchCaptions(videoId) {
		const fastPath = await tryFastFetch(videoId);
		let resolvedTrack = fastPath.track;
		let events = fastPath.events;
		if (!events) {
			const fallback = await fetchWithFallback(videoId, fastPath.track);
			resolvedTrack = fallback.track;
			events = fallback.events;
		}
		if (!resolvedTrack || !events) throw new Error("未找到可用字幕");
		return processRawEvents(events, resolvedTrack.languageCode).map((f, idx) => ({
			id: String(idx),
			startMs: f.start,
			durationMs: f.end - f.start,
			text: f.text,
			status: "pending"
		}));
	}
	/**
	* 请求 MAIN world 注入脚本关闭 YouTube 原生字幕显示。
	*
	* 在我们开始显示翻译字幕后，原生的英文字幕不再需要，关闭它避免重复显示。
	*
	* @returns 是否成功发送关闭请求
	*/
	async function disableNativeCaptions() {
		try {
			return (await postMessageRequest(DISABLE_NATIVE_CAPTIONS_RESPONSE_TYPE, { type: DISABLE_NATIVE_CAPTIONS_REQUEST_TYPE }))?.success === true;
		} catch {
			return false;
		}
	}
	function postMessageRequest(responseType, message) {
		return new Promise((resolve) => {
			const requestId = cryptoRandomUUID();
			const handler = (event) => {
				if (event.origin !== window.location.origin || event.data?.type !== responseType || event.data?.requestId !== requestId) return;
				window.removeEventListener("message", handler);
				resolve(event.data);
			};
			window.addEventListener("message", handler);
			window.postMessage({
				...message,
				requestId
			}, window.location.origin);
			setTimeout(() => {
				window.removeEventListener("message", handler);
				resolve(null);
			}, POST_MESSAGE_TIMEOUT_MS);
		});
	}
	function cryptoRandomUUID() {
		if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
		return String(Date.now()) + "-" + Math.random().toString(36).slice(2);
	}
	async function requestPlayerData(videoId) {
		const resp = await postMessageRequest(PLAYER_DATA_RESPONSE_TYPE, {
			type: PLAYER_DATA_REQUEST_TYPE,
			expectedVideoId: videoId
		});
		if (!resp) return {
			type: PLAYER_DATA_RESPONSE_TYPE,
			requestId: "",
			success: false,
			error: "TIMEOUT"
		};
		return {
			type: PLAYER_DATA_RESPONSE_TYPE,
			requestId: resp.requestId,
			success: resp.success,
			error: resp.error,
			data: resp.data
		};
	}
	async function waitForTimedtextUrl(videoId) {
		return (await postMessageRequest(WAIT_TIMEDTEXT_RESPONSE_TYPE, {
			type: WAIT_TIMEDTEXT_REQUEST_TYPE,
			videoId
		}))?.url ?? null;
	}
	async function ensureSubtitlesEnabled() {
		await postMessageRequest(ENSURE_SUBTITLES_RESPONSE_TYPE, { type: ENSURE_SUBTITLES_REQUEST_TYPE });
	}
	async function tryFastFetch(videoId) {
		const response = await requestPlayerData(videoId);
		if (!response.success || !response.data) return {
			track: null,
			events: null
		};
		const playerData = response.data;
		const track = selectTrack(playerData);
		if (!track) return {
			track: null,
			events: null
		};
		try {
			return {
				track,
				events: await fetchTrackEvents(track, playerData)
			};
		} catch {
			return {
				track,
				events: null
			};
		}
	}
	async function fetchWithFallback(videoId, preferredTrack) {
		await waitForPlayerState(videoId);
		const playerData = await getPlayerDataWithPot(videoId);
		const track = selectTrack(playerData) ?? preferredTrack;
		if (!track) throw new Error("未找到可用字幕轨道");
		return {
			track,
			events: await fetchTrackEvents(track, playerData)
		};
	}
	async function waitForPlayerState(videoId) {
		for (let i = 0; i < MAX_STATE_WAIT_ATTEMPTS; i++) {
			const response = await requestPlayerData(videoId);
			if (response.success && response.data && response.data.playerState >= 1) return;
			await sleep(STATE_WAIT_INTERVAL_MS);
		}
	}
	async function getPlayerDataWithPot(videoId) {
		const response = await requestPlayerData(videoId);
		if (!response.success || !response.data) throw new Error("获取播放器数据超时");
		let playerData = response.data;
		if (hasPotInAudioTracks(playerData) || playerData.cachedTimedtextUrl) return playerData;
		if (playerData.captionTracks.length === 0) return playerData;
		await ensureSubtitlesEnabled();
		for (let i = 0; i < MAX_POT_WAIT_ATTEMPTS; i++) {
			await sleep(POT_WAIT_INTERVAL_MS);
			const pollResponse = await requestPlayerData(videoId);
			if (pollResponse.success && pollResponse.data) {
				playerData = pollResponse.data;
				if (hasPotInAudioTracks(playerData) || playerData.cachedTimedtextUrl) return playerData;
			}
		}
		const timedtextUrl = await waitForTimedtextUrl(videoId);
		if (timedtextUrl) playerData.cachedTimedtextUrl = timedtextUrl;
		return playerData;
	}
	function hasPotInAudioTracks(playerData) {
		return playerData.audioCaptionTracks.some((t) => {
			try {
				return new URL(t.url).searchParams.has("pot");
			} catch {
				return false;
			}
		});
	}
	async function fetchTrackEvents(track, playerData) {
		return fetchWithRetry(buildSubtitleUrl(track, playerData, extractPotToken(track, playerData)));
	}
	async function fetchWithRetry(url) {
		let lastError = null;
		for (let i = 0; i < MAX_FETCH_RETRIES; i++) try {
			const response = await fetch(url);
			if (!response.ok) {
				const status = response.status;
				if (status === 403) throw new Error("HTTP 403: 字幕请求被拒绝");
				if (status === 404) throw new Error("HTTP 404: 字幕不存在");
				if (status === 429) throw new Error("HTTP 429: 请求过于频繁");
				throw new Error(`HTTP ${status}`);
			}
			return (await response.json())?.events ?? [];
		} catch (e) {
			const err = e instanceof Error ? e : new Error(String(e));
			if (err.message.startsWith("HTTP 403") || err.message.startsWith("HTTP 404") || err.message.startsWith("HTTP 429")) throw err;
			lastError = err;
			if (i < MAX_FETCH_RETRIES - 1) await sleep(FETCH_RETRY_DELAY_MS);
		}
		throw lastError ?? /* @__PURE__ */ new Error("获取字幕失败");
	}
	function sleep(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	/**
	* 选择最佳字幕轨道。
	*
	* 优先级：
	*   1. 用户当前在 YouTube 播放器中选中的轨道
	*   2. 人工字幕（非 ASR），无 name 的原始语言字幕
	*   3. 人工字幕（非 ASR）
	*   4. 自动生成的 ASR 字幕
	*   5. 第一条可用轨道
	*/
	function selectTrack(playerData) {
		const { captionTracks: tracks, selectedTrackLanguageCode, selectedTrackVssId } = playerData;
		if (tracks.length === 0) return null;
		if (selectedTrackVssId) {
			const selected = tracks.find((t) => t.vssId === selectedTrackVssId);
			if (selected) return selected;
		}
		if (selectedTrackLanguageCode) {
			const selected = tracks.find((t) => t.languageCode === selectedTrackLanguageCode);
			if (selected) return selected;
		}
		const humanExact = tracks.find((t) => t.kind !== "asr" && !t.name);
		if (humanExact) return humanExact;
		const humanWithName = tracks.find((t) => t.kind !== "asr");
		if (humanWithName) return humanWithName;
		const asr = tracks.find((t) => t.kind === "asr");
		if (asr) return asr;
		return tracks[0];
	}
	function extractPotToken(selectedTrack, playerData) {
		const { audioCaptionTracks, cachedTimedtextUrl } = playerData;
		if (audioCaptionTracks.length > 0) {
			let matchedTrack = audioCaptionTracks.find((t) => t.vssId === selectedTrack.vssId);
			if (!matchedTrack) matchedTrack = audioCaptionTracks.find((t) => t.languageCode === selectedTrack.languageCode && t.kind === selectedTrack.kind);
			if (!matchedTrack) matchedTrack = audioCaptionTracks.find((t) => t.languageCode === selectedTrack.languageCode);
			if (!matchedTrack) matchedTrack = audioCaptionTracks[0];
			if (matchedTrack?.url) try {
				const url = new URL(matchedTrack.url);
				const pot = url.searchParams.get("pot");
				const potc = url.searchParams.get("potc");
				if (pot) return {
					pot,
					potc
				};
			} catch {}
		}
		if (cachedTimedtextUrl) try {
			const url = new URL(cachedTimedtextUrl);
			const pot = url.searchParams.get("pot");
			const potc = url.searchParams.get("potc");
			if (pot) return {
				pot,
				potc
			};
		} catch {}
		return {
			pot: null,
			potc: null
		};
	}
	var DEVICE_PARAM_KEYS = [
		"cbrand",
		"cbr",
		"cbrver",
		"cos",
		"cosver",
		"cplatform"
	];
	var FIXED_PARAMS = {
		fmt: "json3",
		xorb: "2",
		xobt: "3",
		xovt: "3",
		c: "WEB",
		cplayer: "UNIPLAYER"
	};
	function buildSubtitleUrl(track, playerData, potToken) {
		const url = new URL(track.baseUrl);
		Object.entries(FIXED_PARAMS).forEach(([key, value]) => {
			url.searchParams.set(key, value);
		});
		if (playerData.device) {
			const deviceParams = new URLSearchParams(playerData.device);
			DEVICE_PARAM_KEYS.forEach((key) => {
				const value = deviceParams.get(key);
				if (value) url.searchParams.set(key, value);
			});
		}
		if (playerData.cver) url.searchParams.set("cver", playerData.cver);
		if (potToken.pot) url.searchParams.set("pot", potToken.pot);
		if (potToken.potc) url.searchParams.set("potc", potToken.potc);
		return url.toString();
	}
	var ZERO_WIDTH_SPACE_PATTERN = /\u200B/g;
	var SLASH_PATTERN = /\//g;
	var KANJI_TRACK_ID = 3;
	var WHITESPACE_PATTERN = /\s+/g;
	var SENTENCE_END_PATTERN = /[,.。?？！!；;…؟۔\n]$/;
	var ESTIMATED_WORD_DURATION_MS = 200;
	var MAX_CHARS_CJK = 30;
	var MAX_WORDS = 15;
	function isCJKLanguage(lang) {
		if (!lang) return false;
		return [
			"zh",
			"ja",
			"ko",
			"th",
			"lo",
			"km",
			"my"
		].some((l) => lang.startsWith(l));
	}
	function getTextLength(text, isCJK) {
		if (isCJK) return text.length;
		return text.split(WHITESPACE_PATTERN).filter(Boolean).length;
	}
	function getMaxLength(isCJK) {
		return isCJK ? MAX_CHARS_CJK : MAX_WORDS;
	}
	function getEventText(event) {
		return (event.segs ?? []).map((seg) => seg.utf8 || "").join("");
	}
	function cleanEventText(text) {
		return text.replace(ZERO_WIDTH_SPACE_PATTERN, "").replace(WHITESPACE_PATTERN, " ").trim();
	}
	function detectFormat(events) {
		if (!events || events.length === 0) return "standard";
		if (isAnimatedFormat(events)) return "animated";
		if (isStylizedKaraokeFormat(events)) return "karaoke-stylized";
		if (isKaraokeFormat(events)) return "karaoke";
		if (isScrollingAsrFormat(events)) return "scrolling-asr";
		return "standard";
	}
	function isAnimatedFormat(events) {
		const ANIMATED_DURATION_THRESHOLD_MS = 100;
		const ANIMATED_MIN_EVENTS = 50;
		const ANIMATED_SHORT_DURATION_RATIO = .5;
		if (events.length < ANIMATED_MIN_EVENTS) return false;
		let shortWithPos = 0;
		for (const event of events) if (event.wpWinPosId !== void 0 && (event.dDurationMs ?? 0) <= ANIMATED_DURATION_THRESHOLD_MS) shortWithPos += 1;
		return shortWithPos / events.length >= ANIMATED_SHORT_DURATION_RATIO;
	}
	function isKaraokeFormat(events) {
		if (events.length < 2) return false;
		const groupsByTime = /* @__PURE__ */ new Map();
		for (const event of events) {
			if (event.wpWinPosId === void 0) continue;
			const group = groupsByTime.get(event.tStartMs) ?? /* @__PURE__ */ new Set();
			group.add(event.wpWinPosId);
			if (group.size > 1) return true;
			groupsByTime.set(event.tStartMs, group);
		}
		return false;
	}
	function isStylizedKaraokeFormat(events) {
		if (events.length < 4) return false;
		const STYLIZED_GAP_MS = 400;
		const MIN_STYLIZED_MATCHES = 3;
		function normalizeStylizedText(text) {
			return cleanEventText(text).replace(SLASH_PATTERN, "").replace(WHITESPACE_PATTERN, " ").trim().toLowerCase();
		}
		const tracks = /* @__PURE__ */ new Map();
		for (const event of events) {
			if (event.wpWinPosId === void 0) continue;
			const arr = tracks.get(event.wpWinPosId);
			if (arr) arr.push(event);
			else tracks.set(event.wpWinPosId, [event]);
		}
		for (const trackEvents of tracks.values()) {
			if (trackEvents.length < 4) continue;
			let stylizedMatches = 0;
			let previousNormalized = "";
			let previousTime = 0;
			for (const event of trackEvents) {
				const rawText = getEventText(event);
				const cleanedText = cleanEventText(rawText);
				const normalizedText = normalizeStylizedText(rawText);
				if (!cleanedText || !normalizedText) continue;
				const hasStylizedMarkers = rawText.includes("/") || rawText.includes("​");
				const isDuplicateOrExpansion = previousNormalized.length > 0 && event.tStartMs - previousTime <= STYLIZED_GAP_MS && (normalizedText === previousNormalized || normalizedText.startsWith(previousNormalized) || previousNormalized.startsWith(normalizedText));
				if (hasStylizedMarkers && isDuplicateOrExpansion) {
					stylizedMatches += 1;
					if (stylizedMatches >= MIN_STYLIZED_MATCHES) return true;
				}
				previousNormalized = normalizedText;
				previousTime = event.tStartMs;
			}
		}
		return false;
	}
	function isScrollingAsrFormat(events) {
		return events.some((event) => event.wWinId !== void 0 && event.aAppend === 1);
	}
	var NOISE_PATTERNS = [
		/\[.*?\]/g,
		/\(.*?\)/g,
		/♪.*?♪/g,
		/🎵.*?🎵/g,
		/🎶.*?🎶/g
	];
	function filterNoiseText(text) {
		let result = text;
		for (const pattern of NOISE_PATTERNS) result = result.replace(pattern, "");
		return result;
	}
	function filterNoiseFromEvents(events) {
		return events.map((event) => {
			if (!event.segs) return event;
			const filteredSegs = event.segs.map((seg) => ({
				...seg,
				utf8: filterNoiseText(seg.utf8)
			})).filter((seg) => seg.utf8.trim().length > 0);
			return {
				...event,
				segs: filteredSegs
			};
		});
	}
	function processRawEvents(events, languageCode) {
		const filteredEvents = filterNoiseFromEvents(events);
		switch (detectFormat(filteredEvents)) {
			case "karaoke": return parseKaraokeSubtitles(filteredEvents);
			case "karaoke-stylized": return parseStylizedKaraokeSubtitles(filteredEvents);
			case "animated": return parseAnimatedSubtitles(filteredEvents);
			case "scrolling-asr": return parseScrollingAsrSubtitles(filteredEvents, languageCode);
			default: return parseStandardSubtitles(filteredEvents);
		}
	}
	function parseStandardSubtitles(events = []) {
		const segments = [];
		let buffer = null;
		events.forEach(({ segs = [], tStartMs = 0, dDurationMs = 0 }) => {
			segs.forEach(({ utf8 = "", tOffsetMs = 0 }, segIndex) => {
				const text = utf8.trim().replace(WHITESPACE_PATTERN, " ");
				const start = tStartMs + tOffsetMs;
				if (buffer) {
					if (!buffer.end || buffer.end > start) buffer.end = start;
					segments.push(buffer);
					buffer = null;
				}
				buffer = {
					text,
					start,
					end: 0
				};
				if (segIndex === segs.length - 1) buffer.end = tStartMs + dDurationMs;
			});
		});
		if (buffer) segments.push(buffer);
		return segments;
	}
	function parseScrollingAsrSubtitles(events, lang) {
		const result = [];
		const isSpaceSeparated = lang?.startsWith("en") || false;
		const isCJK = isCJKLanguage(lang);
		const maxLength = getMaxLength(isCJK);
		let currentText = "";
		let currentStart = 0;
		let lastSegEnd = 0;
		let isFirstSeg = true;
		let pendingSplit = false;
		function isSpecialTag(text) {
			return text.startsWith("[") && text.endsWith("]");
		}
		function pushFragment(fragment) {
			const last = result.at(-1);
			if (last && last.end > fragment.start) last.end = fragment.start;
			result.push(fragment);
		}
		function flushPendingFragment() {
			const trimmed = currentText.trim();
			if (trimmed && !isSpecialTag(trimmed)) {
				pushFragment({
					text: trimmed,
					start: currentStart,
					end: lastSegEnd
				});
				return true;
			}
			return false;
		}
		for (const event of events) {
			if (event.aAppend === 1) {
				if (currentText) {
					lastSegEnd = event.tStartMs + (event.dDurationMs || 0);
					if (pendingSplit) {
						flushPendingFragment();
						currentText = "";
						isFirstSeg = true;
						pendingSplit = false;
					}
				}
				continue;
			}
			if (!event.segs || event.segs.length === 0) continue;
			if (pendingSplit && currentText) {
				flushPendingFragment();
				currentText = "";
				isFirstSeg = true;
				pendingSplit = false;
			}
			const segs = event.segs;
			for (let i = 0; i < segs.length; i++) {
				const seg = segs[i];
				const text = seg.utf8 || "";
				const offsetMs = seg.tOffsetMs || 0;
				const segStart = event.tStartMs + offsetMs;
				if (pendingSplit && currentText) {
					flushPendingFragment();
					currentText = "";
					isFirstSeg = true;
					pendingSplit = false;
				}
				if (isFirstSeg && text.trim()) {
					currentStart = segStart;
					isFirstSeg = false;
				}
				if (isSpaceSeparated && currentText && text && i === 0) {
					if (!currentText.endsWith(" ") && !text.startsWith(" ")) currentText += " ";
				}
				currentText += text;
				lastSegEnd = segStart + ESTIMATED_WORD_DURATION_MS;
				const isSentenceEnd = SENTENCE_END_PATTERN.test(text.trim());
				const textLength = getTextLength(currentText, isCJK);
				if (isSentenceEnd || textLength >= maxLength) pendingSplit = true;
			}
		}
		flushPendingFragment();
		return result;
	}
	function cleanKaraokeText(text) {
		return text.replace(ZERO_WIDTH_SPACE_PATTERN, "").replace(WHITESPACE_PATTERN, " ").trim();
	}
	function parseKaraokeSubtitles(events) {
		const posIds = /* @__PURE__ */ new Set();
		for (const event of events) if (event.wpWinPosId !== void 0) posIds.add(event.wpWinPosId);
		const mainTrackId = posIds.has(KANJI_TRACK_ID) ? KANJI_TRACK_ID : Math.max(...posIds);
		const merged = [];
		for (const event of events) {
			if (event.wpWinPosId !== mainTrackId) continue;
			if (!event.segs || event.segs.length === 0) continue;
			const text = cleanKaraokeText(event.segs.map((seg) => seg.utf8 || "").join(""));
			if (!text) continue;
			const last = merged.at(-1);
			if (last && last.end > event.tStartMs) last.end = event.tStartMs;
			merged.push({
				text,
				start: event.tStartMs,
				end: event.tStartMs + (event.dDurationMs ?? 0)
			});
		}
		const result = [];
		for (const fragment of merged) {
			const last = result.at(-1);
			if (last && last.text === fragment.text) last.end = fragment.end;
			else result.push({ ...fragment });
		}
		return result;
	}
	function parseStylizedKaraokeSubtitles(events) {
		const FAMILY_GAP_MS = 1200;
		const MIN_PREFIX_LENGTH = 10;
		function selectMainTrack() {
			const statsByTrack = /* @__PURE__ */ new Map();
			for (const event of events) {
				if (event.wpWinPosId === void 0) continue;
				const rawText = getEventText(event);
				const cleanedText = cleanEventText(rawText);
				if (!cleanedText) continue;
				const current = statsByTrack.get(event.wpWinPosId) ?? {
					trackId: event.wpWinPosId,
					eventCount: 0,
					markerCount: 0,
					textLength: 0
				};
				current.eventCount += 1;
				current.textLength += cleanedText.length;
				if (rawText.includes("/") || rawText.includes("​")) current.markerCount += 1;
				statsByTrack.set(event.wpWinPosId, current);
			}
			const tracks = [...statsByTrack.values()];
			if (tracks.length === 0) return null;
			tracks.sort((left, right) => {
				if (right.eventCount !== left.eventCount) return right.eventCount - left.eventCount;
				if (right.markerCount !== left.markerCount) return right.markerCount - left.markerCount;
				if (right.textLength !== left.textLength) return right.textLength - left.textLength;
				return right.trackId - left.trackId;
			});
			return tracks[0].trackId;
		}
		function pushStylizedFragment(result, fragment) {
			const last = result.at(-1);
			if (last && last.end > fragment.start) last.end = fragment.start;
			result.push(fragment);
		}
		function isSameSentenceFamily(current, text, start) {
			if (start - current.lastStart > FAMILY_GAP_MS) return false;
			const nextNormalized = text.toLowerCase();
			if (nextNormalized === current.normalized) return true;
			const shorter = current.normalized.length <= nextNormalized.length ? current.normalized : nextNormalized;
			const longer = current.normalized.length <= nextNormalized.length ? nextNormalized : current.normalized;
			return shorter.length >= MIN_PREFIX_LENGTH && longer.startsWith(shorter);
		}
		function mergeFamilies(inputEvents) {
			const result = [];
			let currentFamily = null;
			for (const event of inputEvents) {
				const text = cleanEventText(getEventText(event));
				if (!text) continue;
				const fragmentEnd = event.tStartMs + (event.dDurationMs ?? 0);
				if (!currentFamily) {
					currentFamily = {
						text,
						normalized: text.toLowerCase(),
						start: event.tStartMs,
						end: fragmentEnd,
						lastStart: event.tStartMs
					};
					continue;
				}
				if (isSameSentenceFamily(currentFamily, text, event.tStartMs)) {
					currentFamily.end = fragmentEnd;
					currentFamily.lastStart = event.tStartMs;
					if (text.length > currentFamily.text.length) {
						currentFamily.text = text;
						currentFamily.normalized = text.toLowerCase();
					}
					continue;
				}
				pushStylizedFragment(result, {
					text: currentFamily.text,
					start: currentFamily.start,
					end: currentFamily.end
				});
				currentFamily = {
					text,
					normalized: text.toLowerCase(),
					start: event.tStartMs,
					end: fragmentEnd,
					lastStart: event.tStartMs
				};
			}
			if (currentFamily) pushStylizedFragment(result, {
				text: currentFamily.text,
				start: currentFamily.start,
				end: currentFamily.end
			});
			return result;
		}
		function overlapsAny(start, end, intervals) {
			return intervals.some((interval) => start < interval.end && end > interval.start);
		}
		const mainTrackId = selectMainTrack();
		if (mainTrackId === null) return [];
		const mainFragments = mergeFamilies(events.filter((event) => event.wpWinPosId === mainTrackId));
		const offFragments = mergeFamilies(events.filter((event) => {
			if (event.wpWinPosId === mainTrackId) return false;
			if (!cleanEventText(getEventText(event))) return false;
			const start = event.tStartMs;
			return !overlapsAny(start, start + (event.dDurationMs ?? 0), mainFragments);
		}));
		const merged = [...mainFragments, ...offFragments].sort((left, right) => left.start - right.start);
		const result = [];
		for (const fragment of merged) pushStylizedFragment(result, { ...fragment });
		return result;
	}
	function parseAnimatedSubtitles(events) {
		const fragments = [];
		for (const event of events) {
			const text = cleanEventText(getEventText(event));
			if (!text) continue;
			const start = event.tStartMs;
			const end = start + (event.dDurationMs ?? 0);
			const last = fragments.at(-1);
			if (last && last.text === text) last.end = end;
			else {
				if (last && last.end > start) last.end = start;
				fragments.push({
					text,
					start,
					end
				});
			}
		}
		return fragments;
	}
	//#endregion
	//#region src/entrypoints/content/youtube/translator.ts
	/**
	* 去除推理模型可能泄漏的 think 标签。
	* 处理完整标签、截断的开标签、截断的闭标签三种情况。
	*
	* 用占位符变量拼接正则，避免在源码中出现反引号 + < 字面量导致
	* 编辑工具和 IDE 解析异常。
	*/
	var THINK_OPEN = String.fromCharCode(60) + "think>";
	var THINK_CLOSE = String.fromCharCode(60) + "/think>";
	var THINK_OPEN_RE = new RegExp(THINK_OPEN.replace(/[<>\/]/g, "\\$&") + "[\\s\\S]*?" + THINK_CLOSE.replace(/[<>\/]/g, "\\$&"), "gi");
	var THINK_OPEN_ONLY_RE = new RegExp(THINK_OPEN.replace(/[<>\/]/g, "\\$&") + "[\\s\\S]*$", "gi");
	function stripThinkingTags(text) {
		let result = text.replace(THINK_OPEN_RE, "");
		result = result.replace(THINK_OPEN_ONLY_RE, "");
		return result.trim();
	}
	/**
	* 去除模型可能包裹的 ```json ... ``` 代码块标记。
	* 处理完整和截断的代码块。
	*/
	function stripMarkdownCodeBlock(text) {
		let result = text.trim();
		result = result.replace(/^```(?:json)?\s*\n?/i, "");
		result = result.replace(/\n?```\s*$/i, "");
		return result.trim();
	}
	/**
	* 修复可能被截断的 JSON（DeepSeek 在 max_tokens 不足时可能输出不完整的 JSON）。
	* 通过括号计数补全缺失的 `"` `]` `}`。
	*/
	function repairTruncatedJson(text) {
		let result = text.trim();
		let braceDepth = 0;
		let bracketDepth = 0;
		let inString = false;
		let escape = false;
		for (let i = 0; i < result.length; i++) {
			const ch = result[i];
			if (escape) {
				escape = false;
				continue;
			}
			if (ch === "\\") {
				escape = true;
				continue;
			}
			if (ch === "\"") {
				inString = !inString;
				continue;
			}
			if (inString) continue;
			if (ch === "{") braceDepth++;
			if (ch === "}") braceDepth--;
			if (ch === "[") bracketDepth++;
			if (ch === "]") bracketDepth--;
		}
		if (inString) result += "\"";
		for (let i = 0; i < bracketDepth; i++) result += "]";
		for (let i = 0; i < braceDepth; i++) result += "}";
		return result;
	}
	var CAPTION_API_URL = "https://api.deepseek.com/v1/chat/completions";
	var CAPTION_MODEL = "deepseek-v4-flash";
	/**
	* 字幕专用简化 system prompt。
	*
	* 比通用 prompt 短 ~80 tokens，针对字幕特点：
	* - 短文本、口语化
	* - 保持时间轴顺序（id 即顺序）
	* - 不需要术语表 / 站点规则
	*/
	var CAPTION_SYSTEM_PROMPT = [
		"Translate English subtitles to Simplified Chinese.",
		"",
		"1. Return {\"translations\":[{\"id\":\"0\",\"translated_text\":\"译文\"}]}. One entry per subtitle, same ids.",
		"2. Translate naturally and concisely. Subtitles are spoken language — use colloquial Chinese.",
		"3. Keep numbers, URLs, and code unchanged.",
		"4. Keep each subtitle short — match the original's brevity."
	].join("\n");
	/**
	* 调用 DeepSeek API 翻译一批字幕。返回 id -> translated_text 的映射。
	*
	* @param apiKey DeepSeek API Key
	* @param blocks 要翻译的字幕块（id + text）
	* @param signal AbortSignal，取消时立即中止 fetch 请求
	*/
	async function translateBatch(apiKey, blocks, signal) {
		if (blocks.length === 0) return /* @__PURE__ */ new Map();
		if (signal?.aborted) return /* @__PURE__ */ new Map();
		const blocksJson = JSON.stringify(blocks, null, 2);
		const estimatedInputTokens = Math.ceil(blocksJson.length / 4);
		const maxTokens = Math.max(2048, estimatedInputTokens * 2);
		const body = {
			model: CAPTION_MODEL,
			messages: [{
				role: "system",
				content: CAPTION_SYSTEM_PROMPT
			}, {
				role: "user",
				content: "JSON:\n\n" + blocksJson
			}],
			response_format: { type: "json_object" },
			temperature: .1,
			max_tokens: maxTokens,
			thinking: { type: "disabled" },
			stream: false
		};
		const response = await fetch(CAPTION_API_URL, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: "Bearer " + apiKey
			},
			body: JSON.stringify(body),
			signal
		});
		if (!response.ok) {
			const text = await response.text().catch(() => "");
			throw new Error("DeepSeek API error: HTTP " + response.status + " - " + text.substring(0, 200));
		}
		const content = (await response.json())?.choices?.[0]?.message?.content;
		if (!content) throw new Error("DeepSeek 返回了无效响应: 缺少 choices[0].message.content");
		let cleaned = stripThinkingTags(content);
		cleaned = stripMarkdownCodeBlock(cleaned);
		try {
			const result = parseTranslations(JSON.parse(cleaned));
			if (result.size === 0) console.warn("[YouTubeCaptions] Parsed 0 translations from", blocks.length, "blocks");
			return result;
		} catch {
			const repaired = repairTruncatedJson(cleaned);
			try {
				return parseTranslations(JSON.parse(repaired));
			} catch {
				console.warn("[YouTubeCaptions] Failed to parse translation:", cleaned.substring(0, 120));
				return /* @__PURE__ */ new Map();
			}
		}
	}
	/**
	* 从 DeepSeek 返回的 JSON 中提取翻译结果。
	*
	* 兼容多种返回格式（防止模型不严格遵守 prompt 指令导致静默失败）：
	*   - {"translations": [{"id":"0","translated_text":"你好"}]}
	*   - {"results": [...]}
	*   - {"data": [...]}
	*   - [{"id":"0","translated_text":"你好"}, ...]  （直接返回数组）
	*
	* 字段名也兼容：
	*   - translated_text / translation / translatedText
	*   - id 可能是 number 或 string
	*/
	function parseTranslations(parsed) {
		let translations = [];
		if (Array.isArray(parsed)) translations = parsed;
		else if (Array.isArray(parsed?.translations)) translations = parsed.translations;
		else if (Array.isArray(parsed?.results)) translations = parsed.results;
		else if (Array.isArray(parsed?.data)) translations = parsed.data;
		const map = /* @__PURE__ */ new Map();
		for (const t of translations) {
			if (t == null || typeof t !== "object") continue;
			const translated = t.translated_text || t.translation || t.translatedText || t.text;
			if (t.id != null && translated != null) map.set(String(t.id), String(translated));
		}
		return map;
	}
	/** 默认 Ahead Buffer 时间窗口（90 秒预取） */
	var DEFAULT_AHEAD_MS = 9e4;
	/**
	* Ahead Buffer 翻译：翻译 [fromMs, fromMs + aheadMs] 时间窗口内的未翻译字幕。
	*
	* 调用方（Manager）应该在 video.timeupdate / 定时轮询时调用此函数：
	*   - 第一次调用：fromMs = 0，翻译 0~90 秒字幕
	*   - 播放到 40 秒：fromMs = 40000，翻译 60~150 秒字幕（已翻译的会跳过）
	*
	* 翻译状态：
	*   - pending -> translating（标记中，避免重复翻译）
	*   - translating -> done（翻译成功） / failed（翻译失败，可重试）
	*
	* 取消机制：
	*   - signal.aborted 时立即返回，不再继续后续批次
	*   - fetch 在 abort 时会抛 AbortError，被 catch 后停止
	*
	* @param captions 全部字幕数组（直接修改 status 和 translatedText）
	* @param fromMs 起始时间（毫秒），通常用 video.currentTime * 1000
	* @param aheadMs 预取时间窗口（毫秒），默认 90 秒
	* @param apiKey DeepSeek API Key
	* @param signal AbortSignal，用于取消
	* @param onProgress 进度回调
	*/
	async function translateAhead(captions, fromMs, aheadMs, apiKey, signal, onProgress) {
		if (captions.length === 0) return;
		const endMs = fromMs + aheadMs;
		const lookbackMs = 5e3;
		const toTranslate = [];
		for (let i = 0; i < captions.length; i++) {
			if (signal?.aborted) return;
			const c = captions[i];
			if (c.status === "done" || c.status === "translating") continue;
			if (c.startMs + c.durationMs < fromMs - lookbackMs) continue;
			if (c.startMs > endMs) break;
			toTranslate.push({
				caption: c,
				globalIdx: i
			});
		}
		if (toTranslate.length === 0) return;
		const total = toTranslate.length;
		let done = 0;
		for (let i = 0; i < toTranslate.length; i += 50) {
			if (signal?.aborted) return;
			const batch = toTranslate.slice(i, i + 50);
			batch.forEach(({ caption }) => {
				caption.status = "translating";
			});
			const blocks = batch.map(({ caption, globalIdx }) => ({
				id: String(globalIdx),
				text: caption.text
			}));
			try {
				const resultMap = await translateBatch(apiKey, blocks, signal);
				for (const { caption, globalIdx } of batch) {
					const id = String(globalIdx);
					const translated = resultMap.get(id);
					if (translated) {
						caption.translatedText = translated;
						caption.status = "done";
					} else caption.status = "failed";
				}
			} catch (e) {
				if (signal?.aborted) {
					batch.forEach(({ caption }) => {
						caption.status = "pending";
					});
					return;
				}
				console.warn("[YouTubeCaptions] Batch failed:", e instanceof Error ? e.message : e);
				batch.forEach(({ caption }) => {
					caption.status = "failed";
				});
			}
			done += batch.length;
			onProgress?.(done, total);
		}
	}
	//#endregion
	//#region src/entrypoints/content/youtube/overlay.ts
	var OVERLAY_ID = "fanyi-caption-overlay";
	var CaptionOverlay = class {
		video = null;
		captions = [];
		overlayEl = null;
		/** 预建的译文容器（start 时创建，update 时只改 textContent） */
		transEl = null;
		timeUpdateHandler = null;
		lastShownIdx = -1;
		/** 上次渲染的译文文本，用于判断是否需要刷新 DOM（解决 Bug 5：翻译完成后 Overlay 不刷新） */
		renderedTranslation = void 0;
		/**
		* 初始化字幕 Overlay。
		*
		* @returns 是否成功找到视频元素并初始化
		*/
		start(captions) {
			this.captions = captions;
			this.video = document.querySelector("video.html5-main-video") || document.querySelector("video");
			if (!this.video) {
				console.log("[YouTubeCaptions] No <video> element found");
				return false;
			}
			this.createOverlay();
			this.timeUpdateHandler = () => this.update();
			this.video.addEventListener("timeupdate", this.timeUpdateHandler);
			this.update();
			return true;
		}
		/**
		* 动态更新字幕数据（Ahead Buffer 翻译新字幕后调用）。
		*
		* 不重新创建 Overlay DOM，只更新内部 captions 引用。
		* 重置 lastShownIdx 和 renderedTranslation 强制下次 update 刷新 DOM。
		*/
		updateCaptions(captions) {
			const translatedCount = captions.filter((c) => c.translatedText).length;
			console.log("[Overlay] updateCaptions called, captions=" + captions.length + ", translated=" + translatedCount);
			this.captions = captions;
			this.lastShownIdx = -1;
			this.renderedTranslation = void 0;
			this.update();
		}
		/** 停止监听并移除 Overlay。 */
		stop() {
			if (this.timeUpdateHandler && this.video) this.video.removeEventListener("timeupdate", this.timeUpdateHandler);
			this.timeUpdateHandler = null;
			this.overlayEl?.remove();
			this.overlayEl = null;
			this.transEl = null;
			this.video = null;
			this.captions = [];
			this.lastShownIdx = -1;
			this.renderedTranslation = void 0;
		}
		/** 是否已翻译完成（至少有一条字幕有 translatedText）。 */
		isReady() {
			return this.captions.length > 0 && this.captions.some((c) => c.translatedText);
		}
		createOverlay() {
			document.getElementById(OVERLAY_ID)?.remove();
			const el = document.createElement("div");
			el.id = OVERLAY_ID;
			el.style.cssText = [
				"position: absolute",
				"bottom: 24px",
				"left: 50%",
				"transform: translateX(-50%)",
				"max-width: 90%",
				"padding: 6px 12px",
				"background: rgba(0, 0, 0, 0.75)",
				"color: #fff",
				"font-size: 16px",
				"line-height: 1.4",
				"text-align: center",
				"border-radius: 4px",
				"pointer-events: none",
				"z-index: 9999",
				"display: none"
			].join("; ");
			const trans = document.createElement("div");
			trans.style.cssText = [
				"font-size: clamp(14px, 1.4vw, 32px)",
				"font-weight: 400",
				"line-height: 1.3",
				"color: #ffffffff",
				"text-shadow: 0 1px 3px rgba(0, 0, 0, 0.9)"
			].join("; ");
			el.appendChild(trans);
			(document.querySelector(".html5-video-player") || document.body).appendChild(el);
			this.overlayEl = el;
			this.transEl = trans;
		}
		update() {
			if (!this.video || !this.overlayEl || !this.transEl) return;
			const currentMs = this.video.currentTime * 1e3;
			let idx = -1;
			if (this.lastShownIdx >= 0 && this.lastShownIdx < this.captions.length) {
				const c = this.captions[this.lastShownIdx];
				if (currentMs >= c.startMs && currentMs < c.startMs + c.durationMs) idx = this.lastShownIdx;
			}
			if (idx < 0) for (let i = 0; i < this.captions.length; i++) {
				const c = this.captions[i];
				if (currentMs >= c.startMs && currentMs < c.startMs + c.durationMs) {
					idx = i;
					break;
				}
			}
			if (idx < 0) {
				this.overlayEl.style.display = "none";
				this.lastShownIdx = -1;
				this.renderedTranslation = void 0;
				return;
			}
			const caption = this.captions[idx];
			if (!(idx !== this.lastShownIdx || caption.translatedText !== this.renderedTranslation)) return;
			this.lastShownIdx = idx;
			this.renderedTranslation = caption.translatedText;
			if (caption.translatedText) {
				this.transEl.textContent = caption.translatedText;
				this.overlayEl.style.display = "block";
				console.log("[Overlay] render idx=" + idx + ", trans=\"" + caption.translatedText.substring(0, 30) + "\"");
			} else {
				this.transEl.textContent = "";
				this.overlayEl.style.display = "none";
			}
		}
	};
	//#endregion
	//#region src/entrypoints/content/youtube/manager.ts
	/** timeupdate 轮询节流间隔（毫秒） */
	var TIMEUPDATE_THROTTLE_MS = 1e3;
	var YouTubeCaptionManager = class YouTubeCaptionManager {
		static _instance = null;
		static getInstance() {
			if (!this._instance) this._instance = new YouTubeCaptionManager();
			return this._instance;
		}
		cache = /* @__PURE__ */ new Map();
		currentVideoId = null;
		captions = [];
		overlay = null;
		video = null;
		abortController = null;
		navigateHandler = null;
		timeUpdateHandler = null;
		lastTranslateTimeMs = 0;
		pumping = false;
		isRunning = false;
		/** 当前是否正在运行，以及运行中的 videoId（供外部检测 SPA 导航是否需要停止） */
		get runningVideoId() {
			return this.isRunning ? this.currentVideoId : null;
		}
		constructor() {
			this.navigateHandler = () => {};
			document.addEventListener("yt-navigate-finish", this.navigateHandler, true);
		}
		/**
		* 启动字幕翻译流程。
		*
		* 如果当前正在运行同一视频，直接返回 true（幂等）。
		* 如果正在运行其他视频，先 stop() 再启动。
		*
		* @returns 是否成功启动
		*/
		async start(apiKey, onStatus) {
			const videoId = extractVideoId();
			if (!videoId) {
				onStatus?.("非 YouTube 视频页", "error");
				return false;
			}
			if (this.isRunning && this.currentVideoId === videoId) return true;
			if (this.isRunning) this.stop();
			this.currentVideoId = videoId;
			this.isRunning = true;
			this.abortController = new AbortController();
			const cached = this.cache.get(videoId);
			if (cached && cached.length > 0) {
				this.captions = cached;
				onStatus?.("已命中字幕缓存", "success");
			} else {
				onStatus?.("正在获取 YouTube 字幕...", "loading");
				try {
					this.captions = await fetchCaptions(videoId);
					if (this.captions.length === 0) {
						onStatus?.("未找到字幕", "error");
						this.isRunning = false;
						this.abortController = null;
						return false;
					}
				} catch (e) {
					const msg = e instanceof Error ? e.message : String(e);
					onStatus?.("字幕获取失败: " + msg, "error");
					console.error("[YouTubeCaptions] fetchCaptions failed:", e);
					this.isRunning = false;
					this.abortController = null;
					return false;
				}
			}
			this.overlay = new CaptionOverlay();
			if (!this.overlay.start(this.captions)) {
				onStatus?.("未找到视频播放器", "error");
				this.isRunning = false;
				this.abortController = null;
				return false;
			}
			this.video = document.querySelector("video.html5-main-video") || document.querySelector("video");
			disableNativeCaptions().then((success) => {
				if (success) console.log("[YouTubeCaptions] Native captions disabled");
			});
			this.timeUpdateHandler = () => {
				this.onTimeUpdate(apiKey, onStatus);
			};
			this.video?.addEventListener("timeupdate", this.timeUpdateHandler);
			this.onTimeUpdate(apiKey, onStatus);
			onStatus?.("字幕翻译已启动", "success");
			return true;
		}
		/**
		* SPA 导航时调用（由外部监听 yt-navigate-finish 触发）。
		*
		* 检查 videoId 是否变化，如果变化则重新启动。
		*/
		async onNavigate(apiKey, onStatus) {
			if (extractVideoId() === this.currentVideoId) return;
			setTimeout(() => {
				this.start(apiKey, onStatus);
			}, 500);
		}
		/** 停止所有任务并清理资源（保留缓存）。 */
		stop() {
			if (this.abortController) {
				this.abortController.abort();
				this.abortController = null;
			}
			if (this.overlay) {
				this.overlay.stop();
				this.overlay = null;
			}
			if (this.timeUpdateHandler && this.video) this.video.removeEventListener("timeupdate", this.timeUpdateHandler);
			this.timeUpdateHandler = null;
			if (this.currentVideoId && this.captions.length > 0) this.cache.set(this.currentVideoId, deepCloneCaptions(this.captions));
			this.currentVideoId = null;
			this.captions = [];
			this.video = null;
			this.lastTranslateTimeMs = 0;
			this.pumping = false;
			this.isRunning = false;
		}
		/** 销毁 Manager（移除 SPA 事件监听）。通常在页面卸载时调用。 */
		destroy() {
			this.stop();
			this.cache.clear();
			if (this.navigateHandler) {
				document.removeEventListener("yt-navigate-finish", this.navigateHandler, true);
				this.navigateHandler = null;
			}
			YouTubeCaptionManager._instance = null;
		}
		/**
		* 视频 timeupdate 回调：节流 + 防止并发 + 触发 Ahead Buffer。
		*/
		async onTimeUpdate(apiKey, onStatus) {
			const signal = this.abortController?.signal;
			if (!signal || signal.aborted) return;
			if (this.pumping) return;
			const now = Date.now();
			if (now - this.lastTranslateTimeMs < TIMEUPDATE_THROTTLE_MS) return;
			this.lastTranslateTimeMs = now;
			const currentMs = this.video ? Math.round(this.video.currentTime * 1e3) : 0;
			this.pumping = true;
			try {
				await translateAhead(this.captions, currentMs, DEFAULT_AHEAD_MS, apiKey, signal);
				this.overlay?.updateCaptions(this.captions);
				const doneCount = this.captions.filter((c) => c.status === "done").length;
				const total = this.captions.length;
				if (doneCount > 0 && doneCount < total) onStatus?.("字幕翻译进度 (" + doneCount + "/" + total + ")", "success");
			} catch (e) {
				if (signal?.aborted) return;
				console.warn("[YouTubeCaptions] translateAhead failed:", e);
			} finally {
				this.pumping = false;
			}
		}
	};
	function deepCloneCaptions(captions) {
		return captions.map((c) => ({ ...c }));
	}
	//#endregion
	//#region src/entrypoints/content/youtube/index.ts
	/**
	* YouTube 字幕翻译模块入口。
	*
	* 当前采用 read-frog 风格的字幕抓取方案：
	*   - MAIN world 注入脚本读取 movie_player.getPlayerResponse()
	*   - 通过 postMessage 与 ISOLATED world 通信
	*   - 用 POT/timedtext 抓取完整字幕时间轴
	*
	* 公共 API：
	*   - isYouTubeWatchPage(url?)            检测是否是 YouTube 视频页
	*   - startYouTubeCaptionTranslation(...) 启动字幕翻译（内部走 Manager 单例）
	*   - stopYouTubeCaptionTranslation()     停止字幕翻译
	*   - onYouTubeNavigate(...)              SPA 导航时调用
	*
	* 内部模块（./youtube/）：
	*   types.ts       共享类型
	*   provider.ts    字幕获取
	*   translator.ts  批量翻译 + AbortSignal + Ahead Buffer
	*   overlay.ts     CaptionOverlay
	*   manager.ts     YouTubeCaptionManager 生命周期 / 缓存 / SPA 导航
	*/
	/**
	* 检测当前页面是否是 YouTube 视频播放页（/watch?v=...）。
	*
	* 用于决定是否启动字幕翻译。YouTube 首页、搜索页、频道页不启动。
	*
	* @param url 可选 URL，默认用 window.location.href（测试时可传入 mock URL）
	*/
	function isYouTubeWatchPage(url = typeof window !== "undefined" ? window.location.href : "") {
		let parsed;
		try {
			parsed = new URL(url);
		} catch {
			return false;
		}
		if (parsed.hostname !== "www.youtube.com") return false;
		return parsed.searchParams.has("v");
	}
	/**
	* 启动 YouTube 字幕翻译完整流程。
	*
	* 内部使用 YouTubeCaptionManager 单例：
	*   - 幂等：同一视频不重复启动
	*   - 切视频：自动清理旧资源（AbortController + Overlay + 监听）
	*   - 抓取完整时间轴后通过 Ahead Buffer 增量翻译
	*
	* @param apiKey DeepSeek API Key
	* @param onStatus 状态回调（用于 UI 显示进度）
	* @returns 是否成功启动
	*/
	async function startYouTubeCaptionTranslation(apiKey, onStatus) {
		return YouTubeCaptionManager.getInstance().start(apiKey, onStatus);
	}
	/**
	* 停止 YouTube 字幕翻译。
	*
	* 取消正在进行的翻译任务，移除 Overlay，清理定时器。
	* 缓存不清空（切回同一视频仍可命中缓存）。
	*/
	function stopYouTubeCaptionTranslation() {
		YouTubeCaptionManager.getInstance().stop();
	}
	//#endregion
	//#region src/entrypoints/content.ts
	/**
	* Content Script 入口
	*
	* 职责（精简后只做"接线"，业务逻辑已拆分到 ./content/*）：
	*   1. 注入样式（getStyles）
	*   2. 创建浮动按钮 + 触屏手势
	*   3. 创建翻译控制器（lazily，首次 translate 动作时实例化）
	*   4. 路由来自 background / popup / keyboard shortcut 的消息
	*   5. 维护"是否已翻译"的小型状态（originalTexts / translatedBlocks / isTranslated）
	*
	* 文件结构（见 ./content/）：
	*   styles.ts        CSS 模板字符串
	*   statusOverlay.ts 状态条 + HTML 转义
	*   floatingButton.ts 浮动按钮 + 触屏手势
	*   configPanel.ts   配置面板（API Key / 语言 / 模式 / 手势）
	*   translation.ts   翻译编排（核心：handleFullTranslation / translateChunkPayload / 动态监听）
	*/
	var isMobile = /Android/i.test(navigator.userAgent) || /iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
	var content_default = defineContentScript({
		matches: ["*://*/*"],
		main() {
			console.log("[ContentScript] Initializing on:", window.location.href, "isMobile:", isMobile);
			const state = {
				originalTexts: /* @__PURE__ */ new Map(),
				translatedBlocks: /* @__PURE__ */ new Set(),
				translatedTexts: /* @__PURE__ */ new Map()
			};
			let translation = null;
			let translatedVideoId = null;
			const style = document.createElement("style");
			style.textContent = getStyles(isMobile);
			(document.head || document.documentElement).appendChild(style);
			const youTubeStatusCallback = (msg, type) => {
				if (type === "error") console.warn("[YouTubeCaptions]", msg);
			};
			document.addEventListener("yt-navigate-finish", () => {
				const newVideoId = extractVideoId();
				if (!isYouTubeWatchPage() || !newVideoId) {
					stopYouTubeCaptionTranslation();
					if (translatedVideoId) {
						translation?.restore();
						translatedVideoId = null;
					}
					return;
				}
				const runningVideoId = YouTubeCaptionManager.getInstance().runningVideoId;
				if (runningVideoId !== null && newVideoId !== runningVideoId || translatedVideoId !== null && newVideoId !== translatedVideoId) {
					stopYouTubeCaptionTranslation();
					translation?.restore();
					translatedVideoId = null;
				}
			}, true);
			import_browser_polyfill.default.runtime.onMessage.addListener((message) => {
				switch (message.action) {
					case "translatePage":
						handleAction("translate");
						return;
					case "restoreOriginal":
						handleAction("restore");
						return;
					case "toggleTranslation":
						handleAction("toggle");
						return;
					case "translationStreamUpdate": return;
				}
			});
			/**
			* 统一处理三种动作（translate / restore / toggle）。
			*
			* translate 用 start()（异步），restore/toggle 同步即可。
			* 第一次调用会懒加载控制器。
			*
			* 注意：YouTube 字幕翻译也需要用户点击翻译按钮才会启动，
			* 与整页翻译保持一致。
			*/
			async function handleAction(action) {
				const ctrl = await ensureController();
				if (action === "translate") {
					await ctrl.start();
					if (isYouTubeWatchPage()) {
						translatedVideoId = extractVideoId();
						const config = await getConfig();
						if (config.deepseekApiKey) startYouTubeCaptionTranslation(config.deepseekApiKey, youTubeStatusCallback);
					}
				} else if (action === "restore") {
					ctrl.restore();
					stopYouTubeCaptionTranslation();
					translatedVideoId = null;
					updateButtonState(false);
				} else ctrl.toggle();
			}
			/** 懒加载控制器。 */
			async function ensureController() {
				if (translation) return translation;
				translation = createTranslationController(isMobile, state);
				return translation;
			}
		}
	});
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/internal/logger.mjs
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger$1 = {
		debug: (...args) => ([...args], void 0),
		log: (...args) => ([...args], void 0),
		warn: (...args) => ([...args], void 0),
		error: (...args) => ([...args], void 0)
	};
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/internal/custom-events.mjs
	var WxtLocationChangeEvent = class WxtLocationChangeEvent extends Event {
		static EVENT_NAME = getUniqueEventName("wxt:locationchange");
		constructor(newUrl, oldUrl) {
			super(WxtLocationChangeEvent.EVENT_NAME, {});
			this.newUrl = newUrl;
			this.oldUrl = oldUrl;
		}
	};
	/**
	* Returns an event name unique to the extension and content script that's
	* running.
	*/
	function getUniqueEventName(eventName) {
		return `${import_browser_polyfill.default?.runtime?.id}:content:${eventName}`;
	}
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/internal/location-watcher.mjs
	var supportsNavigationApi = typeof globalThis.navigation?.addEventListener === "function";
	/**
	* Create a util that watches for URL changes, dispatching the custom event when
	* detected. Stops watching when content script is invalidated. Uses Navigation
	* API when available, otherwise falls back to polling.
	*/
	function createLocationWatcher(ctx) {
		let lastUrl;
		let watching = false;
		return { run() {
			if (watching) return;
			watching = true;
			lastUrl = new URL(location.href);
			if (supportsNavigationApi) globalThis.navigation.addEventListener("navigate", (event) => {
				const newUrl = new URL(event.destination.url);
				if (newUrl.href === lastUrl.href) return;
				window.dispatchEvent(new WxtLocationChangeEvent(newUrl, lastUrl));
				lastUrl = newUrl;
			}, { signal: ctx.signal });
			else ctx.setInterval(() => {
				const newUrl = new URL(location.href);
				if (newUrl.href !== lastUrl.href) {
					window.dispatchEvent(new WxtLocationChangeEvent(newUrl, lastUrl));
					lastUrl = newUrl;
				}
			}, 1e3);
		} };
	}
	//#endregion
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/content-script-context.mjs
	/**
	* Implements
	* [`AbortController`](https://developer.mozilla.org/en-US/docs/Web/API/AbortController).
	* Used to detect and stop content script code when the script is invalidated.
	*
	* It also provides several utilities like `ctx.setTimeout` and
	* `ctx.setInterval` that should be used in content scripts instead of
	* `window.setTimeout` or `window.setInterval`.
	*
	* To create context for testing, you can use the class's constructor:
	*
	* ```ts
	* import { ContentScriptContext } from 'wxt/utils/content-scripts-context';
	*
	* test('storage listener should be removed when context is invalidated', () => {
	*   const ctx = new ContentScriptContext('test');
	*   const item = storage.defineItem('local:count', { defaultValue: 0 });
	*   const watcher = vi.fn();
	*
	*   const unwatch = item.watch(watcher);
	*   ctx.onInvalidated(unwatch); // Listen for invalidate here
	*
	*   await item.setValue(1);
	*   expect(watcher).toBeCalledTimes(1);
	*   expect(watcher).toBeCalledWith(1, 0);
	*
	*   ctx.notifyInvalidated(); // Use this function to invalidate the context
	*   await item.setValue(2);
	*   expect(watcher).toBeCalledTimes(1);
	* });
	* ```
	*/
	var ContentScriptContext = class ContentScriptContext {
		static SCRIPT_STARTED_MESSAGE_TYPE = getUniqueEventName("wxt:content-script-started");
		id;
		abortController;
		locationWatcher = createLocationWatcher(this);
		constructor(contentScriptName, options) {
			this.contentScriptName = contentScriptName;
			this.options = options;
			this.id = Math.random().toString(36).slice(2);
			this.abortController = new AbortController();
			this.stopOldScripts();
			this.listenForNewerScripts();
		}
		get signal() {
			return this.abortController.signal;
		}
		abort(reason) {
			return this.abortController.abort(reason);
		}
		get isInvalid() {
			if (import_browser_polyfill.default.runtime?.id == null) this.notifyInvalidated();
			return this.signal.aborted;
		}
		get isValid() {
			return !this.isInvalid;
		}
		/**
		* Add a listener that is called when the content script's context is
		* invalidated.
		*
		* @example
		*   browser.runtime.onMessage.addListener(cb);
		*   const removeInvalidatedListener = ctx.onInvalidated(() => {
		*     browser.runtime.onMessage.removeListener(cb);
		*   });
		*   // ...
		*   removeInvalidatedListener();
		*
		* @returns A function to remove the listener.
		*/
		onInvalidated(cb) {
			this.signal.addEventListener("abort", cb);
			return () => this.signal.removeEventListener("abort", cb);
		}
		/**
		* Return a promise that never resolves. Useful if you have an async function
		* that shouldn't run after the context is expired.
		*
		* @example
		*   const getValueFromStorage = async () => {
		*     if (ctx.isInvalid) return ctx.block();
		*
		*     // ...
		*   };
		*/
		block() {
			return new Promise(() => {});
		}
		/**
		* Wrapper around `window.setInterval` that automatically clears the interval
		* when invalidated.
		*
		* Intervals can be cleared by calling the normal `clearInterval` function.
		*/
		setInterval(handler, timeout) {
			const id = setInterval(() => {
				if (this.isValid) handler();
			}, timeout);
			this.onInvalidated(() => clearInterval(id));
			return id;
		}
		/**
		* Wrapper around `window.setTimeout` that automatically clears the interval
		* when invalidated.
		*
		* Timeouts can be cleared by calling the normal `setTimeout` function.
		*/
		setTimeout(handler, timeout) {
			const id = setTimeout(() => {
				if (this.isValid) handler();
			}, timeout);
			this.onInvalidated(() => clearTimeout(id));
			return id;
		}
		/**
		* Wrapper around `window.requestAnimationFrame` that automatically cancels
		* the request when invalidated.
		*
		* Callbacks can be canceled by calling the normal `cancelAnimationFrame`
		* function.
		*/
		requestAnimationFrame(callback) {
			const id = requestAnimationFrame((...args) => {
				if (this.isValid) callback(...args);
			});
			this.onInvalidated(() => cancelAnimationFrame(id));
			return id;
		}
		/**
		* Wrapper around `window.requestIdleCallback` that automatically cancels the
		* request when invalidated.
		*
		* Callbacks can be canceled by calling the normal `cancelIdleCallback`
		* function.
		*/
		requestIdleCallback(callback, options) {
			const id = requestIdleCallback((...args) => {
				if (!this.signal.aborted) callback(...args);
			}, options);
			this.onInvalidated(() => cancelIdleCallback(id));
			return id;
		}
		addEventListener(target, type, handler, options) {
			if (type === "wxt:locationchange") {
				if (this.isValid) this.locationWatcher.run();
			}
			target.addEventListener?.(type.startsWith("wxt:") ? getUniqueEventName(type) : type, handler, {
				...options,
				signal: this.signal
			});
		}
		/**
		* @internal
		* Abort the abort controller and execute all `onInvalidated` listeners.
		*/
		notifyInvalidated() {
			this.abort("Content script context invalidated");
			logger$1.debug(`Content script "${this.contentScriptName}" context invalidated`);
		}
		stopOldScripts() {
			document.dispatchEvent(new CustomEvent(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, { detail: {
				contentScriptName: this.contentScriptName,
				messageId: this.id
			} }));
			if (!this.options?.noScriptStartedPostMessage) window.postMessage({
				type: ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE,
				contentScriptName: this.contentScriptName,
				messageId: this.id
			}, "*");
		}
		verifyScriptStartedEvent(event) {
			const isSameContentScript = event.detail?.contentScriptName === this.contentScriptName;
			const isFromSelf = event.detail?.messageId === this.id;
			return isSameContentScript && !isFromSelf;
		}
		listenForNewerScripts() {
			const cb = (event) => {
				if (!(event instanceof CustomEvent) || !this.verifyScriptStartedEvent(event)) return;
				this.notifyInvalidated();
			};
			document.addEventListener(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, cb);
			this.onInvalidated(() => document.removeEventListener(ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE, cb));
		}
	};
	//#endregion
	//#region \0virtual:wxt-content-script-isolated-world-entrypoint?/Users/saga/code-repos/fanyi-extension/src/entrypoints/content.ts
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => ([...args], void 0),
		log: (...args) => ([...args], void 0),
		warn: (...args) => ([...args], void 0),
		error: (...args) => ([...args], void 0)
	};
	//#endregion
	return (async () => {
		try {
			const { main, ...options } = content_default;
			return await main(new ContentScriptContext("content", options));
		} catch (err) {
			logger.error(`The content script "content" crashed on startup!`, err);
			throw err;
		}
	})();
})();

content;