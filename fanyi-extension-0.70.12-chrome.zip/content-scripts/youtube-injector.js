var youtubeInjector = (function() {
	//#region node_modules/.pnpm/wxt@0.20.26_@types+node@25.8.0_jiti@2.7.0_rolldown@1.0.1_tsx@4.22.4/node_modules/wxt/dist/utils/define-content-script.mjs
	function defineContentScript(definition) {
		return definition;
	}
	//#endregion
	//#region src/entrypoints/youtube-injector.content/index.ts
	/**
	* YouTube 页面内注入脚本（MAIN world）。
	*
	* 参考 read-frog 的 interceptor.content 实现：
	*   - 通过 postMessage 与 content script（ISOLATED world）通信
	*   - 直接读取 YouTube 播放器内部 API（movie_player.getPlayerResponse）
	*   - 监听 XMLHttpRequest 抓取 timedtext URL（含 POT token）
	*   - 自动开启字幕（CC）
	*
	* 该脚本在 WXT manifest 中注册为 world: 'MAIN'、runAt: 'document_start'，
	* 因此可以在 YouTube 自己的脚本运行前注入并劫持 XHR。
	*/
	var PLAYER_DATA_REQUEST_TYPE = "FANYI_YT_PLAYER_DATA_REQUEST";
	var PLAYER_DATA_RESPONSE_TYPE = "FANYI_YT_PLAYER_DATA_RESPONSE";
	var WAIT_TIMEDTEXT_REQUEST_TYPE = "FANYI_YT_WAIT_TIMEDTEXT_REQUEST";
	var WAIT_TIMEDTEXT_RESPONSE_TYPE = "FANYI_YT_WAIT_TIMEDTEXT_RESPONSE";
	var ENSURE_SUBTITLES_REQUEST_TYPE = "FANYI_YT_ENSURE_SUBTITLES_REQUEST";
	var ENSURE_SUBTITLES_RESPONSE_TYPE = "FANYI_YT_ENSURE_SUBTITLES_RESPONSE";
	var DISABLE_NATIVE_CAPTIONS_REQUEST_TYPE = "FANYI_YT_DISABLE_NATIVE_CAPTIONS_REQUEST";
	var DISABLE_NATIVE_CAPTIONS_RESPONSE_TYPE = "FANYI_YT_DISABLE_NATIVE_CAPTIONS_RESPONSE";
	var TIMEDTEXT_WAIT_TIMEOUT_MS = 8e3;
	var TIMEDTEXT_API_RE = /api\/timedtext/;
	var youtube_injector_content_default = defineContentScript({
		matches: ["*://*.youtube.com/*", "*://*.youtube-nocookie.com/*"],
		allFrames: true,
		world: "MAIN",
		runAt: "document_start",
		main() {
			injectPlayerApi();
		}
	});
	function injectPlayerApi() {
		if (window.__FANYI_YT_INJECTOR_INJECTED__) return;
		window.__FANYI_YT_INJECTOR_INJECTED__ = true;
		setupTimedtextObserver();
		window.addEventListener("message", handleMessage);
	}
	var timedtextUrlCache = /* @__PURE__ */ new Map();
	var timedtextUrlWaiters = /* @__PURE__ */ new Map();
	function cacheTimedtextUrl(url) {
		if (!TIMEDTEXT_API_RE.test(url)) return;
		try {
			const parsedUrl = new URL(url);
			const videoId = parsedUrl.searchParams.get("v");
			const pot = parsedUrl.searchParams.get("pot");
			if (!videoId || !pot) return;
			timedtextUrlCache.set(videoId, url);
			const waiters = timedtextUrlWaiters.get(videoId);
			if (waiters) {
				waiters.forEach((resolve) => resolve(url));
				timedtextUrlWaiters.delete(videoId);
			}
		} catch {}
	}
	function waitForTimedtextUrl(videoId, timeoutMs) {
		const cached = timedtextUrlCache.get(videoId);
		if (cached) return Promise.resolve(cached);
		return new Promise((resolve) => {
			const waiters = timedtextUrlWaiters.get(videoId) || [];
			waiters.push(resolve);
			timedtextUrlWaiters.set(videoId, waiters);
			setTimeout(() => {
				const currentWaiters = timedtextUrlWaiters.get(videoId);
				if (!currentWaiters) return;
				const index = currentWaiters.indexOf(resolve);
				if (index !== -1) {
					currentWaiters.splice(index, 1);
					resolve(timedtextUrlCache.get(videoId) ?? null);
				}
			}, timeoutMs);
		});
	}
	function getCachedTimedtextUrl(videoId) {
		return timedtextUrlCache.get(videoId) ?? null;
	}
	function setupTimedtextObserver() {
		const originalXhrOpen = XMLHttpRequest.prototype.open;
		const originalXhrSend = XMLHttpRequest.prototype.send;
		XMLHttpRequest.prototype.open = function(method, url, ...args) {
			this._url = url.toString();
			return originalXhrOpen.apply(this, [
				method,
				url,
				...args
			]);
		};
		XMLHttpRequest.prototype.send = function(...args) {
			this.addEventListener("load", function() {
				cacheTimedtextUrl(this.responseURL || this._url);
			});
			return originalXhrSend.apply(this, args);
		};
		const originalFetch = window.fetch;
		window.fetch = async function(...args) {
			const request = args[0];
			const url = typeof request === "string" ? request : request?.url;
			if (typeof url === "string") try {
				const response = await originalFetch.apply(this, args);
				cacheTimedtextUrl(response.url || url);
				return response;
			} catch (e) {
				throw e;
			}
			return originalFetch.apply(this, args);
		};
	}
	function handleMessage(event) {
		if (event.origin !== window.location.origin) return;
		if (!event.data?.type) return;
		if (event.data.type === PLAYER_DATA_REQUEST_TYPE) {
			const request = event.data;
			const response = getPlayerData(request);
			window.postMessage(response, window.location.origin);
		}
		if (event.data.type === WAIT_TIMEDTEXT_REQUEST_TYPE) {
			const { requestId, videoId } = event.data;
			waitForTimedtextUrl(videoId, TIMEDTEXT_WAIT_TIMEOUT_MS).then((url) => {
				window.postMessage({
					type: WAIT_TIMEDTEXT_RESPONSE_TYPE,
					requestId,
					url
				}, window.location.origin);
			});
		}
		if (event.data.type === ENSURE_SUBTITLES_REQUEST_TYPE) {
			const { requestId } = event.data;
			ensureSubtitlesEnabled();
			window.postMessage({
				type: ENSURE_SUBTITLES_RESPONSE_TYPE,
				requestId
			}, window.location.origin);
		}
		if (event.data.type === DISABLE_NATIVE_CAPTIONS_REQUEST_TYPE) {
			const { requestId } = event.data;
			const success = disableNativeCaptions();
			window.postMessage({
				type: DISABLE_NATIVE_CAPTIONS_RESPONSE_TYPE,
				requestId,
				success
			}, window.location.origin);
		}
	}
	function findYoutubePlayer() {
		const shortsActive = document.querySelector("#reel-overlay-container .html5-video-player");
		if (shortsActive) return shortsActive;
		return document.querySelector(".html5-video-player.playing-mode, .html5-video-player.paused-mode") ?? document.querySelector(".html5-video-player");
	}
	function getPlayerData(request) {
		const { requestId, expectedVideoId } = request;
		try {
			const player = findYoutubePlayer();
			if (!player) return errorResponse(requestId, "PLAYER_NOT_FOUND");
			const playerResponse = player.getPlayerResponse?.();
			const videoId = playerResponse?.videoDetails?.videoId;
			const captionTracks = normalizeTracks(playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? []);
			const selectedTrack = getSelectedTrackSnapshot(player, captionTracks);
			if (!videoId || videoId !== expectedVideoId) return errorResponse(requestId, "VIDEO_ID_MISMATCH");
			return {
				type: PLAYER_DATA_RESPONSE_TYPE,
				requestId,
				success: true,
				data: {
					videoId,
					captionTracks,
					audioCaptionTracks: parseAudioTracks(player.getAudioTrack?.()?.captionTracks),
					device: window.ytcfg?.get?.("DEVICE") ?? null,
					cver: player.getWebPlayerContextConfig?.()?.innertubeContextClientVersion ?? null,
					playerState: player.getPlayerState?.() ?? -1,
					selectedTrackLanguageCode: selectedTrack.languageCode,
					selectedTrackVssId: selectedTrack.vssId,
					cachedTimedtextUrl: getCachedTimedtextUrl(videoId)
				}
			};
		} catch (e) {
			return errorResponse(requestId, String(e));
		}
	}
	function errorResponse(requestId, error) {
		return {
			type: PLAYER_DATA_RESPONSE_TYPE,
			requestId,
			success: false,
			error
		};
	}
	function normalizeTracks(tracks) {
		return tracks.map((t) => ({
			...t,
			baseUrl: t.baseUrl?.includes("://") ? t.baseUrl : `${location.origin}${t.baseUrl}`
		}));
	}
	function parseAudioTracks(tracks) {
		return (tracks ?? []).flatMap((t) => {
			try {
				return [{
					url: t.url,
					vssId: t.vssId,
					kind: t.kind,
					languageCode: new URL(t.url).searchParams.get("lang") ?? void 0
				}];
			} catch {
				return [];
			}
		});
	}
	function ensureSubtitlesEnabled() {
		const button = document.querySelector(".ytp-subtitles-button");
		if (!button) return;
		if (button.getAttribute("aria-pressed") === "true") return;
		const player = findYoutubePlayer();
		if (player?.toggleSubtitles) player.toggleSubtitles();
		else button.click();
	}
	function disableNativeCaptions() {
		try {
			const player = findYoutubePlayer();
			if (player?.setOption) {
				player.setOption("captions", "track", {});
				return true;
			}
			const button = document.querySelector(".ytp-subtitles-button");
			if (button && button.getAttribute("aria-pressed") === "true") if (player?.toggleSubtitles) player.toggleSubtitles();
			else button.click();
			return true;
		} catch {
			return false;
		}
	}
	function getSelectedTrackSnapshot(player, captionTracks) {
		const selectedTrack = player.getOption?.("captions", "track");
		const languageCode = selectedTrack?.languageCode ?? null;
		const matchedTrack = matchSelectedTrack(captionTracks, selectedTrack);
		return {
			languageCode,
			vssId: getSelectedTrackVssId(selectedTrack) ?? matchedTrack?.vssId ?? null
		};
	}
	function getSelectedTrackVssId(selectedTrack) {
		const directVssId = selectedTrack?.vssId ?? selectedTrack?.vss_id;
		if (typeof directVssId === "string" && directVssId.length > 0) return directVssId;
		const baseUrl = selectedTrack?.baseUrl;
		if (typeof baseUrl !== "string" || baseUrl.length === 0) return null;
		try {
			const url = new URL(baseUrl, window.location.origin);
			return url.searchParams.get("vssId") ?? url.searchParams.get("vss_id");
		} catch {
			return null;
		}
	}
	function matchSelectedTrack(captionTracks, selectedTrack) {
		const selectedVssId = getSelectedTrackVssId(selectedTrack);
		if (selectedVssId) return captionTracks.find((track) => track.vssId === selectedVssId);
		const selectedLanguageCode = selectedTrack?.languageCode;
		const selectedKind = selectedTrack?.kind ?? selectedTrack?.trackKind ?? null;
		if (typeof selectedLanguageCode !== "string" || selectedLanguageCode.length === 0) return;
		if (typeof selectedKind === "string" && selectedKind.length > 0) {
			const exactKindMatch = captionTracks.find((track) => track.languageCode === selectedLanguageCode && (track.kind ?? null) === selectedKind);
			if (exactKindMatch) return exactKindMatch;
		}
		const sameLanguageTracks = captionTracks.filter((track) => track.languageCode === selectedLanguageCode);
		if (sameLanguageTracks.length === 1) return sameLanguageTracks[0];
	}
	//#endregion
	//#region \0virtual:wxt-content-script-main-world-entrypoint?/Users/saga/code-repos/fanyi-extension/src/entrypoints/youtube-injector.content/index.ts
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => ([...args], void 0),
		log: (...args) => ([...args], void 0),
		warn: (...args) => ([...args], void 0),
		error: (...args) => ([...args], void 0)
	};
	//#endregion
	return (async () => {
		try {
			return await youtube_injector_content_default.main();
		} catch (err) {
			logger.error(`The content script "youtube-injector" crashed on startup!`, err);
			throw err;
		}
	})();
})();

youtubeInjector;